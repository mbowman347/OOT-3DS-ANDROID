#pragma once

#include "oot3d_whole_aot_generated.h"

namespace Oot3dNativeGame::GeneratedWholeAot {

Oot3dWholeAotFlow ExecuteOot3dWholeAotIndirect(
    uint32_t pc, Oot3dWholeAotFrame& frame,
    Oot3dWholeAotContext& context, Oot3dAotArchitecturalState& state);

} // namespace Oot3dNativeGame::GeneratedWholeAot
