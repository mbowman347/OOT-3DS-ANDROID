#include "oot3d_whole_aot_generated_internal.h"
#include "oot3d_native_a32_memory.h"

#include <atomic>

namespace Oot3dNativeGame::GeneratedWholeAot {
namespace a32 = oot3d::recomp::a32;

Oot3dWholeAotFlow Execute_address_taken_0010EB88_0010EB88(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_address_taken_0010ECE4_0010ECE4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_address_taken_0010EE40_0010EE40(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_address_taken_00145C9C_00145C9C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_address_taken_001768F4_001768F4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_address_taken_00213D80_00213D80(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EfcErupc_Update_00226370(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_address_taken_002A0C50_002A0C50(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EffectShieldParticle_Update_002A2424(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EnDodongo_OverrideLimbDraw_002A9680(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BgJyaZurerukabe_Update_00382E14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003f450c_003F450C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_cfg_residue_004A857C_004A857C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_cfg_residue_004A8724_004A8724(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_cfg_residue_004A8CD8_004A8CD8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_cfg_residue_004A8F14_004A8F14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_004aa624_004AA624(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_004aa914_004AA914(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_004aac64_004AAC64(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_004aaf7c_004AAF7C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_cfg_residue_004AEB7C_004AEB7C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_cfg_residue_004AED24_004AED24(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_cfg_residue_004AF2D8_004AF2D8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_cfg_residue_004AF514_004AF514(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_004b0c24_004B0C24(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_004b0f14_004B0F14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_004b1264_004B1264(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_004b157c_004B157C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_cfg_residue_004B517C_004B517C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_cfg_residue_004B5324_004B5324(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_cfg_residue_004B58D8_004B58D8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_cfg_residue_004B5B14_004B5B14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_004b7224_004B7224(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_004b7514_004B7514(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_004b7864_004B7864(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_004b7b7c_004B7B7C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);

Oot3dWholeAotFlow Execute_address_taken_0010EB88_0010EB88(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0010EB88U:
        goto block_0010EB88;
    case 0x0010EBA4U:
        goto block_0010EBA4;
    case 0x0010EBB8U:
        goto block_0010EBB8;
    case 0x0010EBCCU:
        goto block_0010EBCC;
    case 0x0010EBE0U:
        goto block_0010EBE0;
    case 0x0010EBF4U:
        goto block_0010EBF4;
    case 0x0010EC44U:
        goto block_0010EC44;
    case 0x0010EC58U:
        goto block_0010EC58;
    case 0x0010EC6CU:
        goto block_0010EC6C;
    case 0x0010EC70U:
        goto block_0010EC70;
    case 0x0010EC94U:
        goto block_0010EC94;
    case 0x0010ECA4U:
        goto block_0010ECA4;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0010EB88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EB88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EB88U);
        }
        {
            const uint32_t address = r0 + 248U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EB88U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0010EB94U + 0x11CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EB8CU, address);
            }
            r2 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x0010EB9CU + 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EB94U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            frame.Guest.vfp[1] = frame.Guest.vfp[3];
        }
        if ((flags.N()) != (flags.V())) { goto block_0010EBCC; }
        goto block_0010EBA4;
    }
block_0010EBA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EBA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EBA4U);
        }
        {
            const uint32_t updatedAddress = 0x0010EBACU + 0x10CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EBA4U, address);
            }
            r2 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = 0x0010EBB8U + 260U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EBB0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0010EBCC; }
        goto block_0010EBB8;
    }
block_0010EBB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EBB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EBB8U);
        }
        {
            const uint32_t address = 0x0010EBC0U + 256U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EBB8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0010EBC4U + 256U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EBBCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EBC0U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[3];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EBC8U, 0xEE400A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        goto block_0010EBCC;
    }
block_0010EBCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EBCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EBCCU);
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 444U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EBD0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0xA6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EBD4U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0010EC70; }
        goto block_0010EBE0;
    }
block_0010EBE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EBE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EBE0U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r2 = r2 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r2, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        {
            const uint32_t updatedAddress = r1 + 0xA6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0010EBECU, address);
            }
        }
        if (!(flags.C())) { goto block_0010EC70; }
        goto block_0010EBF4;
    }
block_0010EBF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EBF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EBF4U);
        }
        {
            const uint32_t operand = 0x00000008U;
            r3 = r2 - operand;
        }
        {
            frame.Guest.vfp[2] = r3;
        }
        {
            const uint32_t address = 0x0010EC04U + 196U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EBFCU, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000010U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EC04U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EC08U, 0xEE211A02U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0010EC14U + 184U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EC0CU, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EC10U, 0xEE211A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EC14U, 0xEE321A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[4], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EC18U, 0xEE411A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0010EC24U + 172U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EC1CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EC20U, 0xEEFD0AE1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0010EC2CU + 168U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EC24U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            r12 = frame.Guest.vfp[1];
        }
        {
            const uint32_t updatedAddress = r1 + 0xA4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0010EC2CU, address);
            }
        }
        {
            const uint32_t address = r0 + 440U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EC30U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EC34U, 0xEE311A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EC38U, 0xEE410A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 440U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0010EC3CU, address);
            }
        }
        if (flags.C()) { goto block_0010EC58; }
        goto block_0010EC44;
    }
block_0010EC44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EC44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EC44U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 3U);
            r3 = operand - r3;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0010EC50U, address);
            }
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0010EC70; }
        goto block_0010EC58;
    }
block_0010EC58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EC58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EC58U);
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x3F800000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t address = 0x0010EC68U + 112U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EC60U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if ((flags.N()) != (flags.V())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EC64U, 0xBE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t address = r0 + 444U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0010EC68U, address);
            }
        }
        goto block_0010EC6C;
    }
block_0010EC6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EC6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EC6CU);
        }
        return Oot3dAotReturned(r14);
    }
block_0010EC70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EC70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EC70U);
        }
        {
            const uint32_t address = 0x0010EC78U + 100U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EC70U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EC74U, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = 0x0010EC84U + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EC7CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EC80U, 0xCE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = r0 + 444U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0010EC84U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0xA6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EC88U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000008U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0010EC6C; }
        goto block_0010EC94;
    }
block_0010EC94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EC94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EC94U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r0 + 0x1A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0010EC9CU, address);
            }
        }
        if (!(flags.Z())) { goto block_0010EC6C; }
        goto block_0010ECA4;
    }
block_0010ECA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010ECA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010ECA4U);
        }
        {
            r2 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r1 + 0xA6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0010ECA8U, address);
            }
        }
        return Oot3dAotBranch(0x00374428U);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_address_taken_0010ECE4_0010ECE4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0010ECE4U:
        goto block_0010ECE4;
    case 0x0010ED00U:
        goto block_0010ED00;
    case 0x0010ED14U:
        goto block_0010ED14;
    case 0x0010ED28U:
        goto block_0010ED28;
    case 0x0010ED3CU:
        goto block_0010ED3C;
    case 0x0010ED50U:
        goto block_0010ED50;
    case 0x0010EDA0U:
        goto block_0010EDA0;
    case 0x0010EDB4U:
        goto block_0010EDB4;
    case 0x0010EDC8U:
        goto block_0010EDC8;
    case 0x0010EDCCU:
        goto block_0010EDCC;
    case 0x0010EDF0U:
        goto block_0010EDF0;
    case 0x0010EE00U:
        goto block_0010EE00;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0010ECE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010ECE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010ECE4U);
        }
        {
            const uint32_t address = r0 + 248U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010ECE4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0010ECF0U + 0x11CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010ECE8U, address);
            }
            r2 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x0010ECF8U + 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010ECF0U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            frame.Guest.vfp[1] = frame.Guest.vfp[3];
        }
        if ((flags.N()) != (flags.V())) { goto block_0010ED28; }
        goto block_0010ED00;
    }
block_0010ED00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010ED00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010ED00U);
        }
        {
            const uint32_t updatedAddress = 0x0010ED08U + 0x10CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010ED00U, address);
            }
            r2 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = 0x0010ED14U + 260U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010ED0CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0010ED28; }
        goto block_0010ED14;
    }
block_0010ED14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010ED14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010ED14U);
        }
        {
            const uint32_t address = 0x0010ED1CU + 256U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010ED14U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0010ED20U + 256U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010ED18U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010ED1CU, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[3];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010ED24U, 0xEE400A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        goto block_0010ED28;
    }
block_0010ED28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010ED28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010ED28U);
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 436U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010ED2CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010ED30U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0010EDCC; }
        goto block_0010ED3C;
    }
block_0010ED3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010ED3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010ED3CU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r2 = r2 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r2, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        {
            const uint32_t updatedAddress = r1 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0010ED48U, address);
            }
        }
        if (!(flags.C())) { goto block_0010EDCC; }
        goto block_0010ED50;
    }
block_0010ED50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010ED50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010ED50U);
        }
        {
            const uint32_t operand = 0x00000008U;
            r3 = r2 - operand;
        }
        {
            frame.Guest.vfp[2] = r3;
        }
        {
            const uint32_t address = 0x0010ED60U + 196U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010ED58U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000010U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010ED60U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010ED64U, 0xEE211A02U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0010ED70U + 184U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010ED68U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010ED6CU, 0xEE211A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010ED70U, 0xEE321A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[4], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010ED74U, 0xEE411A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0010ED80U + 172U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010ED78U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010ED7CU, 0xEEFD0AE1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0010ED88U + 168U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010ED80U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            r12 = frame.Guest.vfp[1];
        }
        {
            const uint32_t updatedAddress = r1 + 0xBCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0010ED88U, address);
            }
        }
        {
            const uint32_t address = r0 + 432U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010ED8CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010ED90U, 0xEE311A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010ED94U, 0xEE410A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 432U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0010ED98U, address);
            }
        }
        if (flags.C()) { goto block_0010EDB4; }
        goto block_0010EDA0;
    }
block_0010EDA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EDA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EDA0U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 3U);
            r3 = operand - r3;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1C0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0010EDACU, address);
            }
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0010EDCC; }
        goto block_0010EDB4;
    }
block_0010EDB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EDB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EDB4U);
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x3F800000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t address = 0x0010EDC4U + 112U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EDBCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if ((flags.N()) != (flags.V())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EDC0U, 0xBE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t address = r0 + 436U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0010EDC4U, address);
            }
        }
        goto block_0010EDC8;
    }
block_0010EDC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EDC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EDC8U);
        }
        return Oot3dAotReturned(r14);
    }
block_0010EDCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EDCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EDCCU);
        }
        {
            const uint32_t address = 0x0010EDD4U + 100U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EDCCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EDD0U, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = 0x0010EDE0U + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EDD8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EDDCU, 0xCE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = r0 + 436U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0010EDE0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EDE4U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000008U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0010EDC8; }
        goto block_0010EDF0;
    }
block_0010EDF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EDF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EDF0U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r0 + 0x1C0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0010EDF8U, address);
            }
        }
        if (!(flags.Z())) { goto block_0010EDC8; }
        goto block_0010EE00;
    }
block_0010EE00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EE00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EE00U);
        }
        {
            r2 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r1 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0010EE04U, address);
            }
        }
        return Oot3dAotBranch(0x00374428U);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_address_taken_0010EE40_0010EE40(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0010EE40U:
        goto block_0010EE40;
    case 0x0010EE5CU:
        goto block_0010EE5C;
    case 0x0010EE70U:
        goto block_0010EE70;
    case 0x0010EE84U:
        goto block_0010EE84;
    case 0x0010EE98U:
        goto block_0010EE98;
    case 0x0010EEACU:
        goto block_0010EEAC;
    case 0x0010EEFCU:
        goto block_0010EEFC;
    case 0x0010EF10U:
        goto block_0010EF10;
    case 0x0010EF24U:
        goto block_0010EF24;
    case 0x0010EF28U:
        goto block_0010EF28;
    case 0x0010EF4CU:
        goto block_0010EF4C;
    case 0x0010EF5CU:
        goto block_0010EF5C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0010EE40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EE40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EE40U);
        }
        {
            const uint32_t address = r0 + 248U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EE40U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0010EE4CU + 0x11CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EE44U, address);
            }
            r2 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x0010EE54U + 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EE4CU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            frame.Guest.vfp[1] = frame.Guest.vfp[3];
        }
        if ((flags.N()) != (flags.V())) { goto block_0010EE84; }
        goto block_0010EE5C;
    }
block_0010EE5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EE5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EE5CU);
        }
        {
            const uint32_t updatedAddress = 0x0010EE64U + 0x10CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EE5CU, address);
            }
            r2 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = 0x0010EE70U + 260U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EE68U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0010EE84; }
        goto block_0010EE70;
    }
block_0010EE70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EE70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EE70U);
        }
        {
            const uint32_t address = 0x0010EE78U + 256U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EE70U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0010EE7CU + 256U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EE74U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EE78U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[3];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EE80U, 0xEE400A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        goto block_0010EE84;
    }
block_0010EE84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EE84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EE84U);
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 444U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EE88U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0xA6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EE8CU, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0010EF28; }
        goto block_0010EE98;
    }
block_0010EE98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EE98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EE98U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r2 = r2 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r2, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        {
            const uint32_t updatedAddress = r1 + 0xA6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0010EEA4U, address);
            }
        }
        if (!(flags.C())) { goto block_0010EF28; }
        goto block_0010EEAC;
    }
block_0010EEAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EEACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EEACU);
        }
        {
            const uint32_t operand = 0x00000008U;
            r3 = r2 - operand;
        }
        {
            frame.Guest.vfp[2] = r3;
        }
        {
            const uint32_t address = 0x0010EEBCU + 196U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EEB4U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000010U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EEBCU, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EEC0U, 0xEE211A02U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0010EECCU + 184U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EEC4U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EEC8U, 0xEE211A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EECCU, 0xEE321A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[4], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EED0U, 0xEE411A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0010EEDCU + 172U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EED4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EED8U, 0xEEFD0AE1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0010EEE4U + 168U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EEDCU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            r12 = frame.Guest.vfp[1];
        }
        {
            const uint32_t updatedAddress = r1 + 0xA4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x0010EEE4U, address);
            }
        }
        {
            const uint32_t address = r0 + 440U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EEE8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EEECU, 0xEE311A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EEF0U, 0xEE410A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 440U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0010EEF4U, address);
            }
        }
        if (flags.C()) { goto block_0010EF10; }
        goto block_0010EEFC;
    }
block_0010EEFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EEFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EEFCU);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 3U);
            r3 = operand - r3;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 2U);
            r3 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0010EF08U, address);
            }
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0010EF28; }
        goto block_0010EF10;
    }
block_0010EF10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EF10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EF10U);
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x3F800000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t address = 0x0010EF20U + 112U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EF18U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if ((flags.N()) != (flags.V())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EF1CU, 0xBE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t address = r0 + 444U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0010EF20U, address);
            }
        }
        goto block_0010EF24;
    }
block_0010EF24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EF24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EF24U);
        }
        return Oot3dAotReturned(r14);
    }
block_0010EF28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EF28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EF28U);
        }
        {
            const uint32_t address = 0x0010EF30U + 100U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EF28U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EF2CU, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = 0x0010EF3CU + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EF34U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0010EF38U, 0xCE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = r0 + 444U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0010EF3CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0xA6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0010EF40U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000008U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0010EF24; }
        goto block_0010EF4C;
    }
block_0010EF4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EF4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EF4CU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r0 + 0x1A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0010EF54U, address);
            }
        }
        if (!(flags.Z())) { goto block_0010EF24; }
        goto block_0010EF5C;
    }
block_0010EF5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0010EF5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0010EF5CU);
        }
        {
            r2 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r1 + 0xA6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0010EF60U, address);
            }
        }
        return Oot3dAotBranch(0x00374428U);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_address_taken_00145C9C_00145C9C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00145C9CU:
        goto block_00145C9C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00145C9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00145C9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00145C9CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000014U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r0 = 0x00000000U;
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_address_taken_001768F4_001768F4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x001768F4U:
        goto block_001768F4;
    case 0x00176924U:
        goto block_00176924;
    case 0x0017694CU:
        goto block_0017694C;
    case 0x00176958U:
        goto block_00176958;
    case 0x00176968U:
        goto block_00176968;
    case 0x00176988U:
        goto block_00176988;
    case 0x0017699CU:
        goto block_0017699C;
    case 0x001769A8U:
        goto block_001769A8;
    case 0x001769CCU:
        goto block_001769CC;
    case 0x001769D8U:
        goto block_001769D8;
    case 0x001769E0U:
        goto block_001769E0;
    case 0x001769ECU:
        goto block_001769EC;
    case 0x00176A0CU:
        goto block_00176A0C;
    case 0x00176A30U:
        goto block_00176A30;
    case 0x00176A34U:
        goto block_00176A34;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_001768F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001768F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001768F4U);
        }
        {
            const uint32_t updatedAddress = 0x001768FCU + 0x13CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001768F4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x00176900U + 316U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001768F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x124U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001768FCU, address);
            }
            r3 = value;
        }
        {
            r2 = r0;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00176904U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00176910U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00176918U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017691CU, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        if (flags.Z()) { goto block_001769CC; }
        goto block_00176924;
    }
block_00176924:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00176924U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00176924U);
        }
        {
            const uint32_t address = r3 + 100U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00176924U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x00176930U + 272U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00176928U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r2 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017692CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00176930U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & 0x000000FFU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t address = r2 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017693CU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        if (!(flags.Z())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00176940U, 0x1E401A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        if (!(flags.Z())) {
            const uint32_t address = r2 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x00176944U, address);
            }
        }
        if (!(flags.Z())) { goto block_00176958; }
        goto block_0017694C;
    }
block_0017694C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017694CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017694CU);
        }
        {
            const uint32_t address = r3 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017694CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00176950U, 0xEE300A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00176954U, address);
            }
        }
        goto block_00176958;
    }
block_00176958:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00176958U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00176958U);
        }
        {
            const uint32_t updatedAddress = r2 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00176958U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & 0x000000FFU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0017699C; }
        goto block_00176968;
    }
block_00176968:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00176968U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00176968U);
        }
        {
            const uint32_t address = r2 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00176968U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r3 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017696CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x00176978U + 204U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00176970U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00176974U, 0xEE700AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00176978U, 0xEEF40AE1U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[3],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = r2 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00176980U, address);
            }
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0017699C; }
        goto block_00176988;
    }
block_00176988:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00176988U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00176988U);
        }
        {
            const uint32_t updatedAddress = 0x00176990U + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00176988U, address);
            }
            r12 = value;
        }
        {
            r1 = frame.Guest.vfp[1];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r12, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00176994U, 0x8E300A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        if ((flags.C()) && !(flags.Z())) {
            const uint32_t address = r2 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00176998U, address);
            }
        }
        goto block_0017699C;
    }
block_0017699C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017699CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017699CU);
        }
        {
            const uint32_t updatedAddress = r2 + 0x128U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017699CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001769CC; }
        goto block_001769A8;
    }
block_001769A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001769A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001769A8U);
        }
        {
            const uint32_t address = r1 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001769A8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r2 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001769ACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001769B0U, 0xEEF40AC0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[0],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            frame.Guest.vfp[0] = frame.Guest.vfp[1];
        }
        {
            const uint32_t address = r1 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001769BCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x128U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001769C0U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001769A8; }
        goto block_001769CC;
    }
block_001769CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001769CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001769CCU);
        }
        {
            const uint32_t updatedAddress = r3 + 0x298U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001769CCU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001769EC; }
        goto block_001769D8;
    }
block_001769D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001769D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001769D8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00176A34; }
        goto block_001769E0;
    }
block_001769E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001769E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001769E0U);
        }
        {
            const uint32_t updatedAddress = r3 + 0x29CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001769E0U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_00176A34; }
        goto block_001769EC;
    }
block_001769EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001769ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001769ECU);
        }
        {
            const uint32_t updatedAddress = r2 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001769ECU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x001769F8U + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001769F0U, address);
            }
            r3 = value;
        }
        {
            r1 = r1 & 0x000000FFU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r1 = 0x00000003U;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x298U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00176A00U, address);
            }
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r3 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00176A04U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) { goto block_00176A30; }
        goto block_00176A0C;
    }
block_00176A0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00176A0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00176A0CU);
        }
        {
            const uint32_t updatedAddress = 0x00176A14U + 0x3CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00176A0CU, address);
            }
            r12 = value;
        }
        {
            const uint32_t address = r2 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00176A10U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r1 = r12 + operand;
        }
        {
            const uint32_t address = r1 - 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00176A18U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r1 = 0x00000004U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00176A20U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00176A24U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x298U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00176A28U, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00176A2CU, address);
            }
            r1 = value;
        }
        goto block_00176A30;
    }
block_00176A30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00176A30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00176A30U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x294U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00176A30U, address);
            }
        }
        goto block_00176A34;
    }
block_00176A34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00176A34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00176A34U);
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_address_taken_00213D80_00213D80(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00213D80U:
        goto block_00213D80;
    case 0x00213D88U:
        goto block_00213D88;
    case 0x00213DD4U:
        goto block_00213DD4;
    case 0x00213DE4U:
        goto block_00213DE4;
    case 0x00213DF4U:
        goto block_00213DF4;
    case 0x00213DFCU:
        goto block_00213DFC;
    case 0x00213E7CU:
        goto block_00213E7C;
    case 0x00213E80U:
        goto block_00213E80;
    case 0x00213ECCU:
        goto block_00213ECC;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00213D80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00213D80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00213D80U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00213ECC; }
        goto block_00213D88;
    }
block_00213D88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00213D88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00213D88U);
        }
        {
            const uint32_t address = r1 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00213D88U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r2 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00213D8CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213D90U, 0xEE702A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r1 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00213D94U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r2 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00213D98U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213D9CU, 0xEE301A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r1 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00213DA0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r2 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00213DA4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00213DA8U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213DACU, 0xEE701A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213DB0U, 0xEE620AA2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[5], frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r2;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213DB8U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213DBCU, 0xEE410A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213DC0U, 0xEE202A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213DC4U, 0xEE410AA1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[3], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213DC8U, 0xEEB42AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[4], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00213ECC; }
        goto block_00213DD4;
    }
block_00213DD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00213DD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00213DD4U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00213DD4U, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000007U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) {
            r2 = 0x00000000U;
        }
        if (flags.C()) { goto block_00213DF4; }
        goto block_00213DE4;
    }
block_00213DE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00213DE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00213DE4U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 4U);
            r2 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000010U;
            r2 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00213DF0U, address);
            }
        }
        goto block_00213DF4;
    }
block_00213DF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00213DF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00213DF4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00213ECC; }
        goto block_00213DFC;
    }
block_00213DFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00213DFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00213DFCU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213DFCU, 0xEEB12AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x00213E08U + 200U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00213E00U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0xCU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00213E04U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213E08U, 0xEE820A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[4], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213E0CU, 0xEE400A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213E14U, 0xEEB80A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213E18U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213E1CU, 0xEEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00213E24U, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00213E28U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0xDU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00213E2CU, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213E34U, 0xEEB80A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213E38U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213E3CU, 0xEEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r2 + 0x5U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00213E44U, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00213E48U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0xEU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00213E4CU, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213E54U, 0xEEB80A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213E58U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213E5CU, 0xEEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x00213E6CU + 104U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00213E64U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00213E68U, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00213E6CU, address);
            }
        }
        {
            r0 = frame.Guest.vfp[4];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3F800000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_00213E80; }
        goto block_00213E7C;
    }
block_00213E7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00213E7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00213E7CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213E7CU, 0xEE800A02U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[0], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        goto block_00213E80;
    }
block_00213E80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00213E80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00213E80U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213E80U, 0xEE222A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[5], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213E84U, 0xEE211A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213E88U, 0xEE210A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[3], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213E8CU, 0xEEBD2AC2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213E90U, 0xEEBD1AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213E94U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[4];
        }
        {
            const uint32_t updatedAddress = r2 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00213E9CU, address);
            }
        }
        {
            r0 = frame.Guest.vfp[2];
        }
        {
            const uint32_t updatedAddress = r2 + 0x9U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00213EA4U, address);
            }
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x00213EB4U + 36U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00213EACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0xAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00213EB0U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213EB4U, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00213EB8U, 0xEEBC0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r2 + 0x3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00213EC0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x12U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00213EC4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x7U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00213EC8U, address);
            }
        }
        goto block_00213ECC;
    }
block_00213ECC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00213ECCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00213ECCU);
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_EfcErupc_Update_00226370(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00226370U:
        goto block_00226370;
    case 0x0022638CU:
        goto block_0022638C;
    case 0x002263C4U:
        goto block_002263C4;
    case 0x002263D0U:
        goto block_002263D0;
    case 0x0022649CU:
        goto block_0022649C;
    case 0x002264C8U:
        goto block_002264C8;
    case 0x002264E8U:
        goto block_002264E8;
    case 0x00226558U:
        goto block_00226558;
    case 0x0022656CU:
        goto block_0022656C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00226370:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00226370U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00226370U);
        }
        {
            const uint32_t firstAddress = r13 - 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00226370U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00226370U,
                                           firstAddress + 4U);
            }
            r13 = r13 - 8U;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000010U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00226380U, address);
            }
            r2 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x0022638CU;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0022638CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0022638C;
    }
block_0022638C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022638CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022638CU);
        }
        {
            const uint32_t updatedAddress = 0x00226394U + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022638CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x000001B4U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r14 = r13 + operand;
        }
        {
            const uint32_t address = 0x002263A0U + 472U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00226398U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0022639CU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0022639CU,
                                           firstAddress + 4U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0022639CU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r4 = value4;
        }
        {
            const uint32_t updatedAddress = 0x002263A8U + 0x1D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002263A0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x002263ACU + 468U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002263A4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t firstAddress = r14;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x002263A8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x002263A8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r4)) {
                return Oot3dAotMemoryFault(context, 0x002263A8U,
                                           firstAddress + 8U);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002263B0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x002263BCU + 456U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002263B4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x002263C0U + 456U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002263B8U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            r12 = r2;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        goto block_002263C4;
    }
block_002263C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002263C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002263C4U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x34U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002263C4U, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00226558; }
        goto block_002263D0;
    }
block_002263D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002263D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002263D0U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x35U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002263D0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r3 = r3 + operand;
        }
        {
            r3 = r3 & 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r0 + 0x35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002263DCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002263E0U, address);
            }
            r4 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r0 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002263E4U, address);
            }
            frame.Guest.vfp[5] = value;
        }
        {
            const uint32_t address = r0 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002263E8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[6] = r4;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002263F4U, 0xEEB83AC3U};
            Oot3dAotCommitVfp(frame.Guest.vfp[6], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[6], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002263F8U, 0xEE233A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[6], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[6], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002263FCU, 0xEE402A83U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[5], frame.Guest.vfp[1], frame.Guest.vfp[6], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[5])) {
                return Oot3dAotMemoryFault(context, 0x00226400U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00226404U, address);
            }
            r4 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r0 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00226408U, address);
            }
            frame.Guest.vfp[6] = value;
        }
        {
            const uint32_t address = r0 + 32U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022640CU, address);
            }
            frame.Guest.vfp[5] = value;
        }
        {
            frame.Guest.vfp[7] = r4;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00226414U, 0xEEF83AE3U};
            Oot3dAotCommitVfp(frame.Guest.vfp[7], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[7], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00226418U, 0xEE633A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[7], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[7], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022641CU, 0xEE023AA3U};
            Oot3dAotCommitVfp(frame.Guest.vfp[6], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[6], frame.Guest.vfp[5], frame.Guest.vfp[7], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[6])) {
                return Oot3dAotMemoryFault(context, 0x00226420U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00226424U, address);
            }
            r4 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r0 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00226428U, address);
            }
            frame.Guest.vfp[7] = value;
        }
        {
            const uint32_t address = r0 + 36U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022642CU, address);
            }
            frame.Guest.vfp[6] = value;
        }
        {
            frame.Guest.vfp[8] = r4;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00226434U, 0xEEB84AC4U};
            Oot3dAotCommitVfp(frame.Guest.vfp[8], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[8], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00226438U, 0xEE244A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[8], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[8], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022643CU, 0xEE433A04U};
            Oot3dAotCommitVfp(frame.Guest.vfp[7], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[7], frame.Guest.vfp[6], frame.Guest.vfp[8], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[7])) {
                return Oot3dAotMemoryFault(context, 0x00226440U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00226444U, address);
            }
            r4 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r0 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00226448U, address);
            }
            frame.Guest.vfp[7] = value;
        }
        {
            frame.Guest.vfp[8] = r4;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00226450U, 0xEEB84AC4U};
            Oot3dAotCommitVfp(frame.Guest.vfp[8], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[8], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00226454U, 0xEE244A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[8], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[8], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00226458U, 0xEE430A84U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[7], frame.Guest.vfp[8], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0022645CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00226460U, address);
            }
            r4 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r0 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00226464U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[7] = r4;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022646CU, 0xEEF83AE3U};
            Oot3dAotCommitVfp(frame.Guest.vfp[7], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[7], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00226470U, 0xEE633A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[7], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[7], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00226474U, 0xEE402AA3U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[5], frame.Guest.vfp[1], frame.Guest.vfp[7], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[5])) {
                return Oot3dAotMemoryFault(context, 0x00226478U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022647CU, address);
            }
            r4 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r0 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00226480U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[5] = r4;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00226488U, 0xEEF82AE2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022648CU, 0xEE622A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[5], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00226490U, 0xEE003AA2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[6], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[6], frame.Guest.vfp[1], frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[6])) {
                return Oot3dAotMemoryFault(context, 0x00226494U, address);
            }
        }
        if (flags.Z()) { goto block_002264C8; }
        goto block_0022649C;
    }
block_0022649C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022649CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022649CU);
        }
        {
            frame.Guest.vfp[1] = r3;
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002264A0U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[5] = r3;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002264A8U, 0xEEF80A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromUnsigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002264ACU, 0xEEF82AE2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002264B0U, 0xEE602AA2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[2];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002264B8U, 0xEE420A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[5], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002264BCU, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r3 = frame.Guest.vfp[1];
        }
        goto block_002264E8;
    }
block_002264C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002264C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002264C8U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002264C8U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r3;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002264D0U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002264D4U, 0xEE612AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[3], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[2];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002264DCU, 0xEE520A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32NegativeMultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[5], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002264E0U, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r3 = frame.Guest.vfp[1];
        }
        goto block_002264E8;
    }
block_002264E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002264E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002264E8U);
        }
        {
            r4 = Oot3dAotAsr(r3, 31U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 30U);
            r4 = r3 + operand;
        }
        {
            r4 = r4 & ~(0x00000003U);
        }
        {
            const uint32_t operand = r4;
            r3 = r3 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r3, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r3 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r3 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r14 + r3;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00226500U, address);
            }
            r4 = value;
        }
        {
            const uint32_t operand = r14;
            r3 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00226508U, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022650CU, address);
            }
            r4 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x3DU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00226510U, address);
            }
        }
        {
            const uint32_t updatedAddress = r3 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00226514U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x3EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00226518U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0022651CU, address);
            }
            r4 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0x36U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00226520U, address);
            }
            r3 = value;
        }
        {
            frame.Guest.vfp[1] = r4;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00226528U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0022652CU, 0xEE602A82U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[2];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00226534U, 0xEE420A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[5], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00226538U, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r4 = frame.Guest.vfp[1];
        }
        {
            const uint32_t operand = r4;
            r3 = r3 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r3, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            const uint32_t updatedAddress = r0 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0022654CU, address);
            }
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t updatedAddress = r0 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x00226550U, address);
            }
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t updatedAddress = r0 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x00226554U, address);
            }
        }
        goto block_00226558;
    }
block_00226558:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00226558U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00226558U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r2, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000064U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_002263C4; }
        goto block_0022656C;
    }
block_0022656C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0022656CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0022656CU);
        }
        {
            const uint32_t operand = 0x00000010U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00226570U,
                                           firstAddress + 0U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00226570U,
                                           firstAddress + 4U);
            }
            r4 = value4;
            r13 = r13 + 8U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_address_taken_002A0C50_002A0C50(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x002A0C50U:
        goto block_002A0C50;
    case 0x002A0C80U:
        goto block_002A0C80;
    case 0x002A0CA4U:
        goto block_002A0CA4;
    case 0x002A0CF8U:
        goto block_002A0CF8;
    case 0x002A0D48U:
        goto block_002A0D48;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_002A0C50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A0C50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A0C50U);
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1A4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x002A0C54U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x1A8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x002A0C58U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x002A0C64U + 0x138U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0C5CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0C60U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000054U;
            r1 = r0 + operand;
        }
        {
            const uint32_t address = 0x002A0C70U + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0C68U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0C6CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x002A0C78U + 296U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0C70U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000008U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x00001400U;
            r0 = r0 + operand;
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x002A0C84U + Oot3dAotLsl(r3, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0C7CU, address);
            }
            switch (value) {
            case 0x002A0C50U:
                goto block_002A0C50;
            case 0x002A0C80U:
                goto block_002A0C80;
            case 0x002A0CA4U:
                goto block_002A0CA4;
            case 0x002A0CF8U:
                goto block_002A0CF8;
            case 0x002A0D48U:
                goto block_002A0D48;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_002A0C80;
    }
block_002A0C80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A0C80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A0C80U);
        }
        goto block_002A0D48;
    }
block_002A0CA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A0CA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A0CA4U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0CA4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x002A0CB0U + 244U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0CA8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[2];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A0CB4U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A0CB8U, 0xEE401A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[3], frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[2];
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x002A0CC0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0CC4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00001400U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0CCCU, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[3] = r2;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A0CD4U, 0xEEF81AE1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A0CD8U, 0xEE410A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[3], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A0CDCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x66U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0CE0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A0CE8U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A0CECU, 0xEE001A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x002A0CF0U, address);
            }
        }
        return Oot3dAotReturned(r14);
    }
block_002A0CF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A0CF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A0CF8U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x68U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0CF8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[2] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A0D00U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A0D04U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x002A0D10U + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0D08U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A0D0CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0D10U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00001400U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x6AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0D18U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r2;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A0D20U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A0D24U, 0xEE001A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x002A0D30U + 124U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0D28U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x002A0D2CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0D30U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[2] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A0D38U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A0D3CU, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A0D40U, address);
            }
        }
        return Oot3dAotReturned(r14);
    }
block_002A0D48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A0D48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A0D48U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0D48U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x002A0D54U + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0D4CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            frame.Guest.vfp[3] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A0D54U, 0xEEF81AE1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A0D58U, 0xEE011A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r1 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x002A0D5CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0D60U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00001400U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x70U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0D68U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[2] = r2;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A0D70U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A0D74U, 0xEE410A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x002A0D80U + 52U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0D78U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A0D7CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x72U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A0D80U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A0D88U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A0D8CU, 0xEE001A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x002A0D90U, address);
            }
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_EffectShieldParticle_Update_002A2424(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x002A2424U:
        goto block_002A2424;
    case 0x002A242CU:
        goto block_002A242C;
    case 0x002A2444U:
        goto block_002A2444;
    case 0x002A2458U:
        goto block_002A2458;
    case 0x002A2498U:
        goto block_002A2498;
    case 0x002A24C8U:
        goto block_002A24C8;
    case 0x002A2510U:
        goto block_002A2510;
    case 0x002A2528U:
        goto block_002A2528;
    case 0x002A2540U:
        goto block_002A2540;
    case 0x002A254CU:
        goto block_002A254C;
    case 0x002A2560U:
        goto block_002A2560;
    case 0x002A257CU:
        goto block_002A257C;
    case 0x002A2584U:
        goto block_002A2584;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_002A2424:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A2424U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A2424U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002A2584; }
        goto block_002A242C;
    }
block_002A242C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A242CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A242CU);
        }
        {
            const uint32_t updatedAddress = r0 + 0x180U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A242CU, address);
            }
            r2 = value;
        }
        {
            r1 = r0;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 3U);
            r2 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r0, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_002A2540; }
        goto block_002A2444;
    }
block_002A2444:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A2444U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A2444U);
        }
        {
            const uint32_t updatedAddress = 0x002A244CU + 0x140U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A2444U, address);
            }
            r2 = value;
        }
        {
            const uint32_t address = 0x002A2450U + 320U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A2448U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = 0x002A2454U + 320U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A244CU, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A2450U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r2 = r2 + operand;
        }
        goto block_002A2458;
    }
block_002A2458:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A2458U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A2458U);
        }
        {
            const uint32_t address = r1 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A2458U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A245CU, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r0 + 416U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A2460U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[2] = r3;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A2468U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A246CU, 0xEE211A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A2470U, 0xEE000AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002A2474U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A2478U, 0xEEB40AC2U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[4],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            frame.Guest.vfp[0] = frame.Guest.vfp[4];
        }
        {
            const uint32_t address = r1 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002A2484U, address);
            }
        }
        {
            const uint32_t address = r1 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A2488U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A248CU, 0xEEF40AC2U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[4],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_002A24C8; }
        goto block_002A2498;
    }
block_002A2498:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A2498U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A2498U);
        }
        {
            const uint32_t updatedAddress = r2 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A2498U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r0 + 416U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A249CU, address);
            }
            frame.Guest.vfp[5] = value;
        }
        {
            frame.Guest.vfp[2] = r3;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A24A4U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A24A8U, 0xEE213A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[6], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[4];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A24B0U, 0xEE420AC3U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplySubtract(frame.Guest.vfp[1], frame.Guest.vfp[5], frame.Guest.vfp[6], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r1 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A24B4U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A24B8U, 0xEEF40AC1U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[2],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            frame.Guest.vfp[1] = frame.Guest.vfp[2];
        }
        {
            const uint32_t address = r1 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A24C4U, address);
            }
        }
        goto block_002A24C8;
    }
block_002A24C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A24C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A24C8U);
        }
        {
            const uint32_t updatedAddress = r2 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A24C8U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r1 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A24CCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[2] = r3;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A24D4U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A24D8U, 0xEE211A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A24DCU, 0xEE400A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r1 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A24E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A24E4U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r1 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A24E8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r1 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A24ECU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[5] = r3;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A24F4U, 0xEEB40A42U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[4],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A24F8U, 0xEEF82AE2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A24FCU, 0xEE622AA1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[5], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[5], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A2500U, 0xEE001A22U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        {
            const uint32_t address = r1 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x002A2508U, address);
            }
        }
        if (!(flags.Z())) { goto block_002A2528; }
        goto block_002A2510;
    }
block_002A2510:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A2510U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A2510U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A2510U, 0xEE300AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 428U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A2514U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A2518U, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = r1 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A2520U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t address = r1 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002A2524U, address);
            }
        }
        goto block_002A2528;
    }
block_002A2528:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A2528U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A2528U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x180U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A2528U, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = 0x00000018U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 3U);
            r3 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, r1, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_002A2458; }
        goto block_002A2540;
    }
block_002A2540:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A2540U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A2540U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x1D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A2540U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_002A2560; }
        goto block_002A254C;
    }
block_002A254C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A254CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A254CU);
        }
        {
            const uint32_t operand = 0x00000100U;
            r2 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0xC8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A2550U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = Oot3dAotLsr(r1, 31U);
            r1 = r1 + operand;
        }
        {
            r1 = Oot3dAotAsr(r1, 1U);
        }
        {
            const uint32_t updatedAddress = r2 + 0xC8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002A255CU, address);
            }
        }
        goto block_002A2560;
    }
block_002A2560:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A2560U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A2560U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x1B1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A2560U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            r1 = r1 & 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1B1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002A256CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x1B0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A2570U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_002A2584; }
        goto block_002A257C;
    }
block_002A257C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A257CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A257CU);
        }
        {
            r0 = 0x00000001U;
        }
        return Oot3dAotReturned(r14);
    }
block_002A2584:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A2584U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A2584U);
        }
        {
            r0 = 0x00000000U;
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_EnDodongo_OverrideLimbDraw_002A9680(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x002A9680U:
        goto block_002A9680;
    case 0x002A9690U:
        goto block_002A9690;
    case 0x002A969CU:
        goto block_002A969C;
    case 0x002A96A4U:
        goto block_002A96A4;
    case 0x002A9734U:
        goto block_002A9734;
    case 0x002A97B4U:
        goto block_002A97B4;
    case 0x002A983CU:
        goto block_002A983C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_002A9680:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A9680U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A9680U);
        }
        {
            const uint32_t address = 0x002A9688U + 444U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A9680U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r3 + operand;
        }
        if (flags.Z()) { goto block_002A9734; }
        goto block_002A9690;
    }
block_002A9690:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A9690U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A9690U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002A97B4; }
        goto block_002A969C;
    }
block_002A969C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A969CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A969CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x0000000CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002A983C; }
        goto block_002A96A4;
    }
block_002A96A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A96A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A96A4U);
        }
        {
            const uint32_t address = r0 + 452U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A96A4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r2 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A96A8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A96ACU, 0xEE800A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A96B4U, 0xEE610A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A96B8U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r2 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A96C0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A96C4U, 0xEE610A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A96C8U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r2 + 32U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A96D0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A96D4U, 0xEE610A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A96D8U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r2 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A96E0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A96E4U, 0xEE610A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A96E8U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r2 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A96F0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A96F4U, 0xEE610A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A96F8U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r2 + 36U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A9700U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A9704U, 0xEE610A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A9708U, address);
            }
        }
        {
            const uint32_t address = r2 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A970CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A9710U, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A9714U, address);
            }
        }
        {
            const uint32_t address = r2 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A9718U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A971CU, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A9720U, address);
            }
        }
        {
            const uint32_t address = r2 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A9724U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A9728U, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002A972CU, address);
            }
        }
        goto block_002A983C;
    }
block_002A9734:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A9734U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A9734U);
        }
        {
            const uint32_t address = r2 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A9734U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r0 + 452U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A9738U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A973CU, 0xEE211A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x002A9740U, address);
            }
        }
        {
            const uint32_t address = r2 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A9744U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A9748U, 0xEE211A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x002A974CU, address);
            }
        }
        {
            const uint32_t address = r2 + 32U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A9750U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A9754U, 0xEE610A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A9758U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r2 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A9760U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A9764U, 0xEE610A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A9768U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r2 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A9770U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A9774U, 0xEE610A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A9778U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r2 + 36U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A9780U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A9784U, 0xEE610A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A9788U, address);
            }
        }
        {
            const uint32_t address = r2 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A978CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A9790U, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A9794U, address);
            }
        }
        {
            const uint32_t address = r2 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A9798U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A979CU, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A97A0U, address);
            }
        }
        {
            const uint32_t address = r2 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A97A4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A97A8U, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002A97ACU, address);
            }
        }
        goto block_002A983C;
    }
block_002A97B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A97B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A97B4U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[1];
        }
        {
            const uint32_t address = r2 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A97B8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 452U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A97BCU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[0];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A97C4U, 0xEE800A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A97C8U, 0xEE600A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 0U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A97CCU, address);
            }
        }
        {
            const uint32_t address = r2 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A97D0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A97D4U, 0xEE600A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A97D8U, address);
            }
        }
        {
            const uint32_t address = r2 + 32U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A97DCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A97E0U, 0xEE600A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A97E4U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r2 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A97ECU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A97F0U, 0xEE610A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A97F4U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r2 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A97FCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A9800U, 0xEE610A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A9804U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r2 + 36U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A980CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A9810U, 0xEE610A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A9814U, address);
            }
        }
        {
            const uint32_t address = r2 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A9818U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A981CU, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A9820U, address);
            }
        }
        {
            const uint32_t address = r2 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A9824U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A9828U, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x002A982CU, address);
            }
        }
        {
            const uint32_t address = r2 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002A9830U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x002A9834U, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r2 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x002A9838U, address);
            }
        }
        goto block_002A983C;
    }
block_002A983C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002A983CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002A983CU);
        }
        {
            r0 = 0x00000000U;
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_BgJyaZurerukabe_Update_00382E14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00382E14U:
        goto block_00382E14;
    case 0x00382E3CU:
        goto block_00382E3C;
    case 0x00382E48U:
        goto block_00382E48;
    case 0x00382E60U:
        goto block_00382E60;
    case 0x00382E6CU:
        goto block_00382E6C;
    case 0x00382E78U:
        goto block_00382E78;
    case 0x00382E94U:
        goto block_00382E94;
    case 0x00382EB0U:
        goto block_00382EB0;
    case 0x00382EBCU:
        goto block_00382EBC;
    case 0x00382ED4U:
        goto block_00382ED4;
    case 0x00382EF0U:
        goto block_00382EF0;
    case 0x00382F10U:
        goto block_00382F10;
    case 0x00382F14U:
        goto block_00382F14;
    case 0x00382F44U:
        goto block_00382F44;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00382E14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00382E14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00382E14U);
        }
        {
            const uint32_t firstAddress = r13 - 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00382E14U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00382E14U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00382E14U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00382E14U,
                                           firstAddress + 12U);
            }
            r13 = r13 - 16U;
        }
        {
            const uint32_t operand = 0x00000100U;
            r6 = r0 + operand;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t updatedAddress = r6 + 0xC2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382E20U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r5 = r1;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t operand = 0x00000001U;
            r2 = r2 - operand;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r6 + 0xC2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00382E30U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x1BCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382E34U, address);
            }
            r2 = value;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x00382E3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00382E3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00382E3C;
    }
block_00382E3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00382E3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00382E3CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0xC0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382E3CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00382ED4; }
        goto block_00382E48;
    }
block_00382E48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00382E48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00382E48U);
        }
        {
            const uint32_t updatedAddress = 0x00382E50U + 0x10CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382E48U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00382E54U + 0x10CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382E4CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382E50U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r0;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382E54U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00200000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00382ED4; }
        goto block_00382E60;
    }
block_00382E60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00382E60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00382E60U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x78U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382E60U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00382ED4; }
        goto block_00382E6C;
    }
block_00382E6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00382E6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00382E6CU);
        }
        {
            const uint32_t address = r0 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382E6CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x00382E78U + 0xECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382E70U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000000U;
        }
        goto block_00382E78;
    }
block_00382E78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00382E78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00382E78U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r3 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382E7CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00382E84U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00382E88U, 0xEEF40AC0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[0],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00382EB0; }
        goto block_00382E94;
    }
block_00382E94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00382E94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00382E94U);
        }
        {
            const uint32_t updatedAddress = r3 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382E94U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[2] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00382EA0U, 0xEEB81AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00382EA4U, 0xEEB41AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[2], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.N()) == (flags.V())) { goto block_00382EBC; }
        goto block_00382EB0;
    }
block_00382EB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00382EB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00382EB0U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r2 = r2 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000006U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_00382E78; }
        goto block_00382EBC;
    }
block_00382EBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00382EBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00382EBCU);
        }
        {
            const uint32_t updatedAddress = 0x00382EC4U + 0xA4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382EBCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00382EC8U + 0xA4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382EC0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x00382ECCU + 164U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382EC4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x00382ED0U + 164U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382EC8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x00382ED8U + Oot3dAotLsl(r2, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382ED0U, address);
            }
            switch (value) {
            case 0x00382E14U:
                goto block_00382E14;
            case 0x00382E3CU:
                goto block_00382E3C;
            case 0x00382E48U:
                goto block_00382E48;
            case 0x00382E60U:
                goto block_00382E60;
            case 0x00382E6CU:
                goto block_00382E6C;
            case 0x00382E78U:
                goto block_00382E78;
            case 0x00382E94U:
                goto block_00382E94;
            case 0x00382EB0U:
                goto block_00382EB0;
            case 0x00382EBCU:
                goto block_00382EBC;
            case 0x00382ED4U:
                goto block_00382ED4;
            case 0x00382EF0U:
                goto block_00382EF0;
            case 0x00382F10U:
                goto block_00382F10;
            case 0x00382F14U:
                goto block_00382F14;
            case 0x00382F44U:
                goto block_00382F44;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_00382ED4;
    }
block_00382ED4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00382ED4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00382ED4U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00382ED4U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00382ED4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00382ED4U,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00382ED4U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
block_00382EF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00382EF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00382EF0U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382EF4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r1 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382EFCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00382F00U, 0xEEB01AC1U};
            frame.Guest.vfp[2] = frame.Guest.vfp[2] & 0x7FFFFFFFU;
        }
        {
            r0 = frame.Guest.vfp[2];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3F800000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00382ED4; }
        goto block_00382F10;
    }
block_00382F10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00382F10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00382F10U);
        }
        goto block_00382F44;
    }
block_00382F14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00382F14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00382F14U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382F18U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382F1CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r2 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            r0 = r1 + operand;
        }
        {
            const uint32_t address = r2 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382F28U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382F2CU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00382F30U, 0xEE311A61U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00382F34U, 0xEEB01AC1U};
            frame.Guest.vfp[2] = frame.Guest.vfp[2] & 0x7FFFFFFFU;
        }
        {
            r0 = frame.Guest.vfp[2];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3F800000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00382ED4; }
        goto block_00382F44;
    }
block_00382F44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00382F44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00382F44U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00382F44U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r1 = r4;
        }
        {
            r0 = r5;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00382F50U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00382F50U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00382F50U,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x00382F50U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r14 = value14;
            r13 = r13 + 16U;
        }
        {
            r3 = 0x00000000U;
        }
        return Oot3dAotBranch(0x00368FC0U);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_003f450c_003F450C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x003F450CU:
        goto block_003F450C;
    case 0x003F455CU:
        goto block_003F455C;
    case 0x003F4570U:
        goto block_003F4570;
    case 0x003F4584U:
        goto block_003F4584;
    case 0x003F4594U:
        goto block_003F4594;
    case 0x003F4598U:
        goto block_003F4598;
    case 0x003F45B8U:
        goto block_003F45B8;
    case 0x003F45CCU:
        goto block_003F45CC;
    case 0x003F45D8U:
        goto block_003F45D8;
    case 0x003F4608U:
        goto block_003F4608;
    case 0x003F461CU:
        goto block_003F461C;
    case 0x003F4634U:
        goto block_003F4634;
    case 0x003F4648U:
        goto block_003F4648;
    case 0x003F464CU:
        goto block_003F464C;
    case 0x003F465CU:
        goto block_003F465C;
    case 0x003F46A4U:
        goto block_003F46A4;
    case 0x003F46D4U:
        goto block_003F46D4;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_003F450C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F450CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F450CU);
        }
        {
            const uint32_t updatedAddress = 0x003F4514U + 0x1CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F450CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t firstAddress = r13 - 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x003F4510U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r14)) {
                return Oot3dAotMemoryFault(context, 0x003F4510U,
                                           firstAddress + 4U);
            }
            r13 = r13 - 8U;
        }
        {
            const uint32_t operand = 0x00000100U;
            r12 = r0 + operand;
        }
        {
            const uint32_t address = 0x003F4520U + 452U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F4518U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F451CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r12 + 0xA4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F4520U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x003F452CU + 0x1BCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F4524U, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            frame.Guest.vfp[0] = r2;
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F4530U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x003F453CU + 436U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F4534U, address);
            }
            frame.Guest.vfp[5] = value;
        }
        {
            frame.Guest.vfp[1] = r3;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F453CU, 0xEEB80A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F4540U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F4544U, 0xEE600A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F4548U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x003F4554U + 408U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F454CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r3 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, r14, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_003F4570; }
        goto block_003F455C;
    }
block_003F455C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F455CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F455CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F455CU, 0xEE600A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F4560U, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r3 = frame.Guest.vfp[1];
        }
        {
            const uint32_t updatedAddress = r0 + 0x1A6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003F4568U, address);
            }
        }
        goto block_003F4598;
    }
block_003F4570:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F4570U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F4570U);
        }
        {
            const uint32_t updatedAddress = 0x003F4578U + 0x17CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F4570U, address);
            }
            r14 = value;
        }
        {
            r3 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, r14, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            r3 = 0x00000064U;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_003F4594; }
        goto block_003F4584;
    }
block_003F4584:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F4584U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F4584U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F4584U, 0xEE721AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[5], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F4588U, 0xEE610AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[3], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F458CU, 0xEEFD0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r3 = frame.Guest.vfp[1];
        }
        goto block_003F4594;
    }
block_003F4594:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F4594U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F4594U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x1A6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003F4594U, address);
            }
        }
        goto block_003F4598;
    }
block_003F4598:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F4598U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F4598U);
        }
        {
            r3 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x003F45A4U + 340U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F459CU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t operand = 0xC0000000U;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x01200000U;
            r3 = r3 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x01940000U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) {
            r3 = 0x00000000U;
        }
        if (flags.C()) {
            const uint32_t updatedAddress = r0 + 0x1A7U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003F45B0U, address);
            }
        }
        if (flags.C()) { goto block_003F464C; }
        goto block_003F45B8;
    }
block_003F45B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F45B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F45B8U);
        }
        {
            const uint32_t updatedAddress = 0x003F45C0U + 0x13CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F45B8U, address);
            }
            r3 = value;
        }
        {
            r14 = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x003F45C8U + 312U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F45C0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r14, r3, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_003F461C; }
        goto block_003F45CC;
    }
block_003F45CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F45CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F45CCU);
        }
        {
            const uint32_t updatedAddress = r0 + 0x1A7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F45CCU, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x000000C8U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_003F4608; }
        goto block_003F45D8;
    }
block_003F45D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F45D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F45D8U);
        }
        {
            frame.Guest.vfp[4] = r3;
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F45DCU, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F45E0U, 0xEEB83A42U};
            Oot3dAotCommitVfp(frame.Guest.vfp[6], frame.Guest.fpscr,
                a32::VfpBinary32FromUnsigned(frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[4] = r3;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F45E8U, 0xEEB82AC2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F45ECU, 0xEE623A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[7], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[4], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x003F45F8U + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F45F0U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F45F4U, 0xEE032AA1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[4], frame.Guest.vfp[7], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F45F8U, 0xEE332A02U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[6], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F45FCU, 0xEEBC2AC2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            r3 = frame.Guest.vfp[4];
        }
        {
            const uint32_t updatedAddress = r0 + 0x1A7U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003F4604U, address);
            }
        }
        goto block_003F4608;
    }
block_003F4608:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F4608U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F4608U);
        }
        {
            const uint32_t address = r0 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003F4608U, address);
            }
        }
        {
            const uint32_t address = r0 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003F460CU, address);
            }
        }
        {
            const uint32_t address = 0x003F4618U + 240U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F4610U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 88U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003F4614U, address);
            }
        }
        goto block_003F464C;
    }
block_003F461C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F461CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F461CU);
        }
        {
            r14 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r14, r3, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t address = r0 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003F4624U, address);
            }
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t address = r0 + 84U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003F4628U, address);
            }
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            r3 = 0x000000FFU;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_003F4648; }
        goto block_003F4634;
    }
block_003F4634:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F4634U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F4634U);
        }
        {
            const uint32_t address = 0x003F463CU + 208U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F4634U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F4638U, 0xEE700AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F463CU, 0xEE600AA1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F4640U, 0xEEFC0AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32ToUnsigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r3 = frame.Guest.vfp[1];
        }
        goto block_003F4648;
    }
block_003F4648:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F4648U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F4648U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x1A7U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003F4648U, address);
            }
        }
        goto block_003F464C;
    }
block_003F464C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F464CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F464CU);
        }
        {
            const uint32_t updatedAddress = 0x003F4654U + 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F464CU, address);
            }
            r14 = value;
        }
        {
            r3 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, r14, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_003F46A4; }
        goto block_003F465C;
    }
block_003F465C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F465CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F465CU);
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F465CU, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = r0 + 424U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F4660U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x003F466CU + 168U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F4664U, address);
            }
            frame.Guest.vfp[6] = value;
        }
        {
            frame.Guest.vfp[1] = r3;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F466CU, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F4670U, 0xEE202A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F4674U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F4678U, 0xEE420A03U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[4], frame.Guest.vfp[6], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003F467CU, address);
            }
        }
        {
            const uint32_t address = r0 + 428U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F4680U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F4684U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 424U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x003F4688U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F468CU, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r3;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F4694U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F4698U, 0xEE200A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F469CU, 0xEE400A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 428U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x003F46A0U, address);
            }
        }
        goto block_003F46A4;
    }
block_003F46A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F46A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F46A4U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F46A4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t address = 0x003F46B0U + 104U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003F46A8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F46B0U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F46B4U, 0xEE800A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = r2;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F46BCU, 0xEE200A22U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F46C0U, 0xEEF80A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromUnsigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x003F46C4U, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003F46CCU,
                                           firstAddress + 0U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x003F46CCU,
                                           firstAddress + 4U);
            }
            r4 = value4;
            r14 = value14;
            r13 = r13 + 8U;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { return Oot3dAotBranch(0x00374428U); }
        goto block_003F46D4;
    }
block_003F46D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003F46D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003F46D4U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r12 + 0xA4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003F46D8U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003F46DCU,
                                           firstAddress + 0U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x003F46DCU,
                                           firstAddress + 4U);
            }
            r4 = value4;
            r13 = r13 + 8U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_cfg_residue_004A857C_004A857C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004A857CU:
        goto block_004A857C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004A857C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004A857CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004A857CU);
        }
        {
            const uint32_t updatedAddress = r11 + 0x400U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A857CU, address);
            }
            r6 = value;
            r11 = updatedAddress;
        }
        {
            const uint32_t operand = r12;
            r8 = r3 + operand;
        }
        {
            const uint32_t operand = r3;
            r3 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r3 = r3 + operand;
        }
        {
            r14 = Oot3dAotAsr(r3, 2U);
        }
        {
            const uint32_t operand = r9;
            r3 = r12 + operand;
        }
        {
            const uint32_t operand = r12;
            r12 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r8 = r8 + operand;
        }
        {
            r8 = Oot3dAotAsr(r8, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 1U);
            r12 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r3 = r3 + operand;
        }
        {
            r3 = Oot3dAotAsr(r3, 1U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r12 = r12 + operand;
        }
        {
            r8 = r8 | Oot3dAotLsl(r14, 8U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r3, 16U);
        }
        {
            r12 = Oot3dAotAsr(r12, 2U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r12, 24U);
        }
        {
            const uint32_t operand = 0x00000C00U;
            r14 = r11 - operand;
        }
        {
            const uint32_t updatedAddress = r14 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004A85C8U, address);
            }
        }
        {
            const uint32_t operand = r6;
            r8 = r9 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r8 = r8 + operand;
        }
        {
            r14 = Oot3dAotAsr(r8, 1U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x400U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A85D8U, address);
            }
            r8 = value;
            r11 = updatedAddress;
        }
        {
            r3 = r3 | Oot3dAotLsl(r12, 8U);
        }
        {
            r3 = r3 | Oot3dAotLsl(r14, 16U);
        }
        {
            const uint32_t operand = r9;
            r9 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 1U);
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r9 = r9 + operand;
        }
        {
            r4 = Oot3dAotAsr(r9, 2U);
        }
        {
            const uint32_t operand = r8;
            r9 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r9 = r9 + operand;
        }
        {
            r5 = Oot3dAotAsr(r9, 1U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x400U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A8600U, address);
            }
            r9 = value;
            r11 = updatedAddress;
        }
        {
            r3 = r3 | Oot3dAotLsl(r4, 24U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r7 = r11 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x004A860CU, address);
            }
        }
        {
            const uint32_t operand = r6;
            r6 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 1U);
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r6 = r6 + operand;
        }
        {
            r7 = r14 | Oot3dAotLsl(r4, 8U);
        }
        {
            r6 = Oot3dAotAsr(r6, 2U);
        }
        {
            r7 = r7 | Oot3dAotLsl(r5, 16U);
        }
        {
            const uint32_t operand = r9;
            r3 = r8 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r3 = r3 + operand;
        }
        {
            r7 = r7 | Oot3dAotLsl(r6, 24U);
        }
        {
            const uint32_t operand = 0x00001400U;
            r12 = r11 - operand;
        }
        {
            const uint32_t updatedAddress = r12 + 0x5U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x004A8638U, address);
            }
        }
        {
            r12 = Oot3dAotAsr(r3, 1U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x400U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A8640U, address);
            }
            r3 = value;
            r11 = updatedAddress;
        }
        {
            r14 = r5 | Oot3dAotLsl(r6, 8U);
        }
        {
            r14 = r14 | Oot3dAotLsl(r12, 16U);
        }
        {
            const uint32_t operand = r8;
            r8 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 1U);
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r8 = r8 + operand;
        }
        {
            r8 = Oot3dAotAsr(r8, 2U);
        }
        {
            const uint32_t operand = r3;
            r4 = r9 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r4 = r4 + operand;
        }
        {
            r14 = r14 | Oot3dAotLsl(r8, 24U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r5 = r11 - operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x004A866CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 - 0x3FBU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r14))) {
                return Oot3dAotMemoryFault(context, 0x004A8670U, address);
            }
        }
        {
            r5 = Oot3dAotAsr(r4, 1U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x400U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A8678U, address);
            }
            r4 = value;
        }
        {
            r8 = r12 | Oot3dAotLsl(r8, 8U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r5, 16U);
        }
        {
            const uint32_t operand = r9;
            r9 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = r4;
            r12 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r9 = r9 + operand;
        }
        {
            r9 = Oot3dAotAsr(r9, 2U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r9, 24U);
        }
        {
            const uint32_t operand = r3;
            r3 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r12 = r12 + operand;
        }
        {
            r12 = Oot3dAotAsr(r12, 1U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r3 = r3 + operand;
        }
        {
            r9 = r5 | Oot3dAotLsl(r9, 8U);
        }
        {
            r9 = r9 | Oot3dAotLsl(r12, 16U);
        }
        {
            r3 = Oot3dAotAsr(r3, 2U);
        }
        {
            r9 = r9 | Oot3dAotLsl(r3, 24U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r7 = r11 - operand;
        }
        {
            const uint32_t updatedAddress = r7 - 0x7FBU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004A86C4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 - 0x3FBU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004A86C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 - 0x3FFU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r14))) {
                return Oot3dAotMemoryFault(context, 0x004A86CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004A86D0U, address);
            }
        }
        {
            r8 = r12 | Oot3dAotLsl(r3, 8U);
        }
        {
            const uint32_t updatedAddress = r11 - 0x3FFU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004A86D8U, address);
            }
        }
        {
            r9 = r4 | Oot3dAotLsl(r4, 8U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r4, 16U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r4, 24U);
        }
        {
            r9 = r9 | Oot3dAotLsl(r4, 16U);
        }
        {
            r9 = r9 | Oot3dAotLsl(r4, 24U);
        }
        {
            const uint32_t updatedAddress = r11 - 0x7FBU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004A86F0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 - 0x3FBU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004A86F4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r11 = r11 + operand;
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r8)) {
                return Oot3dAotMemoryFault(context, 0x004A86FCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r9)) {
                return Oot3dAotMemoryFault(context, 0x004A86FCU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x400U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004A8700U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x404U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004A8704U, address);
            }
        }
        {
            const uint32_t operand = 0x00001800U;
            r11 = r11 - operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004A870CU,
                                           firstAddress + 0U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x004A870CU,
                                           firstAddress + 4U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004A870CU,
                                           firstAddress + 8U);
            }
            r3 = value3;
            r12 = value12;
            r13 = r13 + 12U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_cfg_residue_004A8724_004A8724(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004A8724U:
        goto block_004A8724;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004A8724:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004A8724U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004A8724U);
        }
        {
            const uint32_t updatedAddress = r0 - 0x401U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A8724U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = r2;
            r4 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r4 = r4 + operand;
        }
        {
            r14 = Oot3dAotAsr(r4, 1U);
        }
        {
            r7 = r3 & 0x000000FFU;
        }
        {
            const uint32_t operand = r1;
            r4 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r4 = r4 + operand;
        }
        {
            r5 = Oot3dAotAsr(r4, 2U);
        }
        {
            r4 = Oot3dAotLsl(r3, 16U);
        }
        {
            r4 = Oot3dAotLsr(r4, 24U);
        }
        {
            const uint32_t operand = r4;
            r6 = r2 + operand;
        }
        {
            r8 = Oot3dAotLsl(r3, 8U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r7, 1U);
            r6 = r6 + operand;
        }
        {
            r9 = Oot3dAotLsr(r8, 24U);
        }
        {
            const uint32_t operand = r9;
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r6 = r6 + operand;
        }
        {
            r3 = Oot3dAotLsr(r3, 24U);
        }
        {
            const uint32_t operand = r3;
            r4 = r4 + operand;
        }
        {
            r6 = Oot3dAotAsr(r6, 2U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r7 = r7 + operand;
        }
        {
            r8 = r14 | Oot3dAotLsl(r5, 8U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r6, 16U);
        }
        {
            r7 = Oot3dAotAsr(r7, 2U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 1U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r4 = r4 + operand;
        }
        {
            r11 = r8 | Oot3dAotLsl(r7, 24U);
        }
        {
            r8 = Oot3dAotAsr(r4, 2U);
        }
        {
            r4 = r12 & 0x000000FFU;
        }
        {
            r10 = Oot3dAotLsl(r12, 16U);
        }
        {
            r10 = Oot3dAotLsr(r10, 24U);
        }
        {
            const uint32_t operand = r4;
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r9 = r9 + operand;
        }
        {
            r12 = Oot3dAotLsl(r12, 8U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r12, 24U);
            r12 = r4 + operand;
        }
        {
            const uint32_t operand = r10;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r9 = r9 + operand;
        }
        {
            r9 = Oot3dAotAsr(r9, 2U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 1U);
            r12 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r12 = r12 + operand;
        }
        {
            r3 = Oot3dAotAsr(r3, 2U);
        }
        {
            r4 = r8 | Oot3dAotLsl(r9, 8U);
        }
        {
            r3 = r4 | Oot3dAotLsl(r3, 16U);
        }
        {
            r12 = Oot3dAotAsr(r12, 2U);
        }
        {
            r12 = r3 | Oot3dAotLsl(r12, 24U);
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r11)) {
                return Oot3dAotMemoryFault(context, 0x004A87E4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r12)) {
                return Oot3dAotMemoryFault(context, 0x004A87E4U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x3FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A87E8U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = r12;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = r1;
            r3 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r2 = r2 + operand;
        }
        {
            r2 = Oot3dAotAsr(r2, 2U);
        }
        {
            r3 = Oot3dAotAsr(r3, 1U);
        }
        {
            r4 = r3 | Oot3dAotLsl(r2, 8U);
        }
        {
            r4 = r4 | Oot3dAotLsl(r14, 16U);
        }
        {
            r14 = r6 | Oot3dAotLsl(r7, 8U);
        }
        {
            r14 = r14 | Oot3dAotLsl(r8, 16U);
        }
        {
            r14 = r14 | Oot3dAotLsl(r9, 24U);
        }
        {
            r4 = r4 | Oot3dAotLsl(r5, 24U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x004A8824U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r14)) {
                return Oot3dAotMemoryFault(context, 0x004A8824U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x3FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A8828U, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = r14;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = r12;
            r5 = r14 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r1 = r1 + operand;
        }
        {
            r1 = Oot3dAotAsr(r1, 2U);
        }
        {
            r5 = Oot3dAotAsr(r5, 1U);
        }
        {
            r6 = r5 | Oot3dAotLsl(r1, 8U);
        }
        {
            r3 = r6 | Oot3dAotLsl(r3, 16U);
        }
        {
            r2 = r3 | Oot3dAotLsl(r2, 24U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r6 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r6;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x004A8858U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r11)) {
                return Oot3dAotMemoryFault(context, 0x004A8858U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x7FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A885CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = r3;
            r12 = r12 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 1U);
            r12 = r12 + operand;
        }
        {
            const uint32_t operand = r14;
            r6 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r12 = r12 + operand;
        }
        {
            r12 = Oot3dAotAsr(r12, 2U);
        }
        {
            r6 = Oot3dAotAsr(r6, 1U);
        }
        {
            r7 = r6 | Oot3dAotLsl(r12, 8U);
        }
        {
            r5 = r7 | Oot3dAotLsl(r5, 16U);
        }
        {
            r1 = r5 | Oot3dAotLsl(r1, 24U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x004A888CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x004A888CU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x3FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A8890U, address);
            }
            r4 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x404U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x004A8894U, address);
            }
        }
        {
            const uint32_t operand = r4;
            r14 = r14 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r14 = r14 + operand;
        }
        {
            const uint32_t operand = r3;
            r5 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r14 = r14 + operand;
        }
        {
            r14 = Oot3dAotAsr(r14, 2U);
        }
        {
            r5 = Oot3dAotAsr(r5, 1U);
        }
        {
            r7 = r5 | Oot3dAotLsl(r14, 8U);
        }
        {
            r6 = r7 | Oot3dAotLsl(r6, 16U);
        }
        {
            r12 = r6 | Oot3dAotLsl(r12, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x400U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x004A88C0U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r0 + 0x3FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A88C4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x404U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004A88C8U, address);
            }
        }
        {
            const uint32_t operand = r2;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r4;
            r6 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r3 = r3 + operand;
        }
        {
            r3 = Oot3dAotAsr(r3, 2U);
        }
        {
            r6 = Oot3dAotAsr(r6, 1U);
        }
        {
            r7 = r6 | Oot3dAotLsl(r3, 8U);
        }
        {
            r5 = r7 | Oot3dAotLsl(r5, 16U);
        }
        {
            r14 = r5 | Oot3dAotLsl(r14, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x400U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r14))) {
                return Oot3dAotMemoryFault(context, 0x004A88F4U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r0 + 0x3FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A88F8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x404U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x004A88FCU, address);
            }
        }
        {
            const uint32_t operand = r1;
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = r2;
            r5 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r4 = r4 + operand;
        }
        {
            r4 = Oot3dAotAsr(r4, 2U);
        }
        {
            r5 = Oot3dAotAsr(r5, 1U);
        }
        {
            r7 = r5 | Oot3dAotLsl(r4, 8U);
        }
        {
            r6 = r7 | Oot3dAotLsl(r6, 16U);
        }
        {
            r3 = r6 | Oot3dAotLsl(r3, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x400U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x004A8928U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x7FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A892CU, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = r1;
            r3 = r12 + operand;
        }
        {
            const uint32_t operand = r12;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r1 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r3 = r3 + operand;
        }
        {
            r3 = Oot3dAotAsr(r3, 1U);
        }
        {
            r1 = Oot3dAotAsr(r1, 2U);
        }
        {
            r1 = r3 | Oot3dAotLsl(r1, 8U);
        }
        {
            r1 = r1 | Oot3dAotLsl(r5, 16U);
        }
        {
            r1 = r1 | Oot3dAotLsl(r4, 24U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r2 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r2;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x004A895CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r14)) {
                return Oot3dAotMemoryFault(context, 0x004A895CU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x00001400U;
            r11 = r0 - operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x004A8964U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x004A8964U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x004A8964U,
                                           firstAddress + 8U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004A8964U,
                                           firstAddress + 12U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004A8964U,
                                           firstAddress + 16U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x004A8964U,
                                           firstAddress + 20U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004A8964U,
                                           firstAddress + 24U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r10 = value10;
            r12 = value12;
            r13 = r13 + 28U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_cfg_residue_004A8CD8_004A8CD8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004A8CD8U:
        goto block_004A8CD8;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004A8CD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004A8CD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004A8CD8U);
        }
        {
            r12 = Oot3dAotLsr(r2, 24U);
        }
        {
            const uint32_t operand = r12;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = r3;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r2 = r2 + operand;
        }
        {
            r14 = Oot3dAotLsl(r6, 8U);
        }
        {
            r14 = Oot3dAotLsr(r14, 24U);
        }
        {
            const uint32_t operand = r14;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r3 = r3 + operand;
        }
        {
            r6 = Oot3dAotLsr(r6, 24U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = r6;
            r12 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r2 = r2 + operand;
        }
        {
            r2 = Oot3dAotAsr(r2, 2U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 1U);
            r12 = r12 + operand;
        }
        {
            r1 = Oot3dAotAsr(r1, 2U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r3 = r3 + operand;
        }
        {
            r3 = Oot3dAotAsr(r3, 2U);
        }
        {
            r8 = r1 | Oot3dAotLsl(r2, 8U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r12 = r12 + operand;
        }
        {
            r12 = Oot3dAotAsr(r12, 2U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r3, 16U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r12, 24U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004A8D34U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004A8D38U, address);
            }
        }
        {
            const uint32_t operand = 0x00000400U;
            r7 = r11 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A8D40U, address);
            }
            r7 = value;
        }
        {
            r0 = r3 | Oot3dAotLsl(r12, 8U);
        }
        {
            r8 = r7 & 0x000000FFU;
        }
        {
            r9 = Oot3dAotLsl(r7, 16U);
        }
        {
            r9 = Oot3dAotLsr(r9, 24U);
        }
        {
            const uint32_t operand = r8;
            r14 = r14 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 1U);
            r14 = r14 + operand;
        }
        {
            r10 = Oot3dAotLsl(r7, 8U);
        }
        {
            r10 = Oot3dAotLsr(r10, 24U);
        }
        {
            const uint32_t operand = r9;
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 1U);
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = r10;
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r7, 24U);
            r7 = r9 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r14 = r14 + operand;
        }
        {
            r14 = Oot3dAotAsr(r14, 2U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 1U);
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 1U);
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r6 = r6 + operand;
        }
        {
            r6 = Oot3dAotAsr(r6, 2U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r8 = r8 + operand;
        }
        {
            r8 = Oot3dAotAsr(r8, 2U);
        }
        {
            r9 = r14 | Oot3dAotLsl(r6, 8U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r7 = r7 + operand;
        }
        {
            r7 = Oot3dAotAsr(r7, 2U);
        }
        {
            r9 = r9 | Oot3dAotLsl(r8, 16U);
        }
        {
            r7 = r9 | Oot3dAotLsl(r7, 24U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x004A8DA8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x3FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A8DACU, address);
            }
            r7 = value;
        }
        {
            r10 = r12 | Oot3dAotLsl(r14, 8U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r6, 16U);
        }
        {
            const uint32_t operand = r4;
            r4 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 1U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r4 = r4 + operand;
        }
        {
            r4 = Oot3dAotAsr(r4, 2U);
        }
        {
            r9 = r4 | Oot3dAotLsl(r1, 8U);
        }
        {
            r9 = r9 | Oot3dAotLsl(r2, 16U);
        }
        {
            r8 = r10 | Oot3dAotLsl(r8, 24U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x404U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004A8DD4U, address);
            }
        }
        {
            r9 = r9 | Oot3dAotLsl(r3, 24U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x400U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004A8DDCU, address);
            }
            r11 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r11 + 0x3FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A8DE0U, address);
            }
            r8 = value;
        }
        {
            r0 = r0 | Oot3dAotLsl(r14, 16U);
        }
        {
            r6 = r0 | Oot3dAotLsl(r6, 24U);
        }
        {
            const uint32_t operand = r5;
            r5 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r7, 1U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r5 = r5 + operand;
        }
        {
            r5 = Oot3dAotAsr(r5, 2U);
        }
        {
            r10 = r5 | Oot3dAotLsl(r4, 8U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r1, 16U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r2, 24U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x404U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x004A8E08U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x400U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004A8E0CU, address);
            }
            r11 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r11 + 0x3FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A8E10U, address);
            }
            r6 = value;
        }
        {
            r2 = r2 | Oot3dAotLsl(r3, 8U);
        }
        {
            r2 = r2 | Oot3dAotLsl(r12, 16U);
        }
        {
            const uint32_t operand = r7;
            r7 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 1U);
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r7 = r7 + operand;
        }
        {
            r7 = Oot3dAotAsr(r7, 2U);
        }
        {
            r0 = r7 | Oot3dAotLsl(r5, 8U);
        }
        {
            r0 = r0 | Oot3dAotLsl(r4, 16U);
        }
        {
            r1 = r0 | Oot3dAotLsl(r1, 24U);
        }
        {
            r2 = r2 | Oot3dAotLsl(r14, 24U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r11 = r11 + operand;
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x004A8E40U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x004A8E40U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x3FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A8E44U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = r8;
            r3 = r2 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 1U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r3 = r3 + operand;
        }
        {
            r3 = Oot3dAotAsr(r3, 2U);
        }
        {
            r12 = r3 | Oot3dAotLsl(r7, 8U);
        }
        {
            r12 = r12 | Oot3dAotLsl(r5, 16U);
        }
        {
            r12 = r12 | Oot3dAotLsl(r4, 24U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x400U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x004A8E64U, address);
            }
            r11 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A8E68U, address);
            }
            r8 = value;
        }
        {
            const uint32_t updatedAddress = r11 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004A8E6CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x3FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A8E70U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = r6;
            r14 = r12 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r14 = r14 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r14 = r14 + operand;
        }
        {
            r14 = Oot3dAotAsr(r14, 2U);
        }
        {
            r4 = r14 | Oot3dAotLsl(r3, 8U);
        }
        {
            r4 = r4 | Oot3dAotLsl(r7, 16U);
        }
        {
            r4 = r4 | Oot3dAotLsl(r5, 24U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r11 = r11 + operand;
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x004A8E94U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r9)) {
                return Oot3dAotMemoryFault(context, 0x004A8E94U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x3FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A8E98U, address);
            }
            r4 = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = r2;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r2 = r2 + operand;
        }
        {
            r2 = Oot3dAotAsr(r2, 2U);
        }
        {
            r5 = r2 | Oot3dAotLsl(r14, 8U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r3, 16U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r7, 24U);
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004A8EBCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r10)) {
                return Oot3dAotMemoryFault(context, 0x004A8EBCU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x3FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A8EC0U, address);
            }
            r5 = value;
        }
        {
            const uint32_t operand = r12;
            r12 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r12 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r12 = r12 + operand;
        }
        {
            r12 = Oot3dAotAsr(r12, 2U);
        }
        {
            r2 = r12 | Oot3dAotLsl(r2, 8U);
        }
        {
            r2 = r2 | Oot3dAotLsl(r14, 16U);
        }
        {
            r2 = r2 | Oot3dAotLsl(r3, 24U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x400U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x004A8EE0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x404U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004A8EE4U, address);
            }
        }
        {
            const uint32_t operand = 0x00001800U;
            r11 = r11 - operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x004A8EF0U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x004A8EF0U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x004A8EF0U,
                                           firstAddress + 8U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004A8EF0U,
                                           firstAddress + 12U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004A8EF0U,
                                           firstAddress + 16U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x004A8EF0U,
                                           firstAddress + 20U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004A8EF0U,
                                           firstAddress + 24U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r10 = value10;
            r12 = value12;
            r13 = r13 + 28U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_cfg_residue_004A8F14_004A8F14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004A8F14U:
        goto block_004A8F14;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004A8F14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004A8F14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004A8F14U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            r12 = Oot3dAotAsr(r1, 1U);
        }
        {
            r1 = Oot3dAotLsl(r2, 8U);
        }
        {
            r1 = Oot3dAotLsr(r1, 24U);
        }
        {
            const uint32_t operand = r1;
            r14 = r11 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r14 = r14 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004A8F2CU, address);
            }
        }
        {
            r10 = Oot3dAotAsr(r14, 1U);
        }
        {
            r2 = Oot3dAotLsr(r2, 24U);
        }
        {
            const uint32_t operand = r2;
            r14 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r14 = r14 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x004A8F40U, address);
            }
        }
        {
            r11 = Oot3dAotAsr(r14, 1U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r9 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x004A8F4CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004A8F50U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A8F54U, address);
            }
            r4 = value;
        }
        {
            r3 = r4 & 0x000000FFU;
        }
        {
            const uint32_t operand = r3;
            r14 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A8F60U, address);
            }
            r10 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r14 = r14 + operand;
        }
        {
            r5 = Oot3dAotAsr(r14, 1U);
        }
        {
            r12 = r12 | Oot3dAotLsl(r10, 8U);
        }
        {
            r12 = r12 | Oot3dAotLsl(r11, 16U);
        }
        {
            r12 = r12 | Oot3dAotLsl(r5, 24U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x004A8F78U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x004A8F7CU, address);
            }
        }
        {
            r12 = Oot3dAotLsl(r4, 16U);
        }
        {
            r12 = Oot3dAotLsr(r12, 24U);
        }
        {
            const uint32_t operand = r12;
            r14 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r14 = r14 + operand;
        }
        {
            r8 = Oot3dAotAsr(r14, 1U);
        }
        {
            r14 = Oot3dAotLsl(r4, 8U);
        }
        {
            r14 = Oot3dAotLsr(r14, 24U);
        }
        {
            const uint32_t operand = r14;
            r5 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            r6 = Oot3dAotAsr(r5, 1U);
        }
        {
            r4 = Oot3dAotLsr(r4, 24U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004A8FACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A8FB0U, address);
            }
            r8 = value;
        }
        {
            const uint32_t operand = r4;
            r5 = r14 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            r7 = Oot3dAotAsr(r5, 1U);
        }
        {
            r5 = r8 & 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A8FC4U, address);
            }
            r10 = value;
        }
        {
            const uint32_t operand = r5;
            r9 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r9 = r9 + operand;
        }
        {
            r10 = r10 | Oot3dAotLsl(r6, 8U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r7, 16U);
        }
        {
            r9 = Oot3dAotAsr(r9, 1U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r9, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004A8FE0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A8FE4U, address);
            }
            r10 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A8FE8U, address);
            }
            r11 = value;
        }
        {
            const uint32_t operand = r1;
            r10 = r10 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r11, 1U);
            r10 = r10 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r10 = r10 + operand;
        }
        {
            r10 = Oot3dAotAsr(r10, 2U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004A8FFCU, address);
            }
        }
        {
            const uint32_t operand = r2;
            r10 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r10 = r10 + operand;
        }
        {
            const uint32_t operand = r3;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r10 = r10 + operand;
        }
        {
            r10 = Oot3dAotAsr(r10, 2U);
        }
        {
            r1 = Oot3dAotAsr(r1, 2U);
        }
        {
            const uint32_t operand = 0x0000000CU;
            r11 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x004A9024U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r10)) {
                return Oot3dAotMemoryFault(context, 0x004A9024U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = r12;
            r1 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000010U;
            r10 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r10;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x004A9030U,
                                           firstAddress + 0U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004A9030U,
                                           firstAddress + 4U);
            }
            r2 = value2;
            r10 = value10;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r1 = r1 + operand;
        }
        {
            r2 = r10 | Oot3dAotLsl(r2, 8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A903CU, address);
            }
            r10 = value;
        }
        {
            const uint32_t operand = 0x00000002U;
            r1 = r1 + operand;
        }
        {
            r1 = Oot3dAotAsr(r1, 2U);
        }
        {
            r2 = r2 | Oot3dAotLsl(r10, 16U);
        }
        {
            r2 = r2 | Oot3dAotLsl(r1, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x400U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x004A9050U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = r14;
            r2 = r3 + operand;
        }
        {
            const uint32_t operand = r4;
            r3 = r12 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 1U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r5;
            r12 = r14 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r12 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r12 = r12 + operand;
        }
        {
            r14 = Oot3dAotAsr(r12, 2U);
        }
        {
            r12 = Oot3dAotLsl(r8, 16U);
        }
        {
            r12 = Oot3dAotLsr(r12, 24U);
        }
        {
            const uint32_t operand = r12;
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r2 = r2 + operand;
        }
        {
            r2 = Oot3dAotAsr(r2, 2U);
        }
        {
            r3 = Oot3dAotAsr(r3, 2U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 1U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r4 = r4 + operand;
        }
        {
            r10 = r2 | Oot3dAotLsl(r3, 8U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r14, 16U);
        }
        {
            r4 = Oot3dAotAsr(r4, 2U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r4, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004A90A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A90ACU, address);
            }
            r10 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A90B0U, address);
            }
            r11 = value;
        }
        {
            r10 = r10 | Oot3dAotLsl(r11, 8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A90B8U, address);
            }
            r11 = value;
        }
        {
            r10 = r10 | Oot3dAotLsl(r11, 16U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A90C0U, address);
            }
            r11 = value;
        }
        {
            r10 = r10 | Oot3dAotLsl(r11, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x400U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004A90C8U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = r12;
            r10 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r10 = r10 + operand;
        }
        {
            r11 = Oot3dAotAsr(r10, 1U);
        }
        {
            r10 = r6 | Oot3dAotLsl(r7, 8U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r9, 16U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r11, 24U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x004A90E4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004A90E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A90ECU, address);
            }
            r10 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A90F0U, address);
            }
            r11 = value;
        }
        {
            r10 = r10 | Oot3dAotLsl(r11, 8U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r1, 16U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r2, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x400U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004A9100U, address);
            }
            r0 = updatedAddress;
        }
        {
            r10 = Oot3dAotLsl(r8, 8U);
        }
        {
            r10 = Oot3dAotLsr(r10, 24U);
        }
        {
            const uint32_t operand = r10;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r5 = r5 + operand;
        }
        {
            r11 = Oot3dAotAsr(r5, 2U);
        }
        {
            r5 = r3 | Oot3dAotLsl(r14, 8U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r4, 16U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r11, 24U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x004A9128U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x004A912CU, address);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r11 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r11;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004A9134U,
                                           firstAddress + 0U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x004A9134U,
                                           firstAddress + 4U);
            }
            r5 = value5;
            r11 = value11;
        }
        {
            r5 = r11 | Oot3dAotLsl(r5, 8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A913CU, address);
            }
            r11 = value;
        }
        {
            r5 = r5 | Oot3dAotLsl(r11, 16U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r6, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x400U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x004A9148U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = r10;
            r5 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            r11 = Oot3dAotAsr(r5, 1U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x004A9158U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A915CU, address);
            }
            r11 = value;
        }
        {
            r5 = r7 | Oot3dAotLsl(r9, 8U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r11, 16U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A9168U, address);
            }
            r11 = value;
        }
        {
            r5 = r5 | Oot3dAotLsl(r11, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x004A9170U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A9174U, address);
            }
            r11 = value;
        }
        {
            r5 = r11 | Oot3dAotLsl(r1, 8U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r2, 16U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r3, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x400U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x004A9184U, address);
            }
            r0 = updatedAddress;
        }
        {
            r5 = Oot3dAotLsr(r8, 24U);
        }
        {
            const uint32_t operand = r5;
            r12 = r12 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A9190U, address);
            }
            r11 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 1U);
            r12 = r12 + operand;
        }
        {
            r8 = r14 | Oot3dAotLsl(r4, 8U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r11, 16U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r12 = r12 + operand;
        }
        {
            r12 = Oot3dAotAsr(r12, 2U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r12, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004A91ACU, address);
            }
        }
        {
            const uint32_t operand = 0x00000018U;
            r11 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r11;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x004A91B4U,
                                           firstAddress + 0U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x004A91B4U,
                                           firstAddress + 4U);
            }
            r8 = value8;
            r11 = value11;
        }
        {
            r1 = r1 | Oot3dAotLsl(r2, 8U);
        }
        {
            r8 = r11 | Oot3dAotLsl(r8, 8U);
        }
        {
            r6 = r8 | Oot3dAotLsl(r6, 16U);
        }
        {
            r6 = r6 | Oot3dAotLsl(r7, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x400U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x004A91C8U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A91CCU, address);
            }
            r11 = value;
        }
        {
            const uint32_t operand = r5;
            r6 = r10 + operand;
        }
        {
            r7 = r9 | Oot3dAotLsl(r11, 8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A91D8U, address);
            }
            r11 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            r1 = r1 | Oot3dAotLsl(r3, 16U);
        }
        {
            r1 = r1 | Oot3dAotLsl(r14, 24U);
        }
        {
            r6 = Oot3dAotAsr(r6, 1U);
        }
        {
            r7 = r7 | Oot3dAotLsl(r11, 16U);
        }
        {
            r6 = r7 | Oot3dAotLsl(r6, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x400U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004A91F4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x004A91F8U, address);
            }
        }
        {
            const uint32_t operand = 0x00001C00U;
            r11 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r11 + 0xCU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A9200U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004A9204U, address);
            }
            r11 = value;
        }
        {
            const uint32_t operand = r1;
            r1 = r10 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 1U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r1 = r1 + operand;
        }
        {
            r1 = Oot3dAotAsr(r1, 2U);
        }
        {
            r2 = r4 | Oot3dAotLsl(r11, 8U);
        }
        {
            r2 = r2 | Oot3dAotLsl(r12, 16U);
        }
        {
            r1 = r2 | Oot3dAotLsl(r1, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x404U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004A9224U, address);
            }
        }
        {
            const uint32_t operand = 0x00000030U;
            r13 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00001800U;
            r11 = r0 - operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x004A9230U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x004A9230U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x004A9230U,
                                           firstAddress + 8U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004A9230U,
                                           firstAddress + 12U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004A9230U,
                                           firstAddress + 16U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x004A9230U,
                                           firstAddress + 20U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004A9230U,
                                           firstAddress + 24U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r10 = value10;
            r12 = value12;
            r13 = r13 + 28U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_004aa624_004AA624(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004AA624U:
        goto block_004AA624;
    case 0x004AA648U:
        goto block_004AA648;
    case 0x004AA67CU:
        goto block_004AA67C;
    case 0x004AA754U:
        goto block_004AA754;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004AA624:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004AA624U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004AA624U);
        }
        {
            const uint32_t firstAddress = r13 - 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004AA624U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004AA624U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r14)) {
                return Oot3dAotMemoryFault(context, 0x004AA624U,
                                           firstAddress + 8U);
            }
            r13 = r13 - 12U;
        }
        {
            const uint32_t updatedAddress = 0x004AA630U + 0xA84U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AA628U, address);
            }
            r12 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004AA62CU,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004AA62CU,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004AA62CU,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004AA62CU,
                                           firstAddress + 12U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AA630U, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        goto block_004AA648;
    }
block_004AA648:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004AA648U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004AA648U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r3, 8U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 24U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 8U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 24U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 8U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 24U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 8U);
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 24U);
            r6 = r6 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        goto block_004AA67C;
    }
block_004AA67C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004AA67CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004AA67CU);
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x004AA67CU,
                                           firstAddress + 0U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x004AA67CU,
                                           firstAddress + 4U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x004AA67CU,
                                           firstAddress + 8U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004AA67CU,
                                           firstAddress + 12U);
            }
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AA680U, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r0 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r7, 8U);
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 24U);
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r8, 8U);
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 24U);
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r9, 8U);
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 24U);
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r10, 8U);
            r10 = r10 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 24U);
            r10 = r10 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            const uint32_t operand = r7;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r8;
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = r9;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = r10;
            r6 = r6 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r3)) {
                return Oot3dAotMemoryFault(context, 0x004AA6DCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x004AA6DCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004AA6DCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004AA6DCU,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r1 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004AA6E4U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004AA6E4U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004AA6E4U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004AA6E4U,
                                           firstAddress + 12U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AA6E8U, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r3, 8U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 24U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 8U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 24U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 8U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 24U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 8U);
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 24U);
            r6 = r6 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            const uint32_t operand = r3;
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = r4;
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = r5;
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = r6;
            r10 = r10 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r7)) {
                return Oot3dAotMemoryFault(context, 0x004AA744U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r8)) {
                return Oot3dAotMemoryFault(context, 0x004AA744U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r9)) {
                return Oot3dAotMemoryFault(context, 0x004AA744U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r10)) {
                return Oot3dAotMemoryFault(context, 0x004AA744U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            Oot3dAotSetSubtractFlags(flags, r2, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r2 = r2 - operand;
        }
        if (!(flags.Z())) { goto block_004AA67C; }
        goto block_004AA754;
    }
block_004AA754:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004AA754U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004AA754U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004AA754U,
                                           firstAddress + 0U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004AA754U,
                                           firstAddress + 4U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004AA754U,
                                           firstAddress + 8U);
            }
            r5 = value5;
            r6 = value6;
            r13 = r13 + 12U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_004aa914_004AA914(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004AA914U:
        goto block_004AA914;
    case 0x004AA940U:
        goto block_004AA940;
    case 0x004AA990U:
        goto block_004AA990;
    case 0x004AAAA8U:
        goto block_004AAAA8;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004AA914:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004AA914U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004AA914U);
        }
        {
            const uint32_t firstAddress = r13 - 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004AA914U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004AA914U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r11)) {
                return Oot3dAotMemoryFault(context, 0x004AA914U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r14)) {
                return Oot3dAotMemoryFault(context, 0x004AA914U,
                                           firstAddress + 12U);
            }
            r13 = r13 - 16U;
        }
        {
            const uint32_t updatedAddress = 0x004AA920U + 0x794U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AA918U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004AA920U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004AA920U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004AA920U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004AA920U,
                                           firstAddress + 12U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AA924U, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        goto block_004AA940;
    }
block_004AA940:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004AA940U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004AA940U);
        }
        {
            r11 = Oot3dAotLsr(r3, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r3, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 24U);
            r3 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r4, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 24U);
            r4 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r5, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 24U);
            r5 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r6, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 24U);
            r6 = r11 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        goto block_004AA990;
    }
block_004AA990:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004AA990U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004AA990U);
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x004AA990U,
                                           firstAddress + 0U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x004AA990U,
                                           firstAddress + 4U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x004AA990U,
                                           firstAddress + 8U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004AA990U,
                                           firstAddress + 12U);
            }
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AA994U, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r0 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            r11 = Oot3dAotLsr(r7, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r7, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 24U);
            r7 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r8, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r8, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 24U);
            r8 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r9, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r9, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 24U);
            r9 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r10, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r10, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 24U);
            r10 = r11 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            const uint32_t operand = r7;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r8;
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = r9;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = r10;
            r6 = r6 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r3)) {
                return Oot3dAotMemoryFault(context, 0x004AAA10U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x004AAA10U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004AAA10U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004AAA10U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r1 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004AAA18U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004AAA18U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004AAA18U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004AAA18U,
                                           firstAddress + 12U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AAA1CU, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            r11 = Oot3dAotLsr(r3, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r3, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 24U);
            r3 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r4, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 24U);
            r4 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r5, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 24U);
            r5 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r6, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 24U);
            r6 = r11 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            const uint32_t operand = r3;
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = r4;
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = r5;
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = r6;
            r10 = r10 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r7)) {
                return Oot3dAotMemoryFault(context, 0x004AAA98U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r8)) {
                return Oot3dAotMemoryFault(context, 0x004AAA98U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r9)) {
                return Oot3dAotMemoryFault(context, 0x004AAA98U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r10)) {
                return Oot3dAotMemoryFault(context, 0x004AAA98U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            Oot3dAotSetSubtractFlags(flags, r2, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r2 = r2 - operand;
        }
        if (!(flags.Z())) { goto block_004AA990; }
        goto block_004AAAA8;
    }
block_004AAAA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004AAAA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004AAAA8U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004AAAA8U,
                                           firstAddress + 0U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004AAAA8U,
                                           firstAddress + 4U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x004AAAA8U,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004AAAA8U,
                                           firstAddress + 12U);
            }
            r5 = value5;
            r6 = value6;
            r11 = value11;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_004aac64_004AAC64(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004AAC64U:
        goto block_004AAC64;
    case 0x004AAC98U:
        goto block_004AAC98;
    case 0x004AACDCU:
        goto block_004AACDC;
    case 0x004AADECU:
        goto block_004AADEC;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004AAC64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004AAC64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004AAC64U);
        }
        {
            const uint32_t firstAddress = r13 - 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004AAC64U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004AAC64U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r11)) {
                return Oot3dAotMemoryFault(context, 0x004AAC64U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r14)) {
                return Oot3dAotMemoryFault(context, 0x004AAC64U,
                                           firstAddress + 12U);
            }
            r13 = r13 - 16U;
        }
        {
            const uint32_t updatedAddress = 0x004AAC70U + 0x444U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AAC68U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = 0x00000002U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 - 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AAC70U, address);
            }
            r3 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004AAC74U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004AAC74U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004AAC74U,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x004AAC74U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r14 = value14;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 16U);
            r11 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r3, 8U);
            r11 = r11 + operand;
        }
        goto block_004AAC98;
    }
block_004AAC98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004AAC98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004AAC98U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 8U);
            r3 = r11 + operand;
        }
        {
            r4 = Oot3dAotLsr(r4, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 16U);
            r11 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 8U);
            r4 = r11 + operand;
        }
        {
            r5 = Oot3dAotLsr(r5, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 16U);
            r11 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 8U);
            r5 = r11 + operand;
        }
        {
            r6 = Oot3dAotLsr(r6, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 16U);
            r11 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 8U);
            r6 = r11 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        goto block_004AACDC;
    }
block_004AACDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004AACDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004AACDCU);
        }
        {
            const uint32_t updatedAddress = r0 - 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AACDCU, address);
            }
            r7 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x004AACE0U,
                                           firstAddress + 0U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x004AACE0U,
                                           firstAddress + 4U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004AACE0U,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x004AACE0U,
                                           firstAddress + 12U);
            }
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r14 = value14;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r0 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 16U);
            r11 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r7, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 8U);
            r7 = r11 + operand;
        }
        {
            r8 = Oot3dAotLsr(r8, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 16U);
            r11 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r8, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 8U);
            r8 = r11 + operand;
        }
        {
            r9 = Oot3dAotLsr(r9, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 16U);
            r11 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r9, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 8U);
            r9 = r11 + operand;
        }
        {
            r10 = Oot3dAotLsr(r10, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 16U);
            r11 = r10 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r10, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 8U);
            r10 = r11 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            const uint32_t operand = r7;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r8;
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = r9;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = r10;
            r6 = r6 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r3)) {
                return Oot3dAotMemoryFault(context, 0x004AAD58U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x004AAD58U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004AAD58U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004AAD58U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 - 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AAD60U, address);
            }
            r3 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004AAD64U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004AAD64U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004AAD64U,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x004AAD64U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r14 = value14;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 16U);
            r11 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r3, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 8U);
            r3 = r11 + operand;
        }
        {
            r4 = Oot3dAotLsr(r4, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 16U);
            r11 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 8U);
            r4 = r11 + operand;
        }
        {
            r5 = Oot3dAotLsr(r5, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 16U);
            r11 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 8U);
            r5 = r11 + operand;
        }
        {
            r6 = Oot3dAotLsr(r6, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 16U);
            r11 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 8U);
            r6 = r11 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            const uint32_t operand = r3;
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = r4;
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = r5;
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = r6;
            r10 = r10 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r7)) {
                return Oot3dAotMemoryFault(context, 0x004AADDCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r8)) {
                return Oot3dAotMemoryFault(context, 0x004AADDCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r9)) {
                return Oot3dAotMemoryFault(context, 0x004AADDCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r10)) {
                return Oot3dAotMemoryFault(context, 0x004AADDCU,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            Oot3dAotSetSubtractFlags(flags, r2, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r2 = r2 - operand;
        }
        if (!(flags.Z())) { goto block_004AACDC; }
        goto block_004AADEC;
    }
block_004AADEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004AADECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004AADECU);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004AADECU,
                                           firstAddress + 0U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004AADECU,
                                           firstAddress + 4U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x004AADECU,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004AADECU,
                                           firstAddress + 12U);
            }
            r5 = value5;
            r6 = value6;
            r11 = value11;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_004aaf7c_004AAF7C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004AAF7CU:
        goto block_004AAF7C;
    case 0x004AAFB8U:
        goto block_004AAFB8;
    case 0x004AAFD8U:
        goto block_004AAFD8;
    case 0x004AB0B0U:
        goto block_004AB0B0;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004AAF7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004AAF7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004AAF7CU);
        }
        {
            const uint32_t firstAddress = r13 - 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004AAF7CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004AAF7CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r14)) {
                return Oot3dAotMemoryFault(context, 0x004AAF7CU,
                                           firstAddress + 8U);
            }
            r13 = r13 - 12U;
        }
        {
            const uint32_t updatedAddress = 0x004AAF88U + 0x12CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AAF80U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 - 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AAF88U, address);
            }
            r3 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004AAF8CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004AAF8CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004AAF8CU,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x004AAF8CU,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r14 = value14;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 8U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r4;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 24U);
            r4 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 8U);
            r4 = r4 + operand;
        }
        goto block_004AAFB8;
    }
block_004AAFB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004AAFB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004AAFB8U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 24U);
            r5 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 8U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 24U);
            r6 = r14 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 8U);
            r6 = r6 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        goto block_004AAFD8;
    }
block_004AAFD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004AAFD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004AAFD8U);
        }
        {
            const uint32_t updatedAddress = r0 - 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AAFD8U, address);
            }
            r7 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x004AAFDCU,
                                           firstAddress + 0U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x004AAFDCU,
                                           firstAddress + 4U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004AAFDCU,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x004AAFDCU,
                                           firstAddress + 12U);
            }
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r14 = value14;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r0 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 8U);
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = r8;
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r8, 24U);
            r8 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 8U);
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r9, 24U);
            r9 = r10 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 8U);
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r10, 24U);
            r10 = r14 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 8U);
            r10 = r10 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            const uint32_t operand = r7;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r8;
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = r9;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = r10;
            r6 = r6 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r3)) {
                return Oot3dAotMemoryFault(context, 0x004AB038U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x004AB038U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004AB038U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004AB038U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 - 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AB040U, address);
            }
            r3 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004AB044U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004AB044U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004AB044U,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x004AB044U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r14 = value14;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 8U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r4;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 24U);
            r4 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 8U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 24U);
            r5 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 8U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 24U);
            r6 = r14 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 8U);
            r6 = r6 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            const uint32_t operand = r3;
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = r4;
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = r5;
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = r6;
            r10 = r10 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r7)) {
                return Oot3dAotMemoryFault(context, 0x004AB0A0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r8)) {
                return Oot3dAotMemoryFault(context, 0x004AB0A0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r9)) {
                return Oot3dAotMemoryFault(context, 0x004AB0A0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r10)) {
                return Oot3dAotMemoryFault(context, 0x004AB0A0U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            Oot3dAotSetSubtractFlags(flags, r2, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r2 = r2 - operand;
        }
        if (!(flags.Z())) { goto block_004AAFD8; }
        goto block_004AB0B0;
    }
block_004AB0B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004AB0B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004AB0B0U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004AB0B0U,
                                           firstAddress + 0U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004AB0B0U,
                                           firstAddress + 4U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004AB0B0U,
                                           firstAddress + 8U);
            }
            r5 = value5;
            r6 = value6;
            r13 = r13 + 12U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_cfg_residue_004AEB7C_004AEB7C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004AEB7CU:
        goto block_004AEB7C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004AEB7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004AEB7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004AEB7CU);
        }
        {
            const uint32_t updatedAddress = r11 + 0x100U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AEB7CU, address);
            }
            r6 = value;
            r11 = updatedAddress;
        }
        {
            const uint32_t operand = r12;
            r8 = r3 + operand;
        }
        {
            const uint32_t operand = r3;
            r3 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r3 = r3 + operand;
        }
        {
            r14 = Oot3dAotAsr(r3, 2U);
        }
        {
            const uint32_t operand = r9;
            r3 = r12 + operand;
        }
        {
            const uint32_t operand = r12;
            r12 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r8 = r8 + operand;
        }
        {
            r8 = Oot3dAotAsr(r8, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 1U);
            r12 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r3 = r3 + operand;
        }
        {
            r3 = Oot3dAotAsr(r3, 1U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r12 = r12 + operand;
        }
        {
            r8 = r8 | Oot3dAotLsl(r14, 8U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r3, 16U);
        }
        {
            r12 = Oot3dAotAsr(r12, 2U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r12, 24U);
        }
        {
            const uint32_t operand = 0x00000300U;
            r14 = r11 - operand;
        }
        {
            const uint32_t updatedAddress = r14 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004AEBC8U, address);
            }
        }
        {
            const uint32_t operand = r6;
            r8 = r9 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r8 = r8 + operand;
        }
        {
            r14 = Oot3dAotAsr(r8, 1U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x100U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AEBD8U, address);
            }
            r8 = value;
            r11 = updatedAddress;
        }
        {
            r3 = r3 | Oot3dAotLsl(r12, 8U);
        }
        {
            r3 = r3 | Oot3dAotLsl(r14, 16U);
        }
        {
            const uint32_t operand = r9;
            r9 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 1U);
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r9 = r9 + operand;
        }
        {
            r4 = Oot3dAotAsr(r9, 2U);
        }
        {
            const uint32_t operand = r8;
            r9 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r9 = r9 + operand;
        }
        {
            r5 = Oot3dAotAsr(r9, 1U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x100U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AEC00U, address);
            }
            r9 = value;
            r11 = updatedAddress;
        }
        {
            r3 = r3 | Oot3dAotLsl(r4, 24U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r7 = r11 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x004AEC0CU, address);
            }
        }
        {
            const uint32_t operand = r6;
            r6 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 1U);
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r6 = r6 + operand;
        }
        {
            r7 = r14 | Oot3dAotLsl(r4, 8U);
        }
        {
            r6 = Oot3dAotAsr(r6, 2U);
        }
        {
            r7 = r7 | Oot3dAotLsl(r5, 16U);
        }
        {
            const uint32_t operand = r9;
            r3 = r8 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r3 = r3 + operand;
        }
        {
            r7 = r7 | Oot3dAotLsl(r6, 24U);
        }
        {
            const uint32_t operand = 0x00000500U;
            r12 = r11 - operand;
        }
        {
            const uint32_t updatedAddress = r12 + 0x5U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x004AEC38U, address);
            }
        }
        {
            r12 = Oot3dAotAsr(r3, 1U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x100U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AEC40U, address);
            }
            r3 = value;
            r11 = updatedAddress;
        }
        {
            r14 = r5 | Oot3dAotLsl(r6, 8U);
        }
        {
            r14 = r14 | Oot3dAotLsl(r12, 16U);
        }
        {
            const uint32_t operand = r8;
            r8 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 1U);
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r8 = r8 + operand;
        }
        {
            r8 = Oot3dAotAsr(r8, 2U);
        }
        {
            const uint32_t operand = r3;
            r4 = r9 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r4 = r4 + operand;
        }
        {
            r14 = r14 | Oot3dAotLsl(r8, 24U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r5 = r11 - operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x004AEC6CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 - 0xFBU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r14))) {
                return Oot3dAotMemoryFault(context, 0x004AEC70U, address);
            }
        }
        {
            r5 = Oot3dAotAsr(r4, 1U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x100U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AEC78U, address);
            }
            r4 = value;
        }
        {
            r8 = r12 | Oot3dAotLsl(r8, 8U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r5, 16U);
        }
        {
            const uint32_t operand = r9;
            r9 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = r4;
            r12 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r9 = r9 + operand;
        }
        {
            r9 = Oot3dAotAsr(r9, 2U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r9, 24U);
        }
        {
            const uint32_t operand = r3;
            r3 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r12 = r12 + operand;
        }
        {
            r12 = Oot3dAotAsr(r12, 1U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r3 = r3 + operand;
        }
        {
            r9 = r5 | Oot3dAotLsl(r9, 8U);
        }
        {
            r9 = r9 | Oot3dAotLsl(r12, 16U);
        }
        {
            r3 = Oot3dAotAsr(r3, 2U);
        }
        {
            r9 = r9 | Oot3dAotLsl(r3, 24U);
        }
        {
            const uint32_t operand = 0x00000200U;
            r7 = r11 - operand;
        }
        {
            const uint32_t updatedAddress = r7 - 0x1FBU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004AECC4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 - 0xFBU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004AECC8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 - 0xFFU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r14))) {
                return Oot3dAotMemoryFault(context, 0x004AECCCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004AECD0U, address);
            }
        }
        {
            r8 = r12 | Oot3dAotLsl(r3, 8U);
        }
        {
            const uint32_t updatedAddress = r11 - 0xFFU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004AECD8U, address);
            }
        }
        {
            r9 = r4 | Oot3dAotLsl(r4, 8U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r4, 16U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r4, 24U);
        }
        {
            r9 = r9 | Oot3dAotLsl(r4, 16U);
        }
        {
            r9 = r9 | Oot3dAotLsl(r4, 24U);
        }
        {
            const uint32_t updatedAddress = r11 - 0x1FBU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004AECF0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 - 0xFBU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004AECF4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r11 = r11 + operand;
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r8)) {
                return Oot3dAotMemoryFault(context, 0x004AECFCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r9)) {
                return Oot3dAotMemoryFault(context, 0x004AECFCU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x100U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004AED00U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x104U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004AED04U, address);
            }
        }
        {
            const uint32_t operand = 0x00000600U;
            r11 = r11 - operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004AED0CU,
                                           firstAddress + 0U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x004AED0CU,
                                           firstAddress + 4U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004AED0CU,
                                           firstAddress + 8U);
            }
            r3 = value3;
            r12 = value12;
            r13 = r13 + 12U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_cfg_residue_004AED24_004AED24(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004AED24U:
        goto block_004AED24;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004AED24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004AED24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004AED24U);
        }
        {
            const uint32_t updatedAddress = r0 - 0x101U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AED24U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = r2;
            r4 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r4 = r4 + operand;
        }
        {
            r14 = Oot3dAotAsr(r4, 1U);
        }
        {
            r7 = r3 & 0x000000FFU;
        }
        {
            const uint32_t operand = r1;
            r4 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r4 = r4 + operand;
        }
        {
            r5 = Oot3dAotAsr(r4, 2U);
        }
        {
            r4 = Oot3dAotLsl(r3, 16U);
        }
        {
            r4 = Oot3dAotLsr(r4, 24U);
        }
        {
            const uint32_t operand = r4;
            r6 = r2 + operand;
        }
        {
            r8 = Oot3dAotLsl(r3, 8U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r7, 1U);
            r6 = r6 + operand;
        }
        {
            r9 = Oot3dAotLsr(r8, 24U);
        }
        {
            const uint32_t operand = r9;
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r6 = r6 + operand;
        }
        {
            r3 = Oot3dAotLsr(r3, 24U);
        }
        {
            const uint32_t operand = r3;
            r4 = r4 + operand;
        }
        {
            r6 = Oot3dAotAsr(r6, 2U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r7 = r7 + operand;
        }
        {
            r8 = r14 | Oot3dAotLsl(r5, 8U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r6, 16U);
        }
        {
            r7 = Oot3dAotAsr(r7, 2U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 1U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r4 = r4 + operand;
        }
        {
            r11 = r8 | Oot3dAotLsl(r7, 24U);
        }
        {
            r8 = Oot3dAotAsr(r4, 2U);
        }
        {
            r4 = r12 & 0x000000FFU;
        }
        {
            r10 = Oot3dAotLsl(r12, 16U);
        }
        {
            r10 = Oot3dAotLsr(r10, 24U);
        }
        {
            const uint32_t operand = r4;
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r9 = r9 + operand;
        }
        {
            r12 = Oot3dAotLsl(r12, 8U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r12, 24U);
            r12 = r4 + operand;
        }
        {
            const uint32_t operand = r10;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r9 = r9 + operand;
        }
        {
            r9 = Oot3dAotAsr(r9, 2U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 1U);
            r12 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r12 = r12 + operand;
        }
        {
            r3 = Oot3dAotAsr(r3, 2U);
        }
        {
            r4 = r8 | Oot3dAotLsl(r9, 8U);
        }
        {
            r3 = r4 | Oot3dAotLsl(r3, 16U);
        }
        {
            r12 = Oot3dAotAsr(r12, 2U);
        }
        {
            r12 = r3 | Oot3dAotLsl(r12, 24U);
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r11)) {
                return Oot3dAotMemoryFault(context, 0x004AEDE4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r12)) {
                return Oot3dAotMemoryFault(context, 0x004AEDE4U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xFFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AEDE8U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = r12;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = r1;
            r3 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r2 = r2 + operand;
        }
        {
            r2 = Oot3dAotAsr(r2, 2U);
        }
        {
            r3 = Oot3dAotAsr(r3, 1U);
        }
        {
            r4 = r3 | Oot3dAotLsl(r2, 8U);
        }
        {
            r4 = r4 | Oot3dAotLsl(r14, 16U);
        }
        {
            r14 = r6 | Oot3dAotLsl(r7, 8U);
        }
        {
            r14 = r14 | Oot3dAotLsl(r8, 16U);
        }
        {
            r14 = r14 | Oot3dAotLsl(r9, 24U);
        }
        {
            r4 = r4 | Oot3dAotLsl(r5, 24U);
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x004AEE24U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r14)) {
                return Oot3dAotMemoryFault(context, 0x004AEE24U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xFFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AEE28U, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = r14;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = r12;
            r5 = r14 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r1 = r1 + operand;
        }
        {
            r1 = Oot3dAotAsr(r1, 2U);
        }
        {
            r5 = Oot3dAotAsr(r5, 1U);
        }
        {
            r6 = r5 | Oot3dAotLsl(r1, 8U);
        }
        {
            r3 = r6 | Oot3dAotLsl(r3, 16U);
        }
        {
            r2 = r3 | Oot3dAotLsl(r2, 24U);
        }
        {
            const uint32_t operand = 0x00000100U;
            r6 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r6;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x004AEE58U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r11)) {
                return Oot3dAotMemoryFault(context, 0x004AEE58U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x1FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AEE5CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = r3;
            r12 = r12 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 1U);
            r12 = r12 + operand;
        }
        {
            const uint32_t operand = r14;
            r6 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r12 = r12 + operand;
        }
        {
            r12 = Oot3dAotAsr(r12, 2U);
        }
        {
            r6 = Oot3dAotAsr(r6, 1U);
        }
        {
            r7 = r6 | Oot3dAotLsl(r12, 8U);
        }
        {
            r5 = r7 | Oot3dAotLsl(r5, 16U);
        }
        {
            r1 = r5 | Oot3dAotLsl(r1, 24U);
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x004AEE8CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x004AEE8CU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xFFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AEE90U, address);
            }
            r4 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x104U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x004AEE94U, address);
            }
        }
        {
            const uint32_t operand = r4;
            r14 = r14 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r14 = r14 + operand;
        }
        {
            const uint32_t operand = r3;
            r5 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r14 = r14 + operand;
        }
        {
            r14 = Oot3dAotAsr(r14, 2U);
        }
        {
            r5 = Oot3dAotAsr(r5, 1U);
        }
        {
            r7 = r5 | Oot3dAotLsl(r14, 8U);
        }
        {
            r6 = r7 | Oot3dAotLsl(r6, 16U);
        }
        {
            r12 = r6 | Oot3dAotLsl(r12, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x100U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x004AEEC0U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r0 + 0xFFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AEEC4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x104U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004AEEC8U, address);
            }
        }
        {
            const uint32_t operand = r2;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r4;
            r6 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r3 = r3 + operand;
        }
        {
            r3 = Oot3dAotAsr(r3, 2U);
        }
        {
            r6 = Oot3dAotAsr(r6, 1U);
        }
        {
            r7 = r6 | Oot3dAotLsl(r3, 8U);
        }
        {
            r5 = r7 | Oot3dAotLsl(r5, 16U);
        }
        {
            r14 = r5 | Oot3dAotLsl(r14, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x100U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r14))) {
                return Oot3dAotMemoryFault(context, 0x004AEEF4U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r0 + 0xFFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AEEF8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x104U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x004AEEFCU, address);
            }
        }
        {
            const uint32_t operand = r1;
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = r2;
            r5 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r4 = r4 + operand;
        }
        {
            r4 = Oot3dAotAsr(r4, 2U);
        }
        {
            r5 = Oot3dAotAsr(r5, 1U);
        }
        {
            r7 = r5 | Oot3dAotLsl(r4, 8U);
        }
        {
            r6 = r7 | Oot3dAotLsl(r6, 16U);
        }
        {
            r3 = r6 | Oot3dAotLsl(r3, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x100U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x004AEF28U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x1FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AEF2CU, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = r1;
            r3 = r12 + operand;
        }
        {
            const uint32_t operand = r12;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r1 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r3 = r3 + operand;
        }
        {
            r3 = Oot3dAotAsr(r3, 1U);
        }
        {
            r1 = Oot3dAotAsr(r1, 2U);
        }
        {
            r1 = r3 | Oot3dAotLsl(r1, 8U);
        }
        {
            r1 = r1 | Oot3dAotLsl(r5, 16U);
        }
        {
            r1 = r1 | Oot3dAotLsl(r4, 24U);
        }
        {
            const uint32_t operand = 0x00000200U;
            r2 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r2;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x004AEF5CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r14)) {
                return Oot3dAotMemoryFault(context, 0x004AEF5CU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x00000500U;
            r11 = r0 - operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x004AEF64U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x004AEF64U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x004AEF64U,
                                           firstAddress + 8U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004AEF64U,
                                           firstAddress + 12U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004AEF64U,
                                           firstAddress + 16U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x004AEF64U,
                                           firstAddress + 20U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004AEF64U,
                                           firstAddress + 24U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r10 = value10;
            r12 = value12;
            r13 = r13 + 28U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_cfg_residue_004AF2D8_004AF2D8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004AF2D8U:
        goto block_004AF2D8;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004AF2D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004AF2D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004AF2D8U);
        }
        {
            r12 = Oot3dAotLsr(r2, 24U);
        }
        {
            const uint32_t operand = r12;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = r3;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r2 = r2 + operand;
        }
        {
            r14 = Oot3dAotLsl(r6, 8U);
        }
        {
            r14 = Oot3dAotLsr(r14, 24U);
        }
        {
            const uint32_t operand = r14;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r3 = r3 + operand;
        }
        {
            r6 = Oot3dAotLsr(r6, 24U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = r6;
            r12 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r2 = r2 + operand;
        }
        {
            r2 = Oot3dAotAsr(r2, 2U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 1U);
            r12 = r12 + operand;
        }
        {
            r1 = Oot3dAotAsr(r1, 2U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r3 = r3 + operand;
        }
        {
            r3 = Oot3dAotAsr(r3, 2U);
        }
        {
            r8 = r1 | Oot3dAotLsl(r2, 8U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r12 = r12 + operand;
        }
        {
            r12 = Oot3dAotAsr(r12, 2U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r3, 16U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r12, 24U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004AF334U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004AF338U, address);
            }
        }
        {
            const uint32_t operand = 0x00000100U;
            r7 = r11 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF340U, address);
            }
            r7 = value;
        }
        {
            r0 = r3 | Oot3dAotLsl(r12, 8U);
        }
        {
            r8 = r7 & 0x000000FFU;
        }
        {
            r9 = Oot3dAotLsl(r7, 16U);
        }
        {
            r9 = Oot3dAotLsr(r9, 24U);
        }
        {
            const uint32_t operand = r8;
            r14 = r14 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 1U);
            r14 = r14 + operand;
        }
        {
            r10 = Oot3dAotLsl(r7, 8U);
        }
        {
            r10 = Oot3dAotLsr(r10, 24U);
        }
        {
            const uint32_t operand = r9;
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 1U);
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = r10;
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r7, 24U);
            r7 = r9 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r14 = r14 + operand;
        }
        {
            r14 = Oot3dAotAsr(r14, 2U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 1U);
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 1U);
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r6 = r6 + operand;
        }
        {
            r6 = Oot3dAotAsr(r6, 2U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r8 = r8 + operand;
        }
        {
            r8 = Oot3dAotAsr(r8, 2U);
        }
        {
            r9 = r14 | Oot3dAotLsl(r6, 8U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r7 = r7 + operand;
        }
        {
            r7 = Oot3dAotAsr(r7, 2U);
        }
        {
            r9 = r9 | Oot3dAotLsl(r8, 16U);
        }
        {
            r7 = r9 | Oot3dAotLsl(r7, 24U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x004AF3A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xFFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF3ACU, address);
            }
            r7 = value;
        }
        {
            r10 = r12 | Oot3dAotLsl(r14, 8U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r6, 16U);
        }
        {
            const uint32_t operand = r4;
            r4 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 1U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r4 = r4 + operand;
        }
        {
            r4 = Oot3dAotAsr(r4, 2U);
        }
        {
            r9 = r4 | Oot3dAotLsl(r1, 8U);
        }
        {
            r9 = r9 | Oot3dAotLsl(r2, 16U);
        }
        {
            r8 = r10 | Oot3dAotLsl(r8, 24U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x104U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004AF3D4U, address);
            }
        }
        {
            r9 = r9 | Oot3dAotLsl(r3, 24U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x100U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004AF3DCU, address);
            }
            r11 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r11 + 0xFFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF3E0U, address);
            }
            r8 = value;
        }
        {
            r0 = r0 | Oot3dAotLsl(r14, 16U);
        }
        {
            r6 = r0 | Oot3dAotLsl(r6, 24U);
        }
        {
            const uint32_t operand = r5;
            r5 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r7, 1U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r5 = r5 + operand;
        }
        {
            r5 = Oot3dAotAsr(r5, 2U);
        }
        {
            r10 = r5 | Oot3dAotLsl(r4, 8U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r1, 16U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r2, 24U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x104U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x004AF408U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x100U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004AF40CU, address);
            }
            r11 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r11 + 0xFFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF410U, address);
            }
            r6 = value;
        }
        {
            r2 = r2 | Oot3dAotLsl(r3, 8U);
        }
        {
            r2 = r2 | Oot3dAotLsl(r12, 16U);
        }
        {
            const uint32_t operand = r7;
            r7 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 1U);
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r7 = r7 + operand;
        }
        {
            r7 = Oot3dAotAsr(r7, 2U);
        }
        {
            r0 = r7 | Oot3dAotLsl(r5, 8U);
        }
        {
            r0 = r0 | Oot3dAotLsl(r4, 16U);
        }
        {
            r1 = r0 | Oot3dAotLsl(r1, 24U);
        }
        {
            r2 = r2 | Oot3dAotLsl(r14, 24U);
        }
        {
            const uint32_t operand = 0x00000100U;
            r11 = r11 + operand;
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x004AF440U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x004AF440U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xFFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF444U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = r8;
            r3 = r2 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 1U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r3 = r3 + operand;
        }
        {
            r3 = Oot3dAotAsr(r3, 2U);
        }
        {
            r12 = r3 | Oot3dAotLsl(r7, 8U);
        }
        {
            r12 = r12 | Oot3dAotLsl(r5, 16U);
        }
        {
            r12 = r12 | Oot3dAotLsl(r4, 24U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x100U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x004AF464U, address);
            }
            r11 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF468U, address);
            }
            r8 = value;
        }
        {
            const uint32_t updatedAddress = r11 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004AF46CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xFFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF470U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = r6;
            r14 = r12 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r14 = r14 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r14 = r14 + operand;
        }
        {
            r14 = Oot3dAotAsr(r14, 2U);
        }
        {
            r4 = r14 | Oot3dAotLsl(r3, 8U);
        }
        {
            r4 = r4 | Oot3dAotLsl(r7, 16U);
        }
        {
            r4 = r4 | Oot3dAotLsl(r5, 24U);
        }
        {
            const uint32_t operand = 0x00000100U;
            r11 = r11 + operand;
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x004AF494U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r9)) {
                return Oot3dAotMemoryFault(context, 0x004AF494U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xFFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF498U, address);
            }
            r4 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = r2;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r2 = r2 + operand;
        }
        {
            r2 = Oot3dAotAsr(r2, 2U);
        }
        {
            r5 = r2 | Oot3dAotLsl(r14, 8U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r3, 16U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r7, 24U);
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004AF4BCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r10)) {
                return Oot3dAotMemoryFault(context, 0x004AF4BCU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xFFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF4C0U, address);
            }
            r5 = value;
        }
        {
            const uint32_t operand = r12;
            r12 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r12 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r12 = r12 + operand;
        }
        {
            r12 = Oot3dAotAsr(r12, 2U);
        }
        {
            r2 = r12 | Oot3dAotLsl(r2, 8U);
        }
        {
            r2 = r2 | Oot3dAotLsl(r14, 16U);
        }
        {
            r2 = r2 | Oot3dAotLsl(r3, 24U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x100U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x004AF4E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x104U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004AF4E4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000600U;
            r11 = r11 - operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x004AF4F0U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x004AF4F0U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x004AF4F0U,
                                           firstAddress + 8U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004AF4F0U,
                                           firstAddress + 12U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004AF4F0U,
                                           firstAddress + 16U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x004AF4F0U,
                                           firstAddress + 20U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004AF4F0U,
                                           firstAddress + 24U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r10 = value10;
            r12 = value12;
            r13 = r13 + 28U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_cfg_residue_004AF514_004AF514(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004AF514U:
        goto block_004AF514;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004AF514:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004AF514U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004AF514U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            r12 = Oot3dAotAsr(r1, 1U);
        }
        {
            r1 = Oot3dAotLsl(r2, 8U);
        }
        {
            r1 = Oot3dAotLsr(r1, 24U);
        }
        {
            const uint32_t operand = r1;
            r14 = r11 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r14 = r14 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004AF52CU, address);
            }
        }
        {
            r10 = Oot3dAotAsr(r14, 1U);
        }
        {
            r2 = Oot3dAotLsr(r2, 24U);
        }
        {
            const uint32_t operand = r2;
            r14 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r14 = r14 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x004AF540U, address);
            }
        }
        {
            r11 = Oot3dAotAsr(r14, 1U);
        }
        {
            const uint32_t operand = 0x00000100U;
            r9 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x004AF54CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004AF550U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF554U, address);
            }
            r4 = value;
        }
        {
            r3 = r4 & 0x000000FFU;
        }
        {
            const uint32_t operand = r3;
            r14 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF560U, address);
            }
            r10 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r14 = r14 + operand;
        }
        {
            r5 = Oot3dAotAsr(r14, 1U);
        }
        {
            r12 = r12 | Oot3dAotLsl(r10, 8U);
        }
        {
            r12 = r12 | Oot3dAotLsl(r11, 16U);
        }
        {
            r12 = r12 | Oot3dAotLsl(r5, 24U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x004AF578U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x004AF57CU, address);
            }
        }
        {
            r12 = Oot3dAotLsl(r4, 16U);
        }
        {
            r12 = Oot3dAotLsr(r12, 24U);
        }
        {
            const uint32_t operand = r12;
            r14 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r14 = r14 + operand;
        }
        {
            r8 = Oot3dAotAsr(r14, 1U);
        }
        {
            r14 = Oot3dAotLsl(r4, 8U);
        }
        {
            r14 = Oot3dAotLsr(r14, 24U);
        }
        {
            const uint32_t operand = r14;
            r5 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            r6 = Oot3dAotAsr(r5, 1U);
        }
        {
            r4 = Oot3dAotLsr(r4, 24U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004AF5ACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF5B0U, address);
            }
            r8 = value;
        }
        {
            const uint32_t operand = r4;
            r5 = r14 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            r7 = Oot3dAotAsr(r5, 1U);
        }
        {
            r5 = r8 & 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF5C4U, address);
            }
            r10 = value;
        }
        {
            const uint32_t operand = r5;
            r9 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r9 = r9 + operand;
        }
        {
            r10 = r10 | Oot3dAotLsl(r6, 8U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r7, 16U);
        }
        {
            r9 = Oot3dAotAsr(r9, 1U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r9, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004AF5E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF5E4U, address);
            }
            r10 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF5E8U, address);
            }
            r11 = value;
        }
        {
            const uint32_t operand = r1;
            r10 = r10 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r11, 1U);
            r10 = r10 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r10 = r10 + operand;
        }
        {
            r10 = Oot3dAotAsr(r10, 2U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004AF5FCU, address);
            }
        }
        {
            const uint32_t operand = r2;
            r10 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r10 = r10 + operand;
        }
        {
            const uint32_t operand = r3;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r10 = r10 + operand;
        }
        {
            r10 = Oot3dAotAsr(r10, 2U);
        }
        {
            r1 = Oot3dAotAsr(r1, 2U);
        }
        {
            const uint32_t operand = 0x0000000CU;
            r11 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x004AF624U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r10)) {
                return Oot3dAotMemoryFault(context, 0x004AF624U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = r12;
            r1 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000010U;
            r10 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r10;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x004AF630U,
                                           firstAddress + 0U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004AF630U,
                                           firstAddress + 4U);
            }
            r2 = value2;
            r10 = value10;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r1 = r1 + operand;
        }
        {
            r2 = r10 | Oot3dAotLsl(r2, 8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF63CU, address);
            }
            r10 = value;
        }
        {
            const uint32_t operand = 0x00000002U;
            r1 = r1 + operand;
        }
        {
            r1 = Oot3dAotAsr(r1, 2U);
        }
        {
            r2 = r2 | Oot3dAotLsl(r10, 16U);
        }
        {
            r2 = r2 | Oot3dAotLsl(r1, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x100U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x004AF650U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = r14;
            r2 = r3 + operand;
        }
        {
            const uint32_t operand = r4;
            r3 = r12 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 1U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r5;
            r12 = r14 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r12 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r12 = r12 + operand;
        }
        {
            r14 = Oot3dAotAsr(r12, 2U);
        }
        {
            r12 = Oot3dAotLsl(r8, 16U);
        }
        {
            r12 = Oot3dAotLsr(r12, 24U);
        }
        {
            const uint32_t operand = r12;
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r2 = r2 + operand;
        }
        {
            r2 = Oot3dAotAsr(r2, 2U);
        }
        {
            r3 = Oot3dAotAsr(r3, 2U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 1U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r4 = r4 + operand;
        }
        {
            r10 = r2 | Oot3dAotLsl(r3, 8U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r14, 16U);
        }
        {
            r4 = Oot3dAotAsr(r4, 2U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r4, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004AF6A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF6ACU, address);
            }
            r10 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF6B0U, address);
            }
            r11 = value;
        }
        {
            r10 = r10 | Oot3dAotLsl(r11, 8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF6B8U, address);
            }
            r11 = value;
        }
        {
            r10 = r10 | Oot3dAotLsl(r11, 16U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF6C0U, address);
            }
            r11 = value;
        }
        {
            r10 = r10 | Oot3dAotLsl(r11, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x100U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004AF6C8U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = r12;
            r10 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r10 = r10 + operand;
        }
        {
            r11 = Oot3dAotAsr(r10, 1U);
        }
        {
            r10 = r6 | Oot3dAotLsl(r7, 8U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r9, 16U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r11, 24U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x004AF6E4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004AF6E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF6ECU, address);
            }
            r10 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF6F0U, address);
            }
            r11 = value;
        }
        {
            r10 = r10 | Oot3dAotLsl(r11, 8U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r1, 16U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r2, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x100U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004AF700U, address);
            }
            r0 = updatedAddress;
        }
        {
            r10 = Oot3dAotLsl(r8, 8U);
        }
        {
            r10 = Oot3dAotLsr(r10, 24U);
        }
        {
            const uint32_t operand = r10;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r5 = r5 + operand;
        }
        {
            r11 = Oot3dAotAsr(r5, 2U);
        }
        {
            r5 = r3 | Oot3dAotLsl(r14, 8U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r4, 16U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r11, 24U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x004AF728U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x004AF72CU, address);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r11 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r11;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004AF734U,
                                           firstAddress + 0U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x004AF734U,
                                           firstAddress + 4U);
            }
            r5 = value5;
            r11 = value11;
        }
        {
            r5 = r11 | Oot3dAotLsl(r5, 8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF73CU, address);
            }
            r11 = value;
        }
        {
            r5 = r5 | Oot3dAotLsl(r11, 16U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r6, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x100U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x004AF748U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = r10;
            r5 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            r11 = Oot3dAotAsr(r5, 1U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x004AF758U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF75CU, address);
            }
            r11 = value;
        }
        {
            r5 = r7 | Oot3dAotLsl(r9, 8U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r11, 16U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF768U, address);
            }
            r11 = value;
        }
        {
            r5 = r5 | Oot3dAotLsl(r11, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x004AF770U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF774U, address);
            }
            r11 = value;
        }
        {
            r5 = r11 | Oot3dAotLsl(r1, 8U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r2, 16U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r3, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x100U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x004AF784U, address);
            }
            r0 = updatedAddress;
        }
        {
            r5 = Oot3dAotLsr(r8, 24U);
        }
        {
            const uint32_t operand = r5;
            r12 = r12 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF790U, address);
            }
            r11 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 1U);
            r12 = r12 + operand;
        }
        {
            r8 = r14 | Oot3dAotLsl(r4, 8U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r11, 16U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r12 = r12 + operand;
        }
        {
            r12 = Oot3dAotAsr(r12, 2U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r12, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004AF7ACU, address);
            }
        }
        {
            const uint32_t operand = 0x00000018U;
            r11 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r11;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x004AF7B4U,
                                           firstAddress + 0U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x004AF7B4U,
                                           firstAddress + 4U);
            }
            r8 = value8;
            r11 = value11;
        }
        {
            r1 = r1 | Oot3dAotLsl(r2, 8U);
        }
        {
            r8 = r11 | Oot3dAotLsl(r8, 8U);
        }
        {
            r6 = r8 | Oot3dAotLsl(r6, 16U);
        }
        {
            r6 = r6 | Oot3dAotLsl(r7, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x100U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x004AF7C8U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF7CCU, address);
            }
            r11 = value;
        }
        {
            const uint32_t operand = r5;
            r6 = r10 + operand;
        }
        {
            r7 = r9 | Oot3dAotLsl(r11, 8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF7D8U, address);
            }
            r11 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            r1 = r1 | Oot3dAotLsl(r3, 16U);
        }
        {
            r1 = r1 | Oot3dAotLsl(r14, 24U);
        }
        {
            r6 = Oot3dAotAsr(r6, 1U);
        }
        {
            r7 = r7 | Oot3dAotLsl(r11, 16U);
        }
        {
            r6 = r7 | Oot3dAotLsl(r6, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x100U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004AF7F4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x004AF7F8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000700U;
            r11 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r11 + 0xCU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF800U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004AF804U, address);
            }
            r11 = value;
        }
        {
            const uint32_t operand = r1;
            r1 = r10 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 1U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r1 = r1 + operand;
        }
        {
            r1 = Oot3dAotAsr(r1, 2U);
        }
        {
            r2 = r4 | Oot3dAotLsl(r11, 8U);
        }
        {
            r2 = r2 | Oot3dAotLsl(r12, 16U);
        }
        {
            r1 = r2 | Oot3dAotLsl(r1, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x104U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004AF824U, address);
            }
        }
        {
            const uint32_t operand = 0x00000030U;
            r13 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000600U;
            r11 = r0 - operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x004AF830U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x004AF830U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x004AF830U,
                                           firstAddress + 8U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004AF830U,
                                           firstAddress + 12U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004AF830U,
                                           firstAddress + 16U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x004AF830U,
                                           firstAddress + 20U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004AF830U,
                                           firstAddress + 24U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r10 = value10;
            r12 = value12;
            r13 = r13 + 28U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_004b0c24_004B0C24(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004B0C24U:
        goto block_004B0C24;
    case 0x004B0C48U:
        goto block_004B0C48;
    case 0x004B0C7CU:
        goto block_004B0C7C;
    case 0x004B0D54U:
        goto block_004B0D54;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004B0C24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B0C24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B0C24U);
        }
        {
            const uint32_t firstAddress = r13 - 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004B0C24U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004B0C24U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r14)) {
                return Oot3dAotMemoryFault(context, 0x004B0C24U,
                                           firstAddress + 8U);
            }
            r13 = r13 - 12U;
        }
        {
            const uint32_t updatedAddress = 0x004B0C30U + 0xA84U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B0C28U, address);
            }
            r12 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004B0C2CU,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004B0C2CU,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B0C2CU,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B0C2CU,
                                           firstAddress + 12U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B0C30U, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        goto block_004B0C48;
    }
block_004B0C48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B0C48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B0C48U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r3, 8U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 24U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 8U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 24U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 8U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 24U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 8U);
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 24U);
            r6 = r6 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        goto block_004B0C7C;
    }
block_004B0C7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B0C7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B0C7CU);
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x004B0C7CU,
                                           firstAddress + 0U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x004B0C7CU,
                                           firstAddress + 4U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x004B0C7CU,
                                           firstAddress + 8U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004B0C7CU,
                                           firstAddress + 12U);
            }
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B0C80U, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r7, 8U);
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 24U);
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r8, 8U);
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 24U);
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r9, 8U);
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 24U);
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r10, 8U);
            r10 = r10 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 24U);
            r10 = r10 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            const uint32_t operand = r7;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r8;
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = r9;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = r10;
            r6 = r6 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r3)) {
                return Oot3dAotMemoryFault(context, 0x004B0CDCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x004B0CDCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004B0CDCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004B0CDCU,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004B0CE4U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004B0CE4U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B0CE4U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B0CE4U,
                                           firstAddress + 12U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B0CE8U, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r3, 8U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 24U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 8U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 24U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 8U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 24U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 8U);
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 24U);
            r6 = r6 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            const uint32_t operand = r3;
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = r4;
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = r5;
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = r6;
            r10 = r10 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r7)) {
                return Oot3dAotMemoryFault(context, 0x004B0D44U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r8)) {
                return Oot3dAotMemoryFault(context, 0x004B0D44U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r9)) {
                return Oot3dAotMemoryFault(context, 0x004B0D44U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r10)) {
                return Oot3dAotMemoryFault(context, 0x004B0D44U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            Oot3dAotSetSubtractFlags(flags, r2, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r2 = r2 - operand;
        }
        if (!(flags.Z())) { goto block_004B0C7C; }
        goto block_004B0D54;
    }
block_004B0D54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B0D54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B0D54U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B0D54U,
                                           firstAddress + 0U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B0D54U,
                                           firstAddress + 4U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004B0D54U,
                                           firstAddress + 8U);
            }
            r5 = value5;
            r6 = value6;
            r13 = r13 + 12U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_004b0f14_004B0F14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004B0F14U:
        goto block_004B0F14;
    case 0x004B0F40U:
        goto block_004B0F40;
    case 0x004B0F90U:
        goto block_004B0F90;
    case 0x004B10A8U:
        goto block_004B10A8;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004B0F14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B0F14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B0F14U);
        }
        {
            const uint32_t firstAddress = r13 - 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004B0F14U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004B0F14U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r11)) {
                return Oot3dAotMemoryFault(context, 0x004B0F14U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r14)) {
                return Oot3dAotMemoryFault(context, 0x004B0F14U,
                                           firstAddress + 12U);
            }
            r13 = r13 - 16U;
        }
        {
            const uint32_t updatedAddress = 0x004B0F20U + 0x794U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B0F18U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004B0F20U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004B0F20U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B0F20U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B0F20U,
                                           firstAddress + 12U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B0F24U, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        goto block_004B0F40;
    }
block_004B0F40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B0F40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B0F40U);
        }
        {
            r11 = Oot3dAotLsr(r3, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r3, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 24U);
            r3 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r4, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 24U);
            r4 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r5, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 24U);
            r5 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r6, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 24U);
            r6 = r11 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        goto block_004B0F90;
    }
block_004B0F90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B0F90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B0F90U);
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x004B0F90U,
                                           firstAddress + 0U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x004B0F90U,
                                           firstAddress + 4U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x004B0F90U,
                                           firstAddress + 8U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004B0F90U,
                                           firstAddress + 12U);
            }
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B0F94U, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            r11 = Oot3dAotLsr(r7, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r7, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 24U);
            r7 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r8, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r8, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 24U);
            r8 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r9, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r9, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 24U);
            r9 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r10, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r10, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 24U);
            r10 = r11 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            const uint32_t operand = r7;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r8;
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = r9;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = r10;
            r6 = r6 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r3)) {
                return Oot3dAotMemoryFault(context, 0x004B1010U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x004B1010U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004B1010U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004B1010U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004B1018U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004B1018U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B1018U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B1018U,
                                           firstAddress + 12U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B101CU, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            r11 = Oot3dAotLsr(r3, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r3, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 24U);
            r3 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r4, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 24U);
            r4 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r5, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 24U);
            r5 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r6, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 24U);
            r6 = r11 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            const uint32_t operand = r3;
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = r4;
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = r5;
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = r6;
            r10 = r10 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r7)) {
                return Oot3dAotMemoryFault(context, 0x004B1098U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r8)) {
                return Oot3dAotMemoryFault(context, 0x004B1098U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r9)) {
                return Oot3dAotMemoryFault(context, 0x004B1098U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r10)) {
                return Oot3dAotMemoryFault(context, 0x004B1098U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            Oot3dAotSetSubtractFlags(flags, r2, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r2 = r2 - operand;
        }
        if (!(flags.Z())) { goto block_004B0F90; }
        goto block_004B10A8;
    }
block_004B10A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B10A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B10A8U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B10A8U,
                                           firstAddress + 0U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B10A8U,
                                           firstAddress + 4U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x004B10A8U,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004B10A8U,
                                           firstAddress + 12U);
            }
            r5 = value5;
            r6 = value6;
            r11 = value11;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_004b1264_004B1264(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004B1264U:
        goto block_004B1264;
    case 0x004B1298U:
        goto block_004B1298;
    case 0x004B12DCU:
        goto block_004B12DC;
    case 0x004B13ECU:
        goto block_004B13EC;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004B1264:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B1264U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B1264U);
        }
        {
            const uint32_t firstAddress = r13 - 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004B1264U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004B1264U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r11)) {
                return Oot3dAotMemoryFault(context, 0x004B1264U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r14)) {
                return Oot3dAotMemoryFault(context, 0x004B1264U,
                                           firstAddress + 12U);
            }
            r13 = r13 - 16U;
        }
        {
            const uint32_t updatedAddress = 0x004B1270U + 0x444U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B1268U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = 0x00000002U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 - 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B1270U, address);
            }
            r3 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004B1274U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B1274U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B1274U,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x004B1274U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r14 = value14;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 16U);
            r11 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r3, 8U);
            r11 = r11 + operand;
        }
        goto block_004B1298;
    }
block_004B1298:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B1298U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B1298U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 8U);
            r3 = r11 + operand;
        }
        {
            r4 = Oot3dAotLsr(r4, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 16U);
            r11 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 8U);
            r4 = r11 + operand;
        }
        {
            r5 = Oot3dAotLsr(r5, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 16U);
            r11 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 8U);
            r5 = r11 + operand;
        }
        {
            r6 = Oot3dAotLsr(r6, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 16U);
            r11 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 8U);
            r6 = r11 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        goto block_004B12DC;
    }
block_004B12DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B12DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B12DCU);
        }
        {
            const uint32_t updatedAddress = r0 - 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B12DCU, address);
            }
            r7 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x004B12E0U,
                                           firstAddress + 0U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x004B12E0U,
                                           firstAddress + 4U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004B12E0U,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x004B12E0U,
                                           firstAddress + 12U);
            }
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r14 = value14;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 16U);
            r11 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r7, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 8U);
            r7 = r11 + operand;
        }
        {
            r8 = Oot3dAotLsr(r8, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 16U);
            r11 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r8, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 8U);
            r8 = r11 + operand;
        }
        {
            r9 = Oot3dAotLsr(r9, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 16U);
            r11 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r9, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 8U);
            r9 = r11 + operand;
        }
        {
            r10 = Oot3dAotLsr(r10, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 16U);
            r11 = r10 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r10, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 8U);
            r10 = r11 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            const uint32_t operand = r7;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r8;
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = r9;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = r10;
            r6 = r6 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r3)) {
                return Oot3dAotMemoryFault(context, 0x004B1358U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x004B1358U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004B1358U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004B1358U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 - 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B1360U, address);
            }
            r3 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004B1364U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B1364U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B1364U,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x004B1364U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r14 = value14;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 16U);
            r11 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r3, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 8U);
            r3 = r11 + operand;
        }
        {
            r4 = Oot3dAotLsr(r4, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 16U);
            r11 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 8U);
            r4 = r11 + operand;
        }
        {
            r5 = Oot3dAotLsr(r5, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 16U);
            r11 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 8U);
            r5 = r11 + operand;
        }
        {
            r6 = Oot3dAotLsr(r6, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 16U);
            r11 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 8U);
            r6 = r11 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            const uint32_t operand = r3;
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = r4;
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = r5;
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = r6;
            r10 = r10 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r7)) {
                return Oot3dAotMemoryFault(context, 0x004B13DCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r8)) {
                return Oot3dAotMemoryFault(context, 0x004B13DCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r9)) {
                return Oot3dAotMemoryFault(context, 0x004B13DCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r10)) {
                return Oot3dAotMemoryFault(context, 0x004B13DCU,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            Oot3dAotSetSubtractFlags(flags, r2, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r2 = r2 - operand;
        }
        if (!(flags.Z())) { goto block_004B12DC; }
        goto block_004B13EC;
    }
block_004B13EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B13ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B13ECU);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B13ECU,
                                           firstAddress + 0U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B13ECU,
                                           firstAddress + 4U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x004B13ECU,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004B13ECU,
                                           firstAddress + 12U);
            }
            r5 = value5;
            r6 = value6;
            r11 = value11;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_004b157c_004B157C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004B157CU:
        goto block_004B157C;
    case 0x004B15B8U:
        goto block_004B15B8;
    case 0x004B15D8U:
        goto block_004B15D8;
    case 0x004B16B0U:
        goto block_004B16B0;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004B157C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B157CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B157CU);
        }
        {
            const uint32_t firstAddress = r13 - 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004B157CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004B157CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r14)) {
                return Oot3dAotMemoryFault(context, 0x004B157CU,
                                           firstAddress + 8U);
            }
            r13 = r13 - 12U;
        }
        {
            const uint32_t updatedAddress = 0x004B1588U + 0x12CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B1580U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 - 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B1588U, address);
            }
            r3 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004B158CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B158CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B158CU,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x004B158CU,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r14 = value14;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 8U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r4;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 24U);
            r4 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 8U);
            r4 = r4 + operand;
        }
        goto block_004B15B8;
    }
block_004B15B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B15B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B15B8U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 24U);
            r5 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 8U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 24U);
            r6 = r14 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 8U);
            r6 = r6 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        goto block_004B15D8;
    }
block_004B15D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B15D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B15D8U);
        }
        {
            const uint32_t updatedAddress = r0 - 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B15D8U, address);
            }
            r7 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x004B15DCU,
                                           firstAddress + 0U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x004B15DCU,
                                           firstAddress + 4U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004B15DCU,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x004B15DCU,
                                           firstAddress + 12U);
            }
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r14 = value14;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 8U);
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = r8;
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r8, 24U);
            r8 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 8U);
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r9, 24U);
            r9 = r10 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 8U);
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r10, 24U);
            r10 = r14 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 8U);
            r10 = r10 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            const uint32_t operand = r7;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r8;
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = r9;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = r10;
            r6 = r6 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r3)) {
                return Oot3dAotMemoryFault(context, 0x004B1638U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x004B1638U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004B1638U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004B1638U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 - 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B1640U, address);
            }
            r3 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004B1644U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B1644U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B1644U,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x004B1644U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r14 = value14;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 8U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r4;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 24U);
            r4 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 8U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 24U);
            r5 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 8U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 24U);
            r6 = r14 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 8U);
            r6 = r6 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            const uint32_t operand = r3;
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = r4;
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = r5;
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = r6;
            r10 = r10 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r7)) {
                return Oot3dAotMemoryFault(context, 0x004B16A0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r8)) {
                return Oot3dAotMemoryFault(context, 0x004B16A0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r9)) {
                return Oot3dAotMemoryFault(context, 0x004B16A0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r10)) {
                return Oot3dAotMemoryFault(context, 0x004B16A0U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            Oot3dAotSetSubtractFlags(flags, r2, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r2 = r2 - operand;
        }
        if (!(flags.Z())) { goto block_004B15D8; }
        goto block_004B16B0;
    }
block_004B16B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B16B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B16B0U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B16B0U,
                                           firstAddress + 0U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B16B0U,
                                           firstAddress + 4U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004B16B0U,
                                           firstAddress + 8U);
            }
            r5 = value5;
            r6 = value6;
            r13 = r13 + 12U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_cfg_residue_004B517C_004B517C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004B517CU:
        goto block_004B517C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004B517C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B517CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B517CU);
        }
        {
            const uint32_t updatedAddress = r11 + 0x200U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B517CU, address);
            }
            r6 = value;
            r11 = updatedAddress;
        }
        {
            const uint32_t operand = r12;
            r8 = r3 + operand;
        }
        {
            const uint32_t operand = r3;
            r3 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r3 = r3 + operand;
        }
        {
            r14 = Oot3dAotAsr(r3, 2U);
        }
        {
            const uint32_t operand = r9;
            r3 = r12 + operand;
        }
        {
            const uint32_t operand = r12;
            r12 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r8 = r8 + operand;
        }
        {
            r8 = Oot3dAotAsr(r8, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 1U);
            r12 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r3 = r3 + operand;
        }
        {
            r3 = Oot3dAotAsr(r3, 1U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r12 = r12 + operand;
        }
        {
            r8 = r8 | Oot3dAotLsl(r14, 8U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r3, 16U);
        }
        {
            r12 = Oot3dAotAsr(r12, 2U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r12, 24U);
        }
        {
            const uint32_t operand = 0x00000600U;
            r14 = r11 - operand;
        }
        {
            const uint32_t updatedAddress = r14 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004B51C8U, address);
            }
        }
        {
            const uint32_t operand = r6;
            r8 = r9 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r8 = r8 + operand;
        }
        {
            r14 = Oot3dAotAsr(r8, 1U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x200U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B51D8U, address);
            }
            r8 = value;
            r11 = updatedAddress;
        }
        {
            r3 = r3 | Oot3dAotLsl(r12, 8U);
        }
        {
            r3 = r3 | Oot3dAotLsl(r14, 16U);
        }
        {
            const uint32_t operand = r9;
            r9 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 1U);
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r9 = r9 + operand;
        }
        {
            r4 = Oot3dAotAsr(r9, 2U);
        }
        {
            const uint32_t operand = r8;
            r9 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r9 = r9 + operand;
        }
        {
            r5 = Oot3dAotAsr(r9, 1U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x200U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5200U, address);
            }
            r9 = value;
            r11 = updatedAddress;
        }
        {
            r3 = r3 | Oot3dAotLsl(r4, 24U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r7 = r11 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x004B520CU, address);
            }
        }
        {
            const uint32_t operand = r6;
            r6 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 1U);
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r6 = r6 + operand;
        }
        {
            r7 = r14 | Oot3dAotLsl(r4, 8U);
        }
        {
            r6 = Oot3dAotAsr(r6, 2U);
        }
        {
            r7 = r7 | Oot3dAotLsl(r5, 16U);
        }
        {
            const uint32_t operand = r9;
            r3 = r8 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r3 = r3 + operand;
        }
        {
            r7 = r7 | Oot3dAotLsl(r6, 24U);
        }
        {
            const uint32_t operand = 0x00000A00U;
            r12 = r11 - operand;
        }
        {
            const uint32_t updatedAddress = r12 + 0x5U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x004B5238U, address);
            }
        }
        {
            r12 = Oot3dAotAsr(r3, 1U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x200U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5240U, address);
            }
            r3 = value;
            r11 = updatedAddress;
        }
        {
            r14 = r5 | Oot3dAotLsl(r6, 8U);
        }
        {
            r14 = r14 | Oot3dAotLsl(r12, 16U);
        }
        {
            const uint32_t operand = r8;
            r8 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 1U);
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r8 = r8 + operand;
        }
        {
            r8 = Oot3dAotAsr(r8, 2U);
        }
        {
            const uint32_t operand = r3;
            r4 = r9 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r4 = r4 + operand;
        }
        {
            r14 = r14 | Oot3dAotLsl(r8, 24U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r5 = r11 - operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x004B526CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 - 0x1FBU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r14))) {
                return Oot3dAotMemoryFault(context, 0x004B5270U, address);
            }
        }
        {
            r5 = Oot3dAotAsr(r4, 1U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x200U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5278U, address);
            }
            r4 = value;
        }
        {
            r8 = r12 | Oot3dAotLsl(r8, 8U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r5, 16U);
        }
        {
            const uint32_t operand = r9;
            r9 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = r4;
            r12 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r9 = r9 + operand;
        }
        {
            r9 = Oot3dAotAsr(r9, 2U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r9, 24U);
        }
        {
            const uint32_t operand = r3;
            r3 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r12 = r12 + operand;
        }
        {
            r12 = Oot3dAotAsr(r12, 1U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r3 = r3 + operand;
        }
        {
            r9 = r5 | Oot3dAotLsl(r9, 8U);
        }
        {
            r9 = r9 | Oot3dAotLsl(r12, 16U);
        }
        {
            r3 = Oot3dAotAsr(r3, 2U);
        }
        {
            r9 = r9 | Oot3dAotLsl(r3, 24U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r7 = r11 - operand;
        }
        {
            const uint32_t updatedAddress = r7 - 0x3FBU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004B52C4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 - 0x1FBU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004B52C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 - 0x1FFU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r14))) {
                return Oot3dAotMemoryFault(context, 0x004B52CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004B52D0U, address);
            }
        }
        {
            r8 = r12 | Oot3dAotLsl(r3, 8U);
        }
        {
            const uint32_t updatedAddress = r11 - 0x1FFU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004B52D8U, address);
            }
        }
        {
            r9 = r4 | Oot3dAotLsl(r4, 8U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r4, 16U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r4, 24U);
        }
        {
            r9 = r9 | Oot3dAotLsl(r4, 16U);
        }
        {
            r9 = r9 | Oot3dAotLsl(r4, 24U);
        }
        {
            const uint32_t updatedAddress = r11 - 0x3FBU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004B52F0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 - 0x1FBU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004B52F4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r11 = r11 + operand;
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r8)) {
                return Oot3dAotMemoryFault(context, 0x004B52FCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r9)) {
                return Oot3dAotMemoryFault(context, 0x004B52FCU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x200U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004B5300U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x204U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004B5304U, address);
            }
        }
        {
            const uint32_t operand = 0x00000C00U;
            r11 = r11 - operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004B530CU,
                                           firstAddress + 0U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x004B530CU,
                                           firstAddress + 4U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004B530CU,
                                           firstAddress + 8U);
            }
            r3 = value3;
            r12 = value12;
            r13 = r13 + 12U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_cfg_residue_004B5324_004B5324(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004B5324U:
        goto block_004B5324;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004B5324:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B5324U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B5324U);
        }
        {
            const uint32_t updatedAddress = r0 - 0x201U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5324U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = r2;
            r4 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r4 = r4 + operand;
        }
        {
            r14 = Oot3dAotAsr(r4, 1U);
        }
        {
            r7 = r3 & 0x000000FFU;
        }
        {
            const uint32_t operand = r1;
            r4 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r4 = r4 + operand;
        }
        {
            r5 = Oot3dAotAsr(r4, 2U);
        }
        {
            r4 = Oot3dAotLsl(r3, 16U);
        }
        {
            r4 = Oot3dAotLsr(r4, 24U);
        }
        {
            const uint32_t operand = r4;
            r6 = r2 + operand;
        }
        {
            r8 = Oot3dAotLsl(r3, 8U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r7, 1U);
            r6 = r6 + operand;
        }
        {
            r9 = Oot3dAotLsr(r8, 24U);
        }
        {
            const uint32_t operand = r9;
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r6 = r6 + operand;
        }
        {
            r3 = Oot3dAotLsr(r3, 24U);
        }
        {
            const uint32_t operand = r3;
            r4 = r4 + operand;
        }
        {
            r6 = Oot3dAotAsr(r6, 2U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r7 = r7 + operand;
        }
        {
            r8 = r14 | Oot3dAotLsl(r5, 8U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r6, 16U);
        }
        {
            r7 = Oot3dAotAsr(r7, 2U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 1U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r4 = r4 + operand;
        }
        {
            r11 = r8 | Oot3dAotLsl(r7, 24U);
        }
        {
            r8 = Oot3dAotAsr(r4, 2U);
        }
        {
            r4 = r12 & 0x000000FFU;
        }
        {
            r10 = Oot3dAotLsl(r12, 16U);
        }
        {
            r10 = Oot3dAotLsr(r10, 24U);
        }
        {
            const uint32_t operand = r4;
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r9 = r9 + operand;
        }
        {
            r12 = Oot3dAotLsl(r12, 8U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r12, 24U);
            r12 = r4 + operand;
        }
        {
            const uint32_t operand = r10;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r9 = r9 + operand;
        }
        {
            r9 = Oot3dAotAsr(r9, 2U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 1U);
            r12 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r12 = r12 + operand;
        }
        {
            r3 = Oot3dAotAsr(r3, 2U);
        }
        {
            r4 = r8 | Oot3dAotLsl(r9, 8U);
        }
        {
            r3 = r4 | Oot3dAotLsl(r3, 16U);
        }
        {
            r12 = Oot3dAotAsr(r12, 2U);
        }
        {
            r12 = r3 | Oot3dAotLsl(r12, 24U);
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r11)) {
                return Oot3dAotMemoryFault(context, 0x004B53E4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r12)) {
                return Oot3dAotMemoryFault(context, 0x004B53E4U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x1FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B53E8U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = r12;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = r1;
            r3 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r2 = r2 + operand;
        }
        {
            r2 = Oot3dAotAsr(r2, 2U);
        }
        {
            r3 = Oot3dAotAsr(r3, 1U);
        }
        {
            r4 = r3 | Oot3dAotLsl(r2, 8U);
        }
        {
            r4 = r4 | Oot3dAotLsl(r14, 16U);
        }
        {
            r14 = r6 | Oot3dAotLsl(r7, 8U);
        }
        {
            r14 = r14 | Oot3dAotLsl(r8, 16U);
        }
        {
            r14 = r14 | Oot3dAotLsl(r9, 24U);
        }
        {
            r4 = r4 | Oot3dAotLsl(r5, 24U);
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x004B5424U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r14)) {
                return Oot3dAotMemoryFault(context, 0x004B5424U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x1FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5428U, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = r14;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = r12;
            r5 = r14 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r1 = r1 + operand;
        }
        {
            r1 = Oot3dAotAsr(r1, 2U);
        }
        {
            r5 = Oot3dAotAsr(r5, 1U);
        }
        {
            r6 = r5 | Oot3dAotLsl(r1, 8U);
        }
        {
            r3 = r6 | Oot3dAotLsl(r3, 16U);
        }
        {
            r2 = r3 | Oot3dAotLsl(r2, 24U);
        }
        {
            const uint32_t operand = 0x00000200U;
            r6 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r6;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x004B5458U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r11)) {
                return Oot3dAotMemoryFault(context, 0x004B5458U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x3FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B545CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t operand = r3;
            r12 = r12 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 1U);
            r12 = r12 + operand;
        }
        {
            const uint32_t operand = r14;
            r6 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r12 = r12 + operand;
        }
        {
            r12 = Oot3dAotAsr(r12, 2U);
        }
        {
            r6 = Oot3dAotAsr(r6, 1U);
        }
        {
            r7 = r6 | Oot3dAotLsl(r12, 8U);
        }
        {
            r5 = r7 | Oot3dAotLsl(r5, 16U);
        }
        {
            r1 = r5 | Oot3dAotLsl(r1, 24U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x004B548CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x004B548CU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x1FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5490U, address);
            }
            r4 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x204U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x004B5494U, address);
            }
        }
        {
            const uint32_t operand = r4;
            r14 = r14 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r14 = r14 + operand;
        }
        {
            const uint32_t operand = r3;
            r5 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r14 = r14 + operand;
        }
        {
            r14 = Oot3dAotAsr(r14, 2U);
        }
        {
            r5 = Oot3dAotAsr(r5, 1U);
        }
        {
            r7 = r5 | Oot3dAotLsl(r14, 8U);
        }
        {
            r6 = r7 | Oot3dAotLsl(r6, 16U);
        }
        {
            r12 = r6 | Oot3dAotLsl(r12, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x200U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x004B54C0U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B54C4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x204U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004B54C8U, address);
            }
        }
        {
            const uint32_t operand = r2;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r4;
            r6 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r3 = r3 + operand;
        }
        {
            r3 = Oot3dAotAsr(r3, 2U);
        }
        {
            r6 = Oot3dAotAsr(r6, 1U);
        }
        {
            r7 = r6 | Oot3dAotLsl(r3, 8U);
        }
        {
            r5 = r7 | Oot3dAotLsl(r5, 16U);
        }
        {
            r14 = r5 | Oot3dAotLsl(r14, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x200U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r14))) {
                return Oot3dAotMemoryFault(context, 0x004B54F4U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B54F8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x204U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x004B54FCU, address);
            }
        }
        {
            const uint32_t operand = r1;
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = r2;
            r5 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r4 = r4 + operand;
        }
        {
            r4 = Oot3dAotAsr(r4, 2U);
        }
        {
            r5 = Oot3dAotAsr(r5, 1U);
        }
        {
            r7 = r5 | Oot3dAotLsl(r4, 8U);
        }
        {
            r6 = r7 | Oot3dAotLsl(r6, 16U);
        }
        {
            r3 = r6 | Oot3dAotLsl(r3, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x200U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x004B5528U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x3FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B552CU, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = r1;
            r3 = r12 + operand;
        }
        {
            const uint32_t operand = r12;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r1 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r3 = r3 + operand;
        }
        {
            r3 = Oot3dAotAsr(r3, 1U);
        }
        {
            r1 = Oot3dAotAsr(r1, 2U);
        }
        {
            r1 = r3 | Oot3dAotLsl(r1, 8U);
        }
        {
            r1 = r1 | Oot3dAotLsl(r5, 16U);
        }
        {
            r1 = r1 | Oot3dAotLsl(r4, 24U);
        }
        {
            const uint32_t operand = 0x00000400U;
            r2 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r2;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x004B555CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r14)) {
                return Oot3dAotMemoryFault(context, 0x004B555CU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x00000A00U;
            r11 = r0 - operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x004B5564U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x004B5564U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x004B5564U,
                                           firstAddress + 8U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004B5564U,
                                           firstAddress + 12U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004B5564U,
                                           firstAddress + 16U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x004B5564U,
                                           firstAddress + 20U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004B5564U,
                                           firstAddress + 24U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r10 = value10;
            r12 = value12;
            r13 = r13 + 28U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_cfg_residue_004B58D8_004B58D8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004B58D8U:
        goto block_004B58D8;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004B58D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B58D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B58D8U);
        }
        {
            r12 = Oot3dAotLsr(r2, 24U);
        }
        {
            const uint32_t operand = r12;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = r3;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r2 = r2 + operand;
        }
        {
            r14 = Oot3dAotLsl(r6, 8U);
        }
        {
            r14 = Oot3dAotLsr(r14, 24U);
        }
        {
            const uint32_t operand = r14;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r3 = r3 + operand;
        }
        {
            r6 = Oot3dAotLsr(r6, 24U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = r6;
            r12 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r2 = r2 + operand;
        }
        {
            r2 = Oot3dAotAsr(r2, 2U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 1U);
            r12 = r12 + operand;
        }
        {
            r1 = Oot3dAotAsr(r1, 2U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r3 = r3 + operand;
        }
        {
            r3 = Oot3dAotAsr(r3, 2U);
        }
        {
            r8 = r1 | Oot3dAotLsl(r2, 8U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r12 = r12 + operand;
        }
        {
            r12 = Oot3dAotAsr(r12, 2U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r3, 16U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r12, 24U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004B5934U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004B5938U, address);
            }
        }
        {
            const uint32_t operand = 0x00000200U;
            r7 = r11 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5940U, address);
            }
            r7 = value;
        }
        {
            r0 = r3 | Oot3dAotLsl(r12, 8U);
        }
        {
            r8 = r7 & 0x000000FFU;
        }
        {
            r9 = Oot3dAotLsl(r7, 16U);
        }
        {
            r9 = Oot3dAotLsr(r9, 24U);
        }
        {
            const uint32_t operand = r8;
            r14 = r14 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 1U);
            r14 = r14 + operand;
        }
        {
            r10 = Oot3dAotLsl(r7, 8U);
        }
        {
            r10 = Oot3dAotLsr(r10, 24U);
        }
        {
            const uint32_t operand = r9;
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 1U);
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = r10;
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r7, 24U);
            r7 = r9 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r14 = r14 + operand;
        }
        {
            r14 = Oot3dAotAsr(r14, 2U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 1U);
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 1U);
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r6 = r6 + operand;
        }
        {
            r6 = Oot3dAotAsr(r6, 2U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r8 = r8 + operand;
        }
        {
            r8 = Oot3dAotAsr(r8, 2U);
        }
        {
            r9 = r14 | Oot3dAotLsl(r6, 8U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r7 = r7 + operand;
        }
        {
            r7 = Oot3dAotAsr(r7, 2U);
        }
        {
            r9 = r9 | Oot3dAotLsl(r8, 16U);
        }
        {
            r7 = r9 | Oot3dAotLsl(r7, 24U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x004B59A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x1FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B59ACU, address);
            }
            r7 = value;
        }
        {
            r10 = r12 | Oot3dAotLsl(r14, 8U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r6, 16U);
        }
        {
            const uint32_t operand = r4;
            r4 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 1U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r4 = r4 + operand;
        }
        {
            r4 = Oot3dAotAsr(r4, 2U);
        }
        {
            r9 = r4 | Oot3dAotLsl(r1, 8U);
        }
        {
            r9 = r9 | Oot3dAotLsl(r2, 16U);
        }
        {
            r8 = r10 | Oot3dAotLsl(r8, 24U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x204U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004B59D4U, address);
            }
        }
        {
            r9 = r9 | Oot3dAotLsl(r3, 24U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x200U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004B59DCU, address);
            }
            r11 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r11 + 0x1FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B59E0U, address);
            }
            r8 = value;
        }
        {
            r0 = r0 | Oot3dAotLsl(r14, 16U);
        }
        {
            r6 = r0 | Oot3dAotLsl(r6, 24U);
        }
        {
            const uint32_t operand = r5;
            r5 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r7, 1U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r5 = r5 + operand;
        }
        {
            r5 = Oot3dAotAsr(r5, 2U);
        }
        {
            r10 = r5 | Oot3dAotLsl(r4, 8U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r1, 16U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r2, 24U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x204U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x004B5A08U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x200U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004B5A0CU, address);
            }
            r11 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r11 + 0x1FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5A10U, address);
            }
            r6 = value;
        }
        {
            r2 = r2 | Oot3dAotLsl(r3, 8U);
        }
        {
            r2 = r2 | Oot3dAotLsl(r12, 16U);
        }
        {
            const uint32_t operand = r7;
            r7 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 1U);
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r7 = r7 + operand;
        }
        {
            r7 = Oot3dAotAsr(r7, 2U);
        }
        {
            r0 = r7 | Oot3dAotLsl(r5, 8U);
        }
        {
            r0 = r0 | Oot3dAotLsl(r4, 16U);
        }
        {
            r1 = r0 | Oot3dAotLsl(r1, 24U);
        }
        {
            r2 = r2 | Oot3dAotLsl(r14, 24U);
        }
        {
            const uint32_t operand = 0x00000200U;
            r11 = r11 + operand;
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x004B5A40U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x004B5A40U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x1FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5A44U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = r8;
            r3 = r2 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 1U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r3 = r3 + operand;
        }
        {
            r3 = Oot3dAotAsr(r3, 2U);
        }
        {
            r12 = r3 | Oot3dAotLsl(r7, 8U);
        }
        {
            r12 = r12 | Oot3dAotLsl(r5, 16U);
        }
        {
            r12 = r12 | Oot3dAotLsl(r4, 24U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x200U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x004B5A64U, address);
            }
            r11 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5A68U, address);
            }
            r8 = value;
        }
        {
            const uint32_t updatedAddress = r11 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004B5A6CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x1FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5A70U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = r6;
            r14 = r12 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r14 = r14 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r14 = r14 + operand;
        }
        {
            r14 = Oot3dAotAsr(r14, 2U);
        }
        {
            r4 = r14 | Oot3dAotLsl(r3, 8U);
        }
        {
            r4 = r4 | Oot3dAotLsl(r7, 16U);
        }
        {
            r4 = r4 | Oot3dAotLsl(r5, 24U);
        }
        {
            const uint32_t operand = 0x00000200U;
            r11 = r11 + operand;
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x004B5A94U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r9)) {
                return Oot3dAotMemoryFault(context, 0x004B5A94U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x1FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5A98U, address);
            }
            r4 = value;
        }
        {
            const uint32_t operand = 0x00000200U;
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = r2;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r2 = r2 + operand;
        }
        {
            r2 = Oot3dAotAsr(r2, 2U);
        }
        {
            r5 = r2 | Oot3dAotLsl(r14, 8U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r3, 16U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r7, 24U);
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004B5ABCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r10)) {
                return Oot3dAotMemoryFault(context, 0x004B5ABCU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x1FFU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5AC0U, address);
            }
            r5 = value;
        }
        {
            const uint32_t operand = r12;
            r12 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r12 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r12 = r12 + operand;
        }
        {
            r12 = Oot3dAotAsr(r12, 2U);
        }
        {
            r2 = r12 | Oot3dAotLsl(r2, 8U);
        }
        {
            r2 = r2 | Oot3dAotLsl(r14, 16U);
        }
        {
            r2 = r2 | Oot3dAotLsl(r3, 24U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x200U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x004B5AE0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x204U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004B5AE4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000C00U;
            r11 = r11 - operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x004B5AF0U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x004B5AF0U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x004B5AF0U,
                                           firstAddress + 8U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004B5AF0U,
                                           firstAddress + 12U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004B5AF0U,
                                           firstAddress + 16U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x004B5AF0U,
                                           firstAddress + 20U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004B5AF0U,
                                           firstAddress + 24U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r10 = value10;
            r12 = value12;
            r13 = r13 + 28U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_cfg_residue_004B5B14_004B5B14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004B5B14U:
        goto block_004B5B14;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004B5B14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B5B14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B5B14U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 + operand;
        }
        {
            r12 = Oot3dAotAsr(r1, 1U);
        }
        {
            r1 = Oot3dAotLsl(r2, 8U);
        }
        {
            r1 = Oot3dAotLsr(r1, 24U);
        }
        {
            const uint32_t operand = r1;
            r14 = r11 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r14 = r14 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004B5B2CU, address);
            }
        }
        {
            r10 = Oot3dAotAsr(r14, 1U);
        }
        {
            r2 = Oot3dAotLsr(r2, 24U);
        }
        {
            const uint32_t operand = r2;
            r14 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r14 = r14 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x004B5B40U, address);
            }
        }
        {
            r11 = Oot3dAotAsr(r14, 1U);
        }
        {
            const uint32_t operand = 0x00000200U;
            r9 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x004B5B4CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004B5B50U, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5B54U, address);
            }
            r4 = value;
        }
        {
            r3 = r4 & 0x000000FFU;
        }
        {
            const uint32_t operand = r3;
            r14 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5B60U, address);
            }
            r10 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r14 = r14 + operand;
        }
        {
            r5 = Oot3dAotAsr(r14, 1U);
        }
        {
            r12 = r12 | Oot3dAotLsl(r10, 8U);
        }
        {
            r12 = r12 | Oot3dAotLsl(r11, 16U);
        }
        {
            r12 = r12 | Oot3dAotLsl(r5, 24U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x004B5B78U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r12))) {
                return Oot3dAotMemoryFault(context, 0x004B5B7CU, address);
            }
        }
        {
            r12 = Oot3dAotLsl(r4, 16U);
        }
        {
            r12 = Oot3dAotLsr(r12, 24U);
        }
        {
            const uint32_t operand = r12;
            r14 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r14 = r14 + operand;
        }
        {
            r8 = Oot3dAotAsr(r14, 1U);
        }
        {
            r14 = Oot3dAotLsl(r4, 8U);
        }
        {
            r14 = Oot3dAotLsr(r14, 24U);
        }
        {
            const uint32_t operand = r14;
            r5 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            r6 = Oot3dAotAsr(r5, 1U);
        }
        {
            r4 = Oot3dAotLsr(r4, 24U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004B5BACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5BB0U, address);
            }
            r8 = value;
        }
        {
            const uint32_t operand = r4;
            r5 = r14 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            r7 = Oot3dAotAsr(r5, 1U);
        }
        {
            r5 = r8 & 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5BC4U, address);
            }
            r10 = value;
        }
        {
            const uint32_t operand = r5;
            r9 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r9 = r9 + operand;
        }
        {
            r10 = r10 | Oot3dAotLsl(r6, 8U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r7, 16U);
        }
        {
            r9 = Oot3dAotAsr(r9, 1U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r9, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004B5BE0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5BE4U, address);
            }
            r10 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5BE8U, address);
            }
            r11 = value;
        }
        {
            const uint32_t operand = r1;
            r10 = r10 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r11, 1U);
            r10 = r10 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r10 = r10 + operand;
        }
        {
            r10 = Oot3dAotAsr(r10, 2U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004B5BFCU, address);
            }
        }
        {
            const uint32_t operand = r2;
            r10 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r10 = r10 + operand;
        }
        {
            const uint32_t operand = r3;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r10 = r10 + operand;
        }
        {
            r10 = Oot3dAotAsr(r10, 2U);
        }
        {
            r1 = Oot3dAotAsr(r1, 2U);
        }
        {
            const uint32_t operand = 0x0000000CU;
            r11 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r11;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x004B5C24U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r10)) {
                return Oot3dAotMemoryFault(context, 0x004B5C24U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = r12;
            r1 = r2 + operand;
        }
        {
            const uint32_t operand = 0x00000010U;
            r10 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r10;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x004B5C30U,
                                           firstAddress + 0U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004B5C30U,
                                           firstAddress + 4U);
            }
            r2 = value2;
            r10 = value10;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r1 = r1 + operand;
        }
        {
            r2 = r10 | Oot3dAotLsl(r2, 8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5C3CU, address);
            }
            r10 = value;
        }
        {
            const uint32_t operand = 0x00000002U;
            r1 = r1 + operand;
        }
        {
            r1 = Oot3dAotAsr(r1, 2U);
        }
        {
            r2 = r2 | Oot3dAotLsl(r10, 16U);
        }
        {
            r2 = r2 | Oot3dAotLsl(r1, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x200U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x004B5C50U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = r14;
            r2 = r3 + operand;
        }
        {
            const uint32_t operand = r4;
            r3 = r12 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 1U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r5;
            r12 = r14 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 1U);
            r12 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r12 = r12 + operand;
        }
        {
            r14 = Oot3dAotAsr(r12, 2U);
        }
        {
            r12 = Oot3dAotLsl(r8, 16U);
        }
        {
            r12 = Oot3dAotLsr(r12, 24U);
        }
        {
            const uint32_t operand = r12;
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r2 = r2 + operand;
        }
        {
            r2 = Oot3dAotAsr(r2, 2U);
        }
        {
            r3 = Oot3dAotAsr(r3, 2U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 1U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r4 = r4 + operand;
        }
        {
            r10 = r2 | Oot3dAotLsl(r3, 8U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r14, 16U);
        }
        {
            r4 = Oot3dAotAsr(r4, 2U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r4, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004B5CA8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5CACU, address);
            }
            r10 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5CB0U, address);
            }
            r11 = value;
        }
        {
            r10 = r10 | Oot3dAotLsl(r11, 8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5CB8U, address);
            }
            r11 = value;
        }
        {
            r10 = r10 | Oot3dAotLsl(r11, 16U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5CC0U, address);
            }
            r11 = value;
        }
        {
            r10 = r10 | Oot3dAotLsl(r11, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x200U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004B5CC8U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = r12;
            r10 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r10 = r10 + operand;
        }
        {
            r11 = Oot3dAotAsr(r10, 1U);
        }
        {
            r10 = r6 | Oot3dAotLsl(r7, 8U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r9, 16U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r11, 24U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x004B5CE4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004B5CE8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5CECU, address);
            }
            r10 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5CF0U, address);
            }
            r11 = value;
        }
        {
            r10 = r10 | Oot3dAotLsl(r11, 8U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r1, 16U);
        }
        {
            r10 = r10 | Oot3dAotLsl(r2, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x200U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x004B5D00U, address);
            }
            r0 = updatedAddress;
        }
        {
            r10 = Oot3dAotLsl(r8, 8U);
        }
        {
            r10 = Oot3dAotLsr(r10, 24U);
        }
        {
            const uint32_t operand = r10;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r5 = r5 + operand;
        }
        {
            r11 = Oot3dAotAsr(r5, 2U);
        }
        {
            r5 = r3 | Oot3dAotLsl(r14, 8U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r4, 16U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r11, 24U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x004B5D28U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x004B5D2CU, address);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r11 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r11;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B5D34U,
                                           firstAddress + 0U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x004B5D34U,
                                           firstAddress + 4U);
            }
            r5 = value5;
            r11 = value11;
        }
        {
            r5 = r11 | Oot3dAotLsl(r5, 8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5D3CU, address);
            }
            r11 = value;
        }
        {
            r5 = r5 | Oot3dAotLsl(r11, 16U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r6, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x200U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x004B5D48U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t operand = r10;
            r5 = r12 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            r11 = Oot3dAotAsr(r5, 1U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x004B5D58U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5D5CU, address);
            }
            r11 = value;
        }
        {
            r5 = r7 | Oot3dAotLsl(r9, 8U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r11, 16U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5D68U, address);
            }
            r11 = value;
        }
        {
            r5 = r5 | Oot3dAotLsl(r11, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x004B5D70U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5D74U, address);
            }
            r11 = value;
        }
        {
            r5 = r11 | Oot3dAotLsl(r1, 8U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r2, 16U);
        }
        {
            r5 = r5 | Oot3dAotLsl(r3, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x200U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x004B5D84U, address);
            }
            r0 = updatedAddress;
        }
        {
            r5 = Oot3dAotLsr(r8, 24U);
        }
        {
            const uint32_t operand = r5;
            r12 = r12 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5D90U, address);
            }
            r11 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 1U);
            r12 = r12 + operand;
        }
        {
            r8 = r14 | Oot3dAotLsl(r4, 8U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r11, 16U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r12 = r12 + operand;
        }
        {
            r12 = Oot3dAotAsr(r12, 2U);
        }
        {
            r8 = r8 | Oot3dAotLsl(r12, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x004B5DACU, address);
            }
        }
        {
            const uint32_t operand = 0x00000018U;
            r11 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r11;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x004B5DB4U,
                                           firstAddress + 0U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x004B5DB4U,
                                           firstAddress + 4U);
            }
            r8 = value8;
            r11 = value11;
        }
        {
            r1 = r1 | Oot3dAotLsl(r2, 8U);
        }
        {
            r8 = r11 | Oot3dAotLsl(r8, 8U);
        }
        {
            r6 = r8 | Oot3dAotLsl(r6, 16U);
        }
        {
            r6 = r6 | Oot3dAotLsl(r7, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x200U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x004B5DC8U, address);
            }
            r0 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5DCCU, address);
            }
            r11 = value;
        }
        {
            const uint32_t operand = r5;
            r6 = r10 + operand;
        }
        {
            r7 = r9 | Oot3dAotLsl(r11, 8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5DD8U, address);
            }
            r11 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r6 = r6 + operand;
        }
        {
            r1 = r1 | Oot3dAotLsl(r3, 16U);
        }
        {
            r1 = r1 | Oot3dAotLsl(r14, 24U);
        }
        {
            r6 = Oot3dAotAsr(r6, 1U);
        }
        {
            r7 = r7 | Oot3dAotLsl(r11, 16U);
        }
        {
            r6 = r7 | Oot3dAotLsl(r6, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x200U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004B5DF4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x004B5DF8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000E00U;
            r11 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r11 + 0xCU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5E00U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B5E04U, address);
            }
            r11 = value;
        }
        {
            const uint32_t operand = r1;
            r1 = r10 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 1U);
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            r1 = r1 + operand;
        }
        {
            r1 = Oot3dAotAsr(r1, 2U);
        }
        {
            r2 = r4 | Oot3dAotLsl(r11, 8U);
        }
        {
            r2 = r2 | Oot3dAotLsl(r12, 16U);
        }
        {
            r1 = r2 | Oot3dAotLsl(r1, 24U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x204U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004B5E24U, address);
            }
        }
        {
            const uint32_t operand = 0x00000030U;
            r13 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000C00U;
            r11 = r0 - operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x004B5E30U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x004B5E30U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x004B5E30U,
                                           firstAddress + 8U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004B5E30U,
                                           firstAddress + 12U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004B5E30U,
                                           firstAddress + 16U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x004B5E30U,
                                           firstAddress + 20U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004B5E30U,
                                           firstAddress + 24U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
            r3 = value3;
            r10 = value10;
            r12 = value12;
            r13 = r13 + 28U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_004b7224_004B7224(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004B7224U:
        goto block_004B7224;
    case 0x004B7248U:
        goto block_004B7248;
    case 0x004B727CU:
        goto block_004B727C;
    case 0x004B7354U:
        goto block_004B7354;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004B7224:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B7224U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B7224U);
        }
        {
            const uint32_t firstAddress = r13 - 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004B7224U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004B7224U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r14)) {
                return Oot3dAotMemoryFault(context, 0x004B7224U,
                                           firstAddress + 8U);
            }
            r13 = r13 - 12U;
        }
        {
            const uint32_t updatedAddress = 0x004B7230U + 0xA84U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B7228U, address);
            }
            r12 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004B722CU,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004B722CU,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B722CU,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B722CU,
                                           firstAddress + 12U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B7230U, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        goto block_004B7248;
    }
block_004B7248:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B7248U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B7248U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r3, 8U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 24U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 8U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 24U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 8U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 24U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 8U);
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 24U);
            r6 = r6 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        goto block_004B727C;
    }
block_004B727C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B727CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B727CU);
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x004B727CU,
                                           firstAddress + 0U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x004B727CU,
                                           firstAddress + 4U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x004B727CU,
                                           firstAddress + 8U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004B727CU,
                                           firstAddress + 12U);
            }
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B7280U, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r0 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r7, 8U);
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 24U);
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r8, 8U);
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 24U);
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r9, 8U);
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 24U);
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r10, 8U);
            r10 = r10 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 24U);
            r10 = r10 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            const uint32_t operand = r7;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r8;
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = r9;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = r10;
            r6 = r6 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r3)) {
                return Oot3dAotMemoryFault(context, 0x004B72DCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x004B72DCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004B72DCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004B72DCU,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000200U;
            r1 = r1 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004B72E4U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004B72E4U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B72E4U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B72E4U,
                                           firstAddress + 12U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B72E8U, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r3, 8U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 24U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 8U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 24U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 8U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 24U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 8U);
            r6 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 24U);
            r6 = r6 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            const uint32_t operand = r3;
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = r4;
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = r5;
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = r6;
            r10 = r10 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r7)) {
                return Oot3dAotMemoryFault(context, 0x004B7344U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r8)) {
                return Oot3dAotMemoryFault(context, 0x004B7344U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r9)) {
                return Oot3dAotMemoryFault(context, 0x004B7344U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r10)) {
                return Oot3dAotMemoryFault(context, 0x004B7344U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000200U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            Oot3dAotSetSubtractFlags(flags, r2, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r2 = r2 - operand;
        }
        if (!(flags.Z())) { goto block_004B727C; }
        goto block_004B7354;
    }
block_004B7354:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B7354U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B7354U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B7354U,
                                           firstAddress + 0U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B7354U,
                                           firstAddress + 4U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004B7354U,
                                           firstAddress + 8U);
            }
            r5 = value5;
            r6 = value6;
            r13 = r13 + 12U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_004b7514_004B7514(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004B7514U:
        goto block_004B7514;
    case 0x004B7540U:
        goto block_004B7540;
    case 0x004B7590U:
        goto block_004B7590;
    case 0x004B76A8U:
        goto block_004B76A8;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004B7514:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B7514U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B7514U);
        }
        {
            const uint32_t firstAddress = r13 - 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004B7514U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004B7514U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r11)) {
                return Oot3dAotMemoryFault(context, 0x004B7514U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r14)) {
                return Oot3dAotMemoryFault(context, 0x004B7514U,
                                           firstAddress + 12U);
            }
            r13 = r13 - 16U;
        }
        {
            const uint32_t updatedAddress = 0x004B7520U + 0x794U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B7518U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004B7520U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004B7520U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B7520U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B7520U,
                                           firstAddress + 12U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B7524U, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        goto block_004B7540;
    }
block_004B7540:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B7540U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B7540U);
        }
        {
            r11 = Oot3dAotLsr(r3, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r3, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 24U);
            r3 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r4, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 24U);
            r4 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r5, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 24U);
            r5 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r6, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 24U);
            r6 = r11 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        goto block_004B7590;
    }
block_004B7590:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B7590U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B7590U);
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x004B7590U,
                                           firstAddress + 0U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x004B7590U,
                                           firstAddress + 4U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x004B7590U,
                                           firstAddress + 8U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004B7590U,
                                           firstAddress + 12U);
            }
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B7594U, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r0 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            r11 = Oot3dAotLsr(r7, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r7, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 24U);
            r7 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r8, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r8, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 24U);
            r8 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r9, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r9, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 24U);
            r9 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r10, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r10, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 24U);
            r10 = r11 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            const uint32_t operand = r7;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r8;
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = r9;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = r10;
            r6 = r6 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r3)) {
                return Oot3dAotMemoryFault(context, 0x004B7610U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x004B7610U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004B7610U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004B7610U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000200U;
            r1 = r1 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x004B7618U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004B7618U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B7618U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B7618U,
                                           firstAddress + 12U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B761CU, address);
            }
            r14 = value;
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            r11 = Oot3dAotLsr(r3, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r3, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 24U);
            r3 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r4, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 24U);
            r4 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r5, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 24U);
            r5 = r11 + operand;
        }
        {
            r11 = Oot3dAotLsr(r6, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 16U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 24U);
            r6 = r11 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            const uint32_t operand = r3;
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = r4;
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = r5;
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = r6;
            r10 = r10 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r7)) {
                return Oot3dAotMemoryFault(context, 0x004B7698U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r8)) {
                return Oot3dAotMemoryFault(context, 0x004B7698U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r9)) {
                return Oot3dAotMemoryFault(context, 0x004B7698U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r10)) {
                return Oot3dAotMemoryFault(context, 0x004B7698U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000200U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            Oot3dAotSetSubtractFlags(flags, r2, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r2 = r2 - operand;
        }
        if (!(flags.Z())) { goto block_004B7590; }
        goto block_004B76A8;
    }
block_004B76A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B76A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B76A8U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B76A8U,
                                           firstAddress + 0U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B76A8U,
                                           firstAddress + 4U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x004B76A8U,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004B76A8U,
                                           firstAddress + 12U);
            }
            r5 = value5;
            r6 = value6;
            r11 = value11;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_004b7864_004B7864(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004B7864U:
        goto block_004B7864;
    case 0x004B7898U:
        goto block_004B7898;
    case 0x004B78DCU:
        goto block_004B78DC;
    case 0x004B79ECU:
        goto block_004B79EC;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004B7864:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B7864U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B7864U);
        }
        {
            const uint32_t firstAddress = r13 - 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004B7864U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004B7864U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r11)) {
                return Oot3dAotMemoryFault(context, 0x004B7864U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r14)) {
                return Oot3dAotMemoryFault(context, 0x004B7864U,
                                           firstAddress + 12U);
            }
            r13 = r13 - 16U;
        }
        {
            const uint32_t updatedAddress = 0x004B7870U + 0x444U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B7868U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = 0x00000002U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 - 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B7870U, address);
            }
            r3 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004B7874U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B7874U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B7874U,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x004B7874U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r14 = value14;
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 16U);
            r11 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r3, 8U);
            r11 = r11 + operand;
        }
        goto block_004B7898;
    }
block_004B7898:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B7898U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B7898U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 8U);
            r3 = r11 + operand;
        }
        {
            r4 = Oot3dAotLsr(r4, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 16U);
            r11 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 8U);
            r4 = r11 + operand;
        }
        {
            r5 = Oot3dAotLsr(r5, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 16U);
            r11 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 8U);
            r5 = r11 + operand;
        }
        {
            r6 = Oot3dAotLsr(r6, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 16U);
            r11 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 8U);
            r6 = r11 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        goto block_004B78DC;
    }
block_004B78DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B78DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B78DCU);
        }
        {
            const uint32_t updatedAddress = r0 - 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B78DCU, address);
            }
            r7 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x004B78E0U,
                                           firstAddress + 0U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x004B78E0U,
                                           firstAddress + 4U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004B78E0U,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x004B78E0U,
                                           firstAddress + 12U);
            }
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r14 = value14;
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r0 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 16U);
            r11 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r7, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 8U);
            r7 = r11 + operand;
        }
        {
            r8 = Oot3dAotLsr(r8, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 16U);
            r11 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r8, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 8U);
            r8 = r11 + operand;
        }
        {
            r9 = Oot3dAotLsr(r9, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 16U);
            r11 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r9, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 8U);
            r9 = r11 + operand;
        }
        {
            r10 = Oot3dAotLsr(r10, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 16U);
            r11 = r10 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r10, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 8U);
            r10 = r11 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            const uint32_t operand = r7;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r8;
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = r9;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = r10;
            r6 = r6 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r3)) {
                return Oot3dAotMemoryFault(context, 0x004B7958U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x004B7958U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004B7958U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004B7958U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000200U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 - 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B7960U, address);
            }
            r3 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004B7964U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B7964U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B7964U,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x004B7964U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r14 = value14;
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 16U);
            r11 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r3, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 8U);
            r3 = r11 + operand;
        }
        {
            r4 = Oot3dAotLsr(r4, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 16U);
            r11 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 8U);
            r4 = r11 + operand;
        }
        {
            r5 = Oot3dAotLsr(r5, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 16U);
            r11 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 8U);
            r5 = r11 + operand;
        }
        {
            r6 = Oot3dAotLsr(r6, 16U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 16U);
            r11 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 8U);
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 8U);
            r6 = r11 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            const uint32_t operand = r3;
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = r4;
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = r5;
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = r6;
            r10 = r10 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r7)) {
                return Oot3dAotMemoryFault(context, 0x004B79DCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r8)) {
                return Oot3dAotMemoryFault(context, 0x004B79DCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r9)) {
                return Oot3dAotMemoryFault(context, 0x004B79DCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r10)) {
                return Oot3dAotMemoryFault(context, 0x004B79DCU,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000200U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            Oot3dAotSetSubtractFlags(flags, r2, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r2 = r2 - operand;
        }
        if (!(flags.Z())) { goto block_004B78DC; }
        goto block_004B79EC;
    }
block_004B79EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B79ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B79ECU);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B79ECU,
                                           firstAddress + 0U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B79ECU,
                                           firstAddress + 4U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x004B79ECU,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004B79ECU,
                                           firstAddress + 12U);
            }
            r5 = value5;
            r6 = value6;
            r11 = value11;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_004b7b7c_004B7B7C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x004B7B7CU:
        goto block_004B7B7C;
    case 0x004B7BB8U:
        goto block_004B7BB8;
    case 0x004B7BD8U:
        goto block_004B7BD8;
    case 0x004B7CB0U:
        goto block_004B7CB0;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_004B7B7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B7B7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B7B7CU);
        }
        {
            const uint32_t firstAddress = r13 - 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004B7B7CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004B7B7CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r14)) {
                return Oot3dAotMemoryFault(context, 0x004B7B7CU,
                                           firstAddress + 8U);
            }
            r13 = r13 - 12U;
        }
        {
            const uint32_t updatedAddress = 0x004B7B88U + 0x12CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B7B80U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 - 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B7B88U, address);
            }
            r3 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004B7B8CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B7B8CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B7B8CU,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x004B7B8CU,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r14 = value14;
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 8U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r4;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 24U);
            r4 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 8U);
            r4 = r4 + operand;
        }
        goto block_004B7BB8;
    }
block_004B7BB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B7BB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B7BB8U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 24U);
            r5 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 8U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 24U);
            r6 = r14 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 8U);
            r6 = r6 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        goto block_004B7BD8;
    }
block_004B7BD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B7BD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B7BD8U);
        }
        {
            const uint32_t updatedAddress = r0 - 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B7BD8U, address);
            }
            r7 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x004B7BDCU,
                                           firstAddress + 0U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x004B7BDCU,
                                           firstAddress + 4U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x004B7BDCU,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x004B7BDCU,
                                           firstAddress + 12U);
            }
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r14 = value14;
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r0 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 8U);
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = r8;
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r8, 24U);
            r8 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r9, 8U);
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r9, 24U);
            r9 = r10 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r10, 8U);
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r10, 24U);
            r10 = r14 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 8U);
            r10 = r10 + operand;
        }
        {
            r7 = r12 & Oot3dAotLsr(r7, 1U);
        }
        {
            r8 = r12 & Oot3dAotLsr(r8, 1U);
        }
        {
            r9 = r12 & Oot3dAotLsr(r9, 1U);
        }
        {
            r10 = r12 & Oot3dAotLsr(r10, 1U);
        }
        {
            const uint32_t operand = r7;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r8;
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = r9;
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = r10;
            r6 = r6 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r3)) {
                return Oot3dAotMemoryFault(context, 0x004B7C38U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x004B7C38U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x004B7C38U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x004B7C38U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000200U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 - 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004B7C40U, address);
            }
            r3 = value;
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x004B7C44U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B7C44U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B7C44U,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x004B7C44U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r14 = value14;
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r0 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            r14 = r12 & Oot3dAotLsr(r14, 1U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r4, 8U);
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = r4;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r4, 24U);
            r4 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 8U);
            r4 = r4 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r5, 24U);
            r5 = r6 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 8U);
            r5 = r5 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r6, 24U);
            r6 = r14 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r14, 8U);
            r6 = r6 + operand;
        }
        {
            r3 = r12 & Oot3dAotLsr(r3, 1U);
        }
        {
            r4 = r12 & Oot3dAotLsr(r4, 1U);
        }
        {
            r5 = r12 & Oot3dAotLsr(r5, 1U);
        }
        {
            r6 = r12 & Oot3dAotLsr(r6, 1U);
        }
        {
            const uint32_t operand = r3;
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = r4;
            r8 = r8 + operand;
        }
        {
            const uint32_t operand = r5;
            r9 = r9 + operand;
        }
        {
            const uint32_t operand = r6;
            r10 = r10 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r7)) {
                return Oot3dAotMemoryFault(context, 0x004B7CA0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r8)) {
                return Oot3dAotMemoryFault(context, 0x004B7CA0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r9)) {
                return Oot3dAotMemoryFault(context, 0x004B7CA0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r10)) {
                return Oot3dAotMemoryFault(context, 0x004B7CA0U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000200U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            Oot3dAotSetSubtractFlags(flags, r2, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r2 = r2 - operand;
        }
        if (!(flags.Z())) { goto block_004B7BD8; }
        goto block_004B7CB0;
    }
block_004B7CB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004B7CB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004B7CB0U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x004B7CB0U,
                                           firstAddress + 0U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x004B7CB0U,
                                           firstAddress + 4U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x004B7CB0U,
                                           firstAddress + 8U);
            }
            r5 = value5;
            r6 = value6;
            r13 = r13 + 12U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

} // namespace Oot3dNativeGame::GeneratedWholeAot
