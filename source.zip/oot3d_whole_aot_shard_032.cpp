#include "oot3d_whole_aot_generated_internal.h"
#include "oot3d_native_a32_memory.h"

#include <atomic>

namespace Oot3dNativeGame::GeneratedWholeAot {
namespace a32 = oot3d::recomp::a32;

Oot3dWholeAotFlow Execute_address_taken_001CF3AC_001CF3AC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_001cf3b4_001CF3B4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_002c0ca4_002C0CA4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_002d0258_002D0258(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_002d0264_002D0264(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_message_start_textbox_002D0320(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_002d038c_002D038C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_002d6798_002D6798(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_memset_00303B14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0032c540_0032C540(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0032c550_0032C550(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0032c560_0032C560(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0032c570_0032C570(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0032c800_0032C800(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003339e8_003339E8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0033704c_0033704C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003371d8_003371D8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0033c950_0033C950(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0033f248_0033F248(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0033f2d8_0033F2D8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0033f400_0033F400(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_MessageContext_SetDisplayMode_00340BDC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_message_textbox_common_003438A4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00343f0c_00343F0C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0034696c_0034696C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00347cc4_00347CC4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Interface_ChangeAlpha_0034BE04(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_AudioOcarina_SetInstrument_003523DC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_SetVolumeScaleFade_00355FAC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlayFanfare_0035C528(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_SetBGM_003655D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00366748_00366748(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererGlobalState_Init_0036788C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_StaticInitGuard_TryAcquire_003679B4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Message_StartTextbox_00367C7C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Runtime_SignedDivMod32_00368D94(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseContext_GetState_003695F8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Message_ContinueTextbox_0036BE34(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Flags_GetSwitch_0036E864(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Player_SetCsActionWithHaltedActors_0036E980(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Message_QueueTextRequest_003716F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_MessageContext_ResetDisplay_003725E0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_Spawn_003738D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00374be8_00374BE8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlaySoundGeneral_0037547C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_InCsMode_0037577C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Message_GetState_003769D8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Item_Give_00376A78(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_MessageContext_GetDisplayClass_0043C20C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0045a09c_0045A09C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00470778_00470778(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_player_action_swing_bottle_00473EF8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0047b144_0047B144(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00484ba4_00484BA4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00484cb8_00484CB8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0048963c_0048963C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_004896f4_004896F4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0048b814_0048B814(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0048b8f8_0048B8F8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0048b9a0_0048B9A0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_thunk_FUN_002df178_00490DF8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00494de0_00494DE0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_004bdea4_004BDEA4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);

Oot3dWholeAotFlow Execute_address_taken_001CF3AC_001CF3AC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x001CF3ACU:
        goto block_001CF3AC;
    case 0x001CF3B4U:
        goto block_001CF3B4;
    case 0x001CF3D4U:
        goto block_001CF3D4;
    case 0x001CF3FCU:
        goto block_001CF3FC;
    case 0x001CF410U:
        goto block_001CF410;
    case 0x001CF418U:
        goto block_001CF418;
    case 0x001CF424U:
        goto block_001CF424;
    case 0x001CF430U:
        goto block_001CF430;
    case 0x001CF444U:
        goto block_001CF444;
    case 0x001CF454U:
        goto block_001CF454;
    case 0x001CF464U:
        goto block_001CF464;
    case 0x001CF478U:
        goto block_001CF478;
    case 0x001CF480U:
        goto block_001CF480;
    case 0x001CF488U:
        goto block_001CF488;
    case 0x001CF494U:
        goto block_001CF494;
    case 0x001CF4A0U:
        goto block_001CF4A0;
    case 0x001CF4B4U:
        goto block_001CF4B4;
    case 0x001CF4C4U:
        goto block_001CF4C4;
    case 0x001CF4D4U:
        goto block_001CF4D4;
    case 0x001CF4E8U:
        goto block_001CF4E8;
    case 0x001CF4FCU:
        goto block_001CF4FC;
    case 0x001CF518U:
        goto block_001CF518;
    case 0x001CF530U:
        goto block_001CF530;
    case 0x001CF540U:
        goto block_001CF540;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_001CF3AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF3ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF3ACU);
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001CF3ACU, address);
            }
            r0 = value;
        }
        {
            r0 = r0;
        }
        goto block_001CF3B4;
    }
block_001CF3B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF3B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF3B4U);
        }
        {
            const uint32_t firstAddress = r13 - 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001CF3B4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x001CF3B4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x001CF3B4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001CF3B4U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x001CF3B4U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001CF3B4U,
                                           firstAddress + 20U);
            }
            r13 = r13 - 24U;
        }
        {
            const uint32_t operand = 0x00002000U;
            r4 = r0 + operand;
        }
        {
            const uint32_t operand = 0x000008A0U;
            r4 = r4 + operand;
        }
        {
            r5 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001CF3C4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000009U;
            r0 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_001CF540; }
        goto block_001CF3D4;
    }
block_001CF3D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF3D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF3D4U);
        }
        {
            const uint32_t updatedAddress = 0x001CF3DCU + 0x168U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001CF3D4U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001CF3DCU, address);
            }
        }
        {
            r0 = 0x000002E0U;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001CF3E4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = r5;
        }
        if (flags.Z()) {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001CF3F0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001CF3F0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001CF3F0U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001CF3F0U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001CF3F0U,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001CF3F0U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r14 = value14;
            r13 = r13 + 24U;
        }
        if (flags.Z()) {
            r1 = 0x00000021U;
        }
        if (flags.Z()) { return Oot3dAotBranch(0x00340BDCU); }
        goto block_001CF3FC;
    }
block_001CF3FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF3FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF3FCU);
        }
        {
            const uint32_t updatedAddress = 0x001CF404U + 0x144U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001CF3FCU, address);
            }
            r7 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r6 = 0x00000000U;
        }
        {
            r8 = 0x00000005U;
        }
        if (!(flags.Z())) { goto block_001CF464; }
        goto block_001CF410;
    }
block_001CF410:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF410U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF410U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001CF418U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001CF418U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001CF418;
    }
block_001CF418:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF418U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF418U);
        }
        {
            r0 = 0x00000001U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001CF424U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001CF424U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001CF424;
    }
block_001CF424:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF424U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF424U);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001CF430U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f400_0033F400(frame, context, state, 0x0033F400U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001CF430U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001CF430;
    }
block_001CF430:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF430U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF430U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001CF430U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001CF434U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001CF438U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001CF43CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001CF444U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f2d8_0033F2D8(frame, context, state, 0x0033F2D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001CF444U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001CF444;
    }
block_001CF444:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF444U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF444U);
        }
        {
            r1 = 0x00000023U;
        }
        {
            r0 = r5;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001CF44CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001CF454U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001CF454U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001CF454;
    }
block_001CF454:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF454U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF454U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001CF454U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001CF454U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001CF454U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001CF454U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001CF454U,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001CF454U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r14 = value14;
            r13 = r13 + 24U;
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = 0x0000000FU;
        }
        return Oot3dAotBranch(0x0033F248U);
    }
block_001CF464:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF464U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF464U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = r5;
        }
        if (flags.Z()) {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001CF46CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001CF46CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001CF46CU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001CF46CU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001CF46CU,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001CF46CU,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r14 = value14;
            r13 = r13 + 24U;
        }
        if (flags.Z()) {
            r1 = 0x00000024U;
        }
        if (flags.Z()) { return Oot3dAotBranch(0x00340BDCU); }
        goto block_001CF478;
    }
block_001CF478:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF478U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF478U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001CF4D4; }
        goto block_001CF480;
    }
block_001CF480:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF480U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF480U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001CF488U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001CF488U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001CF488;
    }
block_001CF488:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF488U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF488U);
        }
        {
            r0 = 0x00000001U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001CF494U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001CF494U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001CF494;
    }
block_001CF494:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF494U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF494U);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001CF4A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f400_0033F400(frame, context, state, 0x0033F400U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001CF4A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001CF4A0;
    }
block_001CF4A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF4A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF4A0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001CF4A0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001CF4A4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001CF4A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001CF4ACU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001CF4B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f2d8_0033F2D8(frame, context, state, 0x0033F2D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001CF4B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001CF4B4;
    }
block_001CF4B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF4B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF4B4U);
        }
        {
            r1 = 0x00000028U;
        }
        {
            r0 = r5;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001CF4BCU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001CF4C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001CF4C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001CF4C4;
    }
block_001CF4C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF4C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF4C4U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001CF4C4U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001CF4C4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001CF4C4U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001CF4C4U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001CF4C4U,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001CF4C4U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r14 = value14;
            r13 = r13 + 24U;
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = 0x0000000DU;
        }
        return Oot3dAotBranch(0x0033F248U);
    }
block_001CF4D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF4D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF4D4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = r5;
        }
        if (flags.Z()) {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001CF4DCU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001CF4DCU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001CF4DCU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001CF4DCU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001CF4DCU,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001CF4DCU,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r14 = value14;
            r13 = r13 + 24U;
        }
        if (flags.Z()) {
            r1 = 0x00000029U;
        }
        if (flags.Z()) { return Oot3dAotBranch(0x00340BDCU); }
        goto block_001CF4E8;
    }
block_001CF4E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF4E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF4E8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = r5;
        }
        if (flags.Z()) {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001CF4F0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001CF4F0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001CF4F0U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001CF4F0U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001CF4F0U,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001CF4F0U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r14 = value14;
            r13 = r13 + 24U;
        }
        if (flags.Z()) {
            r1 = 0x00000031U;
        }
        if (flags.Z()) { return Oot3dAotBranch(0x00340BDCU); }
        goto block_001CF4FC;
    }
block_001CF4FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF4FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF4FCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000022U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) {
            r0 = r5;
        }
        if (flags.C()) {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001CF50CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001CF50CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001CF50CU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001CF50CU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001CF50CU,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001CF50CU,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r14 = value14;
            r13 = r13 + 24U;
        }
        if (flags.C()) {
            r1 = 0x00000009U;
        }
        if (flags.C()) { return Oot3dAotBranch(0x00340BDCU); }
        goto block_001CF518;
    }
block_001CF518:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF518U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF518U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r0 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) {
            r0 = r5;
        }
        if (!(flags.C()) || (flags.Z())) {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001CF524U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001CF524U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001CF524U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001CF524U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001CF524U,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001CF524U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r14 = value14;
            r13 = r13 + 24U;
        }
        if (!(flags.C()) || (flags.Z())) {
            r1 = 0x0000000AU;
        }
        if (!(flags.C()) || (flags.Z())) { return Oot3dAotBranch(0x00340BDCU); }
        goto block_001CF530;
    }
block_001CF530:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF530U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF530U);
        }
        {
            r0 = r5;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001CF534U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001CF534U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001CF534U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001CF534U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001CF534U,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001CF534U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r14 = value14;
            r13 = r13 + 24U;
        }
        {
            r1 = 0x0000000BU;
        }
        return Oot3dAotBranch(0x00340BDCU);
    }
block_001CF540:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF540U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF540U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001CF540U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001CF540U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001CF540U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001CF540U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001CF540U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001CF540U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_001cf3b4_001CF3B4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x001CF3B4U:
        goto block_001CF3B4;
    case 0x001CF3D4U:
        goto block_001CF3D4;
    case 0x001CF3FCU:
        goto block_001CF3FC;
    case 0x001CF410U:
        goto block_001CF410;
    case 0x001CF418U:
        goto block_001CF418;
    case 0x001CF424U:
        goto block_001CF424;
    case 0x001CF430U:
        goto block_001CF430;
    case 0x001CF444U:
        goto block_001CF444;
    case 0x001CF454U:
        goto block_001CF454;
    case 0x001CF464U:
        goto block_001CF464;
    case 0x001CF478U:
        goto block_001CF478;
    case 0x001CF480U:
        goto block_001CF480;
    case 0x001CF488U:
        goto block_001CF488;
    case 0x001CF494U:
        goto block_001CF494;
    case 0x001CF4A0U:
        goto block_001CF4A0;
    case 0x001CF4B4U:
        goto block_001CF4B4;
    case 0x001CF4C4U:
        goto block_001CF4C4;
    case 0x001CF4D4U:
        goto block_001CF4D4;
    case 0x001CF4E8U:
        goto block_001CF4E8;
    case 0x001CF4FCU:
        goto block_001CF4FC;
    case 0x001CF518U:
        goto block_001CF518;
    case 0x001CF530U:
        goto block_001CF530;
    case 0x001CF540U:
        goto block_001CF540;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_001CF3B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF3B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF3B4U);
        }
        {
            const uint32_t firstAddress = r13 - 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x001CF3B4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x001CF3B4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x001CF3B4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x001CF3B4U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x001CF3B4U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x001CF3B4U,
                                           firstAddress + 20U);
            }
            r13 = r13 - 24U;
        }
        {
            const uint32_t operand = 0x00002000U;
            r4 = r0 + operand;
        }
        {
            const uint32_t operand = 0x000008A0U;
            r4 = r4 + operand;
        }
        {
            r5 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001CF3C4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000009U;
            r0 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_001CF540; }
        goto block_001CF3D4;
    }
block_001CF3D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF3D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF3D4U);
        }
        {
            const uint32_t updatedAddress = 0x001CF3DCU + 0x168U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001CF3D4U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001CF3DCU, address);
            }
        }
        {
            r0 = 0x000002E0U;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001CF3E4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = r5;
        }
        if (flags.Z()) {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001CF3F0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001CF3F0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001CF3F0U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001CF3F0U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001CF3F0U,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001CF3F0U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r14 = value14;
            r13 = r13 + 24U;
        }
        if (flags.Z()) {
            r1 = 0x00000021U;
        }
        if (flags.Z()) { return Oot3dAotBranch(0x00340BDCU); }
        goto block_001CF3FC;
    }
block_001CF3FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF3FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF3FCU);
        }
        {
            const uint32_t updatedAddress = 0x001CF404U + 0x144U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001CF3FCU, address);
            }
            r7 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r6 = 0x00000000U;
        }
        {
            r8 = 0x00000005U;
        }
        if (!(flags.Z())) { goto block_001CF464; }
        goto block_001CF410;
    }
block_001CF410:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF410U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF410U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001CF418U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001CF418U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001CF418;
    }
block_001CF418:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF418U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF418U);
        }
        {
            r0 = 0x00000001U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001CF424U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001CF424U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001CF424;
    }
block_001CF424:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF424U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF424U);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001CF430U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f400_0033F400(frame, context, state, 0x0033F400U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001CF430U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001CF430;
    }
block_001CF430:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF430U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF430U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001CF430U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001CF434U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001CF438U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001CF43CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001CF444U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f2d8_0033F2D8(frame, context, state, 0x0033F2D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001CF444U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001CF444;
    }
block_001CF444:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF444U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF444U);
        }
        {
            r1 = 0x00000023U;
        }
        {
            r0 = r5;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001CF44CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001CF454U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001CF454U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001CF454;
    }
block_001CF454:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF454U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF454U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001CF454U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001CF454U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001CF454U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001CF454U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001CF454U,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001CF454U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r14 = value14;
            r13 = r13 + 24U;
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = 0x0000000FU;
        }
        return Oot3dAotBranch(0x0033F248U);
    }
block_001CF464:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF464U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF464U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = r5;
        }
        if (flags.Z()) {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001CF46CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001CF46CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001CF46CU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001CF46CU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001CF46CU,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001CF46CU,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r14 = value14;
            r13 = r13 + 24U;
        }
        if (flags.Z()) {
            r1 = 0x00000024U;
        }
        if (flags.Z()) { return Oot3dAotBranch(0x00340BDCU); }
        goto block_001CF478;
    }
block_001CF478:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF478U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF478U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001CF4D4; }
        goto block_001CF480;
    }
block_001CF480:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF480U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF480U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001CF488U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001CF488U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001CF488;
    }
block_001CF488:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF488U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF488U);
        }
        {
            r0 = 0x00000001U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001CF494U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001CF494U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001CF494;
    }
block_001CF494:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF494U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF494U);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001CF4A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f400_0033F400(frame, context, state, 0x0033F400U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001CF4A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001CF4A0;
    }
block_001CF4A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF4A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF4A0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001CF4A0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001CF4A4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001CF4A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x001CF4ACU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001CF4B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f2d8_0033F2D8(frame, context, state, 0x0033F2D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001CF4B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001CF4B4;
    }
block_001CF4B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF4B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF4B4U);
        }
        {
            r1 = 0x00000028U;
        }
        {
            r0 = r5;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x001CF4BCU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001CF4C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001CF4C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001CF4C4;
    }
block_001CF4C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF4C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF4C4U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001CF4C4U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001CF4C4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001CF4C4U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001CF4C4U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001CF4C4U,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001CF4C4U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r14 = value14;
            r13 = r13 + 24U;
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = 0x0000000DU;
        }
        return Oot3dAotBranch(0x0033F248U);
    }
block_001CF4D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF4D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF4D4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = r5;
        }
        if (flags.Z()) {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001CF4DCU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001CF4DCU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001CF4DCU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001CF4DCU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001CF4DCU,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001CF4DCU,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r14 = value14;
            r13 = r13 + 24U;
        }
        if (flags.Z()) {
            r1 = 0x00000029U;
        }
        if (flags.Z()) { return Oot3dAotBranch(0x00340BDCU); }
        goto block_001CF4E8;
    }
block_001CF4E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF4E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF4E8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = r5;
        }
        if (flags.Z()) {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001CF4F0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001CF4F0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001CF4F0U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001CF4F0U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001CF4F0U,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001CF4F0U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r14 = value14;
            r13 = r13 + 24U;
        }
        if (flags.Z()) {
            r1 = 0x00000031U;
        }
        if (flags.Z()) { return Oot3dAotBranch(0x00340BDCU); }
        goto block_001CF4FC;
    }
block_001CF4FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF4FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF4FCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000022U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) {
            r0 = r5;
        }
        if (flags.C()) {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001CF50CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001CF50CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001CF50CU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001CF50CU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001CF50CU,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001CF50CU,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r14 = value14;
            r13 = r13 + 24U;
        }
        if (flags.C()) {
            r1 = 0x00000009U;
        }
        if (flags.C()) { return Oot3dAotBranch(0x00340BDCU); }
        goto block_001CF518;
    }
block_001CF518:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF518U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF518U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r0 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) {
            r0 = r5;
        }
        if (!(flags.C()) || (flags.Z())) {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001CF524U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001CF524U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001CF524U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001CF524U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001CF524U,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001CF524U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r14 = value14;
            r13 = r13 + 24U;
        }
        if (!(flags.C()) || (flags.Z())) {
            r1 = 0x0000000AU;
        }
        if (!(flags.C()) || (flags.Z())) { return Oot3dAotBranch(0x00340BDCU); }
        goto block_001CF530;
    }
block_001CF530:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF530U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF530U);
        }
        {
            r0 = r5;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001CF534U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001CF534U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001CF534U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001CF534U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001CF534U,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x001CF534U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r14 = value14;
            r13 = r13 + 24U;
        }
        {
            r1 = 0x0000000BU;
        }
        return Oot3dAotBranch(0x00340BDCU);
    }
block_001CF540:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001CF540U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001CF540U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x001CF540U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x001CF540U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x001CF540U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x001CF540U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x001CF540U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x001CF540U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_002d038c_002D038C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r8 = state.R[8];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x002D038CU:
        goto block_002D038C;
    case 0x002D03A8U:
        goto block_002D03A8;
    case 0x002D03B0U:
        goto block_002D03B0;
    case 0x002D03C0U:
        goto block_002D03C0;
    case 0x002D03C8U:
        goto block_002D03C8;
    case 0x002D03D0U:
        goto block_002D03D0;
    case 0x002D03D8U:
        goto block_002D03D8;
    case 0x002D03ECU:
        goto block_002D03EC;
    case 0x002D03FCU:
        goto block_002D03FC;
    case 0x002D0400U:
        goto block_002D0400;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_002D038C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D038CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D038CU);
        }
        {
            const uint32_t firstAddress = r13 - 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x002D038CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x002D038CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x002D038CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r14)) {
                return Oot3dAotMemoryFault(context, 0x002D038CU,
                                           firstAddress + 12U);
            }
            r13 = r13 - 16U;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t updatedAddress = 0x002D039CU + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D0394U, address);
            }
            r6 = value;
        }
        {
            r5 = r1;
        }
        {
            const uint32_t updatedAddress = r6 + r0;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D039CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002D0400; }
        goto block_002D03A8;
    }
block_002D03A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D03A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D03A8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000008U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_002D03FC; }
        goto block_002D03B0;
    }
block_002D03B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D03B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D03B0U);
        }
        {
            const uint32_t updatedAddress = 0x002D03B8U + 0x50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D03B0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D03B4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_002D03EC; }
        goto block_002D03C0;
    }
block_002D03C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D03C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D03C0U);
        }
        {
            const uint32_t updatedAddress = 0x002D03C8U + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D03C0U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002D03C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002D03C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002D03C8;
    }
block_002D03C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D03C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D03C8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002D03EC; }
        goto block_002D03D0;
    }
block_002D03D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D03D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D03D0U);
        }
        {
            const uint32_t updatedAddress = 0x002D03D8U + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D03D0U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002D03D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002D03D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002D03D8;
    }
block_002D03D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D03D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D03D8U);
        }
        {
            const uint32_t updatedAddress = 0x002D03E0U + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D03D8U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x002D03E4U + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D03DCU, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x002D03ECU + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D03E4U, address);
            }
            r0 = value;
        }
        {
            r0 = r0;
        }
        goto block_002D03EC;
    }
block_002D03EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D03ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D03ECU);
        }
        {
            const uint32_t updatedAddress = 0x002D03F4U + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002D03ECU, address);
            }
            r0 = value;
        }
        {
            r2 = r5;
        }
        {
            r1 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002D03FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00494de0_00494DE0(frame, context, state, 0x00494DE0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002D03FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002D03FC;
    }
block_002D03FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D03FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D03FCU);
        }
        {
            const uint32_t updatedAddress = r6 + r4;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x002D03FCU, address);
            }
        }
        goto block_002D0400;
    }
block_002D0400:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002D0400U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002D0400U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002D0400U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002D0400U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002D0400U,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002D0400U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_003371d8_003371D8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r4 = state.R[4];
    uint32_t& r8 = state.R[8];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x003371D8U:
        goto block_003371D8;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_003371D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003371D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003371D8U);
        }
        {
            const uint32_t updatedAddress = 0x003371E0U + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003371D8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003371DCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FEU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x003371ECU + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003371E4U, address);
            }
            r1 = value;
        }
        if (!(flags.C())) {
            r0 = 0x00000000U;
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = r1 + 0x94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003371ECU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x003371F8U + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003371F0U, address);
            }
            r0 = value;
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_0033f2d8_0033F2D8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0033F2D8U:
        goto block_0033F2D8;
    case 0x0033F320U:
        goto block_0033F320;
    case 0x0033F328U:
        goto block_0033F328;
    case 0x0033F330U:
        goto block_0033F330;
    case 0x0033F338U:
        goto block_0033F338;
    case 0x0033F34CU:
        goto block_0033F34C;
    case 0x0033F354U:
        goto block_0033F354;
    case 0x0033F364U:
        goto block_0033F364;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0033F2D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033F2D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033F2D8U);
        }
        {
            const uint32_t updatedAddress = 0x0033F2E0U + 0xFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033F2D8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r13 - 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0033F2DCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0033F2DCU,
                                           firstAddress + 4U);
            }
            r13 = r13 - 8U;
        }
        {
            r1 = 0x000000BDU;
        }
        {
            r2 = 0x000000B8U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033F2E8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000F00U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x6EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0033F2F0U, address);
            }
        }
        {
            r1 = 0x000000B3U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x70U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0033F2F8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x72U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0033F2FCU, address);
            }
        }
        {
            r1 = 0x000000AEU;
        }
        {
            const uint32_t updatedAddress = r0 + 0x74U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0033F304U, address);
            }
        }
        {
            r1 = 0x000000A9U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x76U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0033F30CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0033F318U + 0xC8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033F310U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033F314U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0033F34C; }
        goto block_0033F320;
    }
block_0033F320:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033F320U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033F320U);
        }
        {
            const uint32_t updatedAddress = 0x0033F328U + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033F320U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0033F328U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0033F328U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0033F328;
    }
block_0033F328:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033F328U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033F328U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0033F34C; }
        goto block_0033F330;
    }
block_0033F330:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033F330U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033F330U);
        }
        {
            const uint32_t updatedAddress = 0x0033F338U + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033F330U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0033F338U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0033F338U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0033F338;
    }
block_0033F338:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033F338U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033F338U);
        }
        {
            const uint32_t updatedAddress = 0x0033F340U + 0xA8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033F338U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0033F344U + 0xA8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033F33CU, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x0033F34CU + 0x94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033F344U, address);
            }
            r0 = value;
        }
        {
            r0 = r0;
        }
        goto block_0033F34C;
    }
block_0033F34C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033F34CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033F34CU);
        }
        {
            const uint32_t updatedAddress = 0x0033F354U + 0x9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033F34CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0033F354U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002c0ca4_002C0CA4(frame, context, state, 0x002C0CA4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0033F354U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0033F354;
    }
block_0033F354:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033F354U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033F354U);
        }
        {
            const uint32_t updatedAddress = 0x0033F35CU + 0x98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033F354U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x000000FFU;
        }
        {
            r1 = 0x00000009U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0033F364U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_memset_00303B14(frame, context, state, 0x00303B14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0033F364U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0033F364;
    }
block_0033F364:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033F364U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033F364U);
        }
        {
            const uint32_t updatedAddress = 0x0033F36CU + 0x8CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033F364U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            r2 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0033F370U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0xEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0033F374U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0033F378U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0xAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0033F37CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0033F380U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0033F384U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0033F388U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0033F38CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0033F390U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0033F39CU + 0x60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033F394U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000050U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0033F39CU, address);
            }
        }
        {
            r1 = 0x00000096U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0033F3A4U, address);
            }
        }
        {
            r1 = 0x0000000AU;
        }
        {
            const uint32_t updatedAddress = r0 + 0x12U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0033F3ACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0033F3B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x1AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0033F3B4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0033F3B8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0033F3BCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0033F3C0U, address);
            }
        }
        {
            r2 = 0x00000032U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0033F3C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x22U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0033F3CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x26U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0033F3D0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0033F3D4U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0033F3D8U,
                                           firstAddress + 0U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0033F3D8U,
                                           firstAddress + 4U);
            }
            r4 = value4;
            r13 = r13 + 8U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_0033f400_0033F400(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0033F400U:
        goto block_0033F400;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0033F400:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033F400U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033F400U);
        }
        {
            const uint32_t updatedAddress = 0x0033F408U + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033F400U, address);
            }
            r0 = value;
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_MessageContext_SetDisplayMode_00340BDC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00340BDCU:
        goto block_00340BDC;
    case 0x00340BF8U:
        goto block_00340BF8;
    case 0x00340C00U:
        goto block_00340C00;
    case 0x00340C18U:
        goto block_00340C18;
    case 0x00340C24U:
        goto block_00340C24;
    case 0x00340C28U:
        goto block_00340C28;
    case 0x00340C30U:
        goto block_00340C30;
    case 0x00340C34U:
        goto block_00340C34;
    case 0x00340C3CU:
        goto block_00340C3C;
    case 0x00340C48U:
        goto block_00340C48;
    case 0x00340C60U:
        goto block_00340C60;
    case 0x00340C6CU:
        goto block_00340C6C;
    case 0x00340C74U:
        goto block_00340C74;
    case 0x00340C84U:
        goto block_00340C84;
    case 0x00340C90U:
        goto block_00340C90;
    case 0x00340CA4U:
        goto block_00340CA4;
    case 0x00340CB8U:
        goto block_00340CB8;
    case 0x00340CCCU:
        goto block_00340CCC;
    case 0x00340CE0U:
        goto block_00340CE0;
    case 0x00340CF4U:
        goto block_00340CF4;
    case 0x00340CF8U:
        goto block_00340CF8;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00340BDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00340BDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00340BDCU);
        }
        {
            const uint32_t firstAddress = r13 - 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00340BDCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00340BDCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00340BDCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00340BDCU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00340BDCU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00340BDCU,
                                           firstAddress + 20U);
            }
            r13 = r13 - 24U;
        }
        {
            const uint32_t operand = 0x00002000U;
            r4 = r0 + operand;
        }
        {
            const uint32_t operand = 0x000008A0U;
            r4 = r4 + operand;
        }
        {
            r6 = r1;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00340BECU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00340CF8; }
        goto block_00340BF8;
    }
block_00340BF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00340BF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00340BF8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00340CF4; }
        goto block_00340C00;
    }
block_00340C00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00340C00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00340C00U);
        }
        {
            const uint32_t updatedAddress = 0x00340C08U + 0xF4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00340C00U, address);
            }
            r7 = value;
        }
        {
            const uint32_t operand = 0x00000000U;
            r1 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r7 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00340C08U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r6, 2U);
            r5 = r1 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00340C84; }
        goto block_00340C18;
    }
block_00340C18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00340C18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00340C18U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00340C18U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00340CB8; }
        goto block_00340C24;
    }
block_00340C24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00340C24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00340C24U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00340C28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_GetDisplayClass_0043C20C(frame, context, state, 0x0043C20CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00340C28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00340C28;
    }
block_00340C28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00340C28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00340C28U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00340C3C; }
        goto block_00340C30;
    }
block_00340C30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00340C30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00340C30U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00340C34U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_GetDisplayClass_0043C20C(frame, context, state, 0x0043C20CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00340C34U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00340C34;
    }
block_00340C34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00340C34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00340C34U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00340C74; }
        goto block_00340C3C;
    }
block_00340C3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00340C3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00340C3CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00340C3CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00340C6C; }
        goto block_00340C48;
    }
block_00340C48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00340C48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00340C48U);
        }
        {
            r0 = 0x000002E0U;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00340C4CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r0 = 0x00000000U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00340C60U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0032c570_0032C570(frame, context, state, 0x0032C570U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00340C60U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00340C60;
    }
block_00340C60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00340C60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00340C60U);
        }
        {
        }
        {
        }
        goto block_00340C74;
    }
block_00340C6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00340C6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00340C6CU);
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00340C74U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0032c570_0032C570(frame, context, state, 0x0032C570U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00340C74U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00340C74;
    }
block_00340C74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00340C74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00340C74U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00340C74U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r7 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00340C78U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00340CB8; }
        goto block_00340C84;
    }
block_00340C84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00340C84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00340C84U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00340C84U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00340CB8; }
        goto block_00340C90;
    }
block_00340C90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00340C90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00340C90U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00340C90U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001FU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001AU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00340CB8; }
        goto block_00340CA4;
    }
block_00340CA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00340CA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00340CA4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x301U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00340CA4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r0 = 0x00000001U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00340CB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_004bdea4_004BDEA4(frame, context, state, 0x004BDEA4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00340CB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00340CB8;
    }
block_00340CB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00340CB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00340CB8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00340CB8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r0 = 0x00000001U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00340CCCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0032c560_0032C560(frame, context, state, 0x0032C560U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00340CCCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00340CCC;
    }
block_00340CCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00340CCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00340CCCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00340CCCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r0 = 0x00000001U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00340CE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0032c550_0032C550(frame, context, state, 0x0032C550U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00340CE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00340CE0;
    }
block_00340CE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00340CE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00340CE0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00340CE0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r0 = 0x00000001U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00340CF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0032c540_0032C540(frame, context, state, 0x0032C540U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00340CF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00340CF4;
    }
block_00340CF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00340CF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00340CF4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00340CF4U, address);
            }
        }
        goto block_00340CF8;
    }
block_00340CF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00340CF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00340CF8U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00340CF8U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00340CF8U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00340CF8U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00340CF8U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00340CF8U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00340CF8U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_AudioOcarina_SetInstrument_003523DC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x003523DCU:
        goto block_003523DC;
    case 0x003523F4U:
        goto block_003523F4;
    case 0x00352414U:
        goto block_00352414;
    case 0x00352430U:
        goto block_00352430;
    case 0x00352438U:
        goto block_00352438;
    case 0x00352440U:
        goto block_00352440;
    case 0x00352458U:
        goto block_00352458;
    case 0x0035245CU:
        goto block_0035245C;
    case 0x00352460U:
        goto block_00352460;
    case 0x0035246CU:
        goto block_0035246C;
    case 0x00352494U:
        goto block_00352494;
    case 0x003524A0U:
        goto block_003524A0;
    case 0x003524B0U:
        goto block_003524B0;
    case 0x003524BCU:
        goto block_003524BC;
    case 0x003524C4U:
        goto block_003524C4;
    case 0x00460E38U:
        goto block_00460E38;
    case 0x00460E50U:
        goto block_00460E50;
    case 0x00460E64U:
        goto block_00460E64;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_003523DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003523DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003523DCU);
        }
        {
            const uint32_t firstAddress = r13 - 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x003523DCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x003523DCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x003523DCU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r14)) {
                return Oot3dAotMemoryFault(context, 0x003523DCU,
                                           firstAddress + 12U);
            }
            r13 = r13 - 16U;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t updatedAddress = 0x003523ECU + 0xECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003523E4U, address);
            }
            r5 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x15U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003523E8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r4, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0035245C; }
        goto block_003523F4;
    }
block_003523F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003523F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003523F4U);
        }
        {
            const uint32_t updatedAddress = 0x003523FCU + 0xE0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003523F4U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | r4;
        }
        {
            r0 = r0;
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x15U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00352404U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r5 + 0xDCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0035240CU, address);
            }
        }
        if (!(flags.Z())) { goto block_00352460; }
        goto block_00352414;
    }
block_00352414:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00352414U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00352414U);
        }
        {
            const uint32_t updatedAddress = 0x0035241CU + 0xC4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00352414U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0xE4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00352418U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0035241CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x13U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00352420U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xE0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00352424U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00352430U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d6798_002D6798(frame, context, state, 0x002D6798U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00352430U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00352430;
    }
block_00352430:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00352430U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00352430U);
        }
        {
            const uint32_t updatedAddress = 0x00352438U + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00352430U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00352438U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0048963c_0048963C(frame, context, state, 0x0048963CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00352438U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00352438;
    }
block_00352438:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00352438U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00352438U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00352440U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00347cc4_00347CC4(frame, context, state, 0x00347CC4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00352440U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00352440;
    }
block_00352440:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00352440U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00352440U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x1DU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00352440U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00352444U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00352448U, address);
            }
        }
        {
            r0 = 0x0000000DU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00352450U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00352458U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033c950_0033C950(frame, context, state, 0x0033C950U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00352458U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00352458;
    }
block_00352458:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00352458U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00352458U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00352458U, address);
            }
        }
        goto block_0035245C;
    }
block_0035245C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035245CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035245CU);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0035245CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0035245CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0035245CU,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0035245CU,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
block_00352460:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00352460U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00352460U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x13U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00352460U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_003524C4; }
        goto block_0035246C;
    }
block_0035246C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035246CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035246CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0xD4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0035246CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00352478U + 0x70U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00352470U, address);
            }
            r1 = value;
        }
        {
            r3 = 0x00000040U;
        }
        {
            const uint32_t updatedAddress = r5 + 0xDCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00352478U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xE4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0035247CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00352480U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = ~(0x0000003FU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000040U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0035248CU, address);
            }
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_003524A0; }
        goto block_00352494;
    }
block_00352494:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00352494U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00352494U);
        }
        {
            Oot3dAotSetAddFlags(flags, r0, 0x00000040U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00352498U, address);
            }
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0035249CU, address);
            }
        }
        goto block_003524A0;
    }
block_003524A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003524A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003524A0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003524A0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000040U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r1 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x003524A8U, address);
            }
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_003524BC; }
        goto block_003524B0;
    }
block_003524B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003524B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003524B0U);
        }
        {
            Oot3dAotSetAddFlags(flags, r0, 0x00000040U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t updatedAddress = r1 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003524B4U, address);
            }
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r1 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x003524B8U, address);
            }
        }
        goto block_003524BC;
    }
block_003524BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003524BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003524BCU);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x13U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003524C0U, address);
            }
        }
        goto block_003524C4;
    }
block_003524C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003524C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003524C4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xDCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003524C4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0xE0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x003524C8U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003524CCU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003524CCU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003524CCU,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x003524CCU,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r14 = value14;
            r13 = r13 + 16U;
        }
        {
            r0 = 0x0000000DU;
        }
        goto block_00460E38;
    }
block_00460E38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00460E38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00460E38U);
        }
        {
            r3 = 0x0000000FU;
        }
        {
            r2 = 0x00000028U;
        }
        {
            r1 = 0x00000002U;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t firstAddress = r13 - 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00460E48U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00460E48U,
                                           firstAddress + 4U);
            }
            r13 = r13 - 8U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00460E50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_SetVolumeScaleFade_00355FAC(frame, context, state, 0x00355FACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00460E50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00460E50;
    }
block_00460E50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00460E50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00460E50U);
        }
        {
            r3 = 0x0000000FU;
        }
        {
            r2 = 0x00000028U;
        }
        {
            r1 = 0x00000002U;
        }
        {
            r0 = 0x00000003U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00460E64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_SetVolumeScaleFade_00355FAC(frame, context, state, 0x00355FACU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00460E64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00460E64;
    }
block_00460E64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00460E64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00460E64U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00460E64U,
                                           firstAddress + 0U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x00460E64U,
                                           firstAddress + 4U);
            }
            r4 = value4;
            r14 = value14;
            r13 = r13 + 8U;
        }
        {
            r1 = 0x0000000FU;
        }
        {
            r0 = 0x00000028U;
        }
        return Oot3dAotBranch(0x0033C98CU);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Runtime_SignedDivMod32_00368D94(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00368D94U:
        goto block_00368D94;
    case 0x00368D9CU:
        goto block_00368D9C;
    case 0x00368DA4U:
        goto block_00368DA4;
    case 0x00368DB0U:
        goto block_00368DB0;
    case 0x00368DB8U:
        goto block_00368DB8;
    case 0x00368DC0U:
        goto block_00368DC0;
    case 0x00368DC8U:
        goto block_00368DC8;
    case 0x00368DE4U:
        goto block_00368DE4;
    case 0x00368DECU:
        goto block_00368DEC;
    case 0x00368DF0U:
        goto block_00368DF0;
    case 0x00368E20U:
        goto block_00368E20;
    case 0x00368E54U:
        goto block_00368E54;
    case 0x00368E84U:
        goto block_00368E84;
    case 0x00368EB8U:
        goto block_00368EB8;
    case 0x00368EC0U:
        goto block_00368EC0;
    case 0x00368EC8U:
        goto block_00368EC8;
    case 0x00368ED4U:
        goto block_00368ED4;
    case 0x00368EECU:
        goto block_00368EEC;
    case 0x00368EF4U:
        goto block_00368EF4;
    case 0x00368F04U:
        goto block_00368F04;
    case 0x00368F14U:
        goto block_00368F14;
    case 0x00368F30U:
        goto block_00368F30;
    case 0x00368F34U:
        goto block_00368F34;
    case 0x00368F64U:
        goto block_00368F64;
    case 0x00368F80U:
        goto block_00368F80;
    case 0x00368FA8U:
        goto block_00368FA8;
    case 0x00368FB0U:
        goto block_00368FB0;
    case 0x00368FBCU:
        goto block_00368FBC;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00368D94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368D94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368D94U);
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            r3 = r0 | shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r3, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x8U));
        }
        if (flags.N()) { goto block_00368ED4; }
        goto block_00368D9C;
    }
block_00368D9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368D9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368D9CU);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 1U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (!(flags.C())) { goto block_00368EB8; }
        goto block_00368DA4;
    }
block_00368DA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368DA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368DA4U);
        }
        {
            r2 = 0x00000000U;
            Oot3dAotSetLogicalFlags(flags, r2, flags.C(), static_cast<Oot3dAotFlagMask>(0x0U));
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 4U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (!(flags.C())) { goto block_00368E84; }
        goto block_00368DB0;
    }
block_00368DB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368DB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368DB0U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 8U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (!(flags.C())) { goto block_00368E54; }
        goto block_00368DB8;
    }
block_00368DB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368DB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368DB8U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 12U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (!(flags.C())) { goto block_00368E20; }
        goto block_00368DC0;
    }
block_00368DC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368DC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368DC0U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 16U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (!(flags.C())) { goto block_00368DF0; }
        goto block_00368DC8;
    }
block_00368DC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368DC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368DC8U);
        }
        {
            r1 = Oot3dAotLsl(r1, 8U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 16U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        {
            r2 = r2 | 0xFF000000U;
        }
        if (flags.C()) {
            r2 = r2 | 0x00FF0000U;
        }
        if (flags.C()) {
            r1 = Oot3dAotLsl(r1, 8U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 12U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (!(flags.C())) { goto block_00368E20; }
        goto block_00368DE4;
    }
block_00368DE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368DE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368DE4U);
        }
        {
            const uint32_t operand = 0x00000000U;
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x3U));
            r3 = operand - r1;
        }
        if (flags.C()) { goto block_00368FB0; }
        goto block_00368DEC;
    }
block_00368DEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368DECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368DECU);
        }
        if (flags.C()) {
            r1 = Oot3dAotLsr(r1, 8U);
        }
        goto block_00368DF0;
    }
block_00368DF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368DF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368DF0U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 15U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (flags.C()) {
            const uint32_t operand = Oot3dAotLsl(r1, 15U);
            r0 = r0 - operand;
        }
        {
            r2 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), true, static_cast<Oot3dAotFlagMask>(0x0U));
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 14U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (flags.C()) {
            const uint32_t operand = Oot3dAotLsl(r1, 14U);
            r0 = r0 - operand;
        }
        {
            r2 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), true, static_cast<Oot3dAotFlagMask>(0x0U));
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 13U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (flags.C()) {
            const uint32_t operand = Oot3dAotLsl(r1, 13U);
            r0 = r0 - operand;
        }
        {
            r2 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), true, static_cast<Oot3dAotFlagMask>(0x0U));
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 12U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (flags.C()) {
            const uint32_t operand = Oot3dAotLsl(r1, 12U);
            r0 = r0 - operand;
        }
        {
            r2 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), true, static_cast<Oot3dAotFlagMask>(0x0U));
        }
        goto block_00368E20;
    }
block_00368E20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368E20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368E20U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 11U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (flags.C()) {
            const uint32_t operand = Oot3dAotLsl(r1, 11U);
            r0 = r0 - operand;
        }
        {
            r2 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), true, static_cast<Oot3dAotFlagMask>(0x0U));
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 10U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (flags.C()) {
            const uint32_t operand = Oot3dAotLsl(r1, 10U);
            r0 = r0 - operand;
        }
        {
            r2 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), true, static_cast<Oot3dAotFlagMask>(0x0U));
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 9U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (flags.C()) {
            const uint32_t operand = Oot3dAotLsl(r1, 9U);
            r0 = r0 - operand;
        }
        {
            r2 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), true, static_cast<Oot3dAotFlagMask>(0x0U));
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 8U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (flags.C()) {
            const uint32_t operand = Oot3dAotLsl(r1, 8U);
            r0 = r0 - operand;
        }
        {
            r2 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), true, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_00368DEC; }
        goto block_00368E54;
    }
block_00368E54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368E54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368E54U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 7U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (flags.C()) {
            const uint32_t operand = Oot3dAotLsl(r1, 7U);
            r0 = r0 - operand;
        }
        {
            r2 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), true, static_cast<Oot3dAotFlagMask>(0x0U));
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 6U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (flags.C()) {
            const uint32_t operand = Oot3dAotLsl(r1, 6U);
            r0 = r0 - operand;
        }
        {
            r2 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), true, static_cast<Oot3dAotFlagMask>(0x0U));
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 5U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (flags.C()) {
            const uint32_t operand = Oot3dAotLsl(r1, 5U);
            r0 = r0 - operand;
        }
        {
            r2 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), true, static_cast<Oot3dAotFlagMask>(0x0U));
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 4U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (flags.C()) {
            const uint32_t operand = Oot3dAotLsl(r1, 4U);
            r0 = r0 - operand;
        }
        {
            r2 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), true, static_cast<Oot3dAotFlagMask>(0x0U));
        }
        goto block_00368E84;
    }
block_00368E84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368E84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368E84U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 3U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (flags.C()) {
            const uint32_t operand = Oot3dAotLsl(r1, 3U);
            r0 = r0 - operand;
        }
        {
            r2 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), true, static_cast<Oot3dAotFlagMask>(0x0U));
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 2U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (flags.C()) {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r0 = r0 - operand;
        }
        {
            r2 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), true, static_cast<Oot3dAotFlagMask>(0x0U));
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 1U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (flags.C()) {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r0 = r0 - operand;
        }
        {
            r2 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), true, static_cast<Oot3dAotFlagMask>(0x0U));
        }
        {
            const uint32_t operand = r1;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r1 = r0 - operand;
        }
        if (!(flags.C())) {
            r1 = r0;
        }
        {
            r0 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), false, static_cast<Oot3dAotFlagMask>(0x0U));
        }
        return Oot3dAotReturned(r14);
    }
block_00368EB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368EB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368EB8U);
        }
        {
            const uint32_t operand = r1;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0x3U));
            r1 = r0 - operand;
        }
        if (!(flags.C())) { goto block_00368EC8; }
        goto block_00368EC0;
    }
block_00368EC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368EC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368EC0U);
        }
        {
            r0 = 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, r0, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        return Oot3dAotReturned(r14);
    }
block_00368EC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368EC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368EC8U);
        }
        {
            r1 = r0;
        }
        {
            r0 = 0x00000000U;
            Oot3dAotSetLogicalFlags(flags, r0, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        return Oot3dAotReturned(r14);
    }
block_00368ED4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368ED4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368ED4U);
        }
        {
            r2 = r1 & 0x80000000U;
            Oot3dAotSetLogicalFlags(flags, r2, (0x80000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xAU));
        }
        if (flags.N()) {
            const uint32_t operand = 0x00000000U;
            r1 = operand - r1;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r0, 2U, 0U, flags.C());
            r12 = r2 ^ shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r12, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 4U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (!(flags.C())) { goto block_00368F64; }
        goto block_00368EEC;
    }
block_00368EEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368EECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368EECU);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 8U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (!(flags.C())) { goto block_00368F34; }
        goto block_00368EF4;
    }
block_00368EF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368EF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368EF4U);
        }
        {
            r1 = Oot3dAotLsl(r1, 6U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 8U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        {
            r2 = r2 | 0xFC000000U;
        }
        if (!(flags.C())) { goto block_00368F34; }
        goto block_00368F04;
    }
block_00368F04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368F04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368F04U);
        }
        {
            r1 = Oot3dAotLsl(r1, 6U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 8U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        {
            r2 = r2 | 0x03F00000U;
        }
        if (!(flags.C())) { goto block_00368F34; }
        goto block_00368F14;
    }
block_00368F14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368F14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368F14U);
        }
        {
            r1 = Oot3dAotLsl(r1, 6U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 8U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        {
            r2 = r2 | 0x000FC000U;
        }
        if (flags.C()) {
            r1 = Oot3dAotLsl(r1, 6U);
        }
        if (flags.C()) {
            r2 = r2 | 0x00003F00U;
        }
        {
            const uint32_t operand = 0x00000000U;
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x3U));
            r3 = operand - r1;
        }
        if (flags.C()) { goto block_00368FA8; }
        goto block_00368F30;
    }
block_00368F30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368F30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368F30U);
        }
        if (flags.C()) {
            r1 = Oot3dAotLsr(r1, 6U);
        }
        goto block_00368F34;
    }
block_00368F34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368F34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368F34U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 7U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (flags.C()) {
            const uint32_t operand = Oot3dAotLsl(r1, 7U);
            r0 = r0 - operand;
        }
        {
            r2 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), true, static_cast<Oot3dAotFlagMask>(0x0U));
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 6U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (flags.C()) {
            const uint32_t operand = Oot3dAotLsl(r1, 6U);
            r0 = r0 - operand;
        }
        {
            r2 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), true, static_cast<Oot3dAotFlagMask>(0x0U));
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 5U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (flags.C()) {
            const uint32_t operand = Oot3dAotLsl(r1, 5U);
            r0 = r0 - operand;
        }
        {
            r2 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), true, static_cast<Oot3dAotFlagMask>(0x0U));
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 4U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (flags.C()) {
            const uint32_t operand = Oot3dAotLsl(r1, 4U);
            r0 = r0 - operand;
        }
        {
            r2 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), true, static_cast<Oot3dAotFlagMask>(0x0U));
        }
        goto block_00368F64;
    }
block_00368F64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368F64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368F64U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 3U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (flags.C()) {
            const uint32_t operand = Oot3dAotLsl(r1, 3U);
            r0 = r0 - operand;
        }
        {
            r2 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), true, static_cast<Oot3dAotFlagMask>(0x0U));
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 2U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (flags.C()) {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r0 = r0 - operand;
        }
        {
            r2 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), true, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_00368F30; }
        goto block_00368F80;
    }
block_00368F80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368F80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368F80U);
        }
        {
            const uint32_t operand = Oot3dAotLsr(r0, 1U);
            Oot3dAotSetSubtractFlags(flags, operand, r1, static_cast<Oot3dAotFlagMask>(0x2U));
            r3 = operand - r1;
        }
        if (flags.C()) {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r0 = r0 - operand;
        }
        {
            r2 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), true, static_cast<Oot3dAotFlagMask>(0x0U));
        }
        {
            const uint32_t operand = r1;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0x3U));
            r1 = r0 - operand;
        }
        if (!(flags.C())) {
            r1 = r0;
        }
        {
            r0 = Oot3dAotAddWithCarry(flags, r2, r2, flags.C(), false, static_cast<Oot3dAotFlagMask>(0x0U));
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r12, 2U, 31U, flags.C());
            r12 = shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r12, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.N()) {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        if (flags.C()) {
            const uint32_t operand = 0x00000000U;
            r1 = operand - r1;
        }
        return Oot3dAotReturned(r14);
    }
block_00368FA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368FA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368FA8U);
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r12, 2U, 31U, flags.C());
            r12 = shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r12, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xAU));
        }
        if (flags.N()) {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        goto block_00368FB0;
    }
block_00368FB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368FB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368FB0U);
        }
        {
            const uint32_t firstAddress = r13 - 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x00368FB0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00368FB0U,
                                           firstAddress + 4U);
            }
            r13 = r13 - 8U;
        }
        {
            r0 = 0x00000000U;
            Oot3dAotSetLogicalFlags(flags, r0, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00368FBCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_thunk_FUN_002df178_00490DF8(frame, context, state, 0x00490DF8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00368FBCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00368FBC;
    }
block_00368FBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00368FBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00368FBCU);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00368FBCU,
                                           firstAddress + 0U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00368FBCU,
                                           firstAddress + 4U);
            }
            r1 = value1;
            r13 = r13 + 8U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_0045a09c_0045A09C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0045A09CU:
        goto block_0045A09C;
    case 0x0045A0E8U:
        goto block_0045A0E8;
    case 0x0045A0F8U:
        goto block_0045A0F8;
    case 0x0045A118U:
        goto block_0045A118;
    case 0x0045A120U:
        goto block_0045A120;
    case 0x0045A12CU:
        goto block_0045A12C;
    case 0x0045A17CU:
        goto block_0045A17C;
    case 0x0045A190U:
        goto block_0045A190;
    case 0x0045A19CU:
        goto block_0045A19C;
    case 0x0045A1B8U:
        goto block_0045A1B8;
    case 0x0045A1E4U:
        goto block_0045A1E4;
    case 0x0045A224U:
        goto block_0045A224;
    case 0x0045A230U:
        goto block_0045A230;
    case 0x0045A238U:
        goto block_0045A238;
    case 0x0045A24CU:
        goto block_0045A24C;
    case 0x0045A254U:
        goto block_0045A254;
    case 0x0045A260U:
        goto block_0045A260;
    case 0x0045A28CU:
        goto block_0045A28C;
    case 0x0045A294U:
        goto block_0045A294;
    case 0x0045A2A0U:
        goto block_0045A2A0;
    case 0x0045A2B4U:
        goto block_0045A2B4;
    case 0x0045A2C4U:
        goto block_0045A2C4;
    case 0x0045A2D0U:
        goto block_0045A2D0;
    case 0x0045A2DCU:
        goto block_0045A2DC;
    case 0x0045A2E8U:
        goto block_0045A2E8;
    case 0x0045A32CU:
        goto block_0045A32C;
    case 0x0045A350U:
        goto block_0045A350;
    case 0x0045A368U:
        goto block_0045A368;
    case 0x0045A378U:
        goto block_0045A378;
    case 0x0045A394U:
        goto block_0045A394;
    case 0x0045A39CU:
        goto block_0045A39C;
    case 0x0045A3B4U:
        goto block_0045A3B4;
    case 0x0045A404U:
        goto block_0045A404;
    case 0x0045A418U:
        goto block_0045A418;
    case 0x0045A430U:
        goto block_0045A430;
    case 0x0045A43CU:
        goto block_0045A43C;
    case 0x0045A448U:
        goto block_0045A448;
    case 0x0045A454U:
        goto block_0045A454;
    case 0x0045A458U:
        goto block_0045A458;
    case 0x0045A478U:
        goto block_0045A478;
    case 0x0045A4B0U:
        goto block_0045A4B0;
    case 0x0045A4C0U:
        goto block_0045A4C0;
    case 0x0045A4D4U:
        goto block_0045A4D4;
    case 0x0045A4E0U:
        goto block_0045A4E0;
    case 0x0045A4E8U:
        goto block_0045A4E8;
    case 0x0045A4F4U:
        goto block_0045A4F4;
    case 0x0045A50CU:
        goto block_0045A50C;
    case 0x0045A530U:
        goto block_0045A530;
    case 0x0045A544U:
        goto block_0045A544;
    case 0x0045A560U:
        goto block_0045A560;
    case 0x0045A56CU:
        goto block_0045A56C;
    case 0x0045A574U:
        goto block_0045A574;
    case 0x0045A584U:
        goto block_0045A584;
    case 0x0045A5A4U:
        goto block_0045A5A4;
    case 0x0045A5ACU:
        goto block_0045A5AC;
    case 0x0045A5BCU:
        goto block_0045A5BC;
    case 0x0045A5C0U:
        goto block_0045A5C0;
    case 0x0045A5C4U:
        goto block_0045A5C4;
    case 0x0045A5C8U:
        goto block_0045A5C8;
    case 0x0045A5E8U:
        goto block_0045A5E8;
    case 0x0045A5FCU:
        goto block_0045A5FC;
    case 0x0045A614U:
        goto block_0045A614;
    case 0x0045A620U:
        goto block_0045A620;
    case 0x0045A62CU:
        goto block_0045A62C;
    case 0x0045A638U:
        goto block_0045A638;
    case 0x0045A63CU:
        goto block_0045A63C;
    case 0x0045A65CU:
        goto block_0045A65C;
    case 0x0045A688U:
        goto block_0045A688;
    case 0x0045A694U:
        goto block_0045A694;
    case 0x0045A6ACU:
        goto block_0045A6AC;
    case 0x0045A6B4U:
        goto block_0045A6B4;
    case 0x0045A6CCU:
        goto block_0045A6CC;
    case 0x0045A6FCU:
        goto block_0045A6FC;
    case 0x0045A700U:
        goto block_0045A700;
    case 0x0045A710U:
        goto block_0045A710;
    case 0x0045A748U:
        goto block_0045A748;
    case 0x0045A754U:
        goto block_0045A754;
    case 0x0045A784U:
        goto block_0045A784;
    case 0x0045A7B4U:
        goto block_0045A7B4;
    case 0x0045A7CCU:
        goto block_0045A7CC;
    case 0x0045A7E4U:
        goto block_0045A7E4;
    case 0x0045A7ECU:
        goto block_0045A7EC;
    case 0x0045A800U:
        goto block_0045A800;
    case 0x0045A818U:
        goto block_0045A818;
    case 0x0045A824U:
        goto block_0045A824;
    case 0x0045A830U:
        goto block_0045A830;
    case 0x0045A83CU:
        goto block_0045A83C;
    case 0x0045A840U:
        goto block_0045A840;
    case 0x0045A860U:
        goto block_0045A860;
    case 0x0045A898U:
        goto block_0045A898;
    case 0x0045A8A8U:
        goto block_0045A8A8;
    case 0x0045A8BCU:
        goto block_0045A8BC;
    case 0x0045A8C8U:
        goto block_0045A8C8;
    case 0x0045A8E0U:
        goto block_0045A8E0;
    case 0x0045A8F4U:
        goto block_0045A8F4;
    case 0x0045A908U:
        goto block_0045A908;
    case 0x0045A914U:
        goto block_0045A914;
    case 0x0045A920U:
        goto block_0045A920;
    case 0x0045A938U:
        goto block_0045A938;
    case 0x0045A984U:
        goto block_0045A984;
    case 0x0045A994U:
        goto block_0045A994;
    case 0x0045A9A0U:
        goto block_0045A9A0;
    case 0x0045A9D4U:
        goto block_0045A9D4;
    case 0x0045A9DCU:
        goto block_0045A9DC;
    case 0x0045A9ECU:
        goto block_0045A9EC;
    case 0x0045AA0CU:
        goto block_0045AA0C;
    case 0x0045AA18U:
        goto block_0045AA18;
    case 0x0045AA20U:
        goto block_0045AA20;
    case 0x0045AA30U:
        goto block_0045AA30;
    case 0x0045AA4CU:
        goto block_0045AA4C;
    case 0x0045AA50U:
        goto block_0045AA50;
    case 0x0045AA54U:
        goto block_0045AA54;
    case 0x0045AA74U:
        goto block_0045AA74;
    case 0x0045AA8CU:
        goto block_0045AA8C;
    case 0x0045AA94U:
        goto block_0045AA94;
    case 0x0045AAA4U:
        goto block_0045AAA4;
    case 0x0045AAB4U:
        goto block_0045AAB4;
    case 0x0045AAB8U:
        goto block_0045AAB8;
    case 0x0045AAE0U:
        goto block_0045AAE0;
    case 0x0045AB00U:
        goto block_0045AB00;
    case 0x0045AB18U:
        goto block_0045AB18;
    case 0x0045AB28U:
        goto block_0045AB28;
    case 0x0045AB34U:
        goto block_0045AB34;
    case 0x0045AB70U:
        goto block_0045AB70;
    case 0x0045AB88U:
        goto block_0045AB88;
    case 0x0045AB9CU:
        goto block_0045AB9C;
    case 0x0045ABB4U:
        goto block_0045ABB4;
    case 0x0045ABC0U:
        goto block_0045ABC0;
    case 0x0045ABE4U:
        goto block_0045ABE4;
    case 0x0045ABF8U:
        goto block_0045ABF8;
    case 0x0045AC34U:
        goto block_0045AC34;
    case 0x0045AC3CU:
        goto block_0045AC3C;
    case 0x0045AC48U:
        goto block_0045AC48;
    case 0x0045AC50U:
        goto block_0045AC50;
    case 0x0045AC68U:
        goto block_0045AC68;
    case 0x0045AC7CU:
        goto block_0045AC7C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0045A09C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A09CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A09CU);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0045A09CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0045A09CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0045A09CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0045A09CU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0045A09CU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0045A09CU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0045A09CU,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x0045A09CU,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0045A09CU,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r9 = r0;
        }
        {
            const uint32_t operand = 0x00002800U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x000003A4U;
            r0 = r0 + operand;
        }
        {
            r13 -= 8U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0045A0ACU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0045A0ACU,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = 0x0045A0BCU + 0x318U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A0B4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A0B8U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0045A0C4U + 0x30CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A0BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00002000U;
            r5 = r9 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A0C4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x000008A0U;
            r5 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + r9;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A0CCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A0D0U, address);
            }
        }
        {
            r0 = 0x00000190U;
        }
        {
            const uint32_t updatedAddress = r0 + r1;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A0D8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0045A0F8; }
        goto block_0045A0E8;
    }
block_0045A0E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A0E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A0E8U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r9 + operand;
        }
        {
            r1 = r9;
        }
        {
            const uint32_t operand = 0x000000F8U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045A0F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0047b144_0047B144(frame, context, state, 0x0047B144U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045A0F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045A0F8;
    }
block_0045A0F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A0F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A0F8U);
        }
        {
            const uint32_t updatedAddress = 0x0045A100U + 0x2D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A0F8U, address);
            }
            r4 = value;
        }
        {
            const uint32_t updatedAddress = 0x0045A104U + 0x2E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A0FCU, address);
            }
            r10 = value;
        }
        {
            const uint32_t address = 0x0045A108U + 724U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A100U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x0045A10CU + 724U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A104U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A108U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00001500U;
            r11 = r4 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0045A230; }
        goto block_0045A118;
    }
block_0045A118:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A118U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A118U);
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045A120U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_GetState_003769D8(frame, context, state, 0x003769D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045A120U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045A120;
    }
block_0045A120:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A120U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A120U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0045A230; }
        goto block_0045A12C;
    }
block_0045A12C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A12CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A12CU);
        }
        {
            const uint32_t updatedAddress = 0x0045A134U + 0x2A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A12CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A130U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A138U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0045A140U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0045A144U, 0xEE880A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0045A148U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0045A14CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r10 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A154U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r11 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A15CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x62U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A160U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x80U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A164U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000003BU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000003CU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000003DU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000055U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0045A190; }
        goto block_0045A17C;
    }
block_0045A17C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A17CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A17CU);
        }
        {
            const uint32_t updatedAddress = 0x0045A184U + 0x264U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A17CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x56FU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A180U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r0 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r11 + 0x80U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A18CU, address);
            }
        }
        goto block_0045A190;
    }
block_0045A190:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A190U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A190U);
        }
        {
            const uint32_t updatedAddress = 0x0045A198U + 0x254U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A190U, address);
            }
            r8 = value;
        }
        {
            r5 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r6 = r11 + operand;
        }
        goto block_0045A19C;
    }
block_0045A19C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A19CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A19CU);
        }
        {
            const uint32_t updatedAddress = 0x0045A1A4U + 0x24CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A19CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0x2DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A1A0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 1U);
            r7 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + r6;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A1A8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A1ACU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0045A224; }
        goto block_0045A1B8;
    }
block_0045A1B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A1B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A1B8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x8AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A1B8U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000007U;
        }
        {
            r2 = 0x00000014U;
        }
        {
            r0 = r0 & ~(0x00008000U);
        }
        {
            r0 = r0 & ~(0x0000007FU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x8AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A1CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0045A1D8U + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A1D0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A1D8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045A1E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_QueueTextRequest_003716F0(frame, context, state, 0x003716F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045A1E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045A1E4;
    }
block_0045A1E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A1E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A1E4U);
        }
        {
            const uint32_t updatedAddress = 0x0045A1ECU + 0x20CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A1E4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r5, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A1ECU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r1 & 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r8 + r1;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A1F4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r6;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A1F8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x81U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A1FCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A200U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r1, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r11 + 0x81U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A208U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x82U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A20CU, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r1, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r11 + 0x82U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A214U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x83U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A218U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r1, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r11 + 0x83U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A220U, address);
            }
        }
        goto block_0045A224;
    }
block_0045A224:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A224U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A224U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r5 = r5 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0045A19C; }
        goto block_0045A230;
    }
block_0045A230:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A230U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A230U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045A238U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseContext_GetState_003695F8(frame, context, state, 0x003695F8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045A238U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045A238;
    }
block_0045A238:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A238U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A238U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x0045A244U + 0x1B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A23CU, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r0 + r9;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A240U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0045ABE4; }
        goto block_0045A24C;
    }
block_0045A24C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A24CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A24CU);
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045A254U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00366748_00366748(frame, context, state, 0x00366748U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045A254U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045A254;
    }
block_0045A254:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A254U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A254U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        {
        }
        if (!(flags.Z())) { goto block_0045ABE4; }
        goto block_0045A260;
    }
block_0045A260:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A260U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A260U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A260U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x714U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A268U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x01000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x01000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) {
            const uint32_t operand = 0x00005C00U;
            r5 = r9 + operand;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x2DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A274U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x0045A284U + 0x17CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A27CU, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r0 + r9;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A280U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0045ABE4; }
        goto block_0045A28C;
    }
block_0045A28C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A28CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A28CU);
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045A294U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_InCsMode_0037577C(frame, context, state, 0x0037577CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045A294U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045A294;
    }
block_0045A294:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A294U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A294U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (!(flags.Z())) { goto block_0045ABE4; }
        goto block_0045A2A0;
    }
block_0045A2A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A2A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A2A0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x94U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A2A0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x74U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A2A8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_0045ABE4; }
        goto block_0045A2B4;
    }
block_0045A2B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A2B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A2B4U);
        }
        {
            const uint32_t operand = 0x00000100U;
            r5 = r9 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A2B8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0045A2DC; }
        goto block_0045A2C4;
    }
block_0045A2C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A2C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A2C4U);
        }
        {
            r1 = 0x00000038U;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045A2D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Flags_GetSwitch_0036E864(frame, context, state, 0x0036E864U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045A2D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045A2D0;
    }
block_0045A2D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A2D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A2D0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (!(flags.Z())) { goto block_0045ABE4; }
        goto block_0045A2DC;
    }
block_0045A2DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A2DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A2DCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A2DCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000010U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x0045A2ECU + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A2E4U, address);
            }
            switch (value) {
            case 0x0045A09CU:
                goto block_0045A09C;
            case 0x0045A0E8U:
                goto block_0045A0E8;
            case 0x0045A0F8U:
                goto block_0045A0F8;
            case 0x0045A118U:
                goto block_0045A118;
            case 0x0045A120U:
                goto block_0045A120;
            case 0x0045A12CU:
                goto block_0045A12C;
            case 0x0045A17CU:
                goto block_0045A17C;
            case 0x0045A190U:
                goto block_0045A190;
            case 0x0045A19CU:
                goto block_0045A19C;
            case 0x0045A1B8U:
                goto block_0045A1B8;
            case 0x0045A1E4U:
                goto block_0045A1E4;
            case 0x0045A224U:
                goto block_0045A224;
            case 0x0045A230U:
                goto block_0045A230;
            case 0x0045A238U:
                goto block_0045A238;
            case 0x0045A24CU:
                goto block_0045A24C;
            case 0x0045A254U:
                goto block_0045A254;
            case 0x0045A260U:
                goto block_0045A260;
            case 0x0045A28CU:
                goto block_0045A28C;
            case 0x0045A294U:
                goto block_0045A294;
            case 0x0045A2A0U:
                goto block_0045A2A0;
            case 0x0045A2B4U:
                goto block_0045A2B4;
            case 0x0045A2C4U:
                goto block_0045A2C4;
            case 0x0045A2D0U:
                goto block_0045A2D0;
            case 0x0045A2DCU:
                goto block_0045A2DC;
            case 0x0045A2E8U:
                goto block_0045A2E8;
            case 0x0045A32CU:
                goto block_0045A32C;
            case 0x0045A350U:
                goto block_0045A350;
            case 0x0045A368U:
                goto block_0045A368;
            case 0x0045A378U:
                goto block_0045A378;
            case 0x0045A394U:
                goto block_0045A394;
            case 0x0045A39CU:
                goto block_0045A39C;
            case 0x0045A3B4U:
                goto block_0045A3B4;
            case 0x0045A404U:
                goto block_0045A404;
            case 0x0045A418U:
                goto block_0045A418;
            case 0x0045A430U:
                goto block_0045A430;
            case 0x0045A43CU:
                goto block_0045A43C;
            case 0x0045A448U:
                goto block_0045A448;
            case 0x0045A454U:
                goto block_0045A454;
            case 0x0045A458U:
                goto block_0045A458;
            case 0x0045A478U:
                goto block_0045A478;
            case 0x0045A4B0U:
                goto block_0045A4B0;
            case 0x0045A4C0U:
                goto block_0045A4C0;
            case 0x0045A4D4U:
                goto block_0045A4D4;
            case 0x0045A4E0U:
                goto block_0045A4E0;
            case 0x0045A4E8U:
                goto block_0045A4E8;
            case 0x0045A4F4U:
                goto block_0045A4F4;
            case 0x0045A50CU:
                goto block_0045A50C;
            case 0x0045A530U:
                goto block_0045A530;
            case 0x0045A544U:
                goto block_0045A544;
            case 0x0045A560U:
                goto block_0045A560;
            case 0x0045A56CU:
                goto block_0045A56C;
            case 0x0045A574U:
                goto block_0045A574;
            case 0x0045A584U:
                goto block_0045A584;
            case 0x0045A5A4U:
                goto block_0045A5A4;
            case 0x0045A5ACU:
                goto block_0045A5AC;
            case 0x0045A5BCU:
                goto block_0045A5BC;
            case 0x0045A5C0U:
                goto block_0045A5C0;
            case 0x0045A5C4U:
                goto block_0045A5C4;
            case 0x0045A5C8U:
                goto block_0045A5C8;
            case 0x0045A5E8U:
                goto block_0045A5E8;
            case 0x0045A5FCU:
                goto block_0045A5FC;
            case 0x0045A614U:
                goto block_0045A614;
            case 0x0045A620U:
                goto block_0045A620;
            case 0x0045A62CU:
                goto block_0045A62C;
            case 0x0045A638U:
                goto block_0045A638;
            case 0x0045A63CU:
                goto block_0045A63C;
            case 0x0045A65CU:
                goto block_0045A65C;
            case 0x0045A688U:
                goto block_0045A688;
            case 0x0045A694U:
                goto block_0045A694;
            case 0x0045A6ACU:
                goto block_0045A6AC;
            case 0x0045A6B4U:
                goto block_0045A6B4;
            case 0x0045A6CCU:
                goto block_0045A6CC;
            case 0x0045A6FCU:
                goto block_0045A6FC;
            case 0x0045A700U:
                goto block_0045A700;
            case 0x0045A710U:
                goto block_0045A710;
            case 0x0045A748U:
                goto block_0045A748;
            case 0x0045A754U:
                goto block_0045A754;
            case 0x0045A784U:
                goto block_0045A784;
            case 0x0045A7B4U:
                goto block_0045A7B4;
            case 0x0045A7CCU:
                goto block_0045A7CC;
            case 0x0045A7E4U:
                goto block_0045A7E4;
            case 0x0045A7ECU:
                goto block_0045A7EC;
            case 0x0045A800U:
                goto block_0045A800;
            case 0x0045A818U:
                goto block_0045A818;
            case 0x0045A824U:
                goto block_0045A824;
            case 0x0045A830U:
                goto block_0045A830;
            case 0x0045A83CU:
                goto block_0045A83C;
            case 0x0045A840U:
                goto block_0045A840;
            case 0x0045A860U:
                goto block_0045A860;
            case 0x0045A898U:
                goto block_0045A898;
            case 0x0045A8A8U:
                goto block_0045A8A8;
            case 0x0045A8BCU:
                goto block_0045A8BC;
            case 0x0045A8C8U:
                goto block_0045A8C8;
            case 0x0045A8E0U:
                goto block_0045A8E0;
            case 0x0045A8F4U:
                goto block_0045A8F4;
            case 0x0045A908U:
                goto block_0045A908;
            case 0x0045A914U:
                goto block_0045A914;
            case 0x0045A920U:
                goto block_0045A920;
            case 0x0045A938U:
                goto block_0045A938;
            case 0x0045A984U:
                goto block_0045A984;
            case 0x0045A994U:
                goto block_0045A994;
            case 0x0045A9A0U:
                goto block_0045A9A0;
            case 0x0045A9D4U:
                goto block_0045A9D4;
            case 0x0045A9DCU:
                goto block_0045A9DC;
            case 0x0045A9ECU:
                goto block_0045A9EC;
            case 0x0045AA0CU:
                goto block_0045AA0C;
            case 0x0045AA18U:
                goto block_0045AA18;
            case 0x0045AA20U:
                goto block_0045AA20;
            case 0x0045AA30U:
                goto block_0045AA30;
            case 0x0045AA4CU:
                goto block_0045AA4C;
            case 0x0045AA50U:
                goto block_0045AA50;
            case 0x0045AA54U:
                goto block_0045AA54;
            case 0x0045AA74U:
                goto block_0045AA74;
            case 0x0045AA8CU:
                goto block_0045AA8C;
            case 0x0045AA94U:
                goto block_0045AA94;
            case 0x0045AAA4U:
                goto block_0045AAA4;
            case 0x0045AAB4U:
                goto block_0045AAB4;
            case 0x0045AAB8U:
                goto block_0045AAB8;
            case 0x0045AAE0U:
                goto block_0045AAE0;
            case 0x0045AB00U:
                goto block_0045AB00;
            case 0x0045AB18U:
                goto block_0045AB18;
            case 0x0045AB28U:
                goto block_0045AB28;
            case 0x0045AB34U:
                goto block_0045AB34;
            case 0x0045AB70U:
                goto block_0045AB70;
            case 0x0045AB88U:
                goto block_0045AB88;
            case 0x0045AB9CU:
                goto block_0045AB9C;
            case 0x0045ABB4U:
                goto block_0045ABB4;
            case 0x0045ABC0U:
                goto block_0045ABC0;
            case 0x0045ABE4U:
                goto block_0045ABE4;
            case 0x0045ABF8U:
                goto block_0045ABF8;
            case 0x0045AC34U:
                goto block_0045AC34;
            case 0x0045AC3CU:
                goto block_0045AC3C;
            case 0x0045AC48U:
                goto block_0045AC48;
            case 0x0045AC50U:
                goto block_0045AC50;
            case 0x0045AC68U:
                goto block_0045AC68;
            case 0x0045AC7CU:
                goto block_0045AC7C;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_0045A2E8;
    }
block_0045A2E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A2E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A2E8U);
        }
        goto block_0045A748;
    }
block_0045A32C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A32CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A32CU);
        }
        {
            r0 = 0x0000001EU;
        }
        {
            const uint32_t updatedAddress = r10 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A330U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A334U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x44U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A338U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = 0x00000002U;
        }
        {
            r1 = Oot3dAotAsr(r1, 1U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x60U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0045A344U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x5EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A348U, address);
            }
        }
        goto block_0045AB34;
    }
block_0045A350:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A350U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A350U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A350U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r10 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A360U, address);
            }
        }
        if (!(flags.Z())) { goto block_0045AB34; }
        goto block_0045A368;
    }
block_0045A368:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A368U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A368U);
        }
        {
            r0 = 0x0000001EU;
        }
        {
            const uint32_t updatedAddress = r10 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A36CU, address);
            }
        }
        {
            r0 = 0x00000003U;
        }
        goto block_0045A394;
    }
block_0045A378:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A378U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A378U);
        }
        {
            r0 = 0x0000001EU;
        }
        {
            const uint32_t updatedAddress = r10 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A37CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A380U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A384U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = 0x0000000CU;
        }
        if (flags.Z()) {
            r0 = 0x00000006U;
        }
        goto block_0045A394;
    }
block_0045A394:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A394U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A394U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x5EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A394U, address);
            }
        }
        goto block_0045AB34;
    }
block_0045A39C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A39CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A39CU);
        }
        {
            const uint32_t updatedAddress = r10 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A39CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r10 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A3ACU, address);
            }
        }
        if (!(flags.Z())) { goto block_0045AB18; }
        goto block_0045A3B4;
    }
block_0045A3B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A3B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A3B4U);
        }
        {
            r0 = 0x0000001EU;
        }
        {
            const uint32_t updatedAddress = r10 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A3B8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A3BCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000006U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = 0x0000000DU;
        }
        if (flags.Z()) {
            r0 = 0x00000007U;
        }
        goto block_0045A394;
    }
block_0045A404:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A404U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A404U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x66U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A404U, address);
            }
            r5 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r10 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A408U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x0000001AU;
            r0 = r5 - operand;
        }
        {
            r6 = r1;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045A418U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045A418U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045A418;
    }
block_0045A418:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A418U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A418U);
        }
        {
            const uint32_t operand = r0;
            r0 = r5 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x66U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A41CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x42U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A420U, address);
            }
            r5 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r4 + 0x6AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A424U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x000000A0U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0045A448; }
        goto block_0045A430;
    }
block_0045A430:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A430U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A430U);
        }
        {
            const uint32_t operand = 0x00000036U;
            r0 = r0 - operand;
        }
        {
            r1 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045A43CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045A43CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045A43C;
    }
block_0045A43C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A43CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A43CU);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
        }
        goto block_0045A458;
    }
block_0045A448:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A448U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A448U);
        }
        {
            const uint32_t operand = 0x0000002EU;
            r0 = r0 - operand;
        }
        {
            r1 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045A454U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045A454U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045A454;
    }
block_0045A454:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A454U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A454U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        goto block_0045A458;
    }
block_0045A458:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A458U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A458U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x6AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A458U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r0;
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A460U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r6 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r10 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A470U, address);
            }
        }
        if (!(flags.Z())) { goto block_0045A4B0; }
        goto block_0045A478;
    }
block_0045A478:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A478U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A478U);
        }
        {
            r0 = 0x0000001EU;
        }
        {
            const uint32_t updatedAddress = r10 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A47CU, address);
            }
        }
        {
            r0 = 0x0000001AU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x000000A0U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x66U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A488U, address);
            }
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            r0 = 0x0000002EU;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r0 = 0x00000036U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A494U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A498U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = 0x00000008U;
        }
        if (flags.Z()) {
            r0 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x5EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A4A8U, address);
            }
        }
        goto block_0045A4C0;
    }
block_0045A4B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A4B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A4B0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A4B0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0045A4D4; }
        goto block_0045A4C0;
    }
block_0045A4C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A4C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A4C0U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x42U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A4C0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000A0U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            r0 = 0x0000002EU;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r0 = 0x00000036U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A4D0U, address);
            }
        }
        goto block_0045A4D4;
    }
block_0045A4D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A4D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A4D4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A4D4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0045AB18; }
        goto block_0045A4E0;
    }
block_0045A4E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A4E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A4E0U);
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045A4E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00366748_00366748(frame, context, state, 0x00366748U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045A4E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045A4E8;
    }
block_0045A4E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A4E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A4E8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (!(flags.Z())) { goto block_0045AB18; }
        goto block_0045A4F4;
    }
block_0045A4F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A4F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A4F4U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x16U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A4F4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r10 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A504U, address);
            }
        }
        if (!(flags.Z())) { goto block_0045AB18; }
        goto block_0045A50C;
    }
block_0045A50C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A50CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A50CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x60U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A50CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x60U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A518U, address);
            }
        }
        {
            r0 = 0x0000001EU;
        }
        {
            const uint32_t updatedAddress = r10 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A520U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x60U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A524U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0045A56C; }
        goto block_0045A530;
    }
block_0045A530:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A530U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A530U);
        }
        {
            r0 = 0x0000000AU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x5EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A534U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A538U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0045A560; }
        goto block_0045A544;
    }
block_0045A544:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A544U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A544U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r11 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A548U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0045A554U + 0x734U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A54CU, address);
            }
            r0 = value;
        }
        {
            r1 = ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r0 + r9;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A554U, address);
            }
            r2 = value;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x0045A560U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r2, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045A560U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045A560;
    }
block_0045A560:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A560U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A560U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r10 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A564U, address);
            }
        }
        goto block_0045AB18;
    }
block_0045A56C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A56CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A56CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000003CU, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0045A5A4; }
        goto block_0045A574;
    }
block_0045A574:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A574U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A574U);
        }
        {
            const uint32_t updatedAddress = 0x0045A57CU + 0x710U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A574U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A578U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0045AB18; }
        goto block_0045A584;
    }
block_0045A584:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A584U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A584U);
        }
        {
            const uint32_t updatedAddress = 0x0045A58CU + 0x704U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A584U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0045A590U + 0x704U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A588U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0045A594U + 0x704U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A58CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0045A594U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        goto block_0045A5C0;
    }
block_0045A5A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A5A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A5A4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0045A5C8; }
        goto block_0045A5AC;
    }
block_0045A5AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A5ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A5ACU);
        }
        {
            const uint32_t updatedAddress = 0x0045A5B4U + 0x6D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A5ACU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A5B0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0045AB18; }
        goto block_0045A5BC;
    }
block_0045A5BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A5BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A5BCU);
        }
        goto block_0045AAE0;
    }
block_0045A5C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A5C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A5C0U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045A5C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045A5C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045A5C4;
    }
block_0045A5C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A5C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A5C4U);
        }
        goto block_0045AB18;
    }
block_0045A5C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A5C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A5C8U);
        }
        {
            const uint32_t updatedAddress = 0x0045A5D0U + 0x6C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A5C8U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0045A5D4U + 0x6C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A5CCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0045A5D8U + 0x6C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A5D0U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0045A5D8U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        goto block_0045A5C0;
    }
block_0045A5E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A5E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A5E8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x66U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A5E8U, address);
            }
            r5 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r10 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A5ECU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x0000001AU;
            r0 = r5 - operand;
        }
        {
            r6 = r1;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045A5FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045A5FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045A5FC;
    }
block_0045A5FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A5FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A5FCU);
        }
        {
            const uint32_t operand = r0;
            r0 = r5 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x66U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A600U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x42U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A604U, address);
            }
            r5 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r4 + 0x6AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A608U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x000000A0U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0045A62C; }
        goto block_0045A614;
    }
block_0045A614:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A614U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A614U);
        }
        {
            const uint32_t operand = 0x00000036U;
            r0 = r0 - operand;
        }
        {
            r1 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045A620U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045A620U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045A620;
    }
block_0045A620:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A620U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A620U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
        }
        goto block_0045A63C;
    }
block_0045A62C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A62CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A62CU);
        }
        {
            const uint32_t operand = 0x0000002EU;
            r0 = r0 - operand;
        }
        {
            r1 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045A638U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045A638U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045A638;
    }
block_0045A638:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A638U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A638U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        goto block_0045A63C;
    }
block_0045A63C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A63CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A63CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x6AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A63CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r0;
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A644U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r6 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r10 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A654U, address);
            }
        }
        if (!(flags.Z())) { goto block_0045A6B4; }
        goto block_0045A65C;
    }
block_0045A65C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A65CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A65CU);
        }
        {
            r0 = 0x0000001EU;
        }
        {
            const uint32_t updatedAddress = r10 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A660U, address);
            }
        }
        {
            r0 = 0x0000001AU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x000000A0U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x66U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A66CU, address);
            }
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            r0 = 0x0000002EU;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r0 = 0x00000036U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A678U, address);
            }
        }
        {
            r0 = 0x0000000EU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x5EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A680U, address);
            }
        }
        goto block_0045A694;
    }
block_0045A688:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A688U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A688U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A688U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000EU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0045A6AC; }
        goto block_0045A694;
    }
block_0045A694:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A694U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A694U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x42U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A694U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000A0U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            r0 = 0x0000002EU;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r0 = 0x00000036U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A6A4U, address);
            }
        }
        goto block_0045A6B4;
    }
block_0045A6AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A6ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A6ACU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0045AB18; }
        goto block_0045A6B4;
    }
block_0045A6B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A6B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A6B4U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x16U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A6B4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r10 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A6C4U, address);
            }
        }
        if (!(flags.Z())) { goto block_0045AB18; }
        goto block_0045A6CC;
    }
block_0045A6CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A6CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A6CCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x60U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A6CCU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x0000001EU;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x60U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A6DCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0045A6E0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000E00U;
            r1 = r0 - operand;
        }
        {
            const uint32_t operand = 0x0000000FU;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r1 = r1 - operand;
        }
        if (flags.Z()) {
            r0 = 0x0000003CU;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r10 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A6F0U, address);
            }
        }
        if (flags.Z()) {
            r0 = 0x0000000FU;
        }
        if (flags.Z()) { goto block_0045A394; }
        goto block_0045A6FC;
    }
block_0045A6FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A6FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A6FCU);
        }
        goto block_0045AAE0;
    }
block_0045A700:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A700U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A700U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A700U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x5EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A708U, address);
            }
        }
        if (flags.Z()) { goto block_0045ABE4; }
        goto block_0045A710;
    }
block_0045A710:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A710U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A710U);
        }
        {
            r1 = 0x0000001EU;
        }
        {
            const uint32_t updatedAddress = r10 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0045A714U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x1AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0045A718U, address);
            }
        }
        {
            r1 = 0x0000008CU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0045A724U, address);
            }
        }
        {
            r1 = 0x00000050U;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r0 = 0x00000008U;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0045A734U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x62U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A738U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x5EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A740U, address);
            }
        }
        goto block_0045AB28;
    }
block_0045A748:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A748U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A748U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A748U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x0045A758U + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A750U, address);
            }
            switch (value) {
            case 0x0045A09CU:
                goto block_0045A09C;
            case 0x0045A0E8U:
                goto block_0045A0E8;
            case 0x0045A0F8U:
                goto block_0045A0F8;
            case 0x0045A118U:
                goto block_0045A118;
            case 0x0045A120U:
                goto block_0045A120;
            case 0x0045A12CU:
                goto block_0045A12C;
            case 0x0045A17CU:
                goto block_0045A17C;
            case 0x0045A190U:
                goto block_0045A190;
            case 0x0045A19CU:
                goto block_0045A19C;
            case 0x0045A1B8U:
                goto block_0045A1B8;
            case 0x0045A1E4U:
                goto block_0045A1E4;
            case 0x0045A224U:
                goto block_0045A224;
            case 0x0045A230U:
                goto block_0045A230;
            case 0x0045A238U:
                goto block_0045A238;
            case 0x0045A24CU:
                goto block_0045A24C;
            case 0x0045A254U:
                goto block_0045A254;
            case 0x0045A260U:
                goto block_0045A260;
            case 0x0045A28CU:
                goto block_0045A28C;
            case 0x0045A294U:
                goto block_0045A294;
            case 0x0045A2A0U:
                goto block_0045A2A0;
            case 0x0045A2B4U:
                goto block_0045A2B4;
            case 0x0045A2C4U:
                goto block_0045A2C4;
            case 0x0045A2D0U:
                goto block_0045A2D0;
            case 0x0045A2DCU:
                goto block_0045A2DC;
            case 0x0045A2E8U:
                goto block_0045A2E8;
            case 0x0045A32CU:
                goto block_0045A32C;
            case 0x0045A350U:
                goto block_0045A350;
            case 0x0045A368U:
                goto block_0045A368;
            case 0x0045A378U:
                goto block_0045A378;
            case 0x0045A394U:
                goto block_0045A394;
            case 0x0045A39CU:
                goto block_0045A39C;
            case 0x0045A3B4U:
                goto block_0045A3B4;
            case 0x0045A404U:
                goto block_0045A404;
            case 0x0045A418U:
                goto block_0045A418;
            case 0x0045A430U:
                goto block_0045A430;
            case 0x0045A43CU:
                goto block_0045A43C;
            case 0x0045A448U:
                goto block_0045A448;
            case 0x0045A454U:
                goto block_0045A454;
            case 0x0045A458U:
                goto block_0045A458;
            case 0x0045A478U:
                goto block_0045A478;
            case 0x0045A4B0U:
                goto block_0045A4B0;
            case 0x0045A4C0U:
                goto block_0045A4C0;
            case 0x0045A4D4U:
                goto block_0045A4D4;
            case 0x0045A4E0U:
                goto block_0045A4E0;
            case 0x0045A4E8U:
                goto block_0045A4E8;
            case 0x0045A4F4U:
                goto block_0045A4F4;
            case 0x0045A50CU:
                goto block_0045A50C;
            case 0x0045A530U:
                goto block_0045A530;
            case 0x0045A544U:
                goto block_0045A544;
            case 0x0045A560U:
                goto block_0045A560;
            case 0x0045A56CU:
                goto block_0045A56C;
            case 0x0045A574U:
                goto block_0045A574;
            case 0x0045A584U:
                goto block_0045A584;
            case 0x0045A5A4U:
                goto block_0045A5A4;
            case 0x0045A5ACU:
                goto block_0045A5AC;
            case 0x0045A5BCU:
                goto block_0045A5BC;
            case 0x0045A5C0U:
                goto block_0045A5C0;
            case 0x0045A5C4U:
                goto block_0045A5C4;
            case 0x0045A5C8U:
                goto block_0045A5C8;
            case 0x0045A5E8U:
                goto block_0045A5E8;
            case 0x0045A5FCU:
                goto block_0045A5FC;
            case 0x0045A614U:
                goto block_0045A614;
            case 0x0045A620U:
                goto block_0045A620;
            case 0x0045A62CU:
                goto block_0045A62C;
            case 0x0045A638U:
                goto block_0045A638;
            case 0x0045A63CU:
                goto block_0045A63C;
            case 0x0045A65CU:
                goto block_0045A65C;
            case 0x0045A688U:
                goto block_0045A688;
            case 0x0045A694U:
                goto block_0045A694;
            case 0x0045A6ACU:
                goto block_0045A6AC;
            case 0x0045A6B4U:
                goto block_0045A6B4;
            case 0x0045A6CCU:
                goto block_0045A6CC;
            case 0x0045A6FCU:
                goto block_0045A6FC;
            case 0x0045A700U:
                goto block_0045A700;
            case 0x0045A710U:
                goto block_0045A710;
            case 0x0045A748U:
                goto block_0045A748;
            case 0x0045A754U:
                goto block_0045A754;
            case 0x0045A784U:
                goto block_0045A784;
            case 0x0045A7B4U:
                goto block_0045A7B4;
            case 0x0045A7CCU:
                goto block_0045A7CC;
            case 0x0045A7E4U:
                goto block_0045A7E4;
            case 0x0045A7ECU:
                goto block_0045A7EC;
            case 0x0045A800U:
                goto block_0045A800;
            case 0x0045A818U:
                goto block_0045A818;
            case 0x0045A824U:
                goto block_0045A824;
            case 0x0045A830U:
                goto block_0045A830;
            case 0x0045A83CU:
                goto block_0045A83C;
            case 0x0045A840U:
                goto block_0045A840;
            case 0x0045A860U:
                goto block_0045A860;
            case 0x0045A898U:
                goto block_0045A898;
            case 0x0045A8A8U:
                goto block_0045A8A8;
            case 0x0045A8BCU:
                goto block_0045A8BC;
            case 0x0045A8C8U:
                goto block_0045A8C8;
            case 0x0045A8E0U:
                goto block_0045A8E0;
            case 0x0045A8F4U:
                goto block_0045A8F4;
            case 0x0045A908U:
                goto block_0045A908;
            case 0x0045A914U:
                goto block_0045A914;
            case 0x0045A920U:
                goto block_0045A920;
            case 0x0045A938U:
                goto block_0045A938;
            case 0x0045A984U:
                goto block_0045A984;
            case 0x0045A994U:
                goto block_0045A994;
            case 0x0045A9A0U:
                goto block_0045A9A0;
            case 0x0045A9D4U:
                goto block_0045A9D4;
            case 0x0045A9DCU:
                goto block_0045A9DC;
            case 0x0045A9ECU:
                goto block_0045A9EC;
            case 0x0045AA0CU:
                goto block_0045AA0C;
            case 0x0045AA18U:
                goto block_0045AA18;
            case 0x0045AA20U:
                goto block_0045AA20;
            case 0x0045AA30U:
                goto block_0045AA30;
            case 0x0045AA4CU:
                goto block_0045AA4C;
            case 0x0045AA50U:
                goto block_0045AA50;
            case 0x0045AA54U:
                goto block_0045AA54;
            case 0x0045AA74U:
                goto block_0045AA74;
            case 0x0045AA8CU:
                goto block_0045AA8C;
            case 0x0045AA94U:
                goto block_0045AA94;
            case 0x0045AAA4U:
                goto block_0045AAA4;
            case 0x0045AAB4U:
                goto block_0045AAB4;
            case 0x0045AAB8U:
                goto block_0045AAB8;
            case 0x0045AAE0U:
                goto block_0045AAE0;
            case 0x0045AB00U:
                goto block_0045AB00;
            case 0x0045AB18U:
                goto block_0045AB18;
            case 0x0045AB28U:
                goto block_0045AB28;
            case 0x0045AB34U:
                goto block_0045AB34;
            case 0x0045AB70U:
                goto block_0045AB70;
            case 0x0045AB88U:
                goto block_0045AB88;
            case 0x0045AB9CU:
                goto block_0045AB9C;
            case 0x0045ABB4U:
                goto block_0045ABB4;
            case 0x0045ABC0U:
                goto block_0045ABC0;
            case 0x0045ABE4U:
                goto block_0045ABE4;
            case 0x0045ABF8U:
                goto block_0045ABF8;
            case 0x0045AC34U:
                goto block_0045AC34;
            case 0x0045AC3CU:
                goto block_0045AC3C;
            case 0x0045AC48U:
                goto block_0045AC48;
            case 0x0045AC50U:
                goto block_0045AC50;
            case 0x0045AC68U:
                goto block_0045AC68;
            case 0x0045AC7CU:
                goto block_0045AC7C;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_0045A754;
    }
block_0045A754:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A754U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A754U);
        }
        goto block_0045AB18;
    }
block_0045A784:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A784U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A784U);
        }
        {
            r0 = 0x0000001EU;
        }
        {
            const uint32_t updatedAddress = r10 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A788U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x1AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A78CU, address);
            }
        }
        {
            r0 = 0x0000008CU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A794U, address);
            }
        }
        {
            r0 = 0x00000050U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A79CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A7A0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = 0x00000008U;
        }
        if (flags.Z()) {
            r0 = 0x00000002U;
        }
        goto block_0045A7E4;
    }
block_0045A7B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A7B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A7B4U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A7B4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r10 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A7C4U, address);
            }
        }
        if (!(flags.Z())) { goto block_0045AB18; }
        goto block_0045A7CC;
    }
block_0045A7CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A7CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A7CCU);
        }
        {
            r0 = 0x0000001EU;
        }
        {
            const uint32_t updatedAddress = r10 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A7D0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A7D4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = 0x00000009U;
        }
        if (flags.Z()) {
            r0 = 0x00000003U;
        }
        goto block_0045A7E4;
    }
block_0045A7E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A7E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A7E4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x62U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A7E4U, address);
            }
        }
        goto block_0045AB18;
    }
block_0045A7EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A7ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A7ECU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x68U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A7ECU, address);
            }
            r6 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r10 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A7F0U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x0000001AU;
            r0 = r6 - operand;
        }
        {
            r7 = r1;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045A800U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045A800U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045A800;
    }
block_0045A800:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A800U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A800U);
        }
        {
            const uint32_t operand = r0;
            r0 = r6 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A804U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x42U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A808U, address);
            }
            r6 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r4 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A80CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x000000A0U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0045A830; }
        goto block_0045A818;
    }
block_0045A818:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A818U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A818U);
        }
        {
            const uint32_t operand = 0x00000036U;
            r0 = r0 - operand;
        }
        {
            r1 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045A824U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045A824U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045A824;
    }
block_0045A824:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A824U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A824U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
        }
        goto block_0045A840;
    }
block_0045A830:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A830U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A830U);
        }
        {
            const uint32_t operand = 0x0000002EU;
            r0 = r0 - operand;
        }
        {
            r1 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045A83CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045A83CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045A83C;
    }
block_0045A83C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A83CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A83CU);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        goto block_0045A840;
    }
block_0045A840:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A840U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A840U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A840U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r0;
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A848U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r7 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r10 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A858U, address);
            }
        }
        if (!(flags.Z())) { goto block_0045A898; }
        goto block_0045A860;
    }
block_0045A860:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A860U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A860U);
        }
        {
            r0 = 0x0000001EU;
        }
        {
            const uint32_t updatedAddress = r10 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A864U, address);
            }
        }
        {
            r0 = 0x0000001AU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x000000A0U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A870U, address);
            }
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            r0 = 0x0000002EU;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r0 = 0x00000036U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A87CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A880U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = 0x0000000AU;
        }
        if (flags.Z()) {
            r0 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x62U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A890U, address);
            }
        }
        goto block_0045A8A8;
    }
block_0045A898:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A898U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A898U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A898U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0045A8BC; }
        goto block_0045A8A8;
    }
block_0045A8A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A8A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A8A8U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x42U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A8A8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000A0U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            r0 = 0x0000002EU;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r0 = 0x00000036U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A8B8U, address);
            }
        }
        goto block_0045A8BC;
    }
block_0045A8BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A8BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A8BCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A8BCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0045AB18; }
        goto block_0045A8C8;
    }
block_0045A8C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A8C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A8C8U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x1AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A8C8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r10 + 0x1AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0045A8D8U, address);
            }
        }
        if (!(flags.Z())) { goto block_0045AB18; }
        goto block_0045A8E0;
    }
block_0045A8E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A8E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A8E0U);
        }
        {
            r1 = 0x0000001EU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            const uint32_t updatedAddress = r10 + 0x1AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0045A8E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A8ECU, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) { goto block_0045AA74; }
        goto block_0045A8F4;
    }
block_0045A8F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A8F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A8F4U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A900U, address);
            }
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0045A9D4; }
        goto block_0045A908;
    }
block_0045A908:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A908U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A908U);
        }
        {
            r1 = 0x00000037U;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045A914U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Flags_GetSwitch_0036E864(frame, context, state, 0x0036E864U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045A914U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045A914;
    }
block_0045A914:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A914U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A914U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0045A938; }
        goto block_0045A920;
    }
block_0045A920:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A920U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A920U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A920U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0045A9A0; }
        goto block_0045A938;
    }
block_0045A938:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A938U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A938U);
        }
        {
            const uint32_t updatedAddress = 0x0045A940U - 0x56CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A938U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0045A944U + 0x35CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A93CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A940U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A948U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0045A950U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0045A954U, 0xEE880A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0045A958U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0045A95CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r10 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A964U, address);
            }
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x62U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A96CU, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            r2 = r0;
        }
        {
            const uint32_t updatedAddress = r11 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A978U, address);
            }
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045A984U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045A984U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045A984;
    }
block_0045A984:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A984U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A984U);
        }
        {
            r2 = 0x00000008U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045A994U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045A994U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045A994;
    }
block_0045A994:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A994U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A994U);
        }
        {
        }
        {
        }
        goto block_0045AAB8;
    }
block_0045A9A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A9A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A9A0U);
        }
        {
            const uint32_t updatedAddress = 0x0045A9A8U - 0x5D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A9A0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A9A4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A9ACU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0045A9B4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0045A9B8U, 0xEE880A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0045A9BCU, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0045A9C0U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r10 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045A9C8U, address);
            }
        }
        {
            r0 = 0x00000006U;
        }
        goto block_0045AAB4;
    }
block_0045A9D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A9D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A9D4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000003CU, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0045AA18; }
        goto block_0045A9DC;
    }
block_0045A9DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A9DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A9DCU);
        }
        {
            const uint32_t updatedAddress = 0x0045A9E4U + 0x2A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A9DCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A9E0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0045AAB8; }
        goto block_0045A9EC;
    }
block_0045A9EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045A9ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045A9ECU);
        }
        {
            const uint32_t updatedAddress = 0x0045A9F4U + 0x29CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A9ECU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0045A9F8U + 0x29CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A9F0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0045A9FCU + 0x29CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045A9F4U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0045A9FCU, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045AA0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045AA0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045AA0C;
    }
block_0045AA0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AA0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AA0CU);
        }
        {
        }
        {
        }
        goto block_0045AAB8;
    }
block_0045AA18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AA18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AA18U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0045AA54; }
        goto block_0045AA20;
    }
block_0045AA20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AA20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AA20U);
        }
        {
            const uint32_t updatedAddress = 0x0045AA28U + 0x264U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AA20U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AA24U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0045AAB8; }
        goto block_0045AA30;
    }
block_0045AA30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AA30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AA30U);
        }
        {
            const uint32_t updatedAddress = 0x0045AA38U + 0x258U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AA30U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0045AA3CU + 0x258U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AA34U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0045AA40U + 0x264U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AA38U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0045AA40U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        goto block_0045AA4C;
    }
block_0045AA4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AA4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AA4CU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045AA50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045AA50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045AA50;
    }
block_0045AA50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AA50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AA50U);
        }
        goto block_0045AAB8;
    }
block_0045AA54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AA54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AA54U);
        }
        {
            const uint32_t updatedAddress = 0x0045AA5CU + 0x234U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AA54U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0045AA60U + 0x234U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AA58U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0045AA64U + 0x238U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AA5CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0045AA64U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        goto block_0045AA4C;
    }
block_0045AA74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AA74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AA74U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x64U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045AA7CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AA80U, address);
            }
            r1 = value;
        }
        {
            const uint32_t value = r1 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0045AAB8; }
        goto block_0045AA8C;
    }
block_0045AA8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AA8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AA8CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000F0U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0045AAB8; }
        goto block_0045AA94;
    }
block_0045AA94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AA94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AA94U);
        }
        {
            const uint32_t updatedAddress = 0x0045AA9CU + 0x20CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AA94U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045AAA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045AAA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045AAA4;
    }
block_0045AAA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AAA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AAA4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x8CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AAA4U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x00000001U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x8CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045AAACU, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        goto block_0045AAB4;
    }
block_0045AAB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AAB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AAB4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x62U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045AAB4U, address);
            }
        }
        goto block_0045AAB8;
    }
block_0045AAB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AAB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AAB8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AAB8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x0045AAC4U + 0x1E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AABCU, address);
            }
            r2 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r0 = r1;
        }
        {
            const uint32_t leftValue = r2;
            const uint32_t rightValue = r1;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            value += (static_cast<uint64_t>(r0) << 32U) |
                     r3;
            r3 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r2 = Oot3dAotAsr(r0, 5U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r0 = r2 - operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 4U);
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 2U);
            Oot3dAotSetAddFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r1 + operand;
        }
        if (!(flags.Z())) { goto block_0045AB18; }
        goto block_0045AAE0;
    }
block_0045AAE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AAE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AAE0U);
        }
        {
            const uint32_t updatedAddress = 0x0045AAE8U + 0x1A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AAE0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0045AAECU + 0x1A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AAE4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0045AAF0U + 0x1B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AAE8U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0045AAF0U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        goto block_0045A5C0;
    }
block_0045AB00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AB00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AB00U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AB00U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r10 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045AB10U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x62U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045AB14U, address);
            }
        }
        goto block_0045AB18;
    }
block_0045AB18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AB18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AB18U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AB18U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0045AB34; }
        goto block_0045AB28;
    }
block_0045AB28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AB28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AB28U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x62U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AB28U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0045ABE4; }
        goto block_0045AB34;
    }
block_0045AB34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AB34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AB34U);
        }
        {
            const uint32_t updatedAddress = 0x0045AB3CU + 0x150U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AB34U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045AB3CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045AB40U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045AB44U, address);
            }
        }
        {
            r0 = 0x0000000AU;
        }
        {
            const uint32_t updatedAddress = r1 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045AB4CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x5EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AB50U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x64U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AB58U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x60U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AB5CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045AB60U, address);
            }
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000003CU, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0045ABB4; }
        goto block_0045AB70;
    }
block_0045AB70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AB70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AB70U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AB70U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            const uint32_t updatedAddress = r1 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045AB80U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_0045AB9C; }
        goto block_0045AB88;
    }
block_0045AB88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AB88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AB88U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AB88U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x0000000AU;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r2 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0045AB94U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045AB98U, address);
            }
        }
        goto block_0045AB9C;
    }
block_0045AB9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AB9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AB9CU);
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AB9CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000003CU, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045ABACU, address);
            }
        }
        if ((flags.N()) == (flags.V())) { goto block_0045AB70; }
        goto block_0045ABB4;
    }
block_0045ABB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045ABB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045ABB4U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045ABB4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_0045ABE4; }
        goto block_0045ABC0;
    }
block_0045ABC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045ABC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045ABC0U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045ABC0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045ABC8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045ABCCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000000AU;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0045ABDCU, address);
            }
        }
        if ((flags.N()) == (flags.V())) { goto block_0045ABC0; }
        goto block_0045ABE4;
    }
block_0045ABE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045ABE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045ABE4U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045ABE4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x7EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045ABECU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0045AC7C; }
        goto block_0045ABF8;
    }
block_0045ABF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045ABF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045ABF8U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x0045AC04U + 176U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045ABFCU, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            const uint32_t address = 0x0045AC08U + 168U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AC00U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x0045AC0CU + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AC04U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0045AC0CU, 0xEEB80A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[1];
        }
        {
            const uint32_t address = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0045AC14U, address);
            }
        }
        {
            const uint32_t address = r13 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0045AC18U, address);
            }
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0045AC1CU, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0045AC20U, 0xEE200A02U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0045AC24U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AC28U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0045AC68; }
        goto block_0045AC34;
    }
block_0045AC34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AC34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AC34U);
        }
        {
            const uint32_t updatedAddress = 0x0045AC3CU + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AC34U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045AC3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045AC3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045AC3C;
    }
block_0045AC3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AC3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AC3CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0045AC68; }
        goto block_0045AC48;
    }
block_0045AC48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AC48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AC48U);
        }
        {
            const uint32_t updatedAddress = 0x0045AC50U + 0x6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AC48U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045AC50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045AC50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045AC50;
    }
block_0045AC50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AC50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AC50U);
        }
        {
            const uint32_t updatedAddress = 0x0045AC58U + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AC50U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0045AC5CU + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AC54U, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x0045AC64U + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AC5CU, address);
            }
            r0 = value;
        }
        {
        }
        {
            r0 = r0;
        }
        goto block_0045AC68;
    }
block_0045AC68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AC68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AC68U);
        }
        {
            const uint32_t updatedAddress = 0x0045AC70U + 0x58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0045AC68U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000004U;
            r2 = r13 + operand;
        }
        {
            r1 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0045AC7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003339e8_003339E8(frame, context, state, 0x003339E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0045AC7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0045AC7C;
    }
block_0045AC7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0045AC7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0045AC7CU);
        }
        {
            const uint32_t operand = 0x0000001CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0045AC80U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0045AC80U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0045AC84U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0045AC84U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0045AC84U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0045AC84U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0045AC84U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0045AC84U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0045AC84U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0045AC84U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0045AC84U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_oot3d_player_action_swing_bottle_00473EF8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00473EF8U:
        goto block_00473EF8;
    case 0x00473F1CU:
        goto block_00473F1C;
    case 0x00473F24U:
        goto block_00473F24;
    case 0x00473F2CU:
        goto block_00473F2C;
    case 0x00473F34U:
        goto block_00473F34;
    case 0x00473F48U:
        goto block_00473F48;
    case 0x00473FA0U:
        goto block_00473FA0;
    case 0x00473FA8U:
        goto block_00473FA8;
    case 0x00473FB4U:
        goto block_00473FB4;
    case 0x00473FBCU:
        goto block_00473FBC;
    case 0x00473FD4U:
        goto block_00473FD4;
    case 0x00473FE4U:
        goto block_00473FE4;
    case 0x00473FECU:
        goto block_00473FEC;
    case 0x00473FFCU:
        goto block_00473FFC;
    case 0x0047400CU:
        goto block_0047400C;
    case 0x004740BCU:
        goto block_004740BC;
    case 0x004740C4U:
        goto block_004740C4;
    case 0x004740D0U:
        goto block_004740D0;
    case 0x004740ECU:
        goto block_004740EC;
    case 0x00474104U:
        goto block_00474104;
    case 0x00474114U:
        goto block_00474114;
    case 0x0047411CU:
        goto block_0047411C;
    case 0x00474124U:
        goto block_00474124;
    case 0x0047412CU:
        goto block_0047412C;
    case 0x00474134U:
        goto block_00474134;
    case 0x00474138U:
        goto block_00474138;
    case 0x0047413CU:
        goto block_0047413C;
    case 0x00474140U:
        goto block_00474140;
    case 0x00474150U:
        goto block_00474150;
    case 0x00474160U:
        goto block_00474160;
    case 0x0047416CU:
        goto block_0047416C;
    case 0x00474178U:
        goto block_00474178;
    case 0x00474180U:
        goto block_00474180;
    case 0x00474194U:
        goto block_00474194;
    case 0x004741A0U:
        goto block_004741A0;
    case 0x004741BCU:
        goto block_004741BC;
    case 0x004741DCU:
        goto block_004741DC;
    case 0x004741F8U:
        goto block_004741F8;
    case 0x00474208U:
        goto block_00474208;
    case 0x00474214U:
        goto block_00474214;
    case 0x00474220U:
        goto block_00474220;
    case 0x00474228U:
        goto block_00474228;
    case 0x00474238U:
        goto block_00474238;
    case 0x00474258U:
        goto block_00474258;
    case 0x00474274U:
        goto block_00474274;
    case 0x00474280U:
        goto block_00474280;
    case 0x004742A0U:
        goto block_004742A0;
    case 0x004742A8U:
        goto block_004742A8;
    case 0x004742D0U:
        goto block_004742D0;
    case 0x004742F8U:
        goto block_004742F8;
    case 0x00474308U:
        goto block_00474308;
    case 0x00474310U:
        goto block_00474310;
    case 0x00474318U:
        goto block_00474318;
    case 0x00474338U:
        goto block_00474338;
    case 0x00474344U:
        goto block_00474344;
    case 0x00474350U:
        goto block_00474350;
    case 0x00474358U:
        goto block_00474358;
    case 0x00474368U:
        goto block_00474368;
    case 0x00474370U:
        goto block_00474370;
    case 0x00474390U:
        goto block_00474390;
    case 0x004743A4U:
        goto block_004743A4;
    case 0x004743B0U:
        goto block_004743B0;
    case 0x004743BCU:
        goto block_004743BC;
    case 0x004743C8U:
        goto block_004743C8;
    case 0x004743F8U:
        goto block_004743F8;
    case 0x00474404U:
        goto block_00474404;
    case 0x00474410U:
        goto block_00474410;
    case 0x00474418U:
        goto block_00474418;
    case 0x00474424U:
        goto block_00474424;
    case 0x00474430U:
        goto block_00474430;
    case 0x00474460U:
        goto block_00474460;
    case 0x0047446CU:
        goto block_0047446C;
    case 0x0047448CU:
        goto block_0047448C;
    case 0x00474498U:
        goto block_00474498;
    case 0x004744A4U:
        goto block_004744A4;
    case 0x004744ACU:
        goto block_004744AC;
    case 0x004744B8U:
        goto block_004744B8;
    case 0x004744C0U:
        goto block_004744C0;
    case 0x004744E0U:
        goto block_004744E0;
    case 0x004744ECU:
        goto block_004744EC;
    case 0x004744F4U:
        goto block_004744F4;
    case 0x004744FCU:
        goto block_004744FC;
    case 0x0047451CU:
        goto block_0047451C;
    case 0x00474530U:
        goto block_00474530;
    case 0x0047453CU:
        goto block_0047453C;
    case 0x00474544U:
        goto block_00474544;
    case 0x00474550U:
        goto block_00474550;
    case 0x0047455CU:
        goto block_0047455C;
    case 0x00474568U:
        goto block_00474568;
    case 0x0047458CU:
        goto block_0047458C;
    case 0x00474594U:
        goto block_00474594;
    case 0x004745B0U:
        goto block_004745B0;
    case 0x004745BCU:
        goto block_004745BC;
    case 0x004745F8U:
        goto block_004745F8;
    case 0x0047461CU:
        goto block_0047461C;
    case 0x00474648U:
        goto block_00474648;
    case 0x004746BCU:
        goto block_004746BC;
    case 0x004746E4U:
        goto block_004746E4;
    case 0x00474710U:
        goto block_00474710;
    case 0x00474798U:
        goto block_00474798;
    case 0x004747CCU:
        goto block_004747CC;
    case 0x00474800U:
        goto block_00474800;
    case 0x00474888U:
        goto block_00474888;
    case 0x004748A8U:
        goto block_004748A8;
    case 0x004748D0U:
        goto block_004748D0;
    case 0x00474934U:
        goto block_00474934;
    case 0x004749A4U:
        goto block_004749A4;
    case 0x004749B8U:
        goto block_004749B8;
    case 0x004749C0U:
        goto block_004749C0;
    case 0x004749CCU:
        goto block_004749CC;
    case 0x004749D8U:
        goto block_004749D8;
    case 0x004749E4U:
        goto block_004749E4;
    case 0x004749F4U:
        goto block_004749F4;
    case 0x004749FCU:
        goto block_004749FC;
    case 0x00474A0CU:
        goto block_00474A0C;
    case 0x00474A14U:
        goto block_00474A14;
    case 0x00474A20U:
        goto block_00474A20;
    case 0x00474A28U:
        goto block_00474A28;
    case 0x00474A34U:
        goto block_00474A34;
    case 0x00474A48U:
        goto block_00474A48;
    case 0x00474A64U:
        goto block_00474A64;
    case 0x00474A70U:
        goto block_00474A70;
    case 0x00474A7CU:
        goto block_00474A7C;
    case 0x00474A90U:
        goto block_00474A90;
    case 0x00474AACU:
        goto block_00474AAC;
    case 0x00474ABCU:
        goto block_00474ABC;
    case 0x00474AC8U:
        goto block_00474AC8;
    case 0x00474B2CU:
        goto block_00474B2C;
    case 0x00474B3CU:
        goto block_00474B3C;
    case 0x00474B44U:
        goto block_00474B44;
    case 0x00474B50U:
        goto block_00474B50;
    case 0x00474B58U:
        goto block_00474B58;
    case 0x00474B70U:
        goto block_00474B70;
    case 0x00474B78U:
        goto block_00474B78;
    case 0x00474B88U:
        goto block_00474B88;
    case 0x00474BBCU:
        goto block_00474BBC;
    case 0x00474BCCU:
        goto block_00474BCC;
    case 0x00474BE0U:
        goto block_00474BE0;
    case 0x00474BECU:
        goto block_00474BEC;
    case 0x00474BF8U:
        goto block_00474BF8;
    case 0x00474C04U:
        goto block_00474C04;
    case 0x00474C18U:
        goto block_00474C18;
    case 0x00474C20U:
        goto block_00474C20;
    case 0x00474C34U:
        goto block_00474C34;
    case 0x00474C40U:
        goto block_00474C40;
    case 0x00474C50U:
        goto block_00474C50;
    case 0x00474C64U:
        goto block_00474C64;
    case 0x00474CACU:
        goto block_00474CAC;
    case 0x00474CB8U:
        goto block_00474CB8;
    case 0x00474CC0U:
        goto block_00474CC0;
    case 0x00474CCCU:
        goto block_00474CCC;
    case 0x00474CE4U:
        goto block_00474CE4;
    case 0x00474CF0U:
        goto block_00474CF0;
    case 0x00474CFCU:
        goto block_00474CFC;
    case 0x00474D08U:
        goto block_00474D08;
    case 0x00474D24U:
        goto block_00474D24;
    case 0x00474D2CU:
        goto block_00474D2C;
    case 0x00474D30U:
        goto block_00474D30;
    case 0x00474D34U:
        goto block_00474D34;
    case 0x00474D44U:
        goto block_00474D44;
    case 0x00474D50U:
        goto block_00474D50;
    case 0x00474D64U:
        goto block_00474D64;
    case 0x00474D74U:
        goto block_00474D74;
    case 0x00474D7CU:
        goto block_00474D7C;
    case 0x00474D88U:
        goto block_00474D88;
    case 0x00474D94U:
        goto block_00474D94;
    case 0x00474D9CU:
        goto block_00474D9C;
    case 0x00474DA0U:
        goto block_00474DA0;
    case 0x00474DA4U:
        goto block_00474DA4;
    case 0x00474DB8U:
        goto block_00474DB8;
    case 0x00474DC8U:
        goto block_00474DC8;
    case 0x00474DD4U:
        goto block_00474DD4;
    case 0x00474E58U:
        goto block_00474E58;
    case 0x00474E74U:
        goto block_00474E74;
    case 0x00474E88U:
        goto block_00474E88;
    case 0x00474E94U:
        goto block_00474E94;
    case 0x00474EA0U:
        goto block_00474EA0;
    case 0x00474EB0U:
        goto block_00474EB0;
    case 0x00474EC0U:
        goto block_00474EC0;
    case 0x00474EC8U:
        goto block_00474EC8;
    case 0x00474ED4U:
        goto block_00474ED4;
    case 0x00474EE0U:
        goto block_00474EE0;
    case 0x00474EECU:
        goto block_00474EEC;
    case 0x00474EF4U:
        goto block_00474EF4;
    case 0x00474EFCU:
        goto block_00474EFC;
    case 0x00474F08U:
        goto block_00474F08;
    case 0x00474F14U:
        goto block_00474F14;
    case 0x00474F20U:
        goto block_00474F20;
    case 0x00474F2CU:
        goto block_00474F2C;
    case 0x00474F3CU:
        goto block_00474F3C;
    case 0x00474F4CU:
        goto block_00474F4C;
    case 0x00474F58U:
        goto block_00474F58;
    case 0x00474F68U:
        goto block_00474F68;
    case 0x00474F74U:
        goto block_00474F74;
    case 0x00474F94U:
        goto block_00474F94;
    case 0x00474FA4U:
        goto block_00474FA4;
    case 0x00474FB0U:
        goto block_00474FB0;
    case 0x00474FBCU:
        goto block_00474FBC;
    case 0x00474FD0U:
        goto block_00474FD0;
    case 0x00474FE8U:
        goto block_00474FE8;
    case 0x00474FF4U:
        goto block_00474FF4;
    case 0x00475004U:
        goto block_00475004;
    case 0x0047500CU:
        goto block_0047500C;
    case 0x00475018U:
        goto block_00475018;
    case 0x00475024U:
        goto block_00475024;
    case 0x0047502CU:
        goto block_0047502C;
    case 0x00475038U:
        goto block_00475038;
    case 0x0047504CU:
        goto block_0047504C;
    case 0x00475058U:
        goto block_00475058;
    case 0x00475078U:
        goto block_00475078;
    case 0x00475084U:
        goto block_00475084;
    case 0x0047509CU:
        goto block_0047509C;
    case 0x004750ACU:
        goto block_004750AC;
    case 0x004750B8U:
        goto block_004750B8;
    case 0x004750C8U:
        goto block_004750C8;
    case 0x004750D0U:
        goto block_004750D0;
    case 0x004750E0U:
        goto block_004750E0;
    case 0x004750ECU:
        goto block_004750EC;
    case 0x004750F8U:
        goto block_004750F8;
    case 0x00475104U:
        goto block_00475104;
    case 0x00475110U:
        goto block_00475110;
    case 0x0047511CU:
        goto block_0047511C;
    case 0x00475128U:
        goto block_00475128;
    case 0x00475138U:
        goto block_00475138;
    case 0x0047513CU:
        goto block_0047513C;
    case 0x00475140U:
        goto block_00475140;
    case 0x00475150U:
        goto block_00475150;
    case 0x00475160U:
        goto block_00475160;
    case 0x0047517CU:
        goto block_0047517C;
    case 0x0047518CU:
        goto block_0047518C;
    case 0x00475194U:
        goto block_00475194;
    case 0x004751A4U:
        goto block_004751A4;
    case 0x004751B4U:
        goto block_004751B4;
    case 0x004751C0U:
        goto block_004751C0;
    case 0x004751CCU:
        goto block_004751CC;
    case 0x004751DCU:
        goto block_004751DC;
    case 0x004751F0U:
        goto block_004751F0;
    case 0x00475214U:
        goto block_00475214;
    case 0x0047523CU:
        goto block_0047523C;
    case 0x00475248U:
        goto block_00475248;
    case 0x00475254U:
        goto block_00475254;
    case 0x0047525CU:
        goto block_0047525C;
    case 0x0047527CU:
        goto block_0047527C;
    case 0x00475290U:
        goto block_00475290;
    case 0x0047529CU:
        goto block_0047529C;
    case 0x004752A8U:
        goto block_004752A8;
    case 0x004752B4U:
        goto block_004752B4;
    case 0x004752C0U:
        goto block_004752C0;
    case 0x004752CCU:
        goto block_004752CC;
    case 0x004752F0U:
        goto block_004752F0;
    case 0x004752FCU:
        goto block_004752FC;
    case 0x00475308U:
        goto block_00475308;
    case 0x00475310U:
        goto block_00475310;
    case 0x0047531CU:
        goto block_0047531C;
    case 0x00475328U:
        goto block_00475328;
    case 0x0047533CU:
        goto block_0047533C;
    case 0x00475348U:
        goto block_00475348;
    case 0x00475354U:
        goto block_00475354;
    case 0x0047535CU:
        goto block_0047535C;
    case 0x0047536CU:
        goto block_0047536C;
    case 0x0047537CU:
        goto block_0047537C;
    case 0x00475388U:
        goto block_00475388;
    case 0x00475398U:
        goto block_00475398;
    case 0x004753A8U:
        goto block_004753A8;
    case 0x004753C0U:
        goto block_004753C0;
    case 0x004753CCU:
        goto block_004753CC;
    case 0x004753E4U:
        goto block_004753E4;
    case 0x004753FCU:
        goto block_004753FC;
    case 0x00475418U:
        goto block_00475418;
    case 0x00475428U:
        goto block_00475428;
    case 0x00475430U:
        goto block_00475430;
    case 0x0047543CU:
        goto block_0047543C;
    case 0x00475448U:
        goto block_00475448;
    case 0x00475454U:
        goto block_00475454;
    case 0x00475478U:
        goto block_00475478;
    case 0x004754ACU:
        goto block_004754AC;
    case 0x004754B8U:
        goto block_004754B8;
    case 0x004754D4U:
        goto block_004754D4;
    case 0x004754E8U:
        goto block_004754E8;
    case 0x004754F0U:
        goto block_004754F0;
    case 0x00475518U:
        goto block_00475518;
    case 0x00475524U:
        goto block_00475524;
    case 0x00475530U:
        goto block_00475530;
    case 0x0047553CU:
        goto block_0047553C;
    case 0x0047554CU:
        goto block_0047554C;
    case 0x00475558U:
        goto block_00475558;
    case 0x00475568U:
        goto block_00475568;
    case 0x00475578U:
        goto block_00475578;
    case 0x00475590U:
        goto block_00475590;
    case 0x0047559CU:
        goto block_0047559C;
    case 0x004755ACU:
        goto block_004755AC;
    case 0x004755C4U:
        goto block_004755C4;
    case 0x004755E4U:
        goto block_004755E4;
    case 0x004755F0U:
        goto block_004755F0;
    case 0x00475600U:
        goto block_00475600;
    case 0x00475608U:
        goto block_00475608;
    case 0x0047561CU:
        goto block_0047561C;
    case 0x00475628U:
        goto block_00475628;
    case 0x00475630U:
        goto block_00475630;
    case 0x0047563CU:
        goto block_0047563C;
    case 0x00475648U:
        goto block_00475648;
    case 0x00475654U:
        goto block_00475654;
    case 0x0047565CU:
        goto block_0047565C;
    case 0x0047566CU:
        goto block_0047566C;
    case 0x0047567CU:
        goto block_0047567C;
    case 0x00475694U:
        goto block_00475694;
    case 0x004756ACU:
        goto block_004756AC;
    case 0x004756BCU:
        goto block_004756BC;
    case 0x004756DCU:
        goto block_004756DC;
    case 0x004756FCU:
        goto block_004756FC;
    case 0x0047570CU:
        goto block_0047570C;
    case 0x00475710U:
        goto block_00475710;
    case 0x00475714U:
        goto block_00475714;
    case 0x0047571CU:
        goto block_0047571C;
    case 0x00475724U:
        goto block_00475724;
    case 0x00475730U:
        goto block_00475730;
    case 0x0047573CU:
        goto block_0047573C;
    case 0x00475748U:
        goto block_00475748;
    case 0x0047576CU:
        goto block_0047576C;
    case 0x00475774U:
        goto block_00475774;
    case 0x00475794U:
        goto block_00475794;
    case 0x004757A0U:
        goto block_004757A0;
    case 0x004757ACU:
        goto block_004757AC;
    case 0x004757B8U:
        goto block_004757B8;
    case 0x004757C0U:
        goto block_004757C0;
    case 0x004757D0U:
        goto block_004757D0;
    case 0x004757DCU:
        goto block_004757DC;
    case 0x004757E8U:
        goto block_004757E8;
    case 0x004757F0U:
        goto block_004757F0;
    case 0x004757FCU:
        goto block_004757FC;
    case 0x00475808U:
        goto block_00475808;
    case 0x00475814U:
        goto block_00475814;
    case 0x00475824U:
        goto block_00475824;
    case 0x00475830U:
        goto block_00475830;
    case 0x0047583CU:
        goto block_0047583C;
    case 0x00475848U:
        goto block_00475848;
    case 0x00475868U:
        goto block_00475868;
    case 0x00475874U:
        goto block_00475874;
    case 0x00475884U:
        goto block_00475884;
    case 0x00475894U:
        goto block_00475894;
    case 0x004758A0U:
        goto block_004758A0;
    case 0x004758ACU:
        goto block_004758AC;
    case 0x004758B8U:
        goto block_004758B8;
    case 0x004758C8U:
        goto block_004758C8;
    case 0x004758ECU:
        goto block_004758EC;
    case 0x004758F4U:
        goto block_004758F4;
    case 0x00475900U:
        goto block_00475900;
    case 0x0047590CU:
        goto block_0047590C;
    case 0x00475914U:
        goto block_00475914;
    case 0x00475920U:
        goto block_00475920;
    case 0x0047592CU:
        goto block_0047592C;
    case 0x00475934U:
        goto block_00475934;
    case 0x00475944U:
        goto block_00475944;
    case 0x00475954U:
        goto block_00475954;
    case 0x00475960U:
        goto block_00475960;
    case 0x00475970U:
        goto block_00475970;
    case 0x00475990U:
        goto block_00475990;
    case 0x0047599CU:
        goto block_0047599C;
    case 0x004759ACU:
        goto block_004759AC;
    case 0x004759BCU:
        goto block_004759BC;
    case 0x004759C8U:
        goto block_004759C8;
    case 0x004759D4U:
        goto block_004759D4;
    case 0x004759E4U:
        goto block_004759E4;
    case 0x004759ECU:
        goto block_004759EC;
    case 0x004759F8U:
        goto block_004759F8;
    case 0x00475A04U:
        goto block_00475A04;
    case 0x00475A10U:
        goto block_00475A10;
    case 0x00475A34U:
        goto block_00475A34;
    case 0x00475A3CU:
        goto block_00475A3C;
    case 0x00475A5CU:
        goto block_00475A5C;
    case 0x00475A68U:
        goto block_00475A68;
    case 0x00475A78U:
        goto block_00475A78;
    case 0x00475A98U:
        goto block_00475A98;
    case 0x00475AA4U:
        goto block_00475AA4;
    case 0x00475AA8U:
        goto block_00475AA8;
    case 0x00475AB0U:
        goto block_00475AB0;
    case 0x00475AB8U:
        goto block_00475AB8;
    case 0x00475AC8U:
        goto block_00475AC8;
    case 0x00475AD8U:
        goto block_00475AD8;
    case 0x00475AE4U:
        goto block_00475AE4;
    case 0x00475AF0U:
        goto block_00475AF0;
    case 0x00475B04U:
        goto block_00475B04;
    case 0x00475B08U:
        goto block_00475B08;
    case 0x00475B1CU:
        goto block_00475B1C;
    case 0x00475B3CU:
        goto block_00475B3C;
    case 0x00475B48U:
        goto block_00475B48;
    case 0x00475B58U:
        goto block_00475B58;
    case 0x00475B64U:
        goto block_00475B64;
    case 0x00475B70U:
        goto block_00475B70;
    case 0x00475B78U:
        goto block_00475B78;
    case 0x00475B84U:
        goto block_00475B84;
    case 0x00475B88U:
        goto block_00475B88;
    case 0x00475B98U:
        goto block_00475B98;
    case 0x00475BA4U:
        goto block_00475BA4;
    case 0x00475BB0U:
        goto block_00475BB0;
    case 0x00475BB8U:
        goto block_00475BB8;
    case 0x00475BC4U:
        goto block_00475BC4;
    case 0x00475BE0U:
        goto block_00475BE0;
    case 0x00475BF0U:
        goto block_00475BF0;
    case 0x00475BFCU:
        goto block_00475BFC;
    case 0x00475C08U:
        goto block_00475C08;
    case 0x00475C10U:
        goto block_00475C10;
    case 0x00475C20U:
        goto block_00475C20;
    case 0x00475C30U:
        goto block_00475C30;
    case 0x00475C48U:
        goto block_00475C48;
    case 0x00475C54U:
        goto block_00475C54;
    case 0x00475C60U:
        goto block_00475C60;
    case 0x00475C68U:
        goto block_00475C68;
    case 0x00475C6CU:
        goto block_00475C6C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00473EF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00473EF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00473EF8U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00473EF8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00473EF8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00473EF8U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00473EF8U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00473EF8U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00473EF8U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00473EF8U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x00473EF8U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00473EF8U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r5 = r0;
        }
        {
            const uint32_t operand = 0x00002000U;
            r4 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000064U;
            r13 = r13 - operand;
        }
        {
            const uint32_t operand = 0x000008A0U;
            r4 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = 0x00473F14U + 0xED0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473F0CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473F10U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_00473F48; }
        goto block_00473F1C;
    }
block_00473F1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00473F1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00473F1CU);
        }
        {
            const uint32_t updatedAddress = 0x00473F24U + 0xEC0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473F1CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00473F24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00473F24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00473F24;
    }
block_00473F24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00473F24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00473F24U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00473F48; }
        goto block_00473F2C;
    }
block_00473F2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00473F2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00473F2CU);
        }
        {
            const uint32_t updatedAddress = 0x00473F34U + 0xEB4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473F2CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00473F34U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00473F34U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00473F34;
    }
block_00473F34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00473F34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00473F34U);
        }
        {
            const uint32_t updatedAddress = 0x00473F3CU + 0xEB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473F34U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00473F40U + 0xEB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473F38U, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x00473F48U + 0xE9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473F40U, address);
            }
            r0 = value;
        }
        {
            r0 = r0;
        }
        goto block_00473F48;
    }
block_00473F48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00473F48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00473F48U);
        }
        {
            const uint32_t operand = 0x00002800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000003A4U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00002000U;
            r11 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00473F54U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473F58U, address);
            }
            r7 = value;
        }
        {
            r0 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x300U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00473F60U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473F64U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000014U;
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = 0x00473F74U + 0xE84U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473F6CU, address);
            }
            r10 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t updatedAddress = r4 + 0x2D4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00473F78U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473F7CU, address);
            }
            r0 = value;
        }
        {
            r9 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = 0x00473F8CU + 0xE68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473F84U, address);
            }
            r6 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
            const uint32_t updatedAddress = 0x00473F94U + 0xE50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473F8CU, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r10 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00473F90U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473F94U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_00473FD4; }
        goto block_00473FA0;
    }
block_00473FA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00473FA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00473FA0U);
        }
        {
            const uint32_t updatedAddress = 0x00473FA8U + 0xE3CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473FA0U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00473FA8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00473FA8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00473FA8;
    }
block_00473FA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00473FA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00473FA8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00473FD4; }
        goto block_00473FB4;
    }
block_00473FB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00473FB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00473FB4U);
        }
        {
            const uint32_t updatedAddress = 0x00473FBCU + 0xE2CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473FB4U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00473FBCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00473FBCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00473FBC;
    }
block_00473FBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00473FBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00473FBCU);
        }
        {
            const uint32_t updatedAddress = 0x00473FC4U + 0xE28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473FBCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00473FC8U + 0xE28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473FC0U, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x00473FD0U + 0xE14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473FC8U, address);
            }
            r0 = value;
        }
        {
        }
        {
            r0 = r0;
        }
        goto block_00473FD4;
    }
block_00473FD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00473FD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00473FD4U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473FD4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473FD8U, address);
            }
            r1 = value;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x00473FE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r1, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00473FE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00473FE4;
    }
block_00473FE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00473FE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00473FE4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00475C6C; }
        goto block_00473FEC;
    }
block_00473FEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00473FECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00473FECU);
        }
        {
            const uint32_t updatedAddress = r6 + 0xF38U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473FECU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00006000U;
            r8 = r5 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00475C68; }
        goto block_00473FFC;
    }
block_00473FFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00473FFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00473FFCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00473FFCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000009U;
            r0 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x00474010U + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474008U, address);
            }
            switch (value) {
            case 0x00473EF8U:
                goto block_00473EF8;
            case 0x00473F1CU:
                goto block_00473F1C;
            case 0x00473F24U:
                goto block_00473F24;
            case 0x00473F2CU:
                goto block_00473F2C;
            case 0x00473F34U:
                goto block_00473F34;
            case 0x00473F48U:
                goto block_00473F48;
            case 0x00473FA0U:
                goto block_00473FA0;
            case 0x00473FA8U:
                goto block_00473FA8;
            case 0x00473FB4U:
                goto block_00473FB4;
            case 0x00473FBCU:
                goto block_00473FBC;
            case 0x00473FD4U:
                goto block_00473FD4;
            case 0x00473FE4U:
                goto block_00473FE4;
            case 0x00473FECU:
                goto block_00473FEC;
            case 0x00473FFCU:
                goto block_00473FFC;
            case 0x0047400CU:
                goto block_0047400C;
            case 0x004740BCU:
                goto block_004740BC;
            case 0x004740C4U:
                goto block_004740C4;
            case 0x004740D0U:
                goto block_004740D0;
            case 0x004740ECU:
                goto block_004740EC;
            case 0x00474104U:
                goto block_00474104;
            case 0x00474114U:
                goto block_00474114;
            case 0x0047411CU:
                goto block_0047411C;
            case 0x00474124U:
                goto block_00474124;
            case 0x0047412CU:
                goto block_0047412C;
            case 0x00474134U:
                goto block_00474134;
            case 0x00474138U:
                goto block_00474138;
            case 0x0047413CU:
                goto block_0047413C;
            case 0x00474140U:
                goto block_00474140;
            case 0x00474150U:
                goto block_00474150;
            case 0x00474160U:
                goto block_00474160;
            case 0x0047416CU:
                goto block_0047416C;
            case 0x00474178U:
                goto block_00474178;
            case 0x00474180U:
                goto block_00474180;
            case 0x00474194U:
                goto block_00474194;
            case 0x004741A0U:
                goto block_004741A0;
            case 0x004741BCU:
                goto block_004741BC;
            case 0x004741DCU:
                goto block_004741DC;
            case 0x004741F8U:
                goto block_004741F8;
            case 0x00474208U:
                goto block_00474208;
            case 0x00474214U:
                goto block_00474214;
            case 0x00474220U:
                goto block_00474220;
            case 0x00474228U:
                goto block_00474228;
            case 0x00474238U:
                goto block_00474238;
            case 0x00474258U:
                goto block_00474258;
            case 0x00474274U:
                goto block_00474274;
            case 0x00474280U:
                goto block_00474280;
            case 0x004742A0U:
                goto block_004742A0;
            case 0x004742A8U:
                goto block_004742A8;
            case 0x004742D0U:
                goto block_004742D0;
            case 0x004742F8U:
                goto block_004742F8;
            case 0x00474308U:
                goto block_00474308;
            case 0x00474310U:
                goto block_00474310;
            case 0x00474318U:
                goto block_00474318;
            case 0x00474338U:
                goto block_00474338;
            case 0x00474344U:
                goto block_00474344;
            case 0x00474350U:
                goto block_00474350;
            case 0x00474358U:
                goto block_00474358;
            case 0x00474368U:
                goto block_00474368;
            case 0x00474370U:
                goto block_00474370;
            case 0x00474390U:
                goto block_00474390;
            case 0x004743A4U:
                goto block_004743A4;
            case 0x004743B0U:
                goto block_004743B0;
            case 0x004743BCU:
                goto block_004743BC;
            case 0x004743C8U:
                goto block_004743C8;
            case 0x004743F8U:
                goto block_004743F8;
            case 0x00474404U:
                goto block_00474404;
            case 0x00474410U:
                goto block_00474410;
            case 0x00474418U:
                goto block_00474418;
            case 0x00474424U:
                goto block_00474424;
            case 0x00474430U:
                goto block_00474430;
            case 0x00474460U:
                goto block_00474460;
            case 0x0047446CU:
                goto block_0047446C;
            case 0x0047448CU:
                goto block_0047448C;
            case 0x00474498U:
                goto block_00474498;
            case 0x004744A4U:
                goto block_004744A4;
            case 0x004744ACU:
                goto block_004744AC;
            case 0x004744B8U:
                goto block_004744B8;
            case 0x004744C0U:
                goto block_004744C0;
            case 0x004744E0U:
                goto block_004744E0;
            case 0x004744ECU:
                goto block_004744EC;
            case 0x004744F4U:
                goto block_004744F4;
            case 0x004744FCU:
                goto block_004744FC;
            case 0x0047451CU:
                goto block_0047451C;
            case 0x00474530U:
                goto block_00474530;
            case 0x0047453CU:
                goto block_0047453C;
            case 0x00474544U:
                goto block_00474544;
            case 0x00474550U:
                goto block_00474550;
            case 0x0047455CU:
                goto block_0047455C;
            case 0x00474568U:
                goto block_00474568;
            case 0x0047458CU:
                goto block_0047458C;
            case 0x00474594U:
                goto block_00474594;
            case 0x004745B0U:
                goto block_004745B0;
            case 0x004745BCU:
                goto block_004745BC;
            case 0x004745F8U:
                goto block_004745F8;
            case 0x0047461CU:
                goto block_0047461C;
            case 0x00474648U:
                goto block_00474648;
            case 0x004746BCU:
                goto block_004746BC;
            case 0x004746E4U:
                goto block_004746E4;
            case 0x00474710U:
                goto block_00474710;
            case 0x00474798U:
                goto block_00474798;
            case 0x004747CCU:
                goto block_004747CC;
            case 0x00474800U:
                goto block_00474800;
            case 0x00474888U:
                goto block_00474888;
            case 0x004748A8U:
                goto block_004748A8;
            case 0x004748D0U:
                goto block_004748D0;
            case 0x00474934U:
                goto block_00474934;
            case 0x004749A4U:
                goto block_004749A4;
            case 0x004749B8U:
                goto block_004749B8;
            case 0x004749C0U:
                goto block_004749C0;
            case 0x004749CCU:
                goto block_004749CC;
            case 0x004749D8U:
                goto block_004749D8;
            case 0x004749E4U:
                goto block_004749E4;
            case 0x004749F4U:
                goto block_004749F4;
            case 0x004749FCU:
                goto block_004749FC;
            case 0x00474A0CU:
                goto block_00474A0C;
            case 0x00474A14U:
                goto block_00474A14;
            case 0x00474A20U:
                goto block_00474A20;
            case 0x00474A28U:
                goto block_00474A28;
            case 0x00474A34U:
                goto block_00474A34;
            case 0x00474A48U:
                goto block_00474A48;
            case 0x00474A64U:
                goto block_00474A64;
            case 0x00474A70U:
                goto block_00474A70;
            case 0x00474A7CU:
                goto block_00474A7C;
            case 0x00474A90U:
                goto block_00474A90;
            case 0x00474AACU:
                goto block_00474AAC;
            case 0x00474ABCU:
                goto block_00474ABC;
            case 0x00474AC8U:
                goto block_00474AC8;
            case 0x00474B2CU:
                goto block_00474B2C;
            case 0x00474B3CU:
                goto block_00474B3C;
            case 0x00474B44U:
                goto block_00474B44;
            case 0x00474B50U:
                goto block_00474B50;
            case 0x00474B58U:
                goto block_00474B58;
            case 0x00474B70U:
                goto block_00474B70;
            case 0x00474B78U:
                goto block_00474B78;
            case 0x00474B88U:
                goto block_00474B88;
            case 0x00474BBCU:
                goto block_00474BBC;
            case 0x00474BCCU:
                goto block_00474BCC;
            case 0x00474BE0U:
                goto block_00474BE0;
            case 0x00474BECU:
                goto block_00474BEC;
            case 0x00474BF8U:
                goto block_00474BF8;
            case 0x00474C04U:
                goto block_00474C04;
            case 0x00474C18U:
                goto block_00474C18;
            case 0x00474C20U:
                goto block_00474C20;
            case 0x00474C34U:
                goto block_00474C34;
            case 0x00474C40U:
                goto block_00474C40;
            case 0x00474C50U:
                goto block_00474C50;
            case 0x00474C64U:
                goto block_00474C64;
            case 0x00474CACU:
                goto block_00474CAC;
            case 0x00474CB8U:
                goto block_00474CB8;
            case 0x00474CC0U:
                goto block_00474CC0;
            case 0x00474CCCU:
                goto block_00474CCC;
            case 0x00474CE4U:
                goto block_00474CE4;
            case 0x00474CF0U:
                goto block_00474CF0;
            case 0x00474CFCU:
                goto block_00474CFC;
            case 0x00474D08U:
                goto block_00474D08;
            case 0x00474D24U:
                goto block_00474D24;
            case 0x00474D2CU:
                goto block_00474D2C;
            case 0x00474D30U:
                goto block_00474D30;
            case 0x00474D34U:
                goto block_00474D34;
            case 0x00474D44U:
                goto block_00474D44;
            case 0x00474D50U:
                goto block_00474D50;
            case 0x00474D64U:
                goto block_00474D64;
            case 0x00474D74U:
                goto block_00474D74;
            case 0x00474D7CU:
                goto block_00474D7C;
            case 0x00474D88U:
                goto block_00474D88;
            case 0x00474D94U:
                goto block_00474D94;
            case 0x00474D9CU:
                goto block_00474D9C;
            case 0x00474DA0U:
                goto block_00474DA0;
            case 0x00474DA4U:
                goto block_00474DA4;
            case 0x00474DB8U:
                goto block_00474DB8;
            case 0x00474DC8U:
                goto block_00474DC8;
            case 0x00474DD4U:
                goto block_00474DD4;
            case 0x00474E58U:
                goto block_00474E58;
            case 0x00474E74U:
                goto block_00474E74;
            case 0x00474E88U:
                goto block_00474E88;
            case 0x00474E94U:
                goto block_00474E94;
            case 0x00474EA0U:
                goto block_00474EA0;
            case 0x00474EB0U:
                goto block_00474EB0;
            case 0x00474EC0U:
                goto block_00474EC0;
            case 0x00474EC8U:
                goto block_00474EC8;
            case 0x00474ED4U:
                goto block_00474ED4;
            case 0x00474EE0U:
                goto block_00474EE0;
            case 0x00474EECU:
                goto block_00474EEC;
            case 0x00474EF4U:
                goto block_00474EF4;
            case 0x00474EFCU:
                goto block_00474EFC;
            case 0x00474F08U:
                goto block_00474F08;
            case 0x00474F14U:
                goto block_00474F14;
            case 0x00474F20U:
                goto block_00474F20;
            case 0x00474F2CU:
                goto block_00474F2C;
            case 0x00474F3CU:
                goto block_00474F3C;
            case 0x00474F4CU:
                goto block_00474F4C;
            case 0x00474F58U:
                goto block_00474F58;
            case 0x00474F68U:
                goto block_00474F68;
            case 0x00474F74U:
                goto block_00474F74;
            case 0x00474F94U:
                goto block_00474F94;
            case 0x00474FA4U:
                goto block_00474FA4;
            case 0x00474FB0U:
                goto block_00474FB0;
            case 0x00474FBCU:
                goto block_00474FBC;
            case 0x00474FD0U:
                goto block_00474FD0;
            case 0x00474FE8U:
                goto block_00474FE8;
            case 0x00474FF4U:
                goto block_00474FF4;
            case 0x00475004U:
                goto block_00475004;
            case 0x0047500CU:
                goto block_0047500C;
            case 0x00475018U:
                goto block_00475018;
            case 0x00475024U:
                goto block_00475024;
            case 0x0047502CU:
                goto block_0047502C;
            case 0x00475038U:
                goto block_00475038;
            case 0x0047504CU:
                goto block_0047504C;
            case 0x00475058U:
                goto block_00475058;
            case 0x00475078U:
                goto block_00475078;
            case 0x00475084U:
                goto block_00475084;
            case 0x0047509CU:
                goto block_0047509C;
            case 0x004750ACU:
                goto block_004750AC;
            case 0x004750B8U:
                goto block_004750B8;
            case 0x004750C8U:
                goto block_004750C8;
            case 0x004750D0U:
                goto block_004750D0;
            case 0x004750E0U:
                goto block_004750E0;
            case 0x004750ECU:
                goto block_004750EC;
            case 0x004750F8U:
                goto block_004750F8;
            case 0x00475104U:
                goto block_00475104;
            case 0x00475110U:
                goto block_00475110;
            case 0x0047511CU:
                goto block_0047511C;
            case 0x00475128U:
                goto block_00475128;
            case 0x00475138U:
                goto block_00475138;
            case 0x0047513CU:
                goto block_0047513C;
            case 0x00475140U:
                goto block_00475140;
            case 0x00475150U:
                goto block_00475150;
            case 0x00475160U:
                goto block_00475160;
            case 0x0047517CU:
                goto block_0047517C;
            case 0x0047518CU:
                goto block_0047518C;
            case 0x00475194U:
                goto block_00475194;
            case 0x004751A4U:
                goto block_004751A4;
            case 0x004751B4U:
                goto block_004751B4;
            case 0x004751C0U:
                goto block_004751C0;
            case 0x004751CCU:
                goto block_004751CC;
            case 0x004751DCU:
                goto block_004751DC;
            case 0x004751F0U:
                goto block_004751F0;
            case 0x00475214U:
                goto block_00475214;
            case 0x0047523CU:
                goto block_0047523C;
            case 0x00475248U:
                goto block_00475248;
            case 0x00475254U:
                goto block_00475254;
            case 0x0047525CU:
                goto block_0047525C;
            case 0x0047527CU:
                goto block_0047527C;
            case 0x00475290U:
                goto block_00475290;
            case 0x0047529CU:
                goto block_0047529C;
            case 0x004752A8U:
                goto block_004752A8;
            case 0x004752B4U:
                goto block_004752B4;
            case 0x004752C0U:
                goto block_004752C0;
            case 0x004752CCU:
                goto block_004752CC;
            case 0x004752F0U:
                goto block_004752F0;
            case 0x004752FCU:
                goto block_004752FC;
            case 0x00475308U:
                goto block_00475308;
            case 0x00475310U:
                goto block_00475310;
            case 0x0047531CU:
                goto block_0047531C;
            case 0x00475328U:
                goto block_00475328;
            case 0x0047533CU:
                goto block_0047533C;
            case 0x00475348U:
                goto block_00475348;
            case 0x00475354U:
                goto block_00475354;
            case 0x0047535CU:
                goto block_0047535C;
            case 0x0047536CU:
                goto block_0047536C;
            case 0x0047537CU:
                goto block_0047537C;
            case 0x00475388U:
                goto block_00475388;
            case 0x00475398U:
                goto block_00475398;
            case 0x004753A8U:
                goto block_004753A8;
            case 0x004753C0U:
                goto block_004753C0;
            case 0x004753CCU:
                goto block_004753CC;
            case 0x004753E4U:
                goto block_004753E4;
            case 0x004753FCU:
                goto block_004753FC;
            case 0x00475418U:
                goto block_00475418;
            case 0x00475428U:
                goto block_00475428;
            case 0x00475430U:
                goto block_00475430;
            case 0x0047543CU:
                goto block_0047543C;
            case 0x00475448U:
                goto block_00475448;
            case 0x00475454U:
                goto block_00475454;
            case 0x00475478U:
                goto block_00475478;
            case 0x004754ACU:
                goto block_004754AC;
            case 0x004754B8U:
                goto block_004754B8;
            case 0x004754D4U:
                goto block_004754D4;
            case 0x004754E8U:
                goto block_004754E8;
            case 0x004754F0U:
                goto block_004754F0;
            case 0x00475518U:
                goto block_00475518;
            case 0x00475524U:
                goto block_00475524;
            case 0x00475530U:
                goto block_00475530;
            case 0x0047553CU:
                goto block_0047553C;
            case 0x0047554CU:
                goto block_0047554C;
            case 0x00475558U:
                goto block_00475558;
            case 0x00475568U:
                goto block_00475568;
            case 0x00475578U:
                goto block_00475578;
            case 0x00475590U:
                goto block_00475590;
            case 0x0047559CU:
                goto block_0047559C;
            case 0x004755ACU:
                goto block_004755AC;
            case 0x004755C4U:
                goto block_004755C4;
            case 0x004755E4U:
                goto block_004755E4;
            case 0x004755F0U:
                goto block_004755F0;
            case 0x00475600U:
                goto block_00475600;
            case 0x00475608U:
                goto block_00475608;
            case 0x0047561CU:
                goto block_0047561C;
            case 0x00475628U:
                goto block_00475628;
            case 0x00475630U:
                goto block_00475630;
            case 0x0047563CU:
                goto block_0047563C;
            case 0x00475648U:
                goto block_00475648;
            case 0x00475654U:
                goto block_00475654;
            case 0x0047565CU:
                goto block_0047565C;
            case 0x0047566CU:
                goto block_0047566C;
            case 0x0047567CU:
                goto block_0047567C;
            case 0x00475694U:
                goto block_00475694;
            case 0x004756ACU:
                goto block_004756AC;
            case 0x004756BCU:
                goto block_004756BC;
            case 0x004756DCU:
                goto block_004756DC;
            case 0x004756FCU:
                goto block_004756FC;
            case 0x0047570CU:
                goto block_0047570C;
            case 0x00475710U:
                goto block_00475710;
            case 0x00475714U:
                goto block_00475714;
            case 0x0047571CU:
                goto block_0047571C;
            case 0x00475724U:
                goto block_00475724;
            case 0x00475730U:
                goto block_00475730;
            case 0x0047573CU:
                goto block_0047573C;
            case 0x00475748U:
                goto block_00475748;
            case 0x0047576CU:
                goto block_0047576C;
            case 0x00475774U:
                goto block_00475774;
            case 0x00475794U:
                goto block_00475794;
            case 0x004757A0U:
                goto block_004757A0;
            case 0x004757ACU:
                goto block_004757AC;
            case 0x004757B8U:
                goto block_004757B8;
            case 0x004757C0U:
                goto block_004757C0;
            case 0x004757D0U:
                goto block_004757D0;
            case 0x004757DCU:
                goto block_004757DC;
            case 0x004757E8U:
                goto block_004757E8;
            case 0x004757F0U:
                goto block_004757F0;
            case 0x004757FCU:
                goto block_004757FC;
            case 0x00475808U:
                goto block_00475808;
            case 0x00475814U:
                goto block_00475814;
            case 0x00475824U:
                goto block_00475824;
            case 0x00475830U:
                goto block_00475830;
            case 0x0047583CU:
                goto block_0047583C;
            case 0x00475848U:
                goto block_00475848;
            case 0x00475868U:
                goto block_00475868;
            case 0x00475874U:
                goto block_00475874;
            case 0x00475884U:
                goto block_00475884;
            case 0x00475894U:
                goto block_00475894;
            case 0x004758A0U:
                goto block_004758A0;
            case 0x004758ACU:
                goto block_004758AC;
            case 0x004758B8U:
                goto block_004758B8;
            case 0x004758C8U:
                goto block_004758C8;
            case 0x004758ECU:
                goto block_004758EC;
            case 0x004758F4U:
                goto block_004758F4;
            case 0x00475900U:
                goto block_00475900;
            case 0x0047590CU:
                goto block_0047590C;
            case 0x00475914U:
                goto block_00475914;
            case 0x00475920U:
                goto block_00475920;
            case 0x0047592CU:
                goto block_0047592C;
            case 0x00475934U:
                goto block_00475934;
            case 0x00475944U:
                goto block_00475944;
            case 0x00475954U:
                goto block_00475954;
            case 0x00475960U:
                goto block_00475960;
            case 0x00475970U:
                goto block_00475970;
            case 0x00475990U:
                goto block_00475990;
            case 0x0047599CU:
                goto block_0047599C;
            case 0x004759ACU:
                goto block_004759AC;
            case 0x004759BCU:
                goto block_004759BC;
            case 0x004759C8U:
                goto block_004759C8;
            case 0x004759D4U:
                goto block_004759D4;
            case 0x004759E4U:
                goto block_004759E4;
            case 0x004759ECU:
                goto block_004759EC;
            case 0x004759F8U:
                goto block_004759F8;
            case 0x00475A04U:
                goto block_00475A04;
            case 0x00475A10U:
                goto block_00475A10;
            case 0x00475A34U:
                goto block_00475A34;
            case 0x00475A3CU:
                goto block_00475A3C;
            case 0x00475A5CU:
                goto block_00475A5C;
            case 0x00475A68U:
                goto block_00475A68;
            case 0x00475A78U:
                goto block_00475A78;
            case 0x00475A98U:
                goto block_00475A98;
            case 0x00475AA4U:
                goto block_00475AA4;
            case 0x00475AA8U:
                goto block_00475AA8;
            case 0x00475AB0U:
                goto block_00475AB0;
            case 0x00475AB8U:
                goto block_00475AB8;
            case 0x00475AC8U:
                goto block_00475AC8;
            case 0x00475AD8U:
                goto block_00475AD8;
            case 0x00475AE4U:
                goto block_00475AE4;
            case 0x00475AF0U:
                goto block_00475AF0;
            case 0x00475B04U:
                goto block_00475B04;
            case 0x00475B08U:
                goto block_00475B08;
            case 0x00475B1CU:
                goto block_00475B1C;
            case 0x00475B3CU:
                goto block_00475B3C;
            case 0x00475B48U:
                goto block_00475B48;
            case 0x00475B58U:
                goto block_00475B58;
            case 0x00475B64U:
                goto block_00475B64;
            case 0x00475B70U:
                goto block_00475B70;
            case 0x00475B78U:
                goto block_00475B78;
            case 0x00475B84U:
                goto block_00475B84;
            case 0x00475B88U:
                goto block_00475B88;
            case 0x00475B98U:
                goto block_00475B98;
            case 0x00475BA4U:
                goto block_00475BA4;
            case 0x00475BB0U:
                goto block_00475BB0;
            case 0x00475BB8U:
                goto block_00475BB8;
            case 0x00475BC4U:
                goto block_00475BC4;
            case 0x00475BE0U:
                goto block_00475BE0;
            case 0x00475BF0U:
                goto block_00475BF0;
            case 0x00475BFCU:
                goto block_00475BFC;
            case 0x00475C08U:
                goto block_00475C08;
            case 0x00475C10U:
                goto block_00475C10;
            case 0x00475C20U:
                goto block_00475C20;
            case 0x00475C30U:
                goto block_00475C30;
            case 0x00475C48U:
                goto block_00475C48;
            case 0x00475C54U:
                goto block_00475C54;
            case 0x00475C60U:
                goto block_00475C60;
            case 0x00475C68U:
                goto block_00475C68;
            case 0x00475C6CU:
                goto block_00475C6C;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_0047400C;
    }
block_0047400C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047400CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047400CU);
        }
        goto block_00475C60;
    }
block_004740BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004740BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004740BCU);
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004740C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004740C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004740C4;
    }
block_004740C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004740C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004740C4U);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004740D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003371d8_003371D8(frame, context, state, 0x003371D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004740D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004740D0;
    }
block_004740D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004740D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004740D0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004740D0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004740D4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004740D8U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x004740E4U + 0xD18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004740DCU, address);
            }
            r0 = value;
        }
        {
            r7 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x004740E4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004740ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f2d8_0033F2D8(frame, context, state, 0x0033F2D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004740ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004740EC;
    }
block_004740EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004740ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004740ECU);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r10 + 0xEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x004740F0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004740F4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004740F8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000009U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00474178; }
        goto block_00474104;
    }
block_00474104:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474104U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474104U);
        }
        {
            r0 = 0x000002E0U;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474108U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00474134; }
        goto block_00474114;
    }
block_00474114:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474114U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474114U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00474140; }
        goto block_0047411C;
    }
block_0047411C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047411CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047411CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00474134; }
        goto block_00474124;
    }
block_00474124:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474124U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474124U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000030U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00474140; }
        goto block_0047412C;
    }
block_0047412C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047412CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047412CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000022U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_00474150; }
        goto block_00474134;
    }
block_00474134:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474134U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474134U);
        }
        {
            const uint32_t updatedAddress = r10 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474134U, address);
            }
            r0 = value;
        }
        goto block_00474138;
    }
block_00474138:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474138U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474138U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0047413CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033704c_0033704C(frame, context, state, 0x0033704CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0047413CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0047413C;
    }
block_0047413C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047413CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047413CU);
        }
        goto block_00474160;
    }
block_00474140:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474140U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474140U);
        }
        {
            const uint32_t updatedAddress = r10 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474140U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000C000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r0 = value;
        }
        goto block_00474138;
    }
block_00474150:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474150U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474150U);
        }
        {
            r0 = Oot3dAotShiftRegister(r7, 0U, r0, false).Value;
        }
        {
            const uint32_t operand = 0x00008000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474160U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033704c_0033704C(frame, context, state, 0x0033704CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474160U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474160;
    }
block_00474160:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474160U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474160U);
        }
        {
            r1 = 0x0000000CU;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0047416CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0047416CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0047416C;
    }
block_0047416C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047416CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047416CU);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_00474178:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474178U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474178U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_004741A0; }
        goto block_00474180;
    }
block_00474180:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474180U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474180U);
        }
        {
            r0 = 0x0000001EU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474184U, address);
            }
        }
        {
            r1 = 0x00000018U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474194U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474194U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474194;
    }
block_00474194:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474194U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474194U);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_004741A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004741A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004741A0U);
        }
        {
            const uint32_t operand = 0x00000200U;
            r4 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xE0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004741A4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000000FU;
            r0 = r0 - operand;
        }
        {
            r0 = Oot3dAotShiftRegister(r7, 0U, r0, false).Value;
        }
        {
            const uint32_t operand = 0x00008000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004741BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033704c_0033704C(frame, context, state, 0x0033704CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004741BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004741BC;
    }
block_004741BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004741BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004741BCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004741BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x004741C8U + 0xC38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004741C0U, address);
            }
            r1 = value;
        }
        {
            r4 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x0000000FU;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 3U);
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = r1;
            r7 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + r0;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004741D8U, address);
            }
            r10 = value;
        }
        goto block_004741DC;
    }
block_004741DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004741DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004741DCU);
        }
        {
            r1 = r4;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, r10, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t operand = r4;
            r0 = r7 + operand;
        }
        if ((flags.N()) == (flags.V())) {
            r2 = 0x000000FFU;
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r0 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004741ECU, address);
            }
            r2 = value;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004741F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0048b814_0048B814(frame, context, state, 0x0048B814U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004741F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004741F8;
    }
block_004741F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004741F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004741F8U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r4 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000008U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_004741DC; }
        goto block_00474208;
    }
block_00474208:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474208U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474208U);
        }
        {
            r1 = 0x0000001BU;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474214U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474214U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474214;
    }
block_00474214:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474214U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474214U);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_00474220:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474220U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474220U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474228U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003371d8_003371D8(frame, context, state, 0x003371D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474228U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474228;
    }
block_00474228:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474228U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474228U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474228U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047422CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00474280; }
        goto block_00474238;
    }
block_00474238:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474238U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474238U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047423CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 - operand;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00474248U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047424CU, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00474280; }
        goto block_00474258;
    }
block_00474258:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474258U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474258U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474258U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x300U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0047425CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474260U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474264U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474268U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474274U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d038c_002D038C(frame, context, state, 0x002D038CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474274U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474274;
    }
block_00474274:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474274U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474274U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474274U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0047427CU, address);
            }
        }
        goto block_00474280;
    }
block_00474280:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474280U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474280U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474280U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474288U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xDCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0047428CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474290U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474294U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x0000000CU, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_004744EC; }
        goto block_004742A0;
    }
block_004742A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004742A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004742A0U);
        }
        {
        }
        if (flags.Z()) { goto block_004742D0; }
        goto block_004742A8;
    }
block_004742A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004742A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004742A8U);
        }
        {
            const uint32_t updatedAddress = 0x004742B0U + 0xB58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004742A8U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x004742B4U + 0xB58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004742ACU, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = 0x004742B8U + 0xB4CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004742B0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r3 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004742B8U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r2 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004742BCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 2U);
            r3 = r12 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004742C4U, address);
            }
            r3 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r3, 0U, 0U, flags.C());
            const uint32_t value = r2 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_004744B8; }
        goto block_004742D0;
    }
block_004742D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004742D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004742D0U);
        }
        {
            const uint32_t updatedAddress = r0 + 0xDCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004742D0U, address);
            }
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xE2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004742D8U, address);
            }
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r1 = value;
        }
        {
            r2 = 0x0000001EU;
        }
        {
            const uint32_t updatedAddress = r10 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004742E4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x004742E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xE0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004742ECU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000030U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00474350; }
        goto block_004742F8;
    }
block_004742F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004742F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004742F8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004742F8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004742FCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_00474310; }
        goto block_00474308;
    }
block_00474308:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474308U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474308U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_004743B0; }
        goto block_00474310;
    }
block_00474310:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474310U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474310U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474318U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474318U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474318;
    }
block_00474318:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474318U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474318U);
        }
        {
            const uint32_t updatedAddress = 0x00474320U + 0xAF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474318U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x00474324U + 0xAF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047431CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00474328U + 0xAF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474320U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00474328U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474338U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474338U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474338;
    }
block_00474338:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474338U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474338U);
        }
        {
            r1 = 0x00000009U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474344U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474344U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474344;
    }
block_00474344:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474344U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474344U);
        }
        {
        }
        {
        }
        goto block_004744A4;
    }
block_00474350:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474350U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474350U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000028U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00474410; }
        goto block_00474358;
    }
block_00474358:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474358U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474358U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474358U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047435CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_004743B0; }
        goto block_00474368;
    }
block_00474368:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474368U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474368U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474370U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474370U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474370;
    }
block_00474370:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474370U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474370U);
        }
        {
            const uint32_t updatedAddress = 0x00474378U + 0xA98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474370U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0047437CU + 0xA98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474374U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00474380U + 0xA98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474378U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00474380U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474390U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474390U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474390;
    }
block_00474390:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474390U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474390U);
        }
        {
            r0 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474394U, address);
            }
        }
        {
            r1 = 0x0000000EU;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004743A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004743A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004743A4;
    }
block_004743A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004743A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004743A4U);
        }
        {
        }
        {
        }
        goto block_004744A4;
    }
block_004743B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004743B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004743B0U);
        }
        {
            const uint32_t updatedAddress = 0x004743B8U + 0xA64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004743B0U, address);
            }
            r1 = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004743BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_ContinueTextbox_0036BE34(frame, context, state, 0x0036BE34U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004743BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004743BC;
    }
block_004743BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004743BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004743BCU);
        }
        {
            r1 = 0x00000011U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004743C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004743C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004743C8;
    }
block_004743C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004743C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004743C8U);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004743CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x004743D8U + 0xA38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004743D0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x004743DCU + 0xA38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004743D4U, address);
            }
            r2 = value;
        }
        {
            r0 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004743DCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x004743E0U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = 0x004743F0U + 0xA30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004743E8U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004743F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004743F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004743F8;
    }
block_004743F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004743F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004743F8U);
        }
        {
            r0 = 0x00000001U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474404U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Interface_ChangeAlpha_0034BE04(frame, context, state, 0x0034BE04U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474404U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474404;
    }
block_00474404:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474404U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474404U);
        }
        {
        }
        {
        }
        goto block_004744A4;
    }
block_00474410:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474410U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474410U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0047446C; }
        goto block_00474418;
    }
block_00474418:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474418U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474418U);
        }
        {
            const uint32_t updatedAddress = 0x00474420U + 0x9FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474418U, address);
            }
            r1 = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474424U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_ContinueTextbox_0036BE34(frame, context, state, 0x0036BE34U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474424U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474424;
    }
block_00474424:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474424U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474424U);
        }
        {
            r1 = 0x00000011U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474430U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474430U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474430;
    }
block_00474430:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474430U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474430U);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474434U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00474440U + 0x9D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474438U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x00474444U + 0x9D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047443CU, address);
            }
            r2 = value;
        }
        {
            r0 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474444U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00474448U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = 0x00474458U + 0x9C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474450U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474460U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474460U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474460;
    }
block_00474460:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474460U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474460U);
        }
        {
        }
        {
        }
        goto block_004744A4;
    }
block_0047446C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047446CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047446CU);
        }
        {
            const uint32_t updatedAddress = 0x00474474U + 0x99CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047446CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x00474478U + 0x99CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474470U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0047447CU + 0x9A4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474474U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0047447CU, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0047448CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0047448CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0047448C;
    }
block_0047448C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047448CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047448CU);
        }
        {
            r0 = r6;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474498U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0048b9a0_0048B9A0(frame, context, state, 0x0048B9A0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474498U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474498;
    }
block_00474498:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474498U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474498U);
        }
        {
            r1 = 0x0000000DU;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004744A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004744A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004744A4;
    }
block_004744A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004744A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004744A4U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004744ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Interface_ChangeAlpha_0034BE04(frame, context, state, 0x0034BE04U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004744ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004744AC;
    }
block_004744AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004744ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004744ACU);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_004744B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004744B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004744B8U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004744C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004744C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004744C0;
    }
block_004744C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004744C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004744C0U);
        }
        {
            const uint32_t updatedAddress = 0x004744C8U + 0x948U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004744C0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x004744CCU + 0x948U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004744C4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x004744D0U + 0x948U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004744C8U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x004744D0U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004744E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004744E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004744E0;
    }
block_004744E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004744E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004744E0U);
        }
        {
        }
        {
        }
        goto block_00474BEC;
    }
block_004744EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004744ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004744ECU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0047453C; }
        goto block_004744F4;
    }
block_004744F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004744F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004744F4U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004744FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004744FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004744FC;
    }
block_004744FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004744FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004744FCU);
        }
        {
            const uint32_t updatedAddress = 0x00474504U + 0x90CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004744FCU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x00474508U + 0x90CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474500U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0047450CU + 0x90CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474504U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0047450CU, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0047451CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0047451CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0047451C;
    }
block_0047451C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047451CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047451CU);
        }
        {
            r0 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474520U, address);
            }
        }
        {
            r1 = 0x0000000EU;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474530U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474530U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474530;
    }
block_00474530:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474530U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474530U);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_0047453C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047453CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047453CU);
        }
        {
            const uint32_t operand = 0x00000014U;
            r6 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474544U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_GetDisplayClass_0043C20C(frame, context, state, 0x0043C20CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474544U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474544;
    }
block_00474544:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474544U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474544U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_00475C68; }
        goto block_00474550;
    }
block_00474550:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474550U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474550U);
        }
        {
            r1 = 0x00000005U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0047455CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0047455CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0047455C;
    }
block_0047455C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047455CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047455CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00475C68; }
        goto block_00474568;
    }
block_00474568:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474568U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474568U);
        }
        {
            const uint32_t updatedAddress = 0x00474570U + 0x8B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474568U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047456CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474570U, address);
            }
            r1 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r8 + 0x16U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474578U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = 0x00000001U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00475C68; }
        goto block_0047458C;
    }
block_0047458C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047458CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047458CU);
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474594U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474594U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474594;
    }
block_00474594:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474594U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474594U);
        }
        {
            const uint32_t updatedAddress = 0x0047459CU + 0x860U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474594U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x301U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0047459CU, address);
            }
        }
        {
            r0 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004745A4U, address);
            }
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004745B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_ResetDisplay_003725E0(frame, context, state, 0x003725E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004745B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004745B0;
    }
block_004745B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004745B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004745B0U);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_004745BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004745BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004745BCU);
        }
        {
            const uint32_t updatedAddress = r10 + 0xEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004745BCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x004745C8U + 0x860U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004745C0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x004745CCU + 0x82CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004745C4U, address);
            }
            r7 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x60U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004745C8U, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r1 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x5CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004745D0U, address);
            }
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r11 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r10 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004745D8U, address);
            }
            r6 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004745DCU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r1;
            Oot3dAotSetSubtractFlags(flags, r6, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r6 - operand;
        }
        if (flags.N()) {
            const uint32_t operand = r6;
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x58U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004745E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004745ECU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r13 + 0x54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004745F0U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004745F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004745F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004745F8;
    }
block_004745F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004745F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004745F8U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r10 = value;
        }
        {
            const uint32_t updatedAddress = r11 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004745FCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r13 + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474600U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x50U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474604U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474608U, address);
            }
            r7 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r0;
            Oot3dAotSetSubtractFlags(flags, r7, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r7 - operand;
        }
        if (flags.N()) {
            const uint32_t updatedAddress = r13 + 0x50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474610U, address);
            }
            r0 = value;
        }
        if (flags.N()) {
            const uint32_t operand = r7;
            r0 = r0 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0047461CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0047461CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0047461C;
    }
block_0047461C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047461CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047461CU);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474620U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474624U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x00474630U + 0x7C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474628U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0047462CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x12U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474630U, address);
            }
            r11 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r13 + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474634U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r0;
            Oot3dAotSetSubtractFlags(flags, r11, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r11 - operand;
        }
        if (flags.N()) {
            const uint32_t updatedAddress = r13 + 0x4CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047463CU, address);
            }
            r0 = value;
        }
        if (flags.N()) {
            const uint32_t operand = r11;
            r0 = r0 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474648U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474648U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474648;
    }
block_00474648:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474648U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474648U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474648U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x00474654U + 0x7A4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047464CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r6, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t operand = r10;
            r1 = r6 + operand;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t operand = r10;
            r1 = r6 - operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00474660U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474664U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x00474670U + 0x788U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474668U, address);
            }
            r6 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r7, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474670U, address);
            }
            r1 = value;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t operand = r7;
            r1 = r1 + operand;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t operand = r1;
            r1 = r7 - operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0047467CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474680U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r11, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t operand = r11;
            r0 = r0 + operand;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t operand = r0;
            r0 = r11 - operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0x12U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474690U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x5CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474694U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x004746A0U + 0x78CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474698U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x16U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047469CU, address);
            }
            r7 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r11 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r11 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004746A4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r1;
            Oot3dAotSetSubtractFlags(flags, r7, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r7 - operand;
        }
        if (flags.N()) {
            const uint32_t operand = r7;
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004746B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004746B4U, address);
            }
            r1 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004746BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004746BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004746BC;
    }
block_004746BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004746BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004746BCU);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004746C0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004746C4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r13 + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004746C8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004746CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x1AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004746D0U, address);
            }
            r10 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r0;
            Oot3dAotSetSubtractFlags(flags, r10, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r10 - operand;
        }
        if (flags.N()) {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004746D8U, address);
            }
            r0 = value;
        }
        if (flags.N()) {
            const uint32_t operand = r10;
            r0 = r0 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004746E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004746E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004746E4;
    }
block_004746E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004746E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004746E4U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004746E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004746ECU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004746F0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0x18U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004746F4U, address);
            }
            r11 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x00474700U + 0x6F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004746F8U, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004746FCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r0;
            Oot3dAotSetSubtractFlags(flags, r11, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r11 - operand;
        }
        if (flags.N()) {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474704U, address);
            }
            r0 = value;
        }
        if (flags.N()) {
            const uint32_t operand = r11;
            r0 = r0 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474710U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474710U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474710;
    }
block_00474710:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474710U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474710U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474710U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x22U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474714U, address);
            }
            r6 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x00474720U + 0x6D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474718U, address);
            }
            r2 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r6, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474724U, address);
            }
            r1 = value;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t operand = r7;
            r1 = r1 + operand;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t operand = r1;
            r1 = r7 - operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00474730U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0047473CU + 0x6BCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474734U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474738U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x26U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047473CU, address);
            }
            r7 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r7, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474744U, address);
            }
            r2 = value;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t operand = r10;
            r2 = r2 + operand;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t operand = r2;
            r2 = r10 - operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x1AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00474750U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474754U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x24U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474758U, address);
            }
            r10 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r10, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t operand = r11;
            r0 = r0 + operand;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t operand = r0;
            r0 = r11 - operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474768U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x5CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047476CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00474778U + 0x6B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474770U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474778U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047477CU, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r1 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474780U, address);
            }
            r11 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r13 + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474784U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00474788U, address);
            }
        }
        {
            const uint32_t operand = r2;
            Oot3dAotSetSubtractFlags(flags, r11, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r11 - operand;
        }
        if (flags.N()) {
            const uint32_t operand = r11;
            r0 = r2 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474798U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474798U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474798;
    }
block_00474798:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474798U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474798U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0047479CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004747A0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x004747ACU + 0x64CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004747A4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004747A8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004747ACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x20U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004747B0U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r0;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004747B8U, address);
            }
        }
        if (flags.N()) {
            const uint32_t updatedAddress = r13 + 0x30U;
            const uint32_t address = updatedAddress;
            uint64_t value = 0;
            uint32_t faultAddress = address;
            if (!context.Memory.ReadFast<uint64_t>(
                    address, &value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x004747BCU, faultAddress);
            }
            r0 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        if (flags.N()) {
            const uint32_t operand = r0;
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004747C4U, address);
            }
            r1 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004747CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004747CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004747CC;
    }
block_004747CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004747CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004747CCU);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004747D0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004747D4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x004747E0U + 0x618U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004747D8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004747DCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004747E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x1EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004747E4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r0;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r1 - operand;
        }
        if (flags.N()) {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004747ECU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004747F0U, address);
            }
        }
        if (flags.N()) {
            const uint32_t operand = r1;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004747F8U, address);
            }
            r1 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474800U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474800U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474800;
    }
block_00474800:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474800U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474800U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474800U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0047480CU + 0x5ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474804U, address);
            }
            r2 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r11, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474810U, address);
            }
            r1 = value;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t operand = r11;
            r1 = r1 + operand;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t operand = r1;
            r1 = r11 - operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0047481CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474820U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474824U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x00474830U + 0x5C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474828U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r3, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            r1 = r3;
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474834U, address);
            }
            r3 = value;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t operand = r3;
            r1 = r1 + operand;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t operand = r3;
            r1 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00474840U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474844U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474848U, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r3, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            r1 = r3;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t operand = r0;
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x1EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0047485CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x5CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474860U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0047486CU + 0x5C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474864U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0047486CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474870U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r1;
            Oot3dAotSetSubtractFlags(flags, r6, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r6 - operand;
        }
        if (flags.N()) {
            const uint32_t operand = r6;
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0047487CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474880U, address);
            }
            r1 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474888U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474888U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474888;
    }
block_00474888:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474888U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474888U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0047488CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474890U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474894U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474898U, address);
            }
            r11 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r11;
            Oot3dAotSetSubtractFlags(flags, r7, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r7 - operand;
        }
        if (flags.N()) {
            const uint32_t operand = r7;
            r0 = r11 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004748A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004748A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004748A8;
    }
block_004748A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004748A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004748A8U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004748ACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004748B0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004748B4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004748B8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004748BCU, address);
            }
        }
        {
            const uint32_t operand = r0;
            Oot3dAotSetSubtractFlags(flags, r10, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r10 - operand;
        }
        if (flags.N()) {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004748C4U, address);
            }
            r0 = value;
        }
        if (flags.N()) {
            const uint32_t operand = r10;
            r0 = r0 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004748D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Runtime_SignedDivMod32_00368D94(frame, context, state, 0x00368D94U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004748D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004748D0;
    }
block_004748D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004748D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004748D0U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004748D4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x004748E0U + 0x518U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004748D8U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r6, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004748E0U, address);
            }
            r0 = value;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t operand = r6;
            r0 = r0 + operand;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t operand = r0;
            r0 = r6 - operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x22U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004748ECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004748F0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x004748FCU + 0x4FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004748F4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r11, r7, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t operand = r7;
            r2 = r2 + operand;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t operand = r2;
            r2 = r7 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x26U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00474904U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474908U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r10, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            const uint32_t operand = r10;
            r1 = r1 + operand;
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            const uint32_t operand = r1;
            r1 = r10 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00474918U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047491CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0047492CU, address);
            }
        }
        if (!(flags.Z())) { goto block_004749A4; }
        goto block_00474934;
    }
block_00474934:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474934U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474934U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474934U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00474938U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047493CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00474940U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474944U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x12U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00474948U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047494CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00474950U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474954U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00474958U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047495CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00474960U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474964U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00474968U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047496CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x20U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00474970U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474974U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00474978U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047497CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x22U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00474980U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x26U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x00474984U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474988U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x24U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0047498CU, address);
            }
        }
        {
            r1 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00474994U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474998U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 ^ 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004749A0U, address);
            }
        }
        goto block_004749A4;
    }
block_004749A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004749A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004749A4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004749A4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            r0 = r0 & 0x000000FFU;
            Oot3dAotSetLogicalFlags(flags, r0, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004749B0U, address);
            }
        }
        if (!(flags.Z())) { goto block_00475C68; }
        goto block_004749B8;
    }
block_004749B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004749B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004749B8U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004749C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004749C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004749C0;
    }
block_004749C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004749C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004749C0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004749C0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_004749F4; }
        goto block_004749CC;
    }
block_004749CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004749CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004749CCU);
        }
        {
            const uint32_t updatedAddress = 0x004749D4U + 0x448U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004749CCU, address);
            }
            r1 = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004749D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_ContinueTextbox_0036BE34(frame, context, state, 0x0036BE34U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004749D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004749D8;
    }
block_004749D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004749D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004749D8U);
        }
        {
            r1 = 0x00000011U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004749E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004749E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004749E4;
    }
block_004749E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004749E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004749E4U);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004749E8U, address);
            }
        }
        {
            r0 = 0x00000002U;
        }
        goto block_00475AA8;
    }
block_004749F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004749F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004749F4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00474A20; }
        goto block_004749FC;
    }
block_004749FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004749FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004749FCU);
        }
        {
            r0 = 0x000002DCU;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474A00U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_004749CC; }
        goto block_00474A0C;
    }
block_00474A0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474A0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474A0CU);
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474A14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_ResetDisplay_003725E0(frame, context, state, 0x003725E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474A14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474A14;
    }
block_00474A14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474A14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474A14U);
        }
        {
        }
        {
        }
        goto block_004750B8;
    }
block_00474A20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474A20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474A20U);
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474A28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_ResetDisplay_003725E0(frame, context, state, 0x003725E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474A28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474A28;
    }
block_00474A28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474A28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474A28U);
        }
        {
        }
        {
        }
        goto block_0047509C;
    }
block_00474A34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474A34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474A34U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474A34U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            r0 = r0 & 0x000000FFU;
            Oot3dAotSetLogicalFlags(flags, r0, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474A40U, address);
            }
        }
        if (!(flags.Z())) { goto block_00475C68; }
        goto block_00474A48;
    }
block_00474A48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474A48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474A48U);
        }
        {
            const uint32_t updatedAddress = 0x00474A50U + 0x3E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474A48U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474A50U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000F00U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x7AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474A58U, address);
            }
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474A64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0048b8f8_0048B8F8(frame, context, state, 0x0048B8F8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474A64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474A64;
    }
block_00474A64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474A64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474A64U);
        }
        {
            r1 = 0x00000010U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474A70U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474A70U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474A70;
    }
block_00474A70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474A70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474A70U);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_00474A7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474A7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474A7CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474A7CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            r0 = r0 & 0x000000FFU;
            Oot3dAotSetLogicalFlags(flags, r0, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474A88U, address);
            }
        }
        if (!(flags.Z())) { goto block_00475C68; }
        goto block_00474A90;
    }
block_00474A90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474A90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474A90U);
        }
        {
            const uint32_t updatedAddress = 0x00474A98U + 0x3A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474A90U, address);
            }
            r0 = value;
        }
        {
            r4 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474A98U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000F00U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x7AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00474AA0U, address);
            }
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474AACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0048b8f8_0048B8F8(frame, context, state, 0x0048B8F8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474AACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474AAC;
    }
block_00474AAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474AACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474AACU);
        }
        {
            r1 = 0x0000001EU;
        }
        {
            r0 = r5;
        }
        {
            const uint32_t updatedAddress = r6 + 0xDU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00474AB4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474ABCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474ABCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474ABC;
    }
block_00474ABC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474ABCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474ABCU);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_00474AC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474AC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474AC8U);
        }
        {
            const uint32_t updatedAddress = 0x00474AD0U + 0x368U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474AC8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474ACCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000F00U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x6EU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474AD4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x7AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474AD8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = r1;
            r2 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x6EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00474AE0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x70U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474AE4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = r1;
            r2 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x70U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00474AECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x72U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474AF0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = r1;
            r2 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x72U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00474AF8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x74U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474AFCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = r1;
            r2 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x74U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00474B04U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x76U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474B08U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = r1;
            r2 = r2 + operand;
        }
        {
            r1 = Oot3dAotLsl(r1, 1U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x76U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x00474B14U, address);
            }
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x7AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00474B1CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00474B28U + 0x314U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474B20U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_00475C68; }
        goto block_00474B2C;
    }
block_00474B2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474B2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474B2CU);
        }
        {
            const uint32_t updatedAddress = 0x00474B34U + 0x2B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474B2CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474B30U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_00474B70; }
        goto block_00474B3C;
    }
block_00474B3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474B3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474B3CU);
        }
        {
            const uint32_t updatedAddress = 0x00474B44U + 0x2A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474B3CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474B44U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474B44U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474B44;
    }
block_00474B44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474B44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474B44U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00474B70; }
        goto block_00474B50;
    }
block_00474B50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474B50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474B50U);
        }
        {
            const uint32_t updatedAddress = 0x00474B58U + 0x290U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474B50U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474B58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474B58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474B58;
    }
block_00474B58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474B58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474B58U);
        }
        {
            const uint32_t updatedAddress = 0x00474B60U + 0x28CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474B58U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00474B64U + 0x28CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474B5CU, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x00474B6CU + 0x278U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474B64U, address);
            }
            r0 = value;
        }
        {
        }
        {
            r0 = r0;
        }
        goto block_00474B70;
    }
block_00474B70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474B70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474B70U);
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474B78U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002c0ca4_002C0CA4(frame, context, state, 0x002C0CA4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474B78U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474B78;
    }
block_00474B78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474B78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474B78U);
        }
        {
            const uint32_t updatedAddress = 0x00474B80U + 0x2C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474B78U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x000000FFU;
        }
        {
            r1 = 0x00000009U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474B88U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_memset_00303B14(frame, context, state, 0x00303B14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474B88U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474B88;
    }
block_00474B88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474B88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474B88U);
        }
        {
            const uint32_t updatedAddress = 0x00474B90U + 0x2B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474B88U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00474B8CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00474B90U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00474B94U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x6U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00474B98U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00474B9CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00474BA0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00474BA4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00474BA8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00474BACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474BB0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00474BEC; }
        goto block_00474BBC;
    }
block_00474BBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474BBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474BBCU);
        }
        {
            const uint32_t updatedAddress = 0x00474BC4U + 0x284U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474BBCU, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474BCCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_message_start_textbox_002D0320(frame, context, state, 0x002D0320U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474BCCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474BCC;
    }
block_00474BCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474BCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474BCCU);
        }
        {
            r0 = 0x00000041U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474BD0U, address);
            }
        }
        {
            r1 = 0x0000001FU;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474BE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474BE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474BE0;
    }
block_00474BE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474BE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474BE0U);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_00474BEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474BECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474BECU);
        }
        {
            r1 = 0x00000009U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474BF8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474BF8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474BF8;
    }
block_00474BF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474BF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474BF8U);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_00474C04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474C04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474C04U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474C04U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            r0 = r0 & 0x000000FFU;
            Oot3dAotSetLogicalFlags(flags, r0, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474C10U, address);
            }
        }
        if (!(flags.Z())) { goto block_00475C68; }
        goto block_00474C18;
    }
block_00474C18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474C18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474C18U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474C20U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474C20U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474C20;
    }
block_00474C20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474C20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474C20U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r6 + 0xDU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474C24U, address);
            }
        }
        {
            r1 = 0x00000012U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474C34U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474C34U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474C34;
    }
block_00474C34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474C34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474C34U);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474C40U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003371d8_003371D8(frame, context, state, 0x003371D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474C40U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474C40;
    }
block_00474C40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474C40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474C40U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474C40U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00474C44U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00474C48U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474C50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f2d8_0033F2D8(frame, context, state, 0x0033F2D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474C50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474C50;
    }
block_00474C50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474C50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474C50U);
        }
        {
            r0 = 0x000002DCU;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474C54U, address);
            }
            r12 = value;
        }
        {
            const uint32_t operand = 0x00000006U;
            r0 = r12 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00475C68; }
        goto block_00474C64;
    }
block_00474C64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474C64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474C64U);
        }
        {
            const uint32_t updatedAddress = 0x00474C6CU + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474C64U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 - 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474C74U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00474C78U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00474C84U + 0x1CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474C7CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x00474C80U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00474C80U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00474C80U,
                                           firstAddress + 8U);
            }
        }
        {
            r3 = r1;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r12, 1U);
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r7 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474C8CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t updatedAddress = r0 - 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474C90U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r7 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474C98U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r7 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474C9CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r5;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474CACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Spawn_003738D0(frame, context, state, 0x003738D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474CACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474CAC;
    }
block_00474CAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474CACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474CACU);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_00474CB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474CB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474CB8U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474CC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474CC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474CC0;
    }
block_00474CC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474CC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474CC0U);
        }
        {
            r0 = 0x00000001U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474CCCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474CCCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474CCC;
    }
block_00474CCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474CCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474CCCU);
        }
        {
            const uint32_t operand = 0x00000200U;
            r4 = r4 + operand;
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xDCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474CD4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int8_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474CE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f248_0033F248(frame, context, state, 0x0033F248U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474CE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474CE4;
    }
block_00474CE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474CE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474CE4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xDCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474CE4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00474D08; }
        goto block_00474CF0;
    }
block_00474CF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474CF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474CF0U);
        }
        {
            const uint32_t updatedAddress = 0x00474CF8U + 0x15CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474CF0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474CF4U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474CFCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayFanfare_0035C528(frame, context, state, 0x0035C528U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474CFCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474CFC;
    }
block_00474CFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474CFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474CFCU);
        }
        {
            r0 = 0x00000020U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474D08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00347cc4_00347CC4(frame, context, state, 0x00347CC4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474D08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474D08;
    }
block_00474D08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474D08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474D08U);
        }
        {
            const uint32_t updatedAddress = 0x00474D10U + 0xECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474D08U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474D10U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xE0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474D14U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = 0x00000029U;
        }
        if (flags.Z()) { goto block_00474D30; }
        goto block_00474D24;
    }
block_00474D24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474D24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474D24U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000030U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00474D34; }
        goto block_00474D2C;
    }
block_00474D2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474D2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474D2CU);
        }
        {
            r0 = 0x00000031U;
        }
        goto block_00474D30;
    }
block_00474D30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474D30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474D30U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474D30U, address);
            }
        }
        goto block_00474D34;
    }
block_00474D34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474D34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474D34U);
        }
        {
            r1 = 0x00000013U;
        }
        {
            r0 = r5;
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00474D3CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474D44U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474D44U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474D44;
    }
block_00474D44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474D44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474D44U);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_00474D50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474D50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474D50U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474D50U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            r0 = r0 & 0x000000FFU;
            Oot3dAotSetLogicalFlags(flags, r0, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474D5CU, address);
            }
        }
        if (!(flags.Z())) { goto block_00475C68; }
        goto block_00474D64;
    }
block_00474D64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474D64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474D64U);
        }
        {
            const uint32_t operand = 0x00000200U;
            r4 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xE0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474D68U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00474D88; }
        goto block_00474D74;
    }
block_00474D74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474D74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474D74U);
        }
        {
            r0 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474D7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474D7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474D7C;
    }
block_00474D7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474D7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474D7CU);
        }
        {
        }
        {
        }
        goto block_00474DA4;
    }
block_00474D88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474D88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474D88U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000009U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = 0x00000002U;
        }
        if (flags.Z()) { goto block_00474DA0; }
        goto block_00474D94;
    }
block_00474D94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474D94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474D94U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00474DD4; }
        goto block_00474D9C;
    }
block_00474D9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474D9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474D9CU);
        }
        {
            r0 = 0x00000003U;
        }
        goto block_00474DA0;
    }
block_00474DA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474DA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474DA0U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474DA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474DA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474DA4;
    }
block_00474DA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474DA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474DA4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474DA4U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int8_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474DB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f248_0033F248(frame, context, state, 0x0033F248U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474DB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474DB8;
    }
block_00474DB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474DB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474DB8U);
        }
        {
            r1 = 0x00000019U;
        }
        {
            r0 = r5;
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00474DC0U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474DC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474DC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474DC8;
    }
block_00474DC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474DC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474DC8U);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_00474DD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474DD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474DD4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r0 = 0x00000001U;
        }
        if (flags.Z()) {
            r0 = 0x00000005U;
        }
        goto block_00474DA0;
    }
block_00474E58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474E58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474E58U);
        }
        {
            r0 = 0x000002DCU;
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474E60U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r0 + operand;
        }
        {
            const uint32_t operand = 0x00000093U;
            r1 = r1 + operand;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474E74U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_message_start_textbox_002D0320(frame, context, state, 0x002D0320U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474E74U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474E74;
    }
block_00474E74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474E74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474E74U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r6 + 0xDU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474E78U, address);
            }
        }
        {
            r1 = 0x00000015U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474E88U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474E88U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474E88;
    }
block_00474E88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474E88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474E88U);
        }
        {
            r0 = 0x0000001EU;
        }
        {
        }
        goto block_00475AA8;
    }
block_00474E94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474E94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474E94U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474E94U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00474EEC; }
        goto block_00474EA0;
    }
block_00474EA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474EA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474EA0U);
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xDCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474EA4U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00474EC0; }
        goto block_00474EB0;
    }
block_00474EB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474EB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474EB0U);
        }
        {
            const uint32_t updatedAddress = r0 + 0xE0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474EB0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000000FU;
            r0 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_00474ED4; }
        goto block_00474EC0;
    }
block_00474EC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474EC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474EC0U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474EC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0032c800_0032C800(frame, context, state, 0x0032C800U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474EC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474EC8;
    }
block_00474EC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474EC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474EC8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_00475C68; }
        goto block_00474ED4;
    }
block_00474ED4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474ED4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474ED4U);
        }
        {
            r1 = 0x00000016U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474EE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474EE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474EE0;
    }
block_00474EE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474EE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474EE0U);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_00474EEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474EECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474EECU);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        goto block_00475AA8;
    }
block_00474EF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474EF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474EF4U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474EFCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474EFCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474EFC;
    }
block_00474EFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474EFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474EFCU);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474F08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f2d8_0033F2D8(frame, context, state, 0x0033F2D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474F08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474F08;
    }
block_00474F08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474F08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474F08U);
        }
        {
            r1 = 0x00000017U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474F14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474F14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474F14;
    }
block_00474F14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474F14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474F14U);
        }
        {
            r0 = 0x00000003U;
        }
        {
        }
        goto block_00475AA8;
    }
block_00474F20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474F20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474F20U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474F20U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00474EEC; }
        goto block_00474F2C;
    }
block_00474F2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474F2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474F2CU);
        }
        {
            const uint32_t operand = 0x00000200U;
            r4 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xDCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474F30U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00475024; }
        goto block_00474F3C;
    }
block_00474F3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474F3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474F3CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474F3CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x0000000FU;
            r1 = r1 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_00475024; }
        goto block_00474F4C;
    }
block_00474F4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474F4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474F4CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474F4CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00474F68; }
        goto block_00474F58;
    }
block_00474F58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474F58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474F58U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474F58U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x2A5U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474F5CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00474FBC; }
        goto block_00474F68;
    }
block_00474F68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474F68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474F68U);
        }
        {
            r1 = 0x0000000FU;
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474F74U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_SetBGM_003655D0(frame, context, state, 0x003655D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474F74U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474F74;
    }
block_00474F74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474F74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474F74U);
        }
        {
            const uint32_t updatedAddress = 0x00474F7CU - 0x16CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474F74U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x00474F80U - 0x16CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474F78U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00474F84U + 0xCF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474F7CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00474F84U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474F94U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474F94U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474F94;
    }
block_00474F94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474F94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474F94U);
        }
        {
            const uint32_t updatedAddress = 0x00474F9CU + 0xCDCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474F94U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474FA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474FA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474FA4;
    }
block_00474FA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474FA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474FA4U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474FB0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474FB0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474FB0;
    }
block_00474FB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474FB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474FB0U);
        }
        {
        }
        {
        }
        goto block_004750B8;
    }
block_00474FBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474FBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474FBCU);
        }
        {
            const uint32_t updatedAddress = 0x00474FC4U + 0xCB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474FBCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x8AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474FC0U, address);
            }
            r1 = value;
        }
        {
            r1 = r1 & 0x0000000FU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00475004; }
        goto block_00474FD0;
    }
block_00474FD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474FD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474FD0U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = 0x0000008DU;
            r0 = r0 + operand;
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r1 = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474FE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474FE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474FE8;
    }
block_00474FE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474FE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474FE8U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00474FF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00474FF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00474FF4;
    }
block_00474FF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00474FF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00474FF4U);
        }
        {
            const uint32_t updatedAddress = 0x00474FFCU - 0x200U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00474FF4U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00474FFCU, address);
            }
        }
        goto block_00475C68;
    }
block_00475004:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475004U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475004U);
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0047500CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_ResetDisplay_003725E0(frame, context, state, 0x003725E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0047500CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0047500C;
    }
block_0047500C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047500CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047500CU);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475018U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475018U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475018;
    }
block_00475018:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475018U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475018U);
        }
        {
        }
        {
        }
        goto block_004750B8;
    }
block_00475024:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475024U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475024U);
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0047502CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_ResetDisplay_003725E0(frame, context, state, 0x003725E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0047502CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0047502C;
    }
block_0047502C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047502CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047502CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xDCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047502CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0047504C; }
        goto block_00475038;
    }
block_00475038:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475038U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475038U);
        }
        {
            const uint32_t updatedAddress = 0x00475040U - 0x208U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475038U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475040U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000500U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475048U, address);
            }
        }
        goto block_0047504C;
    }
block_0047504C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047504CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047504CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xE0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047504CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000029U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00475078; }
        goto block_00475058;
    }
block_00475058:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475058U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475058U);
        }
        {
            const uint32_t operand = 0x00002B00U;
            r0 = r5 + operand;
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x7EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00475060U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xDCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475064U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x0000000CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r1 = 0x0000000BU;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r0 + 0x7EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00475070U, address);
            }
        }
        goto block_00475C68;
    }
block_00475078:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475078U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475078U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xDCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475078U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001CU, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) { goto block_004750AC; }
        goto block_00475084;
    }
block_00475084:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475084U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475084U);
        }
        {
            const uint32_t operand = 0x0000001CU;
            r0 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000001U;
            r0 = r1 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x00475098U - 0x29CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475090U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475094U, address);
            }
        }
        if (!(flags.Z())) { goto block_00475C68; }
        goto block_0047509C;
    }
block_0047509C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047509CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047509CU);
        }
        {
            const uint32_t updatedAddress = 0x004750A4U - 0x2A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047509CU, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004750A4U, address);
            }
        }
        goto block_00475C68;
    }
block_004750AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004750ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004750ACU);
        }
        {
            const uint32_t operand = 0x0000000FU;
            r0 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0047509C; }
        goto block_004750B8;
    }
block_004750B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004750B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004750B8U);
        }
        {
            const uint32_t updatedAddress = 0x004750C0U - 0x2C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004750B8U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004750C0U, address);
            }
        }
        goto block_00475C68;
    }
block_004750C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004750C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004750C8U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004750D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f400_0033F400(frame, context, state, 0x0033F400U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004750D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004750D0;
    }
block_004750D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004750D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004750D0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004750D0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004750D4U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00475128; }
        goto block_004750E0;
    }
block_004750E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004750E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004750E0U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004750E0U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00475128; }
        goto block_004750EC;
    }
block_004750EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004750ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004750ECU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004750ECU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000013U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00475110; }
        goto block_004750F8;
    }
block_004750F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004750F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004750F8U);
        }
        {
            r1 = 0x00000014U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475104U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475104U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475104;
    }
block_00475104:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475104U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475104U);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_00475110:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475110U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475110U);
        }
        {
            r1 = 0x0000001AU;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0047511CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0047511CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0047511C;
    }
block_0047511C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047511CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047511CU);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_00475128:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475128U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475128U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475128U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047512CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_00475140; }
        goto block_00475138;
    }
block_00475138:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475138U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475138U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0047513CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f2d8_0033F2D8(frame, context, state, 0x0033F2D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0047513CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0047513C;
    }
block_0047513C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047513CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047513CU);
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0047513CU, address);
            }
        }
        goto block_00475140;
    }
block_00475140:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475140U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475140U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475140U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475144U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00475C68; }
        goto block_00475150;
    }
block_00475150:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475150U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475150U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475150U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00475C68; }
        goto block_00475160;
    }
block_00475160:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475160U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475160U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475160U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x300U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475164U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475168U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047516CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475170U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0047517CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d038c_002D038C(frame, context, state, 0x002D038CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0047517CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0047517C;
    }
block_0047517C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047517CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047517CU);
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047517CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475184U, address);
            }
        }
        goto block_00475C68;
    }
block_0047518C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047518CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047518CU);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475194U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003371d8_003371D8(frame, context, state, 0x003371D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475194U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475194;
    }
block_00475194:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475194U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475194U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475194U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475198U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_004751CC; }
        goto block_004751A4;
    }
block_004751A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004751A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004751A4U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004751A4U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r2 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r3, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_004751CC; }
        goto block_004751B4;
    }
block_004751B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004751B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004751B4U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004751B4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r2 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004751C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d038c_002D038C(frame, context, state, 0x002D038CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004751C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004751C0;
    }
block_004751C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004751C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004751C0U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004751C0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004751C8U, address);
            }
        }
        goto block_004751CC;
    }
block_004751CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004751CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004751CCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004751CCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004751D0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_00475254; }
        goto block_004751DC;
    }
block_004751DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004751DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004751DCU);
        }
        {
            r1 = 0x000002DCU;
        }
        {
            const uint32_t updatedAddress = r1 + r4;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004751E0U, address);
            }
        }
        {
            r1 = 0x0000001CU;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004751F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004751F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004751F0;
    }
block_004751F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004751F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004751F0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004751F0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x004751FCU - 0x3F4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004751F4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004751F8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475200U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000005AU;
            r0 = r0 + operand;
        }
        {
            r1 = r0 & 0x000000FFU;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475214U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Item_Give_00376A78(frame, context, state, 0x00376A78U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475214U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475214;
    }
block_00475214:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475214U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475214U);
        }
        {
            const uint32_t updatedAddress = 0x0047521CU - 0x40CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475214U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x00475220U - 0x40CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475218U, address);
            }
            r2 = value;
        }
        {
            r0 = 0x0000001EU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475220U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00475224U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = 0x00475234U - 0x414U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047522CU, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0047523CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0047523CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0047523C;
    }
block_0047523C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047523CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047523CU);
        }
        {
            r0 = r6;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475248U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0048b9a0_0048B9A0(frame, context, state, 0x0048B9A0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475248U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475248;
    }
block_00475248:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475248U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475248U);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_00475254:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475254U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475254U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00475C68; }
        goto block_0047525C;
    }
block_0047525C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047525CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047525CU);
        }
        {
            const uint32_t updatedAddress = 0x00475264U - 0x454U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047525CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x00475268U - 0x454U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475260U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0047526CU - 0x454U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475264U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0047526CU, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0047527CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0047527CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0047527C;
    }
block_0047527C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047527CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047527CU);
        }
        {
            r0 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475280U, address);
            }
        }
        {
            r1 = 0x0000001DU;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475290U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475290U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475290;
    }
block_00475290:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475290U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475290U);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_0047529C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047529CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047529CU);
        }
        {
            const uint32_t updatedAddress = r11 + 0xB74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047529CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000003CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_00475C68; }
        goto block_004752A8;
    }
block_004752A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004752A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004752A8U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004752B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034696c_0034696C(frame, context, state, 0x0034696CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004752B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004752B4;
    }
block_004752B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004752B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004752B4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_004752CC; }
        goto block_004752C0;
    }
block_004752C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004752C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004752C0U);
        }
        {
            const uint32_t updatedAddress = r11 + 0xB74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004752C0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00475C68; }
        goto block_004752CC;
    }
block_004752CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004752CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004752CCU);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r10 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004752D0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000200U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xE0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004752DCU, address);
            }
            r4 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xFEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004752E0U, address);
            }
        }
        {
            const uint32_t operand = 0x0000024CU;
            r1 = r1 + operand;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004752F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00343f0c_00343F0C(frame, context, state, 0x00343F0CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004752F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004752F0;
    }
block_004752F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004752F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004752F0U);
        }
        {
            r1 = r4;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004752FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_message_textbox_common_003438A4(frame, context, state, 0x003438A4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004752FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004752FC;
    }
block_004752FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004752FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004752FCU);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_00475308:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475308U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475308U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475310U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d0264_002D0264(frame, context, state, 0x002D0264U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475310U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475310;
    }
block_00475310:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475310U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475310U);
        }
        {
            r0 = 0x00000001U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0047531CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0047531CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0047531C;
    }
block_0047531C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047531CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047531CU);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475328U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d0258_002D0258(frame, context, state, 0x002D0258U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475328U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475328;
    }
block_00475328:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475328U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475328U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475328U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0047532CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00475330U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00475334U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0047533CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f2d8_0033F2D8(frame, context, state, 0x0033F2D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0047533CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0047533C;
    }
block_0047533C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047533CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047533CU);
        }
        {
            r1 = 0x00000022U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475348U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475348U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475348;
    }
block_00475348:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475348U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475348U);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_00475354:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475354U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475354U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0047535CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d0258_002D0258(frame, context, state, 0x002D0258U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0047535CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0047535C;
    }
block_0047535C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047535CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047535CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0047535CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475360U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00475418; }
        goto block_0047536C;
    }
block_0047536C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047536CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047536CU);
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047536CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00475418; }
        goto block_0047537C;
    }
block_0047537C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047537CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047537CU);
        }
        {
            const uint32_t updatedAddress = r10 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047537CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_004753CC; }
        goto block_00475388;
    }
block_00475388:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475388U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475388U);
        }
        {
            const uint32_t updatedAddress = 0x00475390U - 0x550U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475388U, address);
            }
            r11 = value;
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r0 - operand;
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r7 = value;
        }
        goto block_00475398;
    }
block_00475398:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475398U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475398U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r11 + r0;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047539CU, address);
            }
            r1 = value;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004753A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d038c_002D038C(frame, context, state, 0x002D038CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004753A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004753A8;
    }
block_004753A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004753A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004753A8U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r6 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r6 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r7 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000008U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r7 = value;
        }
        if (!(flags.C())) { goto block_00475398; }
        goto block_004753C0;
    }
block_004753C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004753C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004753C0U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004753C0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r10 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004753C8U, address);
            }
        }
        goto block_004753CC;
    }
block_004753CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004753CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004753CCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004753CCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004753D0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x300U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x004753D4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004753D8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r10 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004753DCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004753E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d038c_002D038C(frame, context, state, 0x002D038CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004753E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004753E4;
    }
block_004753E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004753E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004753E4U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004753E4U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x000000FFU;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r10 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004753F4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004753FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d038c_002D038C(frame, context, state, 0x002D038CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004753FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004753FC;
    }
block_004753FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004753FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004753FCU);
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004753FCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475404U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475408U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047540CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00475414U, address);
            }
        }
        goto block_00475418;
    }
block_00475418:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475418U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475418U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475418U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047541CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00475478; }
        goto block_00475428;
    }
block_00475428:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475428U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475428U);
        }
        {
            const uint32_t operand = 0x00000014U;
            r6 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475430U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_GetDisplayClass_0043C20C(frame, context, state, 0x0043C20CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475430U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475430;
    }
block_00475430:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475430U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475430U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_00475C68; }
        goto block_0047543C;
    }
block_0047543C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047543CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047543CU);
        }
        {
            r1 = 0x00000005U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475448U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475448U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475448;
    }
block_00475448:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475448U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475448U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00475C68; }
        goto block_00475454;
    }
block_00475454:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475454U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475454U);
        }
        {
            const uint32_t updatedAddress = 0x0047545CU - 0x638U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475454U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475458U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047545CU, address);
            }
            r1 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r8 + 0x16U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475464U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = 0x00000001U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00475C68; }
        goto block_00475478;
    }
block_00475478:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475478U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475478U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475478U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00475484U - 0x674U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047547CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x00475488U - 0x674U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475480U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x00475490U - 0x68CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475488U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            r0 = 0x00000001U;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r1 + 0xF58U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475490U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00475494U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = 0x004754A4U - 0x68CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047549CU, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004754ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004754ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004754AC;
    }
block_004754AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004754ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004754ACU);
        }
        {
            r0 = 0x00000000U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004754B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d0264_002D0264(frame, context, state, 0x002D0264U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004754B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004754B8;
    }
block_004754B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004754B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004754B8U);
        }
        {
            const uint32_t updatedAddress = 0x004754C0U - 0x6C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004754B8U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004754C0U, address);
            }
        }
        {
            r0 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004754C8U, address);
            }
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004754D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_ResetDisplay_003725E0(frame, context, state, 0x003725E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004754D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004754D4;
    }
block_004754D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004754D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004754D4U);
        }
        {
            const uint32_t updatedAddress = 0x004754DCU + 0x7A4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004754D4U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000360U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004754DCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x004754E8U + 0x79CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004754E0U, address);
            }
            r0 = value;
        }
        goto block_0047570C;
    }
block_004754E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004754E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004754E8U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004754F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f400_0033F400(frame, context, state, 0x0033F400U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004754F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004754F0;
    }
block_004754F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004754F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004754F0U);
        }
        {
            const uint32_t updatedAddress = 0x004754F8U - 0x6D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004754F0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004754F4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004754F8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004754FCU, address);
            }
            r2 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r2, 0U, 0U, flags.C());
            const uint32_t value = r1 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r8 + 0x16U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475504U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r1 = 0x00000001U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00475530; }
        goto block_00475518;
    }
block_00475518:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475518U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475518U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475524U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f248_0033F248(frame, context, state, 0x0033F248U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475524U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475524;
    }
block_00475524:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475524U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475524U);
        }
        {
        }
        {
        }
        goto block_00475600;
    }
block_00475530:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475530U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475530U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475530U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_004755E4; }
        goto block_0047553C;
    }
block_0047553C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047553CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047553CU);
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047553CU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_004755E4; }
        goto block_0047554C;
    }
block_0047554C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047554CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047554CU);
        }
        {
            const uint32_t updatedAddress = r10 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047554CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0047559C; }
        goto block_00475558;
    }
block_00475558:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475558U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475558U);
        }
        {
            const uint32_t updatedAddress = 0x00475560U - 0x720U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475558U, address);
            }
            r11 = value;
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r0 - operand;
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r7 = value;
        }
        goto block_00475568;
    }
block_00475568:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475568U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475568U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r11 + r0;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047556CU, address);
            }
            r1 = value;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475578U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d038c_002D038C(frame, context, state, 0x002D038CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475578U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475578;
    }
block_00475578:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475578U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475578U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r6 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r6 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r7 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000008U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r7 = value;
        }
        if (!(flags.C())) { goto block_00475568; }
        goto block_00475590;
    }
block_00475590:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475590U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475590U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475590U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r10 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475598U, address);
            }
        }
        goto block_0047559C;
    }
block_0047559C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047559CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047559CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047559CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004755A0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r10 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004755A4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004755ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d038c_002D038C(frame, context, state, 0x002D038CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004755ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004755AC;
    }
block_004755AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004755ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004755ACU);
        }
        {
            const uint32_t updatedAddress = r10 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004755ACU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x000000FFU;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r10 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004755BCU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004755C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d038c_002D038C(frame, context, state, 0x002D038CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004755C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004755C4;
    }
block_004755C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004755C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004755C4U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004755C4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004755CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004755D0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004755D4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r10 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004755DCU, address);
            }
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x004755E0U, address);
            }
        }
        goto block_004755E4;
    }
block_004755E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004755E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004755E4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004755E4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00474EEC; }
        goto block_004755F0;
    }
block_004755F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004755F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004755F0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004755F0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004755F4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00475C68; }
        goto block_00475600;
    }
block_00475600:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475600U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475600U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475608U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475608U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475608;
    }
block_00475608:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475608U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475608U);
        }
        {
            const uint32_t updatedAddress = 0x00475610U - 0x814U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475608U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475610U, address);
            }
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0047561CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_ResetDisplay_003725E0(frame, context, state, 0x003725E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0047561CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0047561C;
    }
block_0047561C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047561CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047561CU);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_00475628:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475628U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475628U);
        }
        {
            r0 = 0x00000002U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475630U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d0264_002D0264(frame, context, state, 0x002D0264U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475630U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475630;
    }
block_00475630:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475630U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475630U);
        }
        {
            r0 = 0x00000001U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0047563CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0047563CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0047563C;
    }
block_0047563C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047563CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047563CU);
        }
        {
            r1 = 0x00000025U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475648U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475648U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475648;
    }
block_00475648:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475648U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475648U);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_00475654:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475654U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475654U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0047565CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d0258_002D0258(frame, context, state, 0x002D0258U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0047565CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0047565C;
    }
block_0047565C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047565CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047565CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0047565CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475660U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_004756AC; }
        goto block_0047566C;
    }
block_0047566C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047566CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047566CU);
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047566CU, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_004756AC; }
        goto block_0047567C;
    }
block_0047567C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047567CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047567CU);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047567CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x300U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475680U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475684U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475688U, address);
            }
            r1 = value;
        }
        {
            r0 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475694U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d038c_002D038C(frame, context, state, 0x002D038CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475694U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475694;
    }
block_00475694:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475694U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475694U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475694U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x000000FFU;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004756A4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004756ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d038c_002D038C(frame, context, state, 0x002D038CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004756ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004756AC;
    }
block_004756AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004756ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004756ACU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004756ACU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004756B0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00475714; }
        goto block_004756BC;
    }
block_004756BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004756BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004756BCU);
        }
        {
            const uint32_t updatedAddress = 0x004756C4U + 0x5C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004756BCU, address);
            }
            r1 = value;
        }
        {
            r0 = 0x0000001EU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004756C4U, address);
            }
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x2DDU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004756CCU, address);
            }
        }
        {
            r1 = 0x00000027U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004756DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004756DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004756DC;
    }
block_004756DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004756DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004756DCU);
        }
        {
            const uint32_t updatedAddress = 0x004756E4U - 0x8D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004756DCU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x004756E8U - 0x8D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004756E0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x004756ECU - 0x8CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004756E4U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x004756ECU, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004756FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004756FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004756FC;
    }
block_004756FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004756FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004756FCU);
        }
        {
            const uint32_t updatedAddress = 0x00475704U + 0x588U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004756FCU, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000080U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475704U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x00475710U + 0x580U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475708U, address);
            }
            r0 = value;
        }
        goto block_0047570C;
    }
block_0047570C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047570CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047570CU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475710U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00470778_00470778(frame, context, state, 0x00470778U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475710U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475710;
    }
block_00475710:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475710U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475710U);
        }
        goto block_00475C68;
    }
block_00475714:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475714U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475714U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0047576C; }
        goto block_0047571C;
    }
block_0047571C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047571CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047571CU);
        }
        {
            const uint32_t operand = 0x00000014U;
            r4 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475724U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_GetDisplayClass_0043C20C(frame, context, state, 0x0043C20CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475724U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475724;
    }
block_00475724:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475724U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475724U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_00475C68; }
        goto block_00475730;
    }
block_00475730:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475730U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475730U);
        }
        {
            r1 = 0x00000005U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0047573CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0047573CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0047573C;
    }
block_0047573C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047573CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047573CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00475C68; }
        goto block_00475748;
    }
block_00475748:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475748U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475748U);
        }
        {
            const uint32_t updatedAddress = 0x00475750U - 0x92CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475748U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047574CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475750U, address);
            }
            r1 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r8 + 0x16U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475758U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = 0x00000001U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00475C68; }
        goto block_0047576C;
    }
block_0047576C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047576CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047576CU);
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475774U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d0264_002D0264(frame, context, state, 0x002D0264U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475774U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475774;
    }
block_00475774:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475774U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475774U);
        }
        {
            const uint32_t updatedAddress = 0x0047577CU - 0x96CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475774U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x00475780U - 0x96CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475778U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00475784U - 0x96CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047577CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00475784U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475794U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475794U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475794;
    }
block_00475794:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475794U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475794U);
        }
        {
            r0 = r5;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004757A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_ResetDisplay_003725E0(frame, context, state, 0x003725E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004757A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004757A0;
    }
block_004757A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004757A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004757A0U);
        }
        {
            r1 = 0x00000026U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004757ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004757ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004757AC;
    }
block_004757AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004757ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004757ACU);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_004757B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004757B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004757B8U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004757C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004757C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004757C0;
    }
block_004757C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004757C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004757C0U);
        }
        {
            const uint32_t updatedAddress = 0x004757C8U + 0x4CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004757C0U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004757D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004757D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004757D0;
    }
block_004757D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004757D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004757D0U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004757DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004757DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004757DC;
    }
block_004757DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004757DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004757DCU);
        }
        {
        }
        {
        }
        goto block_004750B8;
    }
block_004757E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004757E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004757E8U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004757F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004757F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004757F0;
    }
block_004757F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004757F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004757F0U);
        }
        {
            r0 = 0x00000006U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004757FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004757FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004757FC;
    }
block_004757FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004757FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004757FCU);
        }
        {
            const uint32_t updatedAddress = 0x00475804U - 0xA00U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004757FCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x53U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475800U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475808U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00484ba4_00484BA4(frame, context, state, 0x00484BA4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475808U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475808;
    }
block_00475808:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475808U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475808U);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475814U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f400_0033F400(frame, context, state, 0x0033F400U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475814U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475814;
    }
block_00475814:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475814U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475814U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475814U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00475818U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x0047581CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475824U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f2d8_0033F2D8(frame, context, state, 0x0033F2D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475824U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475824;
    }
block_00475824:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475824U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475824U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = 0x0000000EU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475830U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f248_0033F248(frame, context, state, 0x0033F248U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475830U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475830;
    }
block_00475830:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475830U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475830U);
        }
        {
            r1 = 0x0000002AU;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0047583CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0047583CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0047583C;
    }
block_0047583C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047583CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047583CU);
        }
        {
            r0 = 0x00000003U;
        }
        {
        }
        goto block_00475AA8;
    }
block_00475848:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475848U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475848U);
        }
        {
            const uint32_t updatedAddress = 0x00475850U - 0xA40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475848U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x00475854U - 0xA40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047584CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00475858U + 0x440U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475850U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00475858U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475868U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475868U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475868;
    }
block_00475868:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475868U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475868U);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475874U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f400_0033F400(frame, context, state, 0x0033F400U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475874U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475874;
    }
block_00475874:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475874U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475874U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475874U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475878U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_004758AC; }
        goto block_00475884;
    }
block_00475884:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475884U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475884U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475884U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r2 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r3, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_004758AC; }
        goto block_00475894;
    }
block_00475894:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475894U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475894U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475894U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r2 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004758A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d038c_002D038C(frame, context, state, 0x002D038CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004758A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004758A0;
    }
block_004758A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004758A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004758A0U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004758A0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004758A8U, address);
            }
        }
        goto block_004758AC;
    }
block_004758AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004758ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004758ACU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004758ACU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00474EEC; }
        goto block_004758B8;
    }
block_004758B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004758B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004758B8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004758B8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004758BCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00475C68; }
        goto block_004758C8;
    }
block_004758C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004758C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004758C8U);
        }
        {
            const uint32_t updatedAddress = 0x004758D0U - 0xAC0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004758C8U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x004758D4U - 0xAC0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004758CCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1F0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004758D0U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x004758D8U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r2 = 0x00000004U;
        }
        if (!(flags.Z())) { goto block_0047590C; }
        goto block_004758EC;
    }
block_004758EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004758ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004758ECU);
        }
        {
            const uint32_t updatedAddress = 0x004758F4U + 0x3A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004758ECU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004758F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004758F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004758F4;
    }
block_004758F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004758F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004758F4U);
        }
        {
            r1 = 0x0000002BU;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475900U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475900U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475900;
    }
block_00475900:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475900U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475900U);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_0047590C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047590CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047590CU);
        }
        {
            const uint32_t updatedAddress = 0x00475914U + 0x38CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0047590CU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475914U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475914U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475914;
    }
block_00475914:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475914U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475914U);
        }
        {
            r1 = 0x0000002DU;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475920U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475920U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475920;
    }
block_00475920:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475920U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475920U);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_0047592C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047592CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047592CU);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475934U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f400_0033F400(frame, context, state, 0x0033F400U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475934U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475934;
    }
block_00475934:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475934U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475934U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475934U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475938U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00475C68; }
        goto block_00475944;
    }
block_00475944:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475944U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475944U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475944U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r2 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r3, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00475C68; }
        goto block_00475954;
    }
block_00475954:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475954U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475954U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475954U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r2 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475960U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d038c_002D038C(frame, context, state, 0x002D038CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475960U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475960;
    }
block_00475960:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475960U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475960U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475960U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475968U, address);
            }
        }
        goto block_00475C68;
    }
block_00475970:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475970U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475970U);
        }
        {
            const uint32_t updatedAddress = 0x00475978U - 0xB68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475970U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0047597CU - 0xB68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475974U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00475980U + 0x318U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475978U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00475980U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475990U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475990U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475990;
    }
block_00475990:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475990U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475990U);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0047599CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003371d8_003371D8(frame, context, state, 0x003371D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0047599CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0047599C;
    }
block_0047599C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0047599CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0047599CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0047599CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004759A0U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_004759D4; }
        goto block_004759AC;
    }
block_004759AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004759ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004759ACU);
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004759ACU, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r2 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r3, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_004759D4; }
        goto block_004759BC;
    }
block_004759BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004759BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004759BCU);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004759BCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r2 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004759C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d038c_002D038C(frame, context, state, 0x002D038CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004759C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004759C8;
    }
block_004759C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004759C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004759C8U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004759C8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x004759D0U, address);
            }
        }
        goto block_004759D4;
    }
block_004759D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004759D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004759D4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004759D4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x004759D8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00475A34; }
        goto block_004759E4;
    }
block_004759E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004759E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004759E4U);
        }
        {
            const uint32_t operand = 0x00000014U;
            r6 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x004759ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_GetDisplayClass_0043C20C(frame, context, state, 0x0043C20CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x004759ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_004759EC;
    }
block_004759EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004759ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004759ECU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_00475A68; }
        goto block_004759F8;
    }
block_004759F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x004759F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x004759F8U);
        }
        {
            r1 = 0x00000005U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475A04U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475A04U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475A04;
    }
block_00475A04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475A04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475A04U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        {
        }
        if (flags.Z()) { goto block_00475A68; }
        goto block_00475A10;
    }
block_00475A10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475A10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475A10U);
        }
        {
            const uint32_t updatedAddress = 0x00475A18U - 0xBF4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475A10U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475A14U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475A18U, address);
            }
            r1 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r8 + 0x16U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475A20U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = 0x00000001U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00475A68; }
        goto block_00475A34;
    }
block_00475A34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475A34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475A34U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475A3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475A3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475A3C;
    }
block_00475A3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475A3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475A3CU);
        }
        {
            const uint32_t updatedAddress = 0x00475A44U - 0xC34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475A3CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x00475A48U - 0xC34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475A40U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00475A4CU - 0xC34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475A44U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00475A4CU, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475A5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475A5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475A5C;
    }
block_00475A5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475A5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475A5CU);
        }
        {
            r0 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475A60U, address);
            }
        }
        goto block_0047509C;
    }
block_00475A68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475A68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475A68U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475A68U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475A6CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00475C68; }
        goto block_00475A78;
    }
block_00475A78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475A78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475A78U);
        }
        {
            const uint32_t updatedAddress = 0x00475A80U - 0xC70U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475A78U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x00475A84U - 0xC70U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475A7CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00475A88U + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475A80U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00475A88U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475A98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475A98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475A98;
    }
block_00475A98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475A98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475A98U);
        }
        {
            r1 = 0x0000002FU;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475AA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475AA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475AA4;
    }
block_00475AA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475AA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475AA4U);
        }
        {
            r0 = 0x0000002DU;
        }
        goto block_00475AA8;
    }
block_00475AA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475AA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475AA8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475AA8U, address);
            }
        }
        goto block_00475C68;
    }
block_00475AB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475AB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475AB0U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475AB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003371d8_003371D8(frame, context, state, 0x003371D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475AB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475AB8;
    }
block_00475AB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475AB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475AB8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475AB8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475ABCU, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_00475AF0; }
        goto block_00475AC8;
    }
block_00475AC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475AC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475AC8U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475AC8U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r2 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r3, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00475AF0; }
        goto block_00475AD8;
    }
block_00475AD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475AD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475AD8U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475AD8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r2 - operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475AE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002d038c_002D038C(frame, context, state, 0x002D038CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475AE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475AE4;
    }
block_00475AE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475AE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475AE4U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475AE4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475AECU, address);
            }
        }
        goto block_00475AF0;
    }
block_00475AF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475AF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475AF0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475AF0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 - operand;
        }
        {
            r0 = r0 & 0x000000FFU;
            Oot3dAotSetLogicalFlags(flags, r0, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x2D3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475AFCU, address);
            }
        }
        if (!(flags.Z())) { goto block_00475C68; }
        goto block_00475B04;
    }
block_00475B04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475B04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475B04U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475B08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00484cb8_00484CB8(frame, context, state, 0x00484CB8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475B08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475B08;
    }
block_00475B08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475B08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475B08U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x00475B14U - 0xD18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475B0CU, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            r0 = 0x0000000FU;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475B14U, address);
            }
        }
        if (flags.Z()) { goto block_00475C68; }
        goto block_00475B1C;
    }
block_00475B1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475B1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475B1CU);
        }
        {
            const uint32_t updatedAddress = 0x00475B24U - 0xD14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475B1CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x00475B28U - 0xD14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475B20U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00475B2CU + 0x170U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475B24U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00475B2CU, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475B3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475B3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475B3C;
    }
block_00475B3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475B3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475B3CU);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475B48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003371d8_003371D8(frame, context, state, 0x003371D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475B48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475B48;
    }
block_00475B48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475B48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475B48U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475B48U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00475B4CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00475B50U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475B58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f2d8_0033F2D8(frame, context, state, 0x0033F2D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475B58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475B58;
    }
block_00475B58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475B58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475B58U);
        }
        {
            r1 = 0x00000030U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475B64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475B64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475B64;
    }
block_00475B64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475B64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475B64U);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_00475B70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475B70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475B70U);
        }
        {
            const uint32_t updatedAddress = 0x00475B78U + 0x124U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475B70U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475B78U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_004896f4_004896F4(frame, context, state, 0x004896F4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475B78U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475B78;
    }
block_00475B78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475B78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475B78U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_00475C68; }
        goto block_00475B84;
    }
block_00475B84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475B84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475B84U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475B88U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f400_0033F400(frame, context, state, 0x0033F400U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475B88U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475B88;
    }
block_00475B88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475B88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475B88U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475B88U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00475B8CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00475B90U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475B98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f2d8_0033F2D8(frame, context, state, 0x0033F2D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475B98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475B98;
    }
block_00475B98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475B98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475B98U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = 0x0000000EU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475BA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f248_0033F248(frame, context, state, 0x0033F248U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475BA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475BA4;
    }
block_00475BA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475BA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475BA4U);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_00475BB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475BB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475BB0U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475BB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AudioOcarina_SetInstrument_003523DC(frame, context, state, 0x003523DCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475BB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475BB8;
    }
block_00475BB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475BB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475BB8U);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475BC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003371d8_003371D8(frame, context, state, 0x003371D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475BC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475BC4;
    }
block_00475BC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475BC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475BC4U);
        }
        {
            const uint32_t updatedAddress = 0x00475BCCU - 0xDD0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475BC4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475BC8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00475BCCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00475BD0U, address);
            }
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475BD8U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475BE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f2d8_0033F2D8(frame, context, state, 0x0033F2D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475BE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475BE0;
    }
block_00475BE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475BE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475BE0U);
        }
        {
            const uint32_t updatedAddress = r10 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475BE0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000C000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<uint16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475BF0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033704c_0033704C(frame, context, state, 0x0033704CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475BF0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475BF0;
    }
block_00475BF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475BF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475BF0U);
        }
        {
            r1 = 0x00000032U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475BFCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475BFCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475BFC;
    }
block_00475BFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475BFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475BFCU);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_00475C08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475C08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475C08U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475C10U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003371d8_003371D8(frame, context, state, 0x003371D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475C10U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475C10;
    }
block_00475C10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475C10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475C10U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475C10U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475C14U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00475C68; }
        goto block_00475C20;
    }
block_00475C20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475C20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475C20U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475C20U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r1 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00475C68; }
        goto block_00475C30;
    }
block_00475C30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475C30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475C30U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475C30U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x300U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475C34U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00475C38U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00475C3CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00475C40U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475C48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0033f2d8_0033F2D8(frame, context, state, 0x0033F2D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475C48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475C48;
    }
block_00475C48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475C48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475C48U);
        }
        {
            r1 = 0x00000033U;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00475C54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_SetDisplayMode_00340BDC(frame, context, state, 0x00340BDCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00475C54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00475C54;
    }
block_00475C54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475C54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475C54U);
        }
        {
        }
        {
        }
        goto block_00475C68;
    }
block_00475C60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475C60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475C60U);
        }
        {
            r0 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x300U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00475C64U, address);
            }
        }
        goto block_00475C68;
    }
block_00475C68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475C68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475C68U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00475C68U, address);
            }
        }
        goto block_00475C6C;
    }
block_00475C6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00475C6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00475C6CU);
        }
        {
            const uint32_t operand = 0x00000064U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00475C70U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00475C70U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00475C70U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00475C70U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00475C70U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00475C70U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00475C70U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00475C70U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00475C70U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

} // namespace Oot3dNativeGame::GeneratedWholeAot
