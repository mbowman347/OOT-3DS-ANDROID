# Translated title sources

This archive contains game-derived translated logic, not game assets.
Use the paired title-build source archive for the ABI, support library,
plugin wrapper and build scripts, and the release source for the current runtime.
See docs/TRIAEVUM_PRECOMPILED_RELEASE.md for developer rebuild instructions.
Original game rights are not relicensed by the TriAevum project license.
