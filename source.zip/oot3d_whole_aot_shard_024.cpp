#include "oot3d_whole_aot_generated_internal.h"
#include "oot3d_native_a32_memory.h"

#include <atomic>

namespace Oot3dNativeGame::GeneratedWholeAot {
namespace a32 = oot3d::recomp::a32;

Oot3dWholeAotFlow Execute_NameEntry_UpdateTouchSelection_002E83EC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseTouchButtons_UpdateActionGridGeometry_002EEF74(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseTouchButtons_ResolveActionStates_002EF2C0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseTouchButtons_AnimatePageTransition_002EF684(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_kaleido_draw_ui_overlay_split_002ef9b4_002EF9B4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_kaleido_draw_ui_overlay_split_002efd88_002EFD88(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseTouchButtons_SetContextIcon_002EFEA0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseTouchButtons_ResolveContextState_002EFFF8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseTouchButtons_GetContextMode_002F008C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseTouchButtons_TogglePrimaryRestriction_002F009C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseTouchButtons_HasAuxiliaryAction_002F00F4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseGearPage_ApplyTransitionMode_002F0444(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseRenderGroup_DrawPositionTexColor_002F0C84(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseRenderGroup_DrawAnimatedMask_002F0E08(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_002f43d8_002F43D8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_002f43e8_002F43E8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseInput_GetHeldButtons_002F5CC4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseIconGroup_Refresh_002F8160(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseUi_ResetInteractionState_002F8708(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseGearPage_SetMode_002F8A34(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseRenderBuffer_SetQuadAlphaRange_002F8B80(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseRenderBuffer_SetVec2Range_002F9430(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseInput_ReadTouch_002F9484(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseQuadGroup_UpdateAndSubmit_002F94A8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseRenderBuffer_SetQuadTexcoords_002FC40C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseCounter_UpdateDigitGeometry_002FCB04(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseCounter_UpdateDigitPositions_002FCC88(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseInput_SetTouchEnabled_002FD84C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_003016e0_003016E0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Input_GetPressedButtonMask_0033B5EC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Play_IsGameplayActive_0033BD6C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseInventory_SyncAndRefresh_0033C25C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_TouchInput_IsRectActive_0033F428(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseRenderBuffer_ClearOffsets_00343270(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Player_ResetMeleeWeaponState_0034BBFC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00351878_00351878(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_get_flag_1710_mask_10_003518CC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Player_HoldsHookshot_00355A60(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0035b164_0035B164(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Player_SetupAction_0036055C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_RendererGlobalState_Init_0036788C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_StaticInitGuard_TryAcquire_003679B4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_GetCamera_0036C5BC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Flags_GetSwitch_0036E864(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00374be8_00374BE8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_InCsMode_0037577C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseTouchButtons_Update_0042DF3C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseTouchButtons_UpdateMessageGeometry_00439134(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseSystemMenu_Open_0043ACA8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseWorldMap_ResetToDestinationMode_0043BDE4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseWorldMap_ResetSelection_0043C038(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseTouchButtons_GetRestrictionMask_00441678(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseTouchButtons_RefreshIconLayout_004439C4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseTouchButtons_UpdateHealthMeterGeometry_0044425C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseTouchButtons_RefreshActionSet_00444564(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseTouchButtons_UpdateHoldProgressGeometry_0044483C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseTouchButtons_RefreshItemAvailability_00444AB0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_PauseTouchButtons_RefreshPrimaryActionIcon_00444D00(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);

Oot3dWholeAotFlow Execute_NameEntry_UpdateTouchSelection_002E83EC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x002E83ECU:
        goto block_002E83EC;
    case 0x002E8404U:
        goto block_002E8404;
    case 0x002E8428U:
        goto block_002E8428;
    case 0x002E8434U:
        goto block_002E8434;
    case 0x002E8450U:
        goto block_002E8450;
    case 0x002E845CU:
        goto block_002E845C;
    case 0x002E846CU:
        goto block_002E846C;
    case 0x002E8488U:
        goto block_002E8488;
    case 0x002E8494U:
        goto block_002E8494;
    case 0x002E84A4U:
        goto block_002E84A4;
    case 0x002E84B8U:
        goto block_002E84B8;
    case 0x002E84D4U:
        goto block_002E84D4;
    case 0x002E84E8U:
        goto block_002E84E8;
    case 0x002E8504U:
        goto block_002E8504;
    case 0x002E8510U:
        goto block_002E8510;
    case 0x002E854CU:
        goto block_002E854C;
    case 0x002E8554U:
        goto block_002E8554;
    case 0x002E8570U:
        goto block_002E8570;
    case 0x002E8580U:
        goto block_002E8580;
    case 0x002E859CU:
        goto block_002E859C;
    case 0x002E85A8U:
        goto block_002E85A8;
    case 0x002E85B8U:
        goto block_002E85B8;
    case 0x002E85C4U:
        goto block_002E85C4;
    case 0x002E85E0U:
        goto block_002E85E0;
    case 0x002E85ECU:
        goto block_002E85EC;
    case 0x002E8608U:
        goto block_002E8608;
    case 0x002E8614U:
        goto block_002E8614;
    case 0x002E8618U:
        goto block_002E8618;
    case 0x002E8624U:
        goto block_002E8624;
    case 0x002E862CU:
        goto block_002E862C;
    case 0x002E864CU:
        goto block_002E864C;
    case 0x002E8654U:
        goto block_002E8654;
    case 0x002E8664U:
        goto block_002E8664;
    case 0x002E8668U:
        goto block_002E8668;
    case 0x002E8670U:
        goto block_002E8670;
    case 0x002E8680U:
        goto block_002E8680;
    case 0x002E869CU:
        goto block_002E869C;
    case 0x002E86A8U:
        goto block_002E86A8;
    case 0x002E86D0U:
        goto block_002E86D0;
    case 0x002E86ECU:
        goto block_002E86EC;
    case 0x002E86F8U:
        goto block_002E86F8;
    case 0x002E8720U:
        goto block_002E8720;
    case 0x002E873CU:
        goto block_002E873C;
    case 0x002E8748U:
        goto block_002E8748;
    case 0x002E8774U:
        goto block_002E8774;
    case 0x002E8790U:
        goto block_002E8790;
    case 0x002E879CU:
        goto block_002E879C;
    case 0x002E87C4U:
        goto block_002E87C4;
    case 0x002E87E0U:
        goto block_002E87E0;
    case 0x002E87ECU:
        goto block_002E87EC;
    case 0x002E8804U:
        goto block_002E8804;
    case 0x002E8820U:
        goto block_002E8820;
    case 0x002E882CU:
        goto block_002E882C;
    case 0x002E8844U:
        goto block_002E8844;
    case 0x002E8860U:
        goto block_002E8860;
    case 0x002E886CU:
        goto block_002E886C;
    case 0x002E8884U:
        goto block_002E8884;
    case 0x002E88A0U:
        goto block_002E88A0;
    case 0x002E88ACU:
        goto block_002E88AC;
    case 0x002E88C0U:
        goto block_002E88C0;
    case 0x002E88DCU:
        goto block_002E88DC;
    case 0x002E88E8U:
        goto block_002E88E8;
    case 0x002E88FCU:
        goto block_002E88FC;
    case 0x002E8918U:
        goto block_002E8918;
    case 0x002E8924U:
        goto block_002E8924;
    case 0x002E8940U:
        goto block_002E8940;
    case 0x002E895CU:
        goto block_002E895C;
    case 0x002E8968U:
        goto block_002E8968;
    case 0x002E897CU:
        goto block_002E897C;
    case 0x002E8998U:
        goto block_002E8998;
    case 0x002E89A4U:
        goto block_002E89A4;
    case 0x002E89B8U:
        goto block_002E89B8;
    case 0x002E89C0U:
        goto block_002E89C0;
    case 0x002E89DCU:
        goto block_002E89DC;
    case 0x002E89ECU:
        goto block_002E89EC;
    case 0x002E8A08U:
        goto block_002E8A08;
    case 0x002E8A14U:
        goto block_002E8A14;
    case 0x002E8A30U:
        goto block_002E8A30;
    case 0x002E8A4CU:
        goto block_002E8A4C;
    case 0x002E8A80U:
        goto block_002E8A80;
    case 0x002E8A9CU:
        goto block_002E8A9C;
    case 0x002E8AA8U:
        goto block_002E8AA8;
    case 0x002E8AF8U:
        goto block_002E8AF8;
    case 0x002E8B14U:
        goto block_002E8B14;
    case 0x002E8B20U:
        goto block_002E8B20;
    case 0x002E8B38U:
        goto block_002E8B38;
    case 0x002E8B54U:
        goto block_002E8B54;
    case 0x002E8B60U:
        goto block_002E8B60;
    case 0x002E8B78U:
        goto block_002E8B78;
    case 0x002E8B80U:
        goto block_002E8B80;
    case 0x002E8B9CU:
        goto block_002E8B9C;
    case 0x002E8BC4U:
        goto block_002E8BC4;
    case 0x002E8BD4U:
        goto block_002E8BD4;
    case 0x002E8BDCU:
        goto block_002E8BDC;
    case 0x002E8BF8U:
        goto block_002E8BF8;
    case 0x002E8C04U:
        goto block_002E8C04;
    case 0x002E8C10U:
        goto block_002E8C10;
    case 0x002E8C2CU:
        goto block_002E8C2C;
    case 0x002E8C38U:
        goto block_002E8C38;
    case 0x002E8C44U:
        goto block_002E8C44;
    case 0x002E8C54U:
        goto block_002E8C54;
    case 0x002E8C70U:
        goto block_002E8C70;
    case 0x002E8C7CU:
        goto block_002E8C7C;
    case 0x002E8C88U:
        goto block_002E8C88;
    case 0x002E8C90U:
        goto block_002E8C90;
    case 0x002E8CACU:
        goto block_002E8CAC;
    case 0x002E8CB8U:
        goto block_002E8CB8;
    case 0x002E8CF4U:
        goto block_002E8CF4;
    case 0x002E8CF8U:
        goto block_002E8CF8;
    case 0x002E8D14U:
        goto block_002E8D14;
    case 0x002E8D20U:
        goto block_002E8D20;
    case 0x002E8D5CU:
        goto block_002E8D5C;
    case 0x002E8D60U:
        goto block_002E8D60;
    case 0x002E8D7CU:
        goto block_002E8D7C;
    case 0x002E8D88U:
        goto block_002E8D88;
    case 0x002E8D9CU:
        goto block_002E8D9C;
    case 0x002E8DA0U:
        goto block_002E8DA0;
    case 0x002E8DBCU:
        goto block_002E8DBC;
    case 0x002E8DC8U:
        goto block_002E8DC8;
    case 0x002E8DDCU:
        goto block_002E8DDC;
    case 0x002E8DE0U:
        goto block_002E8DE0;
    case 0x002E8DFCU:
        goto block_002E8DFC;
    case 0x002E8E08U:
        goto block_002E8E08;
    case 0x002E8E1CU:
        goto block_002E8E1C;
    case 0x002E8E20U:
        goto block_002E8E20;
    case 0x002E8E2CU:
        goto block_002E8E2C;
    case 0x002E8E38U:
        goto block_002E8E38;
    case 0x002E8E40U:
        goto block_002E8E40;
    case 0x002E8E60U:
        goto block_002E8E60;
    case 0x002E8E68U:
        goto block_002E8E68;
    case 0x002E8E74U:
        goto block_002E8E74;
    case 0x002E8E80U:
        goto block_002E8E80;
    case 0x002E8E84U:
        goto block_002E8E84;
    case 0x002E8E8CU:
        goto block_002E8E8C;
    case 0x002E8E98U:
        goto block_002E8E98;
    case 0x002E8EA4U:
        goto block_002E8EA4;
    case 0x002E8EC0U:
        goto block_002E8EC0;
    case 0x002E8ECCU:
        goto block_002E8ECC;
    case 0x002E8EECU:
        goto block_002E8EEC;
    case 0x002E8EF0U:
        goto block_002E8EF0;
    case 0x002E8F0CU:
        goto block_002E8F0C;
    case 0x002E8F18U:
        goto block_002E8F18;
    case 0x002E8F38U:
        goto block_002E8F38;
    case 0x002E8F3CU:
        goto block_002E8F3C;
    case 0x002E8F58U:
        goto block_002E8F58;
    case 0x002E8F64U:
        goto block_002E8F64;
    case 0x002E8F84U:
        goto block_002E8F84;
    case 0x002E8F88U:
        goto block_002E8F88;
    case 0x002E8FA4U:
        goto block_002E8FA4;
    case 0x002E8FB0U:
        goto block_002E8FB0;
    case 0x002E8FD0U:
        goto block_002E8FD0;
    case 0x002E8FD4U:
        goto block_002E8FD4;
    case 0x002E8FF0U:
        goto block_002E8FF0;
    case 0x002E8FFCU:
        goto block_002E8FFC;
    case 0x002E9010U:
        goto block_002E9010;
    case 0x002E9014U:
        goto block_002E9014;
    case 0x002E9030U:
        goto block_002E9030;
    case 0x002E903CU:
        goto block_002E903C;
    case 0x002E9050U:
        goto block_002E9050;
    case 0x002E9054U:
        goto block_002E9054;
    case 0x002E9070U:
        goto block_002E9070;
    case 0x002E907CU:
        goto block_002E907C;
    case 0x002E9090U:
        goto block_002E9090;
    case 0x002E9094U:
        goto block_002E9094;
    case 0x002E90B0U:
        goto block_002E90B0;
    case 0x002E90BCU:
        goto block_002E90BC;
    case 0x002E90D0U:
        goto block_002E90D0;
    case 0x002E90D4U:
        goto block_002E90D4;
    case 0x002E90F0U:
        goto block_002E90F0;
    case 0x002E90FCU:
        goto block_002E90FC;
    case 0x002E9110U:
        goto block_002E9110;
    case 0x002E9114U:
        goto block_002E9114;
    case 0x002E9130U:
        goto block_002E9130;
    case 0x002E913CU:
        goto block_002E913C;
    case 0x002E9150U:
        goto block_002E9150;
    case 0x002E9154U:
        goto block_002E9154;
    case 0x002E9170U:
        goto block_002E9170;
    case 0x002E917CU:
        goto block_002E917C;
    case 0x002E9190U:
        goto block_002E9190;
    case 0x002E9194U:
        goto block_002E9194;
    case 0x002E91B0U:
        goto block_002E91B0;
    case 0x002E91BCU:
        goto block_002E91BC;
    case 0x002E91D0U:
        goto block_002E91D0;
    case 0x002E91D4U:
        goto block_002E91D4;
    case 0x002E91E0U:
        goto block_002E91E0;
    case 0x002E91E8U:
        goto block_002E91E8;
    case 0x002E91F0U:
        goto block_002E91F0;
    case 0x002E920CU:
        goto block_002E920C;
    case 0x002E9218U:
        goto block_002E9218;
    case 0x002E9224U:
        goto block_002E9224;
    case 0x002E922CU:
        goto block_002E922C;
    case 0x002E9248U:
        goto block_002E9248;
    case 0x002E9254U:
        goto block_002E9254;
    case 0x002E9290U:
        goto block_002E9290;
    case 0x002E9294U:
        goto block_002E9294;
    case 0x002E92B0U:
        goto block_002E92B0;
    case 0x002E92BCU:
        goto block_002E92BC;
    case 0x002E92F8U:
        goto block_002E92F8;
    case 0x002E9304U:
        goto block_002E9304;
    case 0x002E9320U:
        goto block_002E9320;
    case 0x002E932CU:
        goto block_002E932C;
    case 0x002E9340U:
        goto block_002E9340;
    case 0x002E9344U:
        goto block_002E9344;
    case 0x002E9360U:
        goto block_002E9360;
    case 0x002E936CU:
        goto block_002E936C;
    case 0x002E9380U:
        goto block_002E9380;
    case 0x002E9384U:
        goto block_002E9384;
    case 0x002E93A0U:
        goto block_002E93A0;
    case 0x002E93ACU:
        goto block_002E93AC;
    case 0x002E93C0U:
        goto block_002E93C0;
    case 0x002E93C4U:
        goto block_002E93C4;
    case 0x002E93D0U:
        goto block_002E93D0;
    case 0x002E93D8U:
        goto block_002E93D8;
    case 0x002E93E0U:
        goto block_002E93E0;
    case 0x002E93FCU:
        goto block_002E93FC;
    case 0x002E9408U:
        goto block_002E9408;
    case 0x002E9414U:
        goto block_002E9414;
    case 0x002E9418U:
        goto block_002E9418;
    case 0x002E9434U:
        goto block_002E9434;
    case 0x002E9440U:
        goto block_002E9440;
    case 0x002E944CU:
        goto block_002E944C;
    case 0x002E9458U:
        goto block_002E9458;
    case 0x002E9464U:
        goto block_002E9464;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_002E83EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E83ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E83ECU);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x002E83ECU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x002E83ECU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x002E83ECU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x002E83ECU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x002E83ECU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x002E83ECU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x002E83ECU,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x002E83ECU,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x002E83ECU,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 - operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8404U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseInput_ReadTouch_002F9484(frame, context, state, 0x002F9484U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8404U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8404;
    }
block_002E8404:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8404U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8404U);
        }
        {
            const uint32_t updatedAddress = 0x002E840CU + 0xEF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8404U, address);
            }
            r7 = value;
        }
        {
            const uint32_t updatedAddress = 0x002E8410U + 0xEF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8408U, address);
            }
            r6 = value;
        }
        {
            r8 = ~(0x00000000U);
        }
        {
            r4 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8414U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000124U;
            r11 = r8 + operand;
        }
        {
            Oot3dAotSetAddFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r7 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8420U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) { goto block_002E8BD4; }
        goto block_002E8428;
    }
block_002E8428:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8428U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8428U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r5 = 0x00000000U;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_002E84A4; }
        goto block_002E8434;
    }
block_002E8434:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8434U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8434U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8438U, address);
            }
        }
        {
            r3 = 0x00000020U;
        }
        {
            r2 = 0x00000060U;
        }
        {
            r1 = 0x000000CCU;
        }
        {
            r0 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8450U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8450U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8450;
    }
block_002E8450:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8450U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8450U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r9 = 0x00000005U;
        }
        if (flags.Z()) { goto block_002E846C; }
        goto block_002E845C;
    }
block_002E845C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E845CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E845CU);
        }
        {
            r0 = ~(0x00000009U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E8460U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x002E8464U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x002E8468U, address);
            }
        }
        goto block_002E846C;
    }
block_002E846C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E846CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E846CU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8470U, address);
            }
        }
        {
            r3 = 0x00000020U;
        }
        {
            r2 = 0x00000060U;
        }
        {
            r1 = 0x000000CCU;
        }
        {
            r0 = 0x000000DCU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8488U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8488U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8488;
    }
block_002E8488:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8488U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8488U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (flags.Z()) { goto block_002E84A4; }
        goto block_002E8494;
    }
block_002E8494:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8494U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8494U);
        }
        {
            r0 = ~(0x0000000AU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E8498U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x002E849CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x002E84A0U, address);
            }
        }
        goto block_002E84A4;
    }
block_002E84A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E84A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E84A4U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E84A4U, address);
            }
            r0 = value;
        }
        {
            r9 = 0x0000000AU;
        }
        {
            r10 = 0x00000003U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_002E8624; }
        goto block_002E84B8;
    }
block_002E84B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E84B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E84B8U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E84BCU, address);
            }
        }
        {
            r3 = 0x00000018U;
        }
        {
            r2 = 0x00000080U;
        }
        {
            r1 = 0x00000028U;
        }
        {
            r0 = 0x000000A1U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E84D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E84D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E84D4;
    }
block_002E84D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E84D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E84D4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x002E84D8U, address);
            }
            r7 = updatedAddress;
        }
        if (!(flags.Z())) {
            r0 = ~(0x00000001U);
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r7 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E84E0U, address);
            }
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E84E8;
    }
block_002E84E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E84E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E84E8U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E84ECU, address);
            }
        }
        {
            r3 = 0x0000007FU;
        }
        {
            const uint32_t operand = 0x00000082U;
            r2 = r3 + operand;
        }
        {
            r1 = 0x00000042U;
        }
        {
            r0 = 0x0000001FU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8504U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8504U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8504;
    }
block_002E8504:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8504U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8504U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E8554; }
        goto block_002E8510;
    }
block_002E8510:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8510U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8510U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8510U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000001FU;
            r0 = r0 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r1 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r1 = Oot3dAotAsr(r0, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E8524U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E8528U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E852CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000042U;
            r0 = r0 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r1 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r1 = Oot3dAotAsr(r0, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E8540U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E8544U, address);
            }
            r7 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r7 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x002E8548U, address);
            }
        }
        goto block_002E854C;
    }
block_002E854C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E854CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E854CU);
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002E8550U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002E8550U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002E8550U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002E8550U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002E8550U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002E8550U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002E8550U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002E8550U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002E8550U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_002E8554:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8554U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8554U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8558U, address);
            }
        }
        {
            r3 = 0x00000082U;
        }
        {
            r2 = 0x0000001AU;
        }
        {
            r1 = 0x00000042U;
        }
        {
            r0 = 0x00000009U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8570U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8570U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8570;
    }
block_002E8570:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8570U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8570U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8574U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000039U;
            r0 = r0 - operand;
        }
        if (!(flags.Z())) { goto block_002E8A4C; }
        goto block_002E8580;
    }
block_002E8580:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8580U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8580U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8584U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            r2 = r3;
        }
        {
            r1 = 0x00000042U;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E859CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E859CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E859C;
    }
block_002E859C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E859CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E859CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E85C4; }
        goto block_002E85A8;
    }
block_002E85A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E85A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E85A8U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x002E85A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x002E85ACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x002E85B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x002E85B4U, address);
            }
        }
        goto block_002E85B8;
    }
block_002E85B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E85B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E85B8U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x002E85B8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002E85C0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002E85C0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002E85C0U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002E85C0U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002E85C0U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002E85C0U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002E85C0U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002E85C0U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002E85C0U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_002E85C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E85C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E85C4U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E85C8U, address);
            }
        }
        {
            r3 = 0x00000032U;
        }
        {
            r2 = 0x00000018U;
        }
        {
            r1 = 0x0000005CU;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E85E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E85E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E85E0;
    }
block_002E85E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E85E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E85E0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_002E8B20; }
        goto block_002E85EC;
    }
block_002E85EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E85ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E85ECU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E85F0U, address);
            }
        }
        {
            r3 = 0x00000032U;
        }
        {
            r2 = 0x00000018U;
        }
        {
            r1 = 0x00000090U;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8608U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8608U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8608;
    }
block_002E8608:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8608U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8608U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E854C; }
        goto block_002E8614;
    }
block_002E8614:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8614U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8614U);
        }
        goto block_002E8B60;
    }
block_002E8618:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8618U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8618U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E8618U, address);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002E8620U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002E8620U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002E8620U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002E8620U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002E8620U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002E8620U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002E8620U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002E8620U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002E8620U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_002E8624:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8624U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8624U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_002E89B8; }
        goto block_002E862C;
    }
block_002E862C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E862CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E862CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E862CU, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8634U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r3 = 0x00000018U;
        }
        {
            r2 = 0x00000080U;
        }
        {
            r1 = 0x00000028U;
        }
        if (!(flags.Z())) { goto block_002E8668; }
        goto block_002E864C;
    }
block_002E864C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E864CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E864CU);
        }
        {
            r0 = 0x0000001FU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8654U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8654U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8654;
    }
block_002E8654:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8654U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8654U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r0 = ~(0x00000002U);
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x002E865CU, address);
            }
        }
        if (!(flags.Z())) { goto block_002E8618; }
        goto block_002E8664;
    }
block_002E8664:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8664U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8664U);
        }
        goto block_002E8680;
    }
block_002E8668:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8668U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8668U);
        }
        {
            r0 = 0x000000A1U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8670U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8670U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8670;
    }
block_002E8670:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8670U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8670U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r0 = ~(0x0000000BU);
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x002E8678U, address);
            }
        }
        if (!(flags.Z())) { goto block_002E8618; }
        goto block_002E8680;
    }
block_002E8680:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8680U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8680U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8684U, address);
            }
        }
        {
            r3 = 0x00000018U;
        }
        {
            r2 = 0x00000138U;
        }
        {
            r1 = 0x00000040U;
        }
        {
            r0 = 0x00000005U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E869CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E869CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E869C;
    }
block_002E869C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E869CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E869CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E86D0; }
        goto block_002E86A8;
    }
block_002E86A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E86A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E86A8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E86A8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000005U;
            r0 = r0 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r1 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r1 = Oot3dAotAsr(r0, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E86BCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E86C0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x002E86C4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x002E86C8U, address);
            }
        }
        goto block_002E85B8;
    }
block_002E86D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E86D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E86D0U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E86D4U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            const uint32_t operand = 0x000000E8U;
            r2 = r3 + operand;
        }
        {
            r1 = 0x0000005AU;
        }
        {
            r0 = 0x00000013U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E86ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E86ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E86EC;
    }
block_002E86EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E86ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E86ECU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E8720; }
        goto block_002E86F8;
    }
block_002E86F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E86F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E86F8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E86F8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000013U;
            r0 = r0 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r1 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r1 = Oot3dAotAsr(r0, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E870CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E8710U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x002E8714U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x002E8718U, address);
            }
        }
        goto block_002E85B8;
    }
block_002E8720:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8720U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8720U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8724U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            r2 = 0x000000E8U;
        }
        {
            r1 = 0x00000074U;
        }
        {
            r0 = 0x0000001FU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E873CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E873CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E873C;
    }
block_002E873C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E873CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E873CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E8774; }
        goto block_002E8748;
    }
block_002E8748:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8748U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8748U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8748U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000001FU;
            r0 = r0 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r1 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r1 = Oot3dAotAsr(r0, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E875CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E8760U, address);
            }
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E8768U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E876CU, address);
            }
        }
        goto block_002E85B8;
    }
block_002E8774:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8774U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8774U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8778U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            const uint32_t operand = 0x000000E8U;
            r2 = r3 + operand;
        }
        {
            r1 = 0x0000008EU;
        }
        {
            r0 = 0x0000002BU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8790U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8790U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8790;
    }
block_002E8790:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8790U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8790U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E87C4; }
        goto block_002E879C;
    }
block_002E879C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E879CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E879CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E879CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000002BU;
            r0 = r0 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r1 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r1 = Oot3dAotAsr(r0, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E87B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E87B4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002E87B8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002E87BCU, address);
            }
        }
        goto block_002E85B8;
    }
block_002E87C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E87C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E87C4U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E87C8U, address);
            }
        }
        {
            r3 = 0x00000034U;
        }
        {
            r2 = 0x00000018U;
        }
        {
            r1 = 0x0000005CU;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E87E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E87E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E87E0;
    }
block_002E87E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E87E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E87E0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E8804; }
        goto block_002E87EC;
    }
block_002E87EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E87ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E87ECU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x002E87ECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x002E87F0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x002E87F4U, address);
            }
        }
        {
            r0 = ~(0x00000005U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x002E87FCU, address);
            }
        }
        goto block_002E8618;
    }
block_002E8804:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8804U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8804U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8808U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            r2 = 0x00000018U;
        }
        {
            r1 = 0x00000074U;
        }
        {
            r0 = 0x00000005U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8820U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8820U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8820;
    }
block_002E8820:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8820U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8820U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E8844; }
        goto block_002E882C;
    }
block_002E882C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E882CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E882CU);
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x002E8830U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E8834U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x002E8838U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E883CU, address);
            }
        }
        goto block_002E85B8;
    }
block_002E8844:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8844U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8844U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8848U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            r2 = r3;
        }
        {
            r1 = 0x0000008CU;
        }
        {
            r0 = 0x00000002U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8860U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8860U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8860;
    }
block_002E8860:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8860U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8860U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E8884; }
        goto block_002E886C;
    }
block_002E886C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E886CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E886CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x002E886CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x002E8870U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002E8874U, address);
            }
        }
        {
            r0 = ~(0x00000004U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002E887CU, address);
            }
        }
        goto block_002E8618;
    }
block_002E8884:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8884U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8884U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8888U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            r2 = 0x00000018U;
        }
        {
            r1 = 0x000000A8U;
        }
        {
            r0 = 0x00000039U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E88A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E88A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E88A0;
    }
block_002E88A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E88A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E88A0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r6 = 0x00000004U;
        }
        if (flags.Z()) { goto block_002E88C0; }
        goto block_002E88AC;
    }
block_002E88AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E88ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E88ACU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x002E88ACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x002E88B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x002E88B4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x002E88B8U, address);
            }
        }
        goto block_002E85B8;
    }
block_002E88C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E88C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E88C0U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E88C4U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            r2 = 0x00000018U;
        }
        {
            r1 = 0x000000A8U;
        }
        {
            r0 = 0x00000053U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E88DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E88DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E88DC;
    }
block_002E88DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E88DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E88DCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E88FC; }
        goto block_002E88E8;
    }
block_002E88E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E88E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E88E8U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x002E88E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x002E88ECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x002E88F0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x002E88F4U, address);
            }
        }
        goto block_002E85B8;
    }
block_002E88FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E88FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E88FCU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8900U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            r2 = 0x0000007EU;
        }
        {
            r1 = 0x000000A8U;
        }
        {
            r0 = 0x0000006BU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8918U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8918U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8918;
    }
block_002E8918:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8918U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8918U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E8940; }
        goto block_002E8924;
    }
block_002E8924:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8924U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8924U);
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E8928U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E892CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x002E8930U, address);
            }
        }
        {
            r0 = ~(0x00000006U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x002E8938U, address);
            }
        }
        goto block_002E8618;
    }
block_002E8940:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8940U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8940U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8944U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            r2 = 0x00000018U;
        }
        {
            r1 = 0x000000A8U;
        }
        {
            r0 = 0x000000EFU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E895CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E895CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E895C;
    }
block_002E895C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E895CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E895CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E897C; }
        goto block_002E8968;
    }
block_002E8968:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8968U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8968U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002E8968U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x002E896CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002E8970U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x002E8974U, address);
            }
        }
        goto block_002E85B8;
    }
block_002E897C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E897CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E897CU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            r1 = 0x000000A8U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8984U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            r2 = 0x00000018U;
        }
        {
            const uint32_t operand = 0x00000061U;
            r0 = r1 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8998U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8998U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8998;
    }
block_002E8998:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8998U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8998U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E854C; }
        goto block_002E89A4;
    }
block_002E89A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E89A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E89A4U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x002E89A4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x002E89A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x002E89ACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x002E89B0U, address);
            }
        }
        goto block_002E85B8;
    }
block_002E89B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E89B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E89B8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E8B78; }
        goto block_002E89C0;
    }
block_002E89C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E89C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E89C0U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E89C4U, address);
            }
        }
        {
            r3 = 0x00000018U;
        }
        {
            r2 = 0x00000080U;
        }
        {
            r1 = 0x00000028U;
        }
        {
            r0 = 0x0000001FU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E89DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E89DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E89DC;
    }
block_002E89DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E89DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E89DCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r0 = ~(0x00000001U);
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x002E89E4U, address);
            }
        }
        if (!(flags.Z())) { goto block_002E8618; }
        goto block_002E89EC;
    }
block_002E89EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E89ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E89ECU);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E89F0U, address);
            }
        }
        {
            r3 = 0x00000082U;
        }
        {
            r2 = 0x00000104U;
        }
        {
            r1 = 0x00000042U;
        }
        {
            r0 = 0x0000001FU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8A08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8A08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8A08;
    }
block_002E8A08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8A08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8A08U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E8A80; }
        goto block_002E8A14;
    }
block_002E8A14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8A14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8A14U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8A14U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000001FU;
            r0 = r0 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r2 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r2 = Oot3dAotAsr(r1, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r1, 31U);
            r1 = r2 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000009U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E8A4C; }
        goto block_002E8A30;
    }
block_002E8A30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8A30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8A30U);
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8A30U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000042U;
            r1 = r1 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r1;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r2 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r2 = Oot3dAotAsr(r1, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r1, 31U);
            r1 = r2 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002E854C; }
        goto block_002E8A4C;
    }
block_002E8A4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8A4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8A4CU);
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r1 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r1 = Oot3dAotAsr(r0, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E8A58U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E8A5CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8A60U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000042U;
            r0 = r0 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r1 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r1 = Oot3dAotAsr(r0, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E8A74U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E8A78U, address);
            }
        }
        goto block_002E85B8;
    }
block_002E8A80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8A80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8A80U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8A84U, address);
            }
        }
        {
            r3 = 0x00000082U;
        }
        {
            r2 = 0x0000001AU;
        }
        {
            r1 = 0x00000042U;
        }
        {
            r0 = 0x00000005U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8A9CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8A9CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8A9C;
    }
block_002E8A9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8A9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8A9CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E8AF8; }
        goto block_002E8AA8;
    }
block_002E8AA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8AA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8AA8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8AA8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000039U;
            r0 = r0 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r1 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r1 = Oot3dAotAsr(r0, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E8ABCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x002E8AC0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8AC4U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetAddFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x00000042U;
            r1 = r1 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r1;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r2 = static_cast<uint32_t>(value);
            r1 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r2 = Oot3dAotAsr(r1, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r1, 31U);
            r1 = r2 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002E8ADCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x002E8AE0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x002E8AE4U, address);
            }
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x002E8AE8U, address);
            }
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x002E8AECU, address);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002E8AF4U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002E8AF4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002E8AF4U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002E8AF4U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002E8AF4U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002E8AF4U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002E8AF4U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002E8AF4U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002E8AF4U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_002E8AF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8AF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8AF8U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8AFCU, address);
            }
        }
        {
            r3 = 0x00000032U;
        }
        {
            r2 = 0x00000018U;
        }
        {
            r1 = 0x0000005CU;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8B14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8B14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8B14;
    }
block_002E8B14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8B14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8B14U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E8B38; }
        goto block_002E8B20;
    }
block_002E8B20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8B20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8B20U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x002E8B20U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x002E8B24U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x002E8B28U, address);
            }
        }
        {
            r0 = ~(0x00000008U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x002E8B30U, address);
            }
        }
        goto block_002E8618;
    }
block_002E8B38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8B38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8B38U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8B3CU, address);
            }
        }
        {
            r3 = 0x00000032U;
        }
        {
            r2 = 0x00000018U;
        }
        {
            r1 = 0x00000090U;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8B54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8B54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8B54;
    }
block_002E8B54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8B54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8B54U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E854C; }
        goto block_002E8B60;
    }
block_002E8B60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8B60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8B60U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x002E8B60U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x002E8B64U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002E8B68U, address);
            }
        }
        {
            r0 = ~(0x00000007U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x002E8B70U, address);
            }
        }
        goto block_002E8618;
    }
block_002E8B78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8B78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8B78U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E8B80;
    }
block_002E8B80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8B80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8B80U);
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8B84U, address);
            }
        }
        {
            r3 = 0x00000030U;
        }
        {
            r2 = 0x00000078U;
        }
        {
            r1 = 0x00000060U;
        }
        {
            r0 = 0x00000024U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8B9CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8B9CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8B9C;
    }
block_002E8B9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8B9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8B9CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r7 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x002E8BA0U, address);
            }
        }
        {
            r3 = 0x00000001U;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r7 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r5))) {
                return Oot3dAotMemoryFault(context, 0x002E8BA8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8BACU, address);
            }
        }
        {
            r3 = 0x00000030U;
        }
        {
            r2 = 0x00000078U;
        }
        {
            r1 = 0x00000060U;
        }
        {
            r0 = 0x000000A4U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8BC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8BC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8BC4;
    }
block_002E8BC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8BC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8BC4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r7 + 0x2CU;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r5) << 32U |
                                   r4;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x002E8BC8U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002E8BD0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002E8BD0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002E8BD0U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002E8BD0U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002E8BD0U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002E8BD0U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002E8BD0U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002E8BD0U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002E8BD0U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_002E8BD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8BD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8BD4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_002E93D8; }
        goto block_002E8BDC;
    }
block_002E8BDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8BDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8BDCU);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8BE0U, address);
            }
        }
        {
            r3 = 0x00000020U;
        }
        {
            r2 = 0x00000060U;
        }
        {
            r1 = 0x000000CCU;
        }
        {
            r0 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8BF8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8BF8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8BF8;
    }
block_002E8BF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8BF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8BF8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r5 = ~(0x0000000FU);
        }
        if (flags.Z()) { goto block_002E8C10; }
        goto block_002E8C04;
    }
block_002E8C04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8C04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8C04U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8C04U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetAddFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002E85B8; }
        goto block_002E8C10;
    }
block_002E8C10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8C10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8C10U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8C14U, address);
            }
        }
        {
            r3 = 0x00000020U;
        }
        {
            r2 = 0x00000060U;
        }
        {
            r1 = 0x000000CCU;
        }
        {
            r0 = 0x000000DCU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8C2CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8C2CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8C2C;
    }
block_002E8C2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8C2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8C2CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (flags.Z()) { goto block_002E8C44; }
        goto block_002E8C38;
    }
block_002E8C38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8C38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8C38U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8C38U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetAddFlags(flags, r0, 0x0000000BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002E85B8; }
        goto block_002E8C44;
    }
block_002E8C44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8C44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8C44U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8C44U, address);
            }
            r0 = value;
        }
        {
            r5 = ~(0x00000013U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_002E8E38; }
        goto block_002E8C54;
    }
block_002E8C54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8C54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8C54U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8C58U, address);
            }
        }
        {
            r3 = 0x00000018U;
        }
        {
            r2 = 0x00000080U;
        }
        {
            r1 = 0x00000028U;
        }
        {
            r0 = 0x000000A1U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8C70U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8C70U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8C70;
    }
block_002E8C70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8C70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8C70U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E8C90; }
        goto block_002E8C7C;
    }
block_002E8C7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8C7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8C7CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8C7CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetAddFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002E85B8; }
        goto block_002E8C88;
    }
block_002E8C88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8C88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8C88U);
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002E8C8CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002E8C8CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002E8C8CU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002E8C8CU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002E8C8CU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002E8C8CU,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002E8C8CU,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002E8C8CU,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002E8C8CU,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_002E8C90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8C90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8C90U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8C94U, address);
            }
        }
        {
            r3 = 0x0000007FU;
        }
        {
            const uint32_t operand = 0x00000082U;
            r2 = r3 + operand;
        }
        {
            r1 = 0x00000042U;
        }
        {
            r0 = 0x0000001FU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8CACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8CACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8CAC;
    }
block_002E8CAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8CACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8CACU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E8CF8; }
        goto block_002E8CB8;
    }
block_002E8CB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8CB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8CB8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8CB8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000001FU;
            r0 = r0 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r1 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r1 = Oot3dAotAsr(r0, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r1 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8CCCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000042U;
            r0 = r0 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r2 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r2 = Oot3dAotAsr(r0, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r0 = r2 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8CE0U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8CE8U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E8CF4;
    }
block_002E8CF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8CF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8CF4U);
        }
        goto block_002E944C;
    }
block_002E8CF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8CF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8CF8U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8CFCU, address);
            }
        }
        {
            r3 = 0x00000082U;
        }
        {
            r2 = 0x0000001AU;
        }
        {
            r1 = 0x00000042U;
        }
        {
            r0 = 0x00000005U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8D14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8D14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8D14;
    }
block_002E8D14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8D14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8D14U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E8D60; }
        goto block_002E8D20;
    }
block_002E8D20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8D20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8D20U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8D20U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000039U;
            r0 = r0 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r1 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r1 = Oot3dAotAsr(r0, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r1 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8D34U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000042U;
            r0 = r0 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r2 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r2 = Oot3dAotAsr(r0, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r0 = r2 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8D48U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8D50U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E8D5C;
    }
block_002E8D5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8D5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8D5CU);
        }
        goto block_002E944C;
    }
block_002E8D60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8D60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8D60U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8D64U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            r2 = r3;
        }
        {
            r1 = 0x00000042U;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8D7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8D7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8D7C;
    }
block_002E8D7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8D7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8D7CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E8DA0; }
        goto block_002E8D88;
    }
block_002E8D88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8D88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8D88U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8D88U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8D90U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E8D9C;
    }
block_002E8D9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8D9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8D9CU);
        }
        goto block_002E944C;
    }
block_002E8DA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8DA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8DA0U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8DA4U, address);
            }
        }
        {
            r3 = 0x00000034U;
        }
        {
            r2 = 0x0000001AU;
        }
        {
            r1 = 0x0000005CU;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8DBCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8DBCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8DBC;
    }
block_002E8DBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8DBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8DBCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E8DE0; }
        goto block_002E8DC8;
    }
block_002E8DC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8DC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8DC8U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8DC8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8DD0U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E8DDC;
    }
block_002E8DDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8DDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8DDCU);
        }
        goto block_002E944C;
    }
block_002E8DE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8DE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8DE0U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8DE4U, address);
            }
        }
        {
            r3 = 0x00000034U;
        }
        {
            r2 = 0x0000001AU;
        }
        {
            r1 = 0x00000090U;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8DFCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8DFCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8DFC;
    }
block_002E8DFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8DFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8DFCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (flags.Z()) { goto block_002E8E20; }
        goto block_002E8E08;
    }
block_002E8E08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8E08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8E08U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8E08U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8E10U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E8E1C;
    }
block_002E8E1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8E1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8E1CU);
        }
        goto block_002E944C;
    }
block_002E8E20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8E20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8E20U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8E20U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E8E2C;
    }
block_002E8E2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8E2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8E2CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x002E8E2CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002E8E34U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002E8E34U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002E8E34U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002E8E34U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002E8E34U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002E8E34U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002E8E34U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002E8E34U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002E8E34U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_002E8E38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8E38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8E38U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_002E91E8; }
        goto block_002E8E40;
    }
block_002E8E40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8E40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8E40U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8E40U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8E48U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r3 = 0x00000018U;
        }
        {
            r2 = 0x00000080U;
        }
        {
            r1 = 0x00000028U;
        }
        if (!(flags.Z())) { goto block_002E8E84; }
        goto block_002E8E60;
    }
block_002E8E60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8E60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8E60U);
        }
        {
            r0 = 0x0000001FU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8E68U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8E68U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8E68;
    }
block_002E8E68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8E68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8E68U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E8EA4; }
        goto block_002E8E74;
    }
block_002E8E74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8E74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8E74U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8E74U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetAddFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002E85B8; }
        goto block_002E8E80;
    }
block_002E8E80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8E80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8E80U);
        }
        goto block_002E8EA4;
    }
block_002E8E84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8E84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8E84U);
        }
        {
            r0 = 0x000000A1U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8E8CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8E8CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8E8C;
    }
block_002E8E8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8E8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8E8CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E8EA4; }
        goto block_002E8E98;
    }
block_002E8E98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8E98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8E98U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8E98U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetAddFlags(flags, r0, 0x0000000CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002E85B8; }
        goto block_002E8EA4;
    }
block_002E8EA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8EA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8EA4U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8EA8U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            r2 = 0x00000138U;
        }
        {
            r1 = 0x00000040U;
        }
        {
            r0 = 0x00000005U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8EC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8EC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8EC0;
    }
block_002E8EC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8EC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8EC0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E8EF0; }
        goto block_002E8ECC;
    }
block_002E8ECC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8ECCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8ECCU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8ECCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000005U;
            r0 = r0 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r1 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r1 = Oot3dAotAsr(r0, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8EE0U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E8EEC;
    }
block_002E8EEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8EECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8EECU);
        }
        goto block_002E944C;
    }
block_002E8EF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8EF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8EF0U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8EF4U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            r2 = 0x00000104U;
        }
        {
            r1 = 0x0000005AU;
        }
        {
            r0 = 0x00000013U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8F0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8F0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8F0C;
    }
block_002E8F0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8F0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8F0CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E8F3C; }
        goto block_002E8F18;
    }
block_002E8F18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8F18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8F18U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8F18U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000013U;
            r0 = r0 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r1 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r1 = Oot3dAotAsr(r0, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8F2CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E8F38;
    }
block_002E8F38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8F38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8F38U);
        }
        goto block_002E944C;
    }
block_002E8F3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8F3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8F3CU);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8F40U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            r2 = 0x000000EAU;
        }
        {
            r1 = 0x00000074U;
        }
        {
            r0 = 0x0000001FU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8F58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8F58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8F58;
    }
block_002E8F58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8F58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8F58U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E8F88; }
        goto block_002E8F64;
    }
block_002E8F64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8F64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8F64U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8F64U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000001FU;
            r0 = r0 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r1 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r1 = Oot3dAotAsr(r0, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8F78U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E8F84;
    }
block_002E8F84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8F84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8F84U);
        }
        goto block_002E944C;
    }
block_002E8F88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8F88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8F88U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8F8CU, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            r2 = 0x00000104U;
        }
        {
            r1 = 0x0000008EU;
        }
        {
            r0 = 0x0000002BU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8FA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8FA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8FA4;
    }
block_002E8FA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8FA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8FA4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E8FD4; }
        goto block_002E8FB0;
    }
block_002E8FB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8FB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8FB0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8FB0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000002BU;
            r0 = r0 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r1 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r1 = Oot3dAotAsr(r0, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r0 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8FC4U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E8FD0;
    }
block_002E8FD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8FD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8FD0U);
        }
        goto block_002E944C;
    }
block_002E8FD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8FD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8FD4U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E8FD8U, address);
            }
        }
        {
            r3 = 0x00000034U;
        }
        {
            r2 = 0x0000001AU;
        }
        {
            r1 = 0x0000005CU;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E8FF0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E8FF0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E8FF0;
    }
block_002E8FF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8FF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8FF0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E9014; }
        goto block_002E8FFC;
    }
block_002E8FFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E8FFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E8FFCU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E8FFCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E9004U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E9010;
    }
block_002E9010:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9010U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9010U);
        }
        goto block_002E944C;
    }
block_002E9014:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9014U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9014U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E9018U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            r2 = r3;
        }
        {
            r1 = 0x00000074U;
        }
        {
            r0 = 0x00000005U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E9030U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E9030U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E9030;
    }
block_002E9030:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9030U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9030U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E9054; }
        goto block_002E903C;
    }
block_002E903C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E903CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E903CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E903CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetAddFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E9044U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E9050;
    }
block_002E9050:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9050U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9050U);
        }
        goto block_002E944C;
    }
block_002E9054:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9054U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9054U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E9058U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            r2 = 0x0000001CU;
        }
        {
            r1 = 0x0000008CU;
        }
        {
            r0 = 0x00000002U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E9070U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E9070U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E9070;
    }
block_002E9070:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9070U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9070U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E9094; }
        goto block_002E907C;
    }
block_002E907C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E907CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E907CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E907CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetAddFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E9084U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E9090;
    }
block_002E9090:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9090U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9090U);
        }
        goto block_002E944C;
    }
block_002E9094:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9094U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9094U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E9098U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            r2 = r3;
        }
        {
            r1 = 0x000000A8U;
        }
        {
            r0 = 0x00000039U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E90B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E90B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E90B0;
    }
block_002E90B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E90B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E90B0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E90D4; }
        goto block_002E90BC;
    }
block_002E90BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E90BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E90BCU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E90BCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E90C4U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E90D0;
    }
block_002E90D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E90D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E90D0U);
        }
        goto block_002E944C;
    }
block_002E90D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E90D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E90D4U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E90D8U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            r2 = r3;
        }
        {
            r1 = 0x000000A8U;
        }
        {
            r0 = 0x00000053U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E90F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E90F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E90F0;
    }
block_002E90F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E90F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E90F0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E9114; }
        goto block_002E90FC;
    }
block_002E90FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E90FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E90FCU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E90FCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E9104U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E9110;
    }
block_002E9110:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9110U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9110U);
        }
        goto block_002E944C;
    }
block_002E9114:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9114U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9114U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E9118U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            r2 = 0x00000080U;
        }
        {
            r1 = 0x000000A8U;
        }
        {
            r0 = 0x0000006BU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E9130U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E9130U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E9130;
    }
block_002E9130:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9130U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9130U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E9154; }
        goto block_002E913C;
    }
block_002E913C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E913CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E913CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E913CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E9144U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E9150;
    }
block_002E9150:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9150U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9150U);
        }
        goto block_002E944C;
    }
block_002E9154:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9154U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9154U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E9158U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            r2 = r3;
        }
        {
            r1 = 0x000000A8U;
        }
        {
            r0 = 0x000000EFU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E9170U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E9170U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E9170;
    }
block_002E9170:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9170U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9170U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E9194; }
        goto block_002E917C;
    }
block_002E917C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E917CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E917CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E917CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E9184U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E9190;
    }
block_002E9190:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9190U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9190U);
        }
        goto block_002E944C;
    }
block_002E9194:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9194U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9194U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E9198U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            r1 = 0x000000A8U;
        }
        {
            r2 = r3;
        }
        {
            const uint32_t operand = 0x00000061U;
            r0 = r1 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E91B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E91B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E91B0;
    }
block_002E91B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E91B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E91B0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (flags.Z()) { goto block_002E91D4; }
        goto block_002E91BC;
    }
block_002E91BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E91BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E91BCU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E91BCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E91C4U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E91D0;
    }
block_002E91D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E91D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E91D0U);
        }
        goto block_002E944C;
    }
block_002E91D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E91D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E91D4U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E91D4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002E8E2C; }
        goto block_002E91E0;
    }
block_002E91E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E91E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E91E0U);
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002E91E4U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002E91E4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002E91E4U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002E91E4U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002E91E4U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002E91E4U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002E91E4U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002E91E4U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002E91E4U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_002E91E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E91E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E91E8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E93D8; }
        goto block_002E91F0;
    }
block_002E91F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E91F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E91F0U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E91F4U, address);
            }
        }
        {
            r3 = 0x00000018U;
        }
        {
            r2 = 0x00000080U;
        }
        {
            r1 = 0x00000028U;
        }
        {
            r0 = 0x0000001FU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E920CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E920CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E920C;
    }
block_002E920C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E920CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E920CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E922C; }
        goto block_002E9218;
    }
block_002E9218:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9218U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9218U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E9218U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetAddFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002E85B8; }
        goto block_002E9224;
    }
block_002E9224:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9224U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9224U);
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002E9228U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002E9228U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002E9228U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002E9228U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002E9228U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002E9228U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002E9228U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002E9228U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002E9228U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_002E922C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E922CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E922CU);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E9230U, address);
            }
        }
        {
            r3 = 0x00000082U;
        }
        {
            r2 = 0x00000104U;
        }
        {
            r1 = 0x00000042U;
        }
        {
            r0 = 0x0000001FU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E9248U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E9248U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E9248;
    }
block_002E9248:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9248U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9248U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E9294; }
        goto block_002E9254;
    }
block_002E9254:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9254U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9254U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E9254U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000001FU;
            r0 = r0 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r1 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r1 = Oot3dAotAsr(r0, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r1 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E9268U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000042U;
            r0 = r0 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r2 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r2 = Oot3dAotAsr(r0, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r0 = r2 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E927CU, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E9284U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E9290;
    }
block_002E9290:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9290U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9290U);
        }
        goto block_002E944C;
    }
block_002E9294:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9294U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9294U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E9298U, address);
            }
        }
        {
            r3 = 0x00000082U;
        }
        {
            r2 = 0x0000001AU;
        }
        {
            r1 = 0x00000042U;
        }
        {
            r0 = 0x00000005U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E92B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E92B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E92B0;
    }
block_002E92B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E92B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E92B0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E9304; }
        goto block_002E92BC;
    }
block_002E92BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E92BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E92BCU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E92BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000039U;
            r0 = r0 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r1 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r1 = Oot3dAotAsr(r0, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r1 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E92D0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000042U;
            r0 = r0 - operand;
        }
        {
            const uint32_t leftValue = r6;
            const uint32_t rightValue = r0;
            const int64_t product =
                static_cast<int64_t>(static_cast<int32_t>(leftValue)) *
                static_cast<int64_t>(static_cast<int32_t>(rightValue));
            uint64_t value = static_cast<uint64_t>(product);
            r2 = static_cast<uint32_t>(value);
            r0 = static_cast<uint32_t>(value >> 32U);
        }
        {
            r2 = Oot3dAotAsr(r0, 3U);
        }
        {
            const uint32_t operand = Oot3dAotAsr(r0, 31U);
            r0 = r2 - operand;
        }
        {
            const uint32_t updatedAddress = r7 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E92E4U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0x38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E92ECU, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E92F8;
    }
block_002E92F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E92F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E92F8U);
        }
        goto block_002E944C;
    }
block_002E9304:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9304U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9304U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E9308U, address);
            }
        }
        {
            r3 = 0x0000001AU;
        }
        {
            r2 = r3;
        }
        {
            r1 = 0x00000042U;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E9320U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E9320U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E9320;
    }
block_002E9320:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9320U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9320U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E9344; }
        goto block_002E932C;
    }
block_002E932C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E932CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E932CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E932CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E9334U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E9340;
    }
block_002E9340:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9340U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9340U);
        }
        goto block_002E944C;
    }
block_002E9344:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9344U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9344U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E9348U, address);
            }
        }
        {
            r3 = 0x00000034U;
        }
        {
            r2 = 0x0000001AU;
        }
        {
            r1 = 0x0000005CU;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E9360U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E9360U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E9360;
    }
block_002E9360:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9360U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9360U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E9384; }
        goto block_002E936C;
    }
block_002E936C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E936CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E936CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E936CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E9374U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E9380;
    }
block_002E9380:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9380U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9380U);
        }
        goto block_002E944C;
    }
block_002E9384:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9384U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9384U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E9388U, address);
            }
        }
        {
            r3 = 0x00000034U;
        }
        {
            r2 = 0x0000001AU;
        }
        {
            r1 = 0x00000090U;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E93A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E93A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E93A0;
    }
block_002E93A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E93A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E93A0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (flags.Z()) { goto block_002E93C4; }
        goto block_002E93AC;
    }
block_002E93AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E93ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E93ACU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E93ACU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r7 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E93B4U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E93C0;
    }
block_002E93C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E93C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E93C0U);
        }
        goto block_002E944C;
    }
block_002E93C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E93C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E93C4U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E93C4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002E8E2C; }
        goto block_002E93D0;
    }
block_002E93D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E93D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E93D0U);
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002E93D4U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002E93D4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002E93D4U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002E93D4U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002E93D4U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002E93D4U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002E93D4U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002E93D4U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002E93D4U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_002E93D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E93D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E93D8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E93E0;
    }
block_002E93E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E93E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E93E0U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E93E4U, address);
            }
        }
        {
            r3 = 0x00000030U;
        }
        {
            r2 = 0x00000078U;
        }
        {
            r1 = 0x00000060U;
        }
        {
            r0 = 0x00000024U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E93FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E93FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E93FC;
    }
block_002E93FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E93FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E93FCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_002E9418; }
        goto block_002E9408;
    }
block_002E9408:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9408U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9408U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E9408U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E9414;
    }
block_002E9414:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9414U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9414U);
        }
        goto block_002E944C;
    }
block_002E9418:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9418U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9418U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x002E941CU, address);
            }
        }
        {
            r3 = 0x00000030U;
        }
        {
            r2 = 0x00000078U;
        }
        {
            r1 = 0x00000060U;
        }
        {
            r0 = 0x000000A4U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x002E9434U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x002E9434U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_002E9434;
    }
block_002E9434:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9434U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9434U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (flags.Z()) { goto block_002E9458; }
        goto block_002E9440;
    }
block_002E9440:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9440U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9440U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E9440U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_002E854C; }
        goto block_002E944C;
    }
block_002E944C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E944CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E944CU);
        }
        {
            const uint32_t updatedAddress = r7 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x002E944CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002E9454U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002E9454U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002E9454U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002E9454U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002E9454U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002E9454U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002E9454U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002E9454U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002E9454U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_002E9458:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9458U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9458U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002E9458U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_002E8E2C; }
        goto block_002E9464;
    }
block_002E9464:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002E9464U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002E9464U);
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x002E9468U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x002E9468U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x002E9468U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x002E9468U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x002E9468U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x002E9468U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x002E9468U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x002E9468U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x002E9468U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_002f43e8_002F43E8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r4 = state.R[4];
    uint32_t& r8 = state.R[8];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x002F43E8U:
        goto block_002F43E8;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_002F43E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x002F43E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x002F43E8U);
        }
        {
            const uint32_t updatedAddress = 0x002F43F0U + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F43E8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x002F43ECU, address);
            }
            r0 = value;
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_TouchInput_IsRectActive_0033F428(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0033F428U:
        goto block_0033F428;
    case 0x0033F444U:
        goto block_0033F444;
    case 0x0033F450U:
        goto block_0033F450;
    case 0x0033F454U:
        goto block_0033F454;
    case 0x0033F45CU:
        goto block_0033F45C;
    case 0x0033F468U:
        goto block_0033F468;
    case 0x0033F46CU:
        goto block_0033F46C;
    case 0x0033F474U:
        goto block_0033F474;
    case 0x0033F480U:
        goto block_0033F480;
    case 0x0033F484U:
        goto block_0033F484;
    case 0x0033F494U:
        goto block_0033F494;
    case 0x0033F4B0U:
        goto block_0033F4B0;
    case 0x0033F4BCU:
        goto block_0033F4BC;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0033F428:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033F428U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033F428U);
        }
        {
            const uint32_t firstAddress = r13 - 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0033F428U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0033F428U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0033F428U,
                                           firstAddress + 8U);
            }
            r13 = r13 - 12U;
        }
        {
            const uint32_t updatedAddress = 0x0033F434U + 0x94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033F42CU, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033F430U, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033F434U, address);
            }
            r4 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033F438U, address);
            }
            r5 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0033F454; }
        goto block_0033F444;
    }
block_0033F444:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033F444U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033F444U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033F444U, address);
            }
            r12 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0033F4B0; }
        goto block_0033F450;
    }
block_0033F450:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033F450U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033F450U);
        }
        goto block_0033F494;
    }
block_0033F454:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033F454U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033F454U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0033F46C; }
        goto block_0033F45C;
    }
block_0033F45C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033F45CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033F45CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033F45CU, address);
            }
            r12 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0033F4B0; }
        goto block_0033F468;
    }
block_0033F468:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033F468U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033F468U);
        }
        goto block_0033F494;
    }
block_0033F46C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033F46CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033F46CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0033F484; }
        goto block_0033F474;
    }
block_0033F474:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033F474U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033F474U);
        }
        {
            const uint32_t updatedAddress = r6 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033F474U, address);
            }
            r12 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0033F4B0; }
        goto block_0033F480;
    }
block_0033F480:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033F480U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033F480U);
        }
        goto block_0033F494;
    }
block_0033F484:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033F484U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033F484U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r6 + 0x10U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0033F488U, address);
            }
            r12 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0033F4B0; }
        goto block_0033F494;
    }
block_0033F494:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033F494U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033F494U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) {
            const uint32_t operand = r2;
            r0 = r0 + operand;
        }
        if (flags.C()) {
            Oot3dAotSetSubtractFlags(flags, r0, r4, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) {
            Oot3dAotSetSubtractFlags(flags, r5, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) {
            const uint32_t operand = r3;
            r0 = r1 + operand;
        }
        if (flags.C()) {
            Oot3dAotSetSubtractFlags(flags, r0, r5, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0033F4BC; }
        goto block_0033F4B0;
    }
block_0033F4B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033F4B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033F4B0U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0033F4B0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0033F4B0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0033F4B0U,
                                           firstAddress + 8U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 12U;
        }
        {
            r0 = 0x00000000U;
        }
        return Oot3dAotReturned(r14);
    }
block_0033F4BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0033F4BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0033F4BCU);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0033F4BCU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0033F4BCU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0033F4BCU,
                                           firstAddress + 8U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 12U;
        }
        {
            r0 = 0x00000001U;
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_00374be8_00374BE8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00374BE8U:
        goto block_00374BE8;
    case 0x00374C00U:
        goto block_00374C00;
    case 0x00374C70U:
        goto block_00374C70;
    case 0x00374C84U:
        goto block_00374C84;
    case 0x00374C88U:
        goto block_00374C88;
    case 0x00374CA8U:
        goto block_00374CA8;
    case 0x00374CB8U:
        goto block_00374CB8;
    case 0x00374CC8U:
        goto block_00374CC8;
    case 0x00374CE0U:
        goto block_00374CE0;
    case 0x00374CF0U:
        goto block_00374CF0;
    case 0x00374CF8U:
        goto block_00374CF8;
    case 0x00374D04U:
        goto block_00374D04;
    case 0x00374D20U:
        goto block_00374D20;
    case 0x00374D2CU:
        goto block_00374D2C;
    case 0x00374D4CU:
        goto block_00374D4C;
    case 0x00374D58U:
        goto block_00374D58;
    case 0x00374D68U:
        goto block_00374D68;
    case 0x00374D70U:
        goto block_00374D70;
    case 0x00374D90U:
        goto block_00374D90;
    case 0x00374DA4U:
        goto block_00374DA4;
    case 0x00374DACU:
        goto block_00374DAC;
    case 0x00374DB8U:
        goto block_00374DB8;
    case 0x00374DDCU:
        goto block_00374DDC;
    case 0x00374DE8U:
        goto block_00374DE8;
    case 0x00374DF4U:
        goto block_00374DF4;
    case 0x00374E00U:
        goto block_00374E00;
    case 0x00374E0CU:
        goto block_00374E0C;
    case 0x00374E20U:
        goto block_00374E20;
    case 0x00374E38U:
        goto block_00374E38;
    case 0x00374E44U:
        goto block_00374E44;
    case 0x00374E58U:
        goto block_00374E58;
    case 0x00374E78U:
        goto block_00374E78;
    case 0x00374E84U:
        goto block_00374E84;
    case 0x00374E8CU:
        goto block_00374E8C;
    case 0x00374E98U:
        goto block_00374E98;
    case 0x00374EB4U:
        goto block_00374EB4;
    case 0x00374EC4U:
        goto block_00374EC4;
    case 0x00374ED0U:
        goto block_00374ED0;
    case 0x00374ED8U:
        goto block_00374ED8;
    case 0x00374EDCU:
        goto block_00374EDC;
    case 0x00374EF0U:
        goto block_00374EF0;
    case 0x00374F00U:
        goto block_00374F00;
    case 0x00374F14U:
        goto block_00374F14;
    case 0x00374F18U:
        goto block_00374F18;
    case 0x00374F28U:
        goto block_00374F28;
    case 0x00374F38U:
        goto block_00374F38;
    case 0x00374F40U:
        goto block_00374F40;
    case 0x00374F50U:
        goto block_00374F50;
    case 0x00374F5CU:
        goto block_00374F5C;
    case 0x00374F68U:
        goto block_00374F68;
    case 0x00374F70U:
        goto block_00374F70;
    case 0x00374F7CU:
        goto block_00374F7C;
    case 0x00374F8CU:
        goto block_00374F8C;
    case 0x00374F98U:
        goto block_00374F98;
    case 0x00374FACU:
        goto block_00374FAC;
    case 0x00374FBCU:
        goto block_00374FBC;
    case 0x00374FC4U:
        goto block_00374FC4;
    case 0x00374FD4U:
        goto block_00374FD4;
    case 0x00374FE0U:
        goto block_00374FE0;
    case 0x00374FE4U:
        goto block_00374FE4;
    case 0x00374FECU:
        goto block_00374FEC;
    case 0x00375004U:
        goto block_00375004;
    case 0x0037500CU:
        goto block_0037500C;
    case 0x00375030U:
        goto block_00375030;
    case 0x00375038U:
        goto block_00375038;
    case 0x0037503CU:
        goto block_0037503C;
    case 0x00375044U:
        goto block_00375044;
    case 0x00375050U:
        goto block_00375050;
    case 0x00375058U:
        goto block_00375058;
    case 0x0037506CU:
        goto block_0037506C;
    case 0x00375078U:
        goto block_00375078;
    case 0x00375094U:
        goto block_00375094;
    case 0x003750A4U:
        goto block_003750A4;
    case 0x003750ACU:
        goto block_003750AC;
    case 0x003750B8U:
        goto block_003750B8;
    case 0x003750C4U:
        goto block_003750C4;
    case 0x003750D8U:
        goto block_003750D8;
    case 0x003750E4U:
        goto block_003750E4;
    case 0x003750ECU:
        goto block_003750EC;
    case 0x003750F8U:
        goto block_003750F8;
    case 0x003750FCU:
        goto block_003750FC;
    case 0x00375110U:
        goto block_00375110;
    case 0x0037511CU:
        goto block_0037511C;
    case 0x00375128U:
        goto block_00375128;
    case 0x00375138U:
        goto block_00375138;
    case 0x0037515CU:
        goto block_0037515C;
    case 0x00375160U:
        goto block_00375160;
    case 0x00375174U:
        goto block_00375174;
    case 0x00375178U:
        goto block_00375178;
    case 0x00375194U:
        goto block_00375194;
    case 0x00375198U:
        goto block_00375198;
    case 0x003751ACU:
        goto block_003751AC;
    case 0x003751C0U:
        goto block_003751C0;
    case 0x003751C4U:
        goto block_003751C4;
    case 0x003751D4U:
        goto block_003751D4;
    case 0x003751D8U:
        goto block_003751D8;
    case 0x003751FCU:
        goto block_003751FC;
    case 0x00375208U:
        goto block_00375208;
    case 0x00375218U:
        goto block_00375218;
    case 0x00375220U:
        goto block_00375220;
    case 0x00375224U:
        goto block_00375224;
    case 0x00375238U:
        goto block_00375238;
    case 0x0037523CU:
        goto block_0037523C;
    case 0x0037524CU:
        goto block_0037524C;
    case 0x00375250U:
        goto block_00375250;
    case 0x00375260U:
        goto block_00375260;
    case 0x00375264U:
        goto block_00375264;
    case 0x00375278U:
        goto block_00375278;
    case 0x0037530CU:
        goto block_0037530C;
    case 0x00375320U:
        goto block_00375320;
    case 0x00375328U:
        goto block_00375328;
    case 0x00375330U:
        goto block_00375330;
    case 0x00375344U:
        goto block_00375344;
    case 0x00375348U:
        goto block_00375348;
    case 0x00375358U:
        goto block_00375358;
    case 0x0037535CU:
        goto block_0037535C;
    case 0x00375370U:
        goto block_00375370;
    case 0x00375384U:
        goto block_00375384;
    case 0x00375388U:
        goto block_00375388;
    case 0x003753A8U:
        goto block_003753A8;
    case 0x003753B8U:
        goto block_003753B8;
    case 0x003753C4U:
        goto block_003753C4;
    case 0x003753C8U:
        goto block_003753C8;
    case 0x003753DCU:
        goto block_003753DC;
    case 0x003753E0U:
        goto block_003753E0;
    case 0x003753ECU:
        goto block_003753EC;
    case 0x003753FCU:
        goto block_003753FC;
    case 0x00375400U:
        goto block_00375400;
    case 0x00375410U:
        goto block_00375410;
    case 0x00375414U:
        goto block_00375414;
    case 0x00375424U:
        goto block_00375424;
    case 0x00375438U:
        goto block_00375438;
    case 0x0037543CU:
        goto block_0037543C;
    case 0x00375450U:
        goto block_00375450;
    case 0x00375454U:
        goto block_00375454;
    case 0x00375464U:
        goto block_00375464;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00374BE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374BE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374BE8U);
        }
        {
            const uint32_t firstAddress = r13 - 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00374BE8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00374BE8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00374BE8U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00374BE8U,
                                           firstAddress + 12U);
            }
            r13 = r13 - 16U;
        }
        {
            const uint32_t operand = 0x00002000U;
            r5 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x0000001BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r5 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374BF4U, address);
            }
            r4 = value;
        }
        {
            r6 = r0;
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x00374C04U + Oot3dAotLsl(r1, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374BFCU, address);
            }
            switch (value) {
            case 0x00374BE8U:
                goto block_00374BE8;
            case 0x00374C00U:
                goto block_00374C00;
            case 0x00374C70U:
                goto block_00374C70;
            case 0x00374C84U:
                goto block_00374C84;
            case 0x00374C88U:
                goto block_00374C88;
            case 0x00374CA8U:
                goto block_00374CA8;
            case 0x00374CB8U:
                goto block_00374CB8;
            case 0x00374CC8U:
                goto block_00374CC8;
            case 0x00374CE0U:
                goto block_00374CE0;
            case 0x00374CF0U:
                goto block_00374CF0;
            case 0x00374CF8U:
                goto block_00374CF8;
            case 0x00374D04U:
                goto block_00374D04;
            case 0x00374D20U:
                goto block_00374D20;
            case 0x00374D2CU:
                goto block_00374D2C;
            case 0x00374D4CU:
                goto block_00374D4C;
            case 0x00374D58U:
                goto block_00374D58;
            case 0x00374D68U:
                goto block_00374D68;
            case 0x00374D70U:
                goto block_00374D70;
            case 0x00374D90U:
                goto block_00374D90;
            case 0x00374DA4U:
                goto block_00374DA4;
            case 0x00374DACU:
                goto block_00374DAC;
            case 0x00374DB8U:
                goto block_00374DB8;
            case 0x00374DDCU:
                goto block_00374DDC;
            case 0x00374DE8U:
                goto block_00374DE8;
            case 0x00374DF4U:
                goto block_00374DF4;
            case 0x00374E00U:
                goto block_00374E00;
            case 0x00374E0CU:
                goto block_00374E0C;
            case 0x00374E20U:
                goto block_00374E20;
            case 0x00374E38U:
                goto block_00374E38;
            case 0x00374E44U:
                goto block_00374E44;
            case 0x00374E58U:
                goto block_00374E58;
            case 0x00374E78U:
                goto block_00374E78;
            case 0x00374E84U:
                goto block_00374E84;
            case 0x00374E8CU:
                goto block_00374E8C;
            case 0x00374E98U:
                goto block_00374E98;
            case 0x00374EB4U:
                goto block_00374EB4;
            case 0x00374EC4U:
                goto block_00374EC4;
            case 0x00374ED0U:
                goto block_00374ED0;
            case 0x00374ED8U:
                goto block_00374ED8;
            case 0x00374EDCU:
                goto block_00374EDC;
            case 0x00374EF0U:
                goto block_00374EF0;
            case 0x00374F00U:
                goto block_00374F00;
            case 0x00374F14U:
                goto block_00374F14;
            case 0x00374F18U:
                goto block_00374F18;
            case 0x00374F28U:
                goto block_00374F28;
            case 0x00374F38U:
                goto block_00374F38;
            case 0x00374F40U:
                goto block_00374F40;
            case 0x00374F50U:
                goto block_00374F50;
            case 0x00374F5CU:
                goto block_00374F5C;
            case 0x00374F68U:
                goto block_00374F68;
            case 0x00374F70U:
                goto block_00374F70;
            case 0x00374F7CU:
                goto block_00374F7C;
            case 0x00374F8CU:
                goto block_00374F8C;
            case 0x00374F98U:
                goto block_00374F98;
            case 0x00374FACU:
                goto block_00374FAC;
            case 0x00374FBCU:
                goto block_00374FBC;
            case 0x00374FC4U:
                goto block_00374FC4;
            case 0x00374FD4U:
                goto block_00374FD4;
            case 0x00374FE0U:
                goto block_00374FE0;
            case 0x00374FE4U:
                goto block_00374FE4;
            case 0x00374FECU:
                goto block_00374FEC;
            case 0x00375004U:
                goto block_00375004;
            case 0x0037500CU:
                goto block_0037500C;
            case 0x00375030U:
                goto block_00375030;
            case 0x00375038U:
                goto block_00375038;
            case 0x0037503CU:
                goto block_0037503C;
            case 0x00375044U:
                goto block_00375044;
            case 0x00375050U:
                goto block_00375050;
            case 0x00375058U:
                goto block_00375058;
            case 0x0037506CU:
                goto block_0037506C;
            case 0x00375078U:
                goto block_00375078;
            case 0x00375094U:
                goto block_00375094;
            case 0x003750A4U:
                goto block_003750A4;
            case 0x003750ACU:
                goto block_003750AC;
            case 0x003750B8U:
                goto block_003750B8;
            case 0x003750C4U:
                goto block_003750C4;
            case 0x003750D8U:
                goto block_003750D8;
            case 0x003750E4U:
                goto block_003750E4;
            case 0x003750ECU:
                goto block_003750EC;
            case 0x003750F8U:
                goto block_003750F8;
            case 0x003750FCU:
                goto block_003750FC;
            case 0x00375110U:
                goto block_00375110;
            case 0x0037511CU:
                goto block_0037511C;
            case 0x00375128U:
                goto block_00375128;
            case 0x00375138U:
                goto block_00375138;
            case 0x0037515CU:
                goto block_0037515C;
            case 0x00375160U:
                goto block_00375160;
            case 0x00375174U:
                goto block_00375174;
            case 0x00375178U:
                goto block_00375178;
            case 0x00375194U:
                goto block_00375194;
            case 0x00375198U:
                goto block_00375198;
            case 0x003751ACU:
                goto block_003751AC;
            case 0x003751C0U:
                goto block_003751C0;
            case 0x003751C4U:
                goto block_003751C4;
            case 0x003751D4U:
                goto block_003751D4;
            case 0x003751D8U:
                goto block_003751D8;
            case 0x003751FCU:
                goto block_003751FC;
            case 0x00375208U:
                goto block_00375208;
            case 0x00375218U:
                goto block_00375218;
            case 0x00375220U:
                goto block_00375220;
            case 0x00375224U:
                goto block_00375224;
            case 0x00375238U:
                goto block_00375238;
            case 0x0037523CU:
                goto block_0037523C;
            case 0x0037524CU:
                goto block_0037524C;
            case 0x00375250U:
                goto block_00375250;
            case 0x00375260U:
                goto block_00375260;
            case 0x00375264U:
                goto block_00375264;
            case 0x00375278U:
                goto block_00375278;
            case 0x0037530CU:
                goto block_0037530C;
            case 0x00375320U:
                goto block_00375320;
            case 0x00375328U:
                goto block_00375328;
            case 0x00375330U:
                goto block_00375330;
            case 0x00375344U:
                goto block_00375344;
            case 0x00375348U:
                goto block_00375348;
            case 0x00375358U:
                goto block_00375358;
            case 0x0037535CU:
                goto block_0037535C;
            case 0x00375370U:
                goto block_00375370;
            case 0x00375384U:
                goto block_00375384;
            case 0x00375388U:
                goto block_00375388;
            case 0x003753A8U:
                goto block_003753A8;
            case 0x003753B8U:
                goto block_003753B8;
            case 0x003753C4U:
                goto block_003753C4;
            case 0x003753C8U:
                goto block_003753C8;
            case 0x003753DCU:
                goto block_003753DC;
            case 0x003753E0U:
                goto block_003753E0;
            case 0x003753ECU:
                goto block_003753EC;
            case 0x003753FCU:
                goto block_003753FC;
            case 0x00375400U:
                goto block_00375400;
            case 0x00375410U:
                goto block_00375410;
            case 0x00375414U:
                goto block_00375414;
            case 0x00375424U:
                goto block_00375424;
            case 0x00375438U:
                goto block_00375438;
            case 0x0037543CU:
                goto block_0037543C;
            case 0x00375450U:
                goto block_00375450;
            case 0x00375454U:
                goto block_00375454;
            case 0x00375464U:
                goto block_00375464;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_00374C00;
    }
block_00374C00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374C00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374C00U);
        }
        goto block_00375328;
    }
block_00374C70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374C70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374C70U);
        }
        {
            const uint32_t updatedAddress = 0x00374C78U + 0x604U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374C70U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00374C7CU + 0x604U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374C74U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374C78U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_00374C84;
    }
block_00374C84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374C84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374C84U);
        }
        goto block_00375320;
    }
block_00374C88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374C88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374C88U);
        }
        {
            const uint32_t updatedAddress = 0x00374C90U + 0x5F4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374C88U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00374C94U + 0x5F4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374C8CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374C90U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374C94U, address);
            }
            r1 = value;
        }
        {
            r0 = r0 & 0x00004000U;
        }
        {
            r1 = r1 & 0x08000000U;
        }
        {
            r0 = r0 | r1;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00374CA4U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00374CA4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00374CA4U,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00374CA4U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
block_00374CA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374CA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374CA8U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r5 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x749U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374CACU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_00374CB8;
    }
block_00374CB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374CB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374CB8U);
        }
        {
            r0 = 0x00000104U;
        }
        {
            const uint32_t updatedAddress = r0 + r6;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374CBCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000049U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00374CE0; }
        goto block_00374CC8;
    }
block_00374CC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374CC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374CC8U);
        }
        {
            const uint32_t updatedAddress = 0x00374CD0U + 0x5BCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374CC8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374CCCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00375328; }
        goto block_00374CE0;
    }
block_00374CE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374CE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374CE0U);
        }
        {
            const uint32_t updatedAddress = 0x00374CE8U + 0x5A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374CE0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374CE4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_00374CF0;
    }
block_00374CF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374CF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374CF0U);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00374CF8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_get_flag_1710_mask_10_003518CC(frame, context, state, 0x003518CCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00374CF8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00374CF8;
    }
block_00374CF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374CF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374CF8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_00374D04;
    }
block_00374D04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374D04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374D04U);
        }
        {
            const uint32_t updatedAddress = 0x00374D0CU + 0x588U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374D04U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374D08U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xB2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374D10U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000010U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000020U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00375328; }
        goto block_00374D20;
    }
block_00374D20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374D20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374D20U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x714U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374D20U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000100U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000100U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_00374D2C;
    }
block_00374D2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374D2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374D2CU);
        }
        {
            const uint32_t updatedAddress = 0x00374D34U + 0x564U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374D2CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x708U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374D30U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x00374D40U + 0x55CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374D38U, address);
            }
            r2 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x00374D48U + 0x558U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374D40U, address);
            }
            r2 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00375328; }
        goto block_00374D4C;
    }
block_00374D4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374D4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374D4CU);
        }
        {
            const uint32_t updatedAddress = 0x00374D54U + 0x550U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374D4CU, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) { goto block_00374D70; }
        goto block_00374D58;
    }
block_00374D58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374D58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374D58U);
        }
        {
            const uint32_t updatedAddress = 0x00374D60U + 0x548U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374D58U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r2 + r4;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374D5CU, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000018U, static_cast<Oot3dAotFlagMask>(0xBU));
        }
        if ((flags.N()) != (flags.V())) { goto block_00374D70; }
        goto block_00374D68;
    }
block_00374D68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374D68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374D68U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x0000001BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00375328; }
        goto block_00374D70;
    }
block_00374D70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374D70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374D70U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x710U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374D70U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x00374D7CU + 0x530U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374D74U, address);
            }
            r3 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r2, 0U, 0U, flags.C());
            const uint32_t value = r3 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) {
            const uint32_t value = r0 & 0x00000080U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) {
            const uint32_t operand = 0x00002000U;
            r3 = r4 + operand;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r3 + 0x27DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374D84U, address);
            }
            r12 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_00374D90;
    }
block_00374D90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374D90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374D90U);
        }
        {
            const uint32_t updatedAddress = 0x00374D98U + 0x518U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374D90U, address);
            }
            r12 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r12, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x00374DA0U + 0x514U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374D98U, address);
            }
            r12 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r1, r12, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00375328; }
        goto block_00374DA4;
    }
block_00374DA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374DA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374DA4U);
        }
        {
            const uint32_t value = r2 & 0x08000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x08000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_00374DB8; }
        goto block_00374DAC;
    }
block_00374DAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374DACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374DACU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x284U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374DACU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000066U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00375328; }
        goto block_00374DB8;
    }
block_00374DB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374DB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374DB8U);
        }
        {
            const uint32_t updatedAddress = r3 + 0x9B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374DB8U, address);
            }
            r1 = value;
        }
        {
            r0 = r0 & 0x00004000U;
        }
        {
            r1 = r1 & 0x08000000U;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            r0 = r0 | shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r0, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x6F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374DC8U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x00374DD8U + 0x4E0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374DD0U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const auto shifted = Oot3dAotShiftImmediate(
                r2, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_00374DDC;
    }
block_00374DDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374DDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374DDCU);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00374DE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00374DE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00374DE8;
    }
block_00374DE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374DE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374DE8U);
        }
        {
            r1 = 0x00000006U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00374DF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00351878_00351878(frame, context, state, 0x00351878U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00374DF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00374DF4;
    }
block_00374DF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374DF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374DF4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00375328; }
        goto block_00374E00;
    }
block_00374E00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374E00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374E00U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x90U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374E00U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00374E38; }
        goto block_00374E0C;
    }
block_00374E0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374E0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374E0CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x710U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374E0CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x08000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x08000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x1A7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374E14U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00375328; }
        goto block_00374E20;
    }
block_00374E20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374E20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374E20U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x70CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374E20U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 136U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374E24U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374E28U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00374E2CU, 0xEEB40AE0U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[0], frame.Guest.vfp[1],
                true);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (flags.C()) { goto block_00375328; }
        goto block_00374E38;
    }
block_00374E38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374E38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374E38U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x749U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374E38U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00375320; }
        goto block_00374E44;
    }
block_00374E44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374E44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374E44U);
        }
        {
            const uint32_t updatedAddress = 0x00374E4CU + 0x470U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374E44U, address);
            }
            r2 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00374E58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetupAction_0036055C(frame, context, state, 0x0036055CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00374E58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00374E58;
    }
block_00374E58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374E58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374E58U);
        }
        {
            const uint32_t updatedAddress = 0x00374E60U + 0x460U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374E58U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374E5CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x710U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374E64U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            r0 = r0 | 0x20000000U;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x710U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00374E6CU, address);
            }
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00374E78U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_ResetMeleeWeaponState_0034BBFC(frame, context, state, 0x0034BBFCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00374E78U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00374E78;
    }
block_00374E78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374E78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374E78U);
        }
        {
        }
        {
        }
        goto block_00375328;
    }
block_00374E84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374E84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374E84U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00374E8CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00374E8CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00374E8C;
    }
block_00374E8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374E8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374E8CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_00374E98;
    }
block_00374E98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374E98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374E98U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r3 = r4 + operand;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r3 + 0x6F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374EA0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r3 + 0x72CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374EA4U, address);
            }
            r2 = value;
        }
        {
            r12 = r1;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_00374ED8; }
        goto block_00374EB4;
    }
block_00374EB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374EB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374EB4U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374EB4U, address);
            }
            r14 = value;
        }
        {
            const uint32_t updatedAddress = 0x00374EC0U + 0x404U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374EB8U, address);
            }
            r5 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r14, 0U, 0U, flags.C());
            r14 = r5 & ~(shifted.Value);
            Oot3dAotSetLogicalFlags(flags, r14, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00374ED0; }
        goto block_00374EC4;
    }
block_00374EC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374EC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374EC4U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x123U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374EC4U, address);
            }
            r14 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r14, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00374ED8; }
        goto block_00374ED0;
    }
block_00374ED0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374ED0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374ED0U);
        }
        {
            r14 = 0x00000001U;
        }
        goto block_00374EDC;
    }
block_00374ED8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374ED8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374ED8U);
        }
        {
            r14 = 0x00000000U;
        }
        goto block_00374EDC;
    }
block_00374EDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374EDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374EDCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r14, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x00374EE8U + 0x3A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374EE0U, address);
            }
            r5 = value;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + r4;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374EE4U, address);
            }
            r5 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_00374F38; }
        goto block_00374EF0;
    }
block_00374EF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374EF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374EF0U);
        }
        {
            const uint32_t updatedAddress = 0x00374EF8U + 0x398U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374EF0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r4;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374EF4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xBU));
        }
        if ((flags.N()) == (flags.V())) { goto block_00374F14; }
        goto block_00374F00;
    }
block_00374F00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374F00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374F00U);
        }
        {
            const uint32_t operand = 0x00000000U;
            r1 = operand - r1;
        }
        {
            r1 = r1 & 0x0000FF00U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000200U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) {
            r12 = 0x00000001U;
        }
        if (!(flags.Z())) { goto block_00374F18; }
        goto block_00374F14;
    }
block_00374F14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374F14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374F14U);
        }
        {
            r12 = 0x00000000U;
        }
        goto block_00374F18;
    }
block_00374F18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374F18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374F18U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r1 = r12 - operand;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r14, 0U, 0U, flags.C());
            const uint32_t value = r1 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) {
            r1 = r0;
        }
        if (!(flags.Z())) { goto block_00374F38; }
        goto block_00374F28;
    }
block_00374F28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374F28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374F28U);
        }
        {
            const uint32_t updatedAddress = r3 + 0x724U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374F28U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) {
            r0 = 0x00000000U;
        }
        if (!(flags.Z())) {
            r2 = r0;
        }
        goto block_00374F38;
    }
block_00374F38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374F38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374F38U);
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            r5 = r2 | shifted.Value;
            Oot3dAotSetLogicalFlags(flags, r5, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_00375094; }
        goto block_00374F40;
    }
block_00374F40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374F40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374F40U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, r2, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00375094; }
        goto block_00374F50;
    }
block_00374F50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374F50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374F50U);
        }
        {
            const uint32_t updatedAddress = r3 + 0x710U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374F50U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000800U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000800U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) { goto block_00374F8C; }
        goto block_00374F5C;
    }
block_00374F5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374F5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374F5CU);
        }
        {
            const uint32_t updatedAddress = r3 + 0x224U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374F5CU, address);
            }
            r5 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00375328; }
        goto block_00374F68;
    }
block_00374F68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374F68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374F68U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) { goto block_00374F8C; }
        goto block_00374F70;
    }
block_00374F70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374F70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374F70U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, r2, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r5, r1, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_00374F8C; }
        goto block_00374F7C;
    }
block_00374F7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374F7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374F7CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374F80U, address);
            }
            r5 = value;
        }
        if (!(flags.Z())) {
            const uint32_t value = r5 & 0x00010000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00010000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_00375328; }
        goto block_00374F8C;
    }
block_00374F8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374F8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374F8CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x90U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374F8CU, address);
            }
            r5 = value;
        }
        {
            const uint32_t value = r5 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00374FBC; }
        goto block_00374F98;
    }
block_00374F98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374F98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374F98U);
        }
        {
            const uint32_t updatedAddress = r3 + 0x714U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374F98U, address);
            }
            r5 = value;
        }
        {
            const uint32_t value = r5 & 0x00000400U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000400U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x1A7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374FA0U, address);
            }
            r5 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        if (!(flags.Z())) { goto block_00374FBC; }
        goto block_00374FAC;
    }
block_00374FAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374FACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374FACU);
        }
        {
            const uint32_t updatedAddress = 0x00374FB4U + 0x314U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374FACU, address);
            }
            r5 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374FB0U, address);
            }
            r5 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000007U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        if (!(flags.Z())) { goto block_00374FE4; }
        goto block_00374FBC;
    }
block_00374FBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374FBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374FBCU);
        }
        {
            const uint32_t value = r0 & 0x00800000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00800000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00374FEC; }
        goto block_00374FC4;
    }
block_00374FC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374FC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374FC4U);
        }
        {
            const uint32_t value = r0 & 0x08000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x08000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x1A7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374FC8U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00375328; }
        goto block_00374FD4;
    }
block_00374FD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374FD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374FD4U);
        }
        {
            const uint32_t updatedAddress = r3 + 0x714U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374FD4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000400U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000400U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_00374FE0;
    }
block_00374FE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374FE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374FE0U);
        }
        goto block_00375004;
    }
block_00374FE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374FE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374FE4U);
        }
        {
            const uint32_t value = r0 & 0x00800000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00800000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00375004; }
        goto block_00374FEC;
    }
block_00374FEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374FECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374FECU);
        }
        {
            const uint32_t updatedAddress = r3 + 0x2B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374FECU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x00374FF8U + 724U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374FF0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374FF4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00374FF8U, 0xEEF40A40U};
            const auto comparison = a32::VfpBinary32Compare(
                frame.Guest.vfp[1], frame.Guest.vfp[0],
                false);
            frame.Guest.fpscr = (frame.Guest.fpscr & ~0xF0000000U) |
                          (comparison.value & 0xF0000000U);
            frame.Guest.fpscr |= comparison.exception_flags;
        }
        {
            flags.AssignPackedNzcv(frame.Guest.fpscr);
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_00375004;
    }
block_00375004:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375004U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375004U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) { goto block_0037503C; }
        goto block_0037500C;
    }
block_0037500C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037500CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037500CU);
        }
        {
            const uint32_t updatedAddress = 0x00375014U + 0x2BCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037500CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375010U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0037501CU + 0x2B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375014U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r3 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375018U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037501CU, address);
            }
            r0 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r3, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375024U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t value = r0 & 0x00010000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00010000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_00375030;
    }
block_00375030:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375030U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375030U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00375328; }
        goto block_00375038;
    }
block_00375038:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375038U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375038U);
        }
        goto block_00375044;
    }
block_0037503C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037503CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037503CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00375328; }
        goto block_00375044;
    }
block_00375044:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375044U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375044U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r12, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            r0 = 0x00000000U;
        }
        if (!(flags.Z())) { goto block_00375058; }
        goto block_00375050;
    }
block_00375050:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375050U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375050U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r14, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0037506C; }
        goto block_00375058;
    }
block_00375058:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375058U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375058U);
        }
        {
            const uint32_t updatedAddress = 0x00375060U + 0x230U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375058U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037505CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t operand = 0x00000000U;
            r0 = operand - r0;
        }
        goto block_00375078;
    }
block_0037506C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037506CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037506CU);
        }
        {
            const uint32_t updatedAddress = r1 + 0x123U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037506CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000600U;
            r0 = r1 + operand;
        }
        goto block_00375078;
    }
block_00375078:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375078U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375078U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x9DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037507CU, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r1 + 0x9DCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00375084U, address);
            }
        }
        if (!(flags.Z())) {
            r0 = 0x00000001U;
        }
        if (flags.Z()) {
            r0 = ~(0x00000000U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00375090U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00375090U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00375090U,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00375090U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
block_00375094:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375094U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375094U);
        }
        {
            const uint32_t updatedAddress = 0x0037509CU + 0x23CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375094U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r1 + r4;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0037509CU, address);
            }
        }
        goto block_00375328;
    }
block_003750A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003750A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003750A4U);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003750ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Play_IsGameplayActive_0033BD6C(frame, context, state, 0x0033BD6CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003750ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003750AC;
    }
block_003750AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003750ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003750ACU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00375328; }
        goto block_003750B8;
    }
block_003750B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003750B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003750B8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x147U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003750B8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_003750C4;
    }
block_003750C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003750C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003750C4U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = 0x003750D0U + 0x20CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003750C8U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x710U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003750CCU, address);
            }
            r1 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r2, 0U, 0U, flags.C());
            const uint32_t value = r1 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_003750E4; }
        goto block_003750D8;
    }
block_003750D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003750D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003750D8U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x749U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003750D8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_003750E4;
    }
block_003750E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003750E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003750E4U);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x003750ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_HoldsHookshot_00355A60(frame, context, state, 0x00355A60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x003750ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_003750EC;
    }
block_003750EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003750ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003750ECU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00375328; }
        goto block_003750F8;
    }
block_003750F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003750F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003750F8U);
        }
        goto block_00375320;
    }
block_003750FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003750FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003750FCU);
        }
        {
            const uint32_t updatedAddress = 0x00375104U + 0x1DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003750FCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00375108U + 0x1DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375100U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375104U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00375138; }
        goto block_00375110;
    }
block_00375110:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375110U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375110U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1AAU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375110U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FEU, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_00375138; }
        goto block_0037511C;
    }
block_0037511C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037511CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037511CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FCU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000059U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00375138; }
        goto block_00375128;
    }
block_00375128:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375128U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375128U);
        }
        {
            const uint32_t updatedAddress = 0x00375130U + 0x1B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375128U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r0;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037512CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00375320; }
        goto block_00375138;
    }
block_00375138:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375138U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375138U);
        }
        {
            const uint32_t updatedAddress = 0x00375140U + 0x13CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375138U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00375144U + 0x1A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037513CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375140U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x00375150U + 0x1A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375148U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x00375158U + 0x19CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375150U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_0037515C;
    }
block_0037515C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037515CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037515CU);
        }
        goto block_00375320;
    }
block_00375160:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375160U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375160U);
        }
        {
            const uint32_t updatedAddress = 0x00375168U + 0x114U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375160U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0037516CU + 0x18CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375164U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375168U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_00375174;
    }
block_00375174:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375174U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375174U);
        }
        goto block_00375320;
    }
block_00375178:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375178U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375178U);
        }
        {
            const uint32_t updatedAddress = 0x00375180U + 0xFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375178U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00375184U + 0x174U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037517CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375180U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x284U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375188U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000007DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_00375194;
    }
block_00375194:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375194U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375194U);
        }
        goto block_00375320;
    }
block_00375198:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375198U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375198U);
        }
        {
            const uint32_t updatedAddress = 0x003751A0U + 0xDCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375198U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x003751A4U + 0x158U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037519CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003751A0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00375320; }
        goto block_003751AC;
    }
block_003751AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003751ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003751ACU);
        }
        {
            const uint32_t updatedAddress = 0x003751B4U + 0x12CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003751ACU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x003751B8U + 0x148U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003751B0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003751B4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_003751C0;
    }
block_003751C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003751C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003751C0U);
        }
        goto block_00375320;
    }
block_003751C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003751C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003751C4U);
        }
        {
            const uint32_t updatedAddress = 0x003751CCU + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003751C4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003751C8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000100U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000100U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_00375328; }
        goto block_003751D4;
    }
block_003751D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003751D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003751D4U);
        }
        goto block_00375320;
    }
block_003751D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003751D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003751D8U);
        }
        {
            const uint32_t updatedAddress = 0x003751E0U + 0x9CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003751D8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x003751E4U + 0xB4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003751DCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003751E0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x003751F0U + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003751E8U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x003751F8U + 0xA8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003751F0U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00375320; }
        goto block_003751FC;
    }
block_003751FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003751FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003751FCU);
        }
        {
            const uint32_t updatedAddress = 0x00375204U + 0xA0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003751FCU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_00375208;
    }
block_00375208:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375208U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375208U);
        }
        {
            const uint32_t updatedAddress = 0x00375210U + 0x98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375208U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037520CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000018U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_00375328; }
        goto block_00375218;
    }
block_00375218:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375218U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375218U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00375328; }
        goto block_00375220;
    }
block_00375220:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375220U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375220U);
        }
        goto block_00375320;
    }
block_00375224:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375224U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375224U);
        }
        {
            const uint32_t updatedAddress = 0x0037522CU + 0xD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375224U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00375230U + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375228U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037522CU, address);
            }
            r0 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_00375328; }
        goto block_00375238;
    }
block_00375238:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375238U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375238U);
        }
        goto block_00375320;
    }
block_0037523C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037523CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037523CU);
        }
        {
            const uint32_t updatedAddress = 0x00375244U + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037523CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375240U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000080U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_00375328; }
        goto block_0037524C;
    }
block_0037524C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037524CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037524CU);
        }
        goto block_00375320;
    }
block_00375250:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375250U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375250U);
        }
        {
            const uint32_t updatedAddress = 0x00375258U + 0xB0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375250U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375254U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00375328; }
        goto block_00375260;
    }
block_00375260:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375260U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375260U);
        }
        goto block_00375320;
    }
block_00375264:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375264U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375264U);
        }
        {
            const uint32_t updatedAddress = 0x0037526CU + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375264U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00375270U + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375268U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037526CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_00375278;
    }
block_00375278:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375278U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375278U);
        }
        goto block_00375320;
    }
block_0037530C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037530CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037530CU);
        }
        {
            const uint32_t updatedAddress = 0x00375314U - 0x98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037530CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00375318U - 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375310U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375314U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_00375320;
    }
block_00375320:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375320U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375320U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00375324U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00375324U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00375324U,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00375324U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
block_00375328:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375328U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375328U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0037532CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0037532CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0037532CU,
                                           firstAddress + 8U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0037532CU,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r13 = r13 + 16U;
            return Oot3dAotReturned(value15);
        }
    }
block_00375330:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375330U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375330U);
        }
        {
            const uint32_t updatedAddress = 0x00375338U - 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375330U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0037533CU + 0x12CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375334U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375338U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_00375344;
    }
block_00375344:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375344U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375344U);
        }
        goto block_00375320;
    }
block_00375348:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375348U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375348U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x284U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375348U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r0 - operand;
        }
        {
            const uint32_t operand = 0x0000007AU;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r1 = r1 - operand;
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_00375358;
    }
block_00375358:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375358U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375358U);
        }
        goto block_00375320;
    }
block_0037535C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037535CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037535CU);
        }
        {
            const uint32_t updatedAddress = 0x00375364U - 0x60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037535CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00375368U - 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375360U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375364U, address);
            }
            r0 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_00375328; }
        goto block_00375370;
    }
block_00375370:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375370U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375370U);
        }
        {
            const uint32_t updatedAddress = 0x00375378U - 0x98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375370U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0037537CU + 0xF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375374U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375378U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_00375384;
    }
block_00375384:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375384U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375384U);
        }
        goto block_00375320;
    }
block_00375388:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375388U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375388U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = 0x00375394U + 0xDCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037538CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x708U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375390U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x224U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375394U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r3, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x90U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037539CU, address);
            }
            r2 = value;
        }
        if (flags.Z()) {
            const uint32_t value = r2 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_003753A8;
    }
block_003753A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003753A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003753A8U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x710U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003753A8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000800U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000800U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00375328; }
        goto block_003753B8;
    }
block_003753B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003753B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003753B8U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003753B8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000019U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_003753C4;
    }
block_003753C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003753C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003753C4U);
        }
        goto block_00375320;
    }
block_003753C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003753C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003753C8U);
        }
        {
            const uint32_t updatedAddress = 0x003753D0U - 0xF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003753C8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x003753D4U + 0x98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003753CCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003753D0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_003753DC;
    }
block_003753DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003753DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003753DCU);
        }
        goto block_00375320;
    }
block_003753E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003753E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003753E0U);
        }
        {
            r0 = r4;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x003753E4U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x003753E4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x003753E4U,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x003753E4U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r14 = value14;
            r13 = r13 + 16U;
        }
        return Oot3dAotBranch(0x003518CCU);
    }
block_003753EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003753ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003753ECU);
        }
        {
            const uint32_t updatedAddress = 0x003753F4U + 0x80U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003753ECU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x003753F0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_003753FC;
    }
block_003753FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003753FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003753FCU);
        }
        goto block_00375320;
    }
block_00375400:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375400U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375400U);
        }
        {
            const uint32_t updatedAddress = 0x00375408U + 0x6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375400U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375404U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_00375410;
    }
block_00375410:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375410U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375410U);
        }
        goto block_00375320;
    }
block_00375414:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375414U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375414U);
        }
        {
            const uint32_t updatedAddress = 0x0037541CU - 0x118U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375414U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375418U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000200U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000200U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_00375328; }
        goto block_00375424;
    }
block_00375424:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375424U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375424U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = r0 + 576U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375428U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x3E800000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00375328; }
        goto block_00375438;
    }
block_00375438:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375438U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375438U);
        }
        goto block_00375320;
    }
block_0037543C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0037543CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0037543CU);
        }
        {
            const uint32_t updatedAddress = 0x00375444U - 0x1C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0037543CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x00375448U + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375440U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375444U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00375328; }
        goto block_00375450;
    }
block_00375450:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375450U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375450U);
        }
        goto block_00375320;
    }
block_00375454:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375454U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375454U);
        }
        {
            const uint32_t updatedAddress = 0x0037545CU - 0x158U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375454U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00375458U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00800000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00800000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_00375328; }
        goto block_00375464;
    }
block_00375464:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00375464U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00375464U);
        }
        goto block_00375320;
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_PauseTouchButtons_Update_0042DF3C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0042DF3CU:
        goto block_0042DF3C;
    case 0x0042DF58U:
        goto block_0042DF58;
    case 0x0042DF68U:
        goto block_0042DF68;
    case 0x0042DF8CU:
        goto block_0042DF8C;
    case 0x0042DF9CU:
        goto block_0042DF9C;
    case 0x0042DFB8U:
        goto block_0042DFB8;
    case 0x0042DFC8U:
        goto block_0042DFC8;
    case 0x0042DFD0U:
        goto block_0042DFD0;
    case 0x0042DFDCU:
        goto block_0042DFDC;
    case 0x0042DFE4U:
        goto block_0042DFE4;
    case 0x0042DFFCU:
        goto block_0042DFFC;
    case 0x0042E010U:
        goto block_0042E010;
    case 0x0042E020U:
        goto block_0042E020;
    case 0x0042E030U:
        goto block_0042E030;
    case 0x0042E040U:
        goto block_0042E040;
    case 0x0042E04CU:
        goto block_0042E04C;
    case 0x0042E058U:
        goto block_0042E058;
    case 0x0042E060U:
        goto block_0042E060;
    case 0x0042E078U:
        goto block_0042E078;
    case 0x0042E088U:
        goto block_0042E088;
    case 0x0042E0A8U:
        goto block_0042E0A8;
    case 0x0042E0B8U:
        goto block_0042E0B8;
    case 0x0042E0C0U:
        goto block_0042E0C0;
    case 0x0042E0CCU:
        goto block_0042E0CC;
    case 0x0042E0D4U:
        goto block_0042E0D4;
    case 0x0042E0ECU:
        goto block_0042E0EC;
    case 0x0042E0FCU:
        goto block_0042E0FC;
    case 0x0042E110U:
        goto block_0042E110;
    case 0x0042E11CU:
        goto block_0042E11C;
    case 0x0042E124U:
        goto block_0042E124;
    case 0x0042E130U:
        goto block_0042E130;
    case 0x0042E140U:
        goto block_0042E140;
    case 0x0042E150U:
        goto block_0042E150;
    case 0x0042E160U:
        goto block_0042E160;
    case 0x0042E16CU:
        goto block_0042E16C;
    case 0x0042E178U:
        goto block_0042E178;
    case 0x0042E188U:
        goto block_0042E188;
    case 0x0042E194U:
        goto block_0042E194;
    case 0x0042E1A4U:
        goto block_0042E1A4;
    case 0x0042E1B0U:
        goto block_0042E1B0;
    case 0x0042E1B8U:
        goto block_0042E1B8;
    case 0x0042E1D0U:
        goto block_0042E1D0;
    case 0x0042E1E0U:
        goto block_0042E1E0;
    case 0x0042E200U:
        goto block_0042E200;
    case 0x0042E20CU:
        goto block_0042E20C;
    case 0x0042E218U:
        goto block_0042E218;
    case 0x0042E224U:
        goto block_0042E224;
    case 0x0042E230U:
        goto block_0042E230;
    case 0x0042E248U:
        goto block_0042E248;
    case 0x0042E250U:
        goto block_0042E250;
    case 0x0042E254U:
        goto block_0042E254;
    case 0x0042E278U:
        goto block_0042E278;
    case 0x0042E284U:
        goto block_0042E284;
    case 0x0042E290U:
        goto block_0042E290;
    case 0x0042E29CU:
        goto block_0042E29C;
    case 0x0042E2A8U:
        goto block_0042E2A8;
    case 0x0042E2B4U:
        goto block_0042E2B4;
    case 0x0042E2C0U:
        goto block_0042E2C0;
    case 0x0042E2CCU:
        goto block_0042E2CC;
    case 0x0042E2D8U:
        goto block_0042E2D8;
    case 0x0042E2E4U:
        goto block_0042E2E4;
    case 0x0042E2F0U:
        goto block_0042E2F0;
    case 0x0042E308U:
        goto block_0042E308;
    case 0x0042E314U:
        goto block_0042E314;
    case 0x0042E320U:
        goto block_0042E320;
    case 0x0042E33CU:
        goto block_0042E33C;
    case 0x0042E348U:
        goto block_0042E348;
    case 0x0042E354U:
        goto block_0042E354;
    case 0x0042E36CU:
        goto block_0042E36C;
    case 0x0042E390U:
        goto block_0042E390;
    case 0x0042E3A0U:
        goto block_0042E3A0;
    case 0x0042E400U:
        goto block_0042E400;
    case 0x0042E414U:
        goto block_0042E414;
    case 0x0042E420U:
        goto block_0042E420;
    case 0x0042E42CU:
        goto block_0042E42C;
    case 0x0042E43CU:
        goto block_0042E43C;
    case 0x0042E450U:
        goto block_0042E450;
    case 0x0042E4F4U:
        goto block_0042E4F4;
    case 0x0042E504U:
        goto block_0042E504;
    case 0x0042E510U:
        goto block_0042E510;
    case 0x0042E51CU:
        goto block_0042E51C;
    case 0x0042E528U:
        goto block_0042E528;
    case 0x0042E540U:
        goto block_0042E540;
    case 0x0042E550U:
        goto block_0042E550;
    case 0x0042E568U:
        goto block_0042E568;
    case 0x0042E58CU:
        goto block_0042E58C;
    case 0x0042E5ECU:
        goto block_0042E5EC;
    case 0x0042E5F4U:
        goto block_0042E5F4;
    case 0x0042E618U:
        goto block_0042E618;
    case 0x0042E620U:
        goto block_0042E620;
    case 0x0042E630U:
        goto block_0042E630;
    case 0x0042E638U:
        goto block_0042E638;
    case 0x0042E644U:
        goto block_0042E644;
    case 0x0042E648U:
        goto block_0042E648;
    case 0x0042E654U:
        goto block_0042E654;
    case 0x0042E668U:
        goto block_0042E668;
    case 0x0042E66CU:
        goto block_0042E66C;
    case 0x0042E678U:
        goto block_0042E678;
    case 0x0042E67CU:
        goto block_0042E67C;
    case 0x0042E688U:
        goto block_0042E688;
    case 0x0042E690U:
        goto block_0042E690;
    case 0x0042E69CU:
        goto block_0042E69C;
    case 0x0042E6A0U:
        goto block_0042E6A0;
    case 0x0042E6ACU:
        goto block_0042E6AC;
    case 0x0042E6B0U:
        goto block_0042E6B0;
    case 0x0042E6BCU:
        goto block_0042E6BC;
    case 0x0042E6C0U:
        goto block_0042E6C0;
    case 0x0042E6CCU:
        goto block_0042E6CC;
    case 0x0042E6D4U:
        goto block_0042E6D4;
    case 0x0042E6E0U:
        goto block_0042E6E0;
    case 0x0042E6F0U:
        goto block_0042E6F0;
    case 0x0042E6F8U:
        goto block_0042E6F8;
    case 0x0042E704U:
        goto block_0042E704;
    case 0x0042E70CU:
        goto block_0042E70C;
    case 0x0042E724U:
        goto block_0042E724;
    case 0x0042E734U:
        goto block_0042E734;
    case 0x0042E738U:
        goto block_0042E738;
    case 0x0042E744U:
        goto block_0042E744;
    case 0x0042E764U:
        goto block_0042E764;
    case 0x0042E77CU:
        goto block_0042E77C;
    case 0x0042E794U:
        goto block_0042E794;
    case 0x0042E7A0U:
        goto block_0042E7A0;
    case 0x0042E7BCU:
        goto block_0042E7BC;
    case 0x0042E7D4U:
        goto block_0042E7D4;
    case 0x0042E7ECU:
        goto block_0042E7EC;
    case 0x0042E7F4U:
        goto block_0042E7F4;
    case 0x0042E800U:
        goto block_0042E800;
    case 0x0042E818U:
        goto block_0042E818;
    case 0x0042E834U:
        goto block_0042E834;
    case 0x0042E840U:
        goto block_0042E840;
    case 0x0042E844U:
        goto block_0042E844;
    case 0x0042E854U:
        goto block_0042E854;
    case 0x0042E860U:
        goto block_0042E860;
    case 0x0042E86CU:
        goto block_0042E86C;
    case 0x0042E874U:
        goto block_0042E874;
    case 0x0042E890U:
        goto block_0042E890;
    case 0x0042E89CU:
        goto block_0042E89C;
    case 0x0042E8A0U:
        goto block_0042E8A0;
    case 0x0042E8B0U:
        goto block_0042E8B0;
    case 0x0042E8BCU:
        goto block_0042E8BC;
    case 0x0042E8C8U:
        goto block_0042E8C8;
    case 0x0042E8D0U:
        goto block_0042E8D0;
    case 0x0042E8ECU:
        goto block_0042E8EC;
    case 0x0042E8F8U:
        goto block_0042E8F8;
    case 0x0042E8FCU:
        goto block_0042E8FC;
    case 0x0042E90CU:
        goto block_0042E90C;
    case 0x0042E910U:
        goto block_0042E910;
    case 0x0042E91CU:
        goto block_0042E91C;
    case 0x0042E928U:
        goto block_0042E928;
    case 0x0042E934U:
        goto block_0042E934;
    case 0x0042E938U:
        goto block_0042E938;
    case 0x0042E940U:
        goto block_0042E940;
    case 0x0042E95CU:
        goto block_0042E95C;
    case 0x0042E968U:
        goto block_0042E968;
    case 0x0042E96CU:
        goto block_0042E96C;
    case 0x0042E978U:
        goto block_0042E978;
    case 0x0042E97CU:
        goto block_0042E97C;
    case 0x0042E988U:
        goto block_0042E988;
    case 0x0042E98CU:
        goto block_0042E98C;
    case 0x0042E99CU:
        goto block_0042E99C;
    case 0x0042E9A0U:
        goto block_0042E9A0;
    case 0x0042E9B0U:
        goto block_0042E9B0;
    case 0x0042E9CCU:
        goto block_0042E9CC;
    case 0x0042E9D8U:
        goto block_0042E9D8;
    case 0x0042E9DCU:
        goto block_0042E9DC;
    case 0x0042E9E4U:
        goto block_0042E9E4;
    case 0x0042E9E8U:
        goto block_0042E9E8;
    case 0x0042E9F4U:
        goto block_0042E9F4;
    case 0x0042EA10U:
        goto block_0042EA10;
    case 0x0042EA1CU:
        goto block_0042EA1C;
    case 0x0042EA70U:
        goto block_0042EA70;
    case 0x0042EA88U:
        goto block_0042EA88;
    case 0x0042EAA0U:
        goto block_0042EAA0;
    case 0x0042EAACU:
        goto block_0042EAAC;
    case 0x0042EAB8U:
        goto block_0042EAB8;
    case 0x0042EAD4U:
        goto block_0042EAD4;
    case 0x0042EAE0U:
        goto block_0042EAE0;
    case 0x0042EB00U:
        goto block_0042EB00;
    case 0x0042EB14U:
        goto block_0042EB14;
    case 0x0042EB20U:
        goto block_0042EB20;
    case 0x0042EB30U:
        goto block_0042EB30;
    case 0x0042EB4CU:
        goto block_0042EB4C;
    case 0x0042EB60U:
        goto block_0042EB60;
    case 0x0042EB6CU:
        goto block_0042EB6C;
    case 0x0042EB7CU:
        goto block_0042EB7C;
    case 0x0042EB98U:
        goto block_0042EB98;
    case 0x0042EBACU:
        goto block_0042EBAC;
    case 0x0042EBB8U:
        goto block_0042EBB8;
    case 0x0042EBD0U:
        goto block_0042EBD0;
    case 0x0042EBECU:
        goto block_0042EBEC;
    case 0x0042EC00U:
        goto block_0042EC00;
    case 0x0042EC0CU:
        goto block_0042EC0C;
    case 0x0042EC24U:
        goto block_0042EC24;
    case 0x0042EC2CU:
        goto block_0042EC2C;
    case 0x0042EC38U:
        goto block_0042EC38;
    case 0x0042EC44U:
        goto block_0042EC44;
    case 0x0042EC48U:
        goto block_0042EC48;
    case 0x0042EC54U:
        goto block_0042EC54;
    case 0x0042EC5CU:
        goto block_0042EC5C;
    case 0x0042EC68U:
        goto block_0042EC68;
    case 0x0042EC7CU:
        goto block_0042EC7C;
    case 0x0042EC80U:
        goto block_0042EC80;
    case 0x0042EC8CU:
        goto block_0042EC8C;
    case 0x0042EC9CU:
        goto block_0042EC9C;
    case 0x0042ECB0U:
        goto block_0042ECB0;
    case 0x0042ECB4U:
        goto block_0042ECB4;
    case 0x0042ECC0U:
        goto block_0042ECC0;
    case 0x0042ECD0U:
        goto block_0042ECD0;
    case 0x0042ECE8U:
        goto block_0042ECE8;
    case 0x0042ECECU:
        goto block_0042ECEC;
    case 0x0042ECF8U:
        goto block_0042ECF8;
    case 0x0042ED00U:
        goto block_0042ED00;
    case 0x0042ED08U:
        goto block_0042ED08;
    case 0x0042ED20U:
        goto block_0042ED20;
    case 0x0042ED24U:
        goto block_0042ED24;
    case 0x0042ED30U:
        goto block_0042ED30;
    case 0x0042ED34U:
        goto block_0042ED34;
    case 0x0042ED3CU:
        goto block_0042ED3C;
    case 0x0042ED44U:
        goto block_0042ED44;
    case 0x0042ED50U:
        goto block_0042ED50;
    case 0x0042ED54U:
        goto block_0042ED54;
    case 0x0042ED60U:
        goto block_0042ED60;
    case 0x0042ED6CU:
        goto block_0042ED6C;
    case 0x0042ED74U:
        goto block_0042ED74;
    case 0x0042ED80U:
        goto block_0042ED80;
    case 0x0042EDD4U:
        goto block_0042EDD4;
    case 0x0042EDDCU:
        goto block_0042EDDC;
    case 0x0042EDE8U:
        goto block_0042EDE8;
    case 0x0042EDF4U:
        goto block_0042EDF4;
    case 0x0042EE00U:
        goto block_0042EE00;
    case 0x0042EE08U:
        goto block_0042EE08;
    case 0x0042EE14U:
        goto block_0042EE14;
    case 0x0042EE18U:
        goto block_0042EE18;
    case 0x0042EE20U:
        goto block_0042EE20;
    case 0x0042EE2CU:
        goto block_0042EE2C;
    case 0x0042EE38U:
        goto block_0042EE38;
    case 0x0042EE44U:
        goto block_0042EE44;
    case 0x0042EE50U:
        goto block_0042EE50;
    case 0x0042EE6CU:
        goto block_0042EE6C;
    case 0x0042EE78U:
        goto block_0042EE78;
    case 0x0042EE80U:
        goto block_0042EE80;
    case 0x0042EE8CU:
        goto block_0042EE8C;
    case 0x0042EE98U:
        goto block_0042EE98;
    case 0x0042EE9CU:
        goto block_0042EE9C;
    case 0x0042EEA4U:
        goto block_0042EEA4;
    case 0x0042EEB0U:
        goto block_0042EEB0;
    case 0x0042EEB8U:
        goto block_0042EEB8;
    case 0x0042EEC4U:
        goto block_0042EEC4;
    case 0x0042EED0U:
        goto block_0042EED0;
    case 0x0042EED8U:
        goto block_0042EED8;
    case 0x0042EEE4U:
        goto block_0042EEE4;
    case 0x0042EEF0U:
        goto block_0042EEF0;
    case 0x0042EEFCU:
        goto block_0042EEFC;
    case 0x0042EF08U:
        goto block_0042EF08;
    case 0x0042EF10U:
        goto block_0042EF10;
    case 0x0042EF1CU:
        goto block_0042EF1C;
    case 0x0042EF20U:
        goto block_0042EF20;
    case 0x0042EF28U:
        goto block_0042EF28;
    case 0x0042EF34U:
        goto block_0042EF34;
    case 0x0042EF40U:
        goto block_0042EF40;
    case 0x0042EF4CU:
        goto block_0042EF4C;
    case 0x0042EF58U:
        goto block_0042EF58;
    case 0x0042EF74U:
        goto block_0042EF74;
    case 0x0042EF80U:
        goto block_0042EF80;
    case 0x0042EF88U:
        goto block_0042EF88;
    case 0x0042EF94U:
        goto block_0042EF94;
    case 0x0042EFA0U:
        goto block_0042EFA0;
    case 0x0042EFA4U:
        goto block_0042EFA4;
    case 0x0042EFACU:
        goto block_0042EFAC;
    case 0x0042EFB8U:
        goto block_0042EFB8;
    case 0x0042EFBCU:
        goto block_0042EFBC;
    case 0x0042EFC8U:
        goto block_0042EFC8;
    case 0x0042EFD4U:
        goto block_0042EFD4;
    case 0x0042EFE0U:
        goto block_0042EFE0;
    case 0x0042EFECU:
        goto block_0042EFEC;
    case 0x0042EFF4U:
        goto block_0042EFF4;
    case 0x0042F000U:
        goto block_0042F000;
    case 0x0042F004U:
        goto block_0042F004;
    case 0x0042F00CU:
        goto block_0042F00C;
    case 0x0042F018U:
        goto block_0042F018;
    case 0x0042F024U:
        goto block_0042F024;
    case 0x0042F030U:
        goto block_0042F030;
    case 0x0042F03CU:
        goto block_0042F03C;
    case 0x0042F058U:
        goto block_0042F058;
    case 0x0042F064U:
        goto block_0042F064;
    case 0x0042F06CU:
        goto block_0042F06C;
    case 0x0042F078U:
        goto block_0042F078;
    case 0x0042F084U:
        goto block_0042F084;
    case 0x0042F088U:
        goto block_0042F088;
    case 0x0042F090U:
        goto block_0042F090;
    case 0x0042F09CU:
        goto block_0042F09C;
    case 0x0042F0A0U:
        goto block_0042F0A0;
    case 0x0042F0ACU:
        goto block_0042F0AC;
    case 0x0042F0B8U:
        goto block_0042F0B8;
    case 0x0042F0C4U:
        goto block_0042F0C4;
    case 0x0042F0D0U:
        goto block_0042F0D0;
    case 0x0042F0D8U:
        goto block_0042F0D8;
    case 0x0042F0E4U:
        goto block_0042F0E4;
    case 0x0042F0E8U:
        goto block_0042F0E8;
    case 0x0042F0F0U:
        goto block_0042F0F0;
    case 0x0042F0F8U:
        goto block_0042F0F8;
    case 0x0042F104U:
        goto block_0042F104;
    case 0x0042F110U:
        goto block_0042F110;
    case 0x0042F12CU:
        goto block_0042F12C;
    case 0x0042F138U:
        goto block_0042F138;
    case 0x0042F164U:
        goto block_0042F164;
    case 0x0042F170U:
        goto block_0042F170;
    case 0x0042F174U:
        goto block_0042F174;
    case 0x0042F17CU:
        goto block_0042F17C;
    case 0x0042F188U:
        goto block_0042F188;
    case 0x0042F18CU:
        goto block_0042F18C;
    case 0x0042F198U:
        goto block_0042F198;
    case 0x0042F1B4U:
        goto block_0042F1B4;
    case 0x0042F1C0U:
        goto block_0042F1C0;
    case 0x0042F1CCU:
        goto block_0042F1CC;
    case 0x0042F1D0U:
        goto block_0042F1D0;
    case 0x0042F1D8U:
        goto block_0042F1D8;
    case 0x0042F1E8U:
        goto block_0042F1E8;
    case 0x0042F1F0U:
        goto block_0042F1F0;
    case 0x0042F1FCU:
        goto block_0042F1FC;
    case 0x0042F20CU:
        goto block_0042F20C;
    case 0x0042F214U:
        goto block_0042F214;
    case 0x0042F220U:
        goto block_0042F220;
    case 0x0042F228U:
        goto block_0042F228;
    case 0x0042F22CU:
        goto block_0042F22C;
    case 0x0042F234U:
        goto block_0042F234;
    case 0x0042F23CU:
        goto block_0042F23C;
    case 0x0042F248U:
        goto block_0042F248;
    case 0x0042F250U:
        goto block_0042F250;
    case 0x0042F25CU:
        goto block_0042F25C;
    case 0x0042F268U:
        goto block_0042F268;
    case 0x0042F270U:
        goto block_0042F270;
    case 0x0042F27CU:
        goto block_0042F27C;
    case 0x0042F288U:
        goto block_0042F288;
    case 0x0042F294U:
        goto block_0042F294;
    case 0x0042F29CU:
        goto block_0042F29C;
    case 0x0042F2A8U:
        goto block_0042F2A8;
    case 0x0042F2B4U:
        goto block_0042F2B4;
    case 0x0042F2C0U:
        goto block_0042F2C0;
    case 0x0042F2C4U:
        goto block_0042F2C4;
    case 0x0042F2D0U:
        goto block_0042F2D0;
    case 0x0042F2DCU:
        goto block_0042F2DC;
    case 0x0042F2F0U:
        goto block_0042F2F0;
    case 0x0042F324U:
        goto block_0042F324;
    case 0x0042F330U:
        goto block_0042F330;
    case 0x0042F338U:
        goto block_0042F338;
    case 0x0042F33CU:
        goto block_0042F33C;
    case 0x0042F348U:
        goto block_0042F348;
    case 0x0042F350U:
        goto block_0042F350;
    case 0x0042F354U:
        goto block_0042F354;
    case 0x0042F358U:
        goto block_0042F358;
    case 0x0042F35CU:
        goto block_0042F35C;
    case 0x0042F360U:
        goto block_0042F360;
    case 0x0042F36CU:
        goto block_0042F36C;
    case 0x0042F370U:
        goto block_0042F370;
    case 0x0042F37CU:
        goto block_0042F37C;
    case 0x0042F384U:
        goto block_0042F384;
    case 0x0042F38CU:
        goto block_0042F38C;
    case 0x0042F390U:
        goto block_0042F390;
    case 0x0042F39CU:
        goto block_0042F39C;
    case 0x0042F3A0U:
        goto block_0042F3A0;
    case 0x0042F3ACU:
        goto block_0042F3AC;
    case 0x0042F3C0U:
        goto block_0042F3C0;
    case 0x0042F3D4U:
        goto block_0042F3D4;
    case 0x0042F3E8U:
        goto block_0042F3E8;
    case 0x0042F3F8U:
        goto block_0042F3F8;
    case 0x0042F400U:
        goto block_0042F400;
    case 0x0042F40CU:
        goto block_0042F40C;
    case 0x0042F418U:
        goto block_0042F418;
    case 0x0042F424U:
        goto block_0042F424;
    case 0x0042F45CU:
        goto block_0042F45C;
    case 0x0042F464U:
        goto block_0042F464;
    case 0x0042F470U:
        goto block_0042F470;
    case 0x0042F490U:
        goto block_0042F490;
    case 0x0042F49CU:
        goto block_0042F49C;
    case 0x0042F4A8U:
        goto block_0042F4A8;
    case 0x0042F4B0U:
        goto block_0042F4B0;
    case 0x0042F4BCU:
        goto block_0042F4BC;
    case 0x0042F4C8U:
        goto block_0042F4C8;
    case 0x0042F4D4U:
        goto block_0042F4D4;
    case 0x0042F4E0U:
        goto block_0042F4E0;
    case 0x0042F4E8U:
        goto block_0042F4E8;
    case 0x0042F4F8U:
        goto block_0042F4F8;
    case 0x0042F4FCU:
        goto block_0042F4FC;
    case 0x0042F524U:
        goto block_0042F524;
    case 0x0042F534U:
        goto block_0042F534;
    case 0x0042F558U:
        goto block_0042F558;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0042DF3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042DF3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042DF3CU);
        }
        {
            const uint32_t firstAddress = r13 - 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0042DF3CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0042DF3CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0042DF3CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0042DF3CU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0042DF3CU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0042DF3CU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0042DF3CU,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0042DF3CU,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r11)) {
                return Oot3dAotMemoryFault(context, 0x0042DF3CU,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0042DF3CU,
                                           firstAddress + 36U);
            }
            r13 = r13 - 40U;
        }
        {
            const uint32_t updatedAddress = 0x0042DF48U + 0xADCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042DF40U, address);
            }
            r5 = value;
        }
        {
            r13 -= 8U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0042DF44U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0042DF44U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x00000038U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042DF4CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0042F558; }
        goto block_0042DF58;
    }
block_0042DF58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042DF58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042DF58U);
        }
        {
            const uint32_t operand = 0x0000001CU;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000020U;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000024U;
            r0 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042DF68U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseInput_ReadTouch_002F9484(frame, context, state, 0x002F9484U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042DF68U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042DF68;
    }
block_0042DF68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042DF68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042DF68U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042DF68U, address);
            }
            r0 = value;
        }
        {
            r4 = 0x00000000U;
        }
        {
            r8 = r4;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042DF74U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042DF78U, address);
            }
            r0 = value;
        }
        {
            r7 = r4;
        }
        {
            const uint32_t updatedAddress = r0 + 0x100U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042DF80U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) { goto block_0042DFB8; }
        goto block_0042DF8C;
    }
block_0042DF8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042DF8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042DF8CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042DF8CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x101U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042DF90U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0042F558; }
        goto block_0042DF9C;
    }
block_0042DF9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042DF9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042DF9CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042DF9CU, address);
            }
            r4 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x0042DFACU + 0xA7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042DFA4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x0042DFA8U, address);
            }
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00002800U;
            r8 = r4 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x000003A4U;
            r8 = r8 + operand;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042DFB4U, address);
            }
            r7 = value;
        }
        goto block_0042DFB8;
    }
block_0042DFB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042DFB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042DFB8U);
        }
        {
            const uint32_t updatedAddress = 0x0042DFC0U + 0xA6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042DFB8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042DFBCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0042DFFC; }
        goto block_0042DFC8;
    }
block_0042DFC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042DFC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042DFC8U);
        }
        {
            const uint32_t updatedAddress = 0x0042DFD0U + 0xA5CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042DFC8U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042DFD0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042DFD0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042DFD0;
    }
block_0042DFD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042DFD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042DFD0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042DFFC; }
        goto block_0042DFDC;
    }
block_0042DFDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042DFDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042DFDCU);
        }
        {
            const uint32_t updatedAddress = 0x0042DFE4U + 0xA4CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042DFDCU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042DFE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042DFE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042DFE4;
    }
block_0042DFE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042DFE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042DFE4U);
        }
        {
            const uint32_t updatedAddress = 0x0042DFECU + 0xA48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042DFE4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0042DFF0U + 0xA48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042DFE8U, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x0042DFF8U + 0xA34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042DFF0U, address);
            }
            r0 = value;
        }
        {
        }
        {
            r0 = r0;
        }
        goto block_0042DFFC;
    }
block_0042DFFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042DFFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042DFFCU);
        }
        {
            const uint32_t updatedAddress = 0x0042E004U + 0xA38U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042DFFCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E000U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xF38U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E004U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0042E020; }
        goto block_0042E010;
    }
block_0042E010:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E010U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E010U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E010U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0042E058; }
        goto block_0042E020;
    }
block_0042E020:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E020U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E020U);
        }
        {
            const uint32_t updatedAddress = 0x0042E028U + 0xA18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E020U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E024U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_0042E058; }
        goto block_0042E030;
    }
block_0042E030:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E030U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E030U);
        }
        {
            r0 = 0x00000104U;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E034U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0042E060; }
        goto block_0042E040;
    }
block_0042E040:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E040U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E040U);
        }
        {
            r1 = 0x00000038U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E04CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Flags_GetSwitch_0036E864(frame, context, state, 0x0036E864U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E04CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E04C;
    }
block_0042E04C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E04CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E04CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042E060; }
        goto block_0042E058;
    }
block_0042E058:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E058U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E058U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E060U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_003016e0_003016E0(frame, context, state, 0x003016E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E060U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E060;
    }
block_0042E060:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E060U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E060U);
        }
        {
            const uint32_t updatedAddress = 0x0042E068U + 0x9DCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E060U, address);
            }
            r9 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r6 = 0x00000001U;
        }
        {
            r10 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000500U;
            r11 = r9 - operand;
        }
        if (flags.Z()) { goto block_0042E278; }
        goto block_0042E078;
    }
block_0042E078:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E078U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E078U);
        }
        {
            const uint32_t updatedAddress = 0x0042E080U + 0x9C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E078U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E07CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0042E188; }
        goto block_0042E088;
    }
block_0042E088:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E088U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E088U);
        }
        {
            const uint32_t operand = 0x00005C00U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E08CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E090U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x0042E0A0U + 0x9ACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E098U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E09CU, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) { goto block_0042E188; }
        goto block_0042E0A8;
    }
block_0042E0A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E0A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E0A8U);
        }
        {
            const uint32_t updatedAddress = 0x0042E0B0U + 0x97CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E0A8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E0ACU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0042E0EC; }
        goto block_0042E0B8;
    }
block_0042E0B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E0B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E0B8U);
        }
        {
            const uint32_t updatedAddress = 0x0042E0C0U + 0x96CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E0B8U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E0C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E0C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E0C0;
    }
block_0042E0C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E0C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E0C0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042E0EC; }
        goto block_0042E0CC;
    }
block_0042E0CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E0CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E0CCU);
        }
        {
            const uint32_t updatedAddress = 0x0042E0D4U + 0x95CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E0CCU, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E0D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E0D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E0D4;
    }
block_0042E0D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E0D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E0D4U);
        }
        {
            const uint32_t updatedAddress = 0x0042E0DCU + 0x958U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E0D4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0042E0E0U + 0x958U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E0D8U, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x0042E0E8U + 0x944U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E0E0U, address);
            }
            r0 = value;
        }
        {
        }
        {
            r0 = r0;
        }
        goto block_0042E0EC;
    }
block_0042E0EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E0ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E0ECU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E0ECU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF38U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E0F0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0042E188; }
        goto block_0042E0FC;
    }
block_0042E0FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E0FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E0FCU);
        }
        {
            const uint32_t updatedAddress = 0x0042E104U + 0x94CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E0FCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E100U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0042E10CU + 0x948U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E104U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_0042E188; }
        goto block_0042E110;
    }
block_0042E110:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E110U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E110U);
        }
        {
            const uint32_t updatedAddress = r9 + 0xA0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E110U, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0042E188; }
        goto block_0042E11C;
    }
block_0042E11C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E11CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E11CU);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E124U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_InCsMode_0037577C(frame, context, state, 0x0037577CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E124U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E124;
    }
block_0042E124:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E124U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E124U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042E188; }
        goto block_0042E130;
    }
block_0042E130:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E130U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E130U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E130U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x74U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E134U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_0042E188; }
        goto block_0042E140;
    }
block_0042E140:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E140U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E140U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x80U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E140U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000009U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0042E188; }
        goto block_0042E150;
    }
block_0042E150:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E150U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E150U);
        }
        {
            r0 = 0x00000104U;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E154U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0042E178; }
        goto block_0042E160;
    }
block_0042E160:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E160U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E160U);
        }
        {
            r1 = 0x00000038U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E16CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Flags_GetSwitch_0036E864(frame, context, state, 0x0036E864U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E16CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E16C;
    }
block_0042E16C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E16CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E16CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042E188; }
        goto block_0042E178;
    }
block_0042E178:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E178U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E178U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E178U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0xC0000000U);
        }
        {
            r0 = r0 & ~(0x20400000U);
        }
        goto block_0042E194;
    }
block_0042E188:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E188U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E188U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E188U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | 0xC0000000U;
        }
        {
            r0 = r0 | 0x20400000U;
        }
        goto block_0042E194;
    }
block_0042E194:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E194U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E194U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r8, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E19CU, address);
            }
        }
        if (flags.Z()) { goto block_0042E278; }
        goto block_0042E1A4;
    }
block_0042E1A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E1A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E1A4U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E1B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E1B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E1B0;
    }
block_0042E1B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E1B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E1B0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        if (!(flags.Z())) { goto block_0042E1D0; }
        goto block_0042E1B8;
    }
block_0042E1B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E1B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E1B8U);
        }
        {
            const uint32_t updatedAddress = 0x0042E1C0U + 0x898U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E1B8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E1BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xB2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E1C4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000020U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        if (!(flags.Z())) { goto block_0042E1E0; }
        goto block_0042E1D0;
    }
block_0042E1D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E1D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E1D0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E1D0U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & ~(0x10000000U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E1D8U, address);
            }
        }
        goto block_0042E254;
    }
block_0042E1E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E1E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E1E0U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E1E4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x749U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E1E8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = 0x00000230U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r0 + r8;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E1F4U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0042E248; }
        goto block_0042E200;
    }
block_0042E200:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E200U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E200U);
        }
        {
            r1 = 0x0000000CU;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E20CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E20CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E20C;
    }
block_0042E20C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E20CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E20CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042E248; }
        goto block_0042E218;
    }
block_0042E218:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E218U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E218U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E224U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E224U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E224;
    }
block_0042E224:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E224U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E224U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042E248; }
        goto block_0042E230;
    }
block_0042E230:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E230U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E230U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E230U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x749U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E234U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x5U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E23CU, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            r0 = r0 & ~(0x10000000U);
        }
        if (!(flags.Z())) { goto block_0042E250; }
        goto block_0042E248;
    }
block_0042E248:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E248U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E248U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E248U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | 0x10000000U;
        }
        goto block_0042E250;
    }
block_0042E250:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E250U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E250U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E250U, address);
            }
        }
        goto block_0042E254;
    }
block_0042E254:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E254U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E254U);
        }
        {
            const uint32_t updatedAddress = 0x0042E25CU + 0x800U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E254U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r7;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E258U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x08000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x08000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x80U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042E260U, address);
            }
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x80U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0042E264U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x90U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E268U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) {
            r0 = 0x000000FFU;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r11 + 0x575U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E274U, address);
            }
        }
        goto block_0042E278;
    }
block_0042E278:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E278U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E278U);
        }
        {
            r1 = 0x00000008U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E284U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E284U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E284;
    }
block_0042E284:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E284U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E284U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042E2F0; }
        goto block_0042E290;
    }
block_0042E290:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E290U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E290U);
        }
        {
            r1 = 0x00000007U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E29CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E29CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E29C;
    }
block_0042E29C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E29CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E29CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042E2F0; }
        goto block_0042E2A8;
    }
block_0042E2A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E2A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E2A8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E2A8U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000012U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E2B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E2B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E2B4;
    }
block_0042E2B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E2B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E2B4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042E2F0; }
        goto block_0042E2C0;
    }
block_0042E2C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E2C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E2C0U);
        }
        {
            r1 = 0x0000000AU;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E2CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E2CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E2CC;
    }
block_0042E2CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E2CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E2CCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042E2F0; }
        goto block_0042E2D8;
    }
block_0042E2D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E2D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E2D8U);
        }
        {
            r1 = 0x0000000BU;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E2E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E2E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E2E4;
    }
block_0042E2E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E2E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E2E4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042E308; }
        goto block_0042E2F0;
    }
block_0042E2F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E2F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E2F0U);
        }
        {
            r0 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r11 + 0x573U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E2F4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x572U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E2F8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x571U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E2FCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x570U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E300U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x575U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E304U, address);
            }
        }
        goto block_0042E308;
    }
block_0042E308:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E308U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E308U);
        }
        {
            r1 = 0x00000010U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E314U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E314U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E314;
    }
block_0042E314:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E314U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E314U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042E33C; }
        goto block_0042E320;
    }
block_0042E320:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E320U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E320U);
        }
        {
            r0 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r11 + 0x573U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E324U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x572U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E328U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x571U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E32CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x570U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E330U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x575U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E334U, address);
            }
        }
        goto block_0042E400;
    }
block_0042E33C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E33CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E33CU);
        }
        {
            r1 = 0x0000000CU;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E348U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E348U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E348;
    }
block_0042E348:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E348U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E348U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (flags.Z()) { goto block_0042E400; }
        goto block_0042E354;
    }
block_0042E354:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E354U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E354U);
        }
        {
            const uint32_t updatedAddress = 0x0042E35CU + 0x6F4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E354U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r11 + 0x575U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0042E35CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E360U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0042E3A0; }
        goto block_0042E36C;
    }
block_0042E36C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E36CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E36CU);
        }
        {
            const uint32_t updatedAddress = 0x0042E374U + 0x6ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E36CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0042E378U + 0x6ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E370U, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x8AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E374U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r3 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E378U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r12 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E37CU, address);
            }
            r12 = value;
        }
        {
            r0 = r0 & r3;
        }
        {
            r0 = Oot3dAotShiftRegister(r0, 1U, r12, false).Value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0042E3A0; }
        goto block_0042E390;
    }
block_0042E390:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E390U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E390U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x573U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0042E390U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x572U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0042E394U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x571U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0042E398U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x570U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0042E39CU, address);
            }
        }
        goto block_0042E3A0;
    }
block_0042E3A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E3A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E3A0U);
        }
        {
            const uint32_t updatedAddress = r2 + 0x81U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E3A0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000011U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000045U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000046U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r11 + 0x570U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0042E3B4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x82U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E3B8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000011U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000045U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000046U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r11 + 0x571U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0042E3CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x83U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E3D0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000011U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000045U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000046U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r11 + 0x572U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0042E3E4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0x84U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E3E8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000011U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000045U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000046U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r11 + 0x573U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0042E3FCU, address);
            }
        }
        goto block_0042E400;
    }
block_0042E400:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E400U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E400U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r7 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E404U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x6F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E408U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0042E540; }
        goto block_0042E414;
    }
block_0042E414:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E414U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E414U);
        }
        {
            r1 = 0x00000014U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E420U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E420U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E420;
    }
block_0042E420:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E420U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E420U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042E510; }
        goto block_0042E42C;
    }
block_0042E42C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E42CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E42CU);
        }
        {
            const uint32_t updatedAddress = 0x0042E434U + 0x61CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E42CU, address);
            }
            r1 = value;
        }
        {
            r0 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r11 + 0x575U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E434U, address);
            }
        }
        {
            r0 = 0x00000001U;
        }
        goto block_0042E43C;
    }
block_0042E43C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E43CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E43CU);
        }
        {
            const uint32_t operand = r0;
            r2 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r2 + 0x80U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E440U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00000010U;
            r2 = r2 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000028U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x0042E454U + Oot3dAotLsl(r2, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E44CU, address);
            }
            switch (value) {
            case 0x0042DF3CU:
                goto block_0042DF3C;
            case 0x0042DF58U:
                goto block_0042DF58;
            case 0x0042DF68U:
                goto block_0042DF68;
            case 0x0042DF8CU:
                goto block_0042DF8C;
            case 0x0042DF9CU:
                goto block_0042DF9C;
            case 0x0042DFB8U:
                goto block_0042DFB8;
            case 0x0042DFC8U:
                goto block_0042DFC8;
            case 0x0042DFD0U:
                goto block_0042DFD0;
            case 0x0042DFDCU:
                goto block_0042DFDC;
            case 0x0042DFE4U:
                goto block_0042DFE4;
            case 0x0042DFFCU:
                goto block_0042DFFC;
            case 0x0042E010U:
                goto block_0042E010;
            case 0x0042E020U:
                goto block_0042E020;
            case 0x0042E030U:
                goto block_0042E030;
            case 0x0042E040U:
                goto block_0042E040;
            case 0x0042E04CU:
                goto block_0042E04C;
            case 0x0042E058U:
                goto block_0042E058;
            case 0x0042E060U:
                goto block_0042E060;
            case 0x0042E078U:
                goto block_0042E078;
            case 0x0042E088U:
                goto block_0042E088;
            case 0x0042E0A8U:
                goto block_0042E0A8;
            case 0x0042E0B8U:
                goto block_0042E0B8;
            case 0x0042E0C0U:
                goto block_0042E0C0;
            case 0x0042E0CCU:
                goto block_0042E0CC;
            case 0x0042E0D4U:
                goto block_0042E0D4;
            case 0x0042E0ECU:
                goto block_0042E0EC;
            case 0x0042E0FCU:
                goto block_0042E0FC;
            case 0x0042E110U:
                goto block_0042E110;
            case 0x0042E11CU:
                goto block_0042E11C;
            case 0x0042E124U:
                goto block_0042E124;
            case 0x0042E130U:
                goto block_0042E130;
            case 0x0042E140U:
                goto block_0042E140;
            case 0x0042E150U:
                goto block_0042E150;
            case 0x0042E160U:
                goto block_0042E160;
            case 0x0042E16CU:
                goto block_0042E16C;
            case 0x0042E178U:
                goto block_0042E178;
            case 0x0042E188U:
                goto block_0042E188;
            case 0x0042E194U:
                goto block_0042E194;
            case 0x0042E1A4U:
                goto block_0042E1A4;
            case 0x0042E1B0U:
                goto block_0042E1B0;
            case 0x0042E1B8U:
                goto block_0042E1B8;
            case 0x0042E1D0U:
                goto block_0042E1D0;
            case 0x0042E1E0U:
                goto block_0042E1E0;
            case 0x0042E200U:
                goto block_0042E200;
            case 0x0042E20CU:
                goto block_0042E20C;
            case 0x0042E218U:
                goto block_0042E218;
            case 0x0042E224U:
                goto block_0042E224;
            case 0x0042E230U:
                goto block_0042E230;
            case 0x0042E248U:
                goto block_0042E248;
            case 0x0042E250U:
                goto block_0042E250;
            case 0x0042E254U:
                goto block_0042E254;
            case 0x0042E278U:
                goto block_0042E278;
            case 0x0042E284U:
                goto block_0042E284;
            case 0x0042E290U:
                goto block_0042E290;
            case 0x0042E29CU:
                goto block_0042E29C;
            case 0x0042E2A8U:
                goto block_0042E2A8;
            case 0x0042E2B4U:
                goto block_0042E2B4;
            case 0x0042E2C0U:
                goto block_0042E2C0;
            case 0x0042E2CCU:
                goto block_0042E2CC;
            case 0x0042E2D8U:
                goto block_0042E2D8;
            case 0x0042E2E4U:
                goto block_0042E2E4;
            case 0x0042E2F0U:
                goto block_0042E2F0;
            case 0x0042E308U:
                goto block_0042E308;
            case 0x0042E314U:
                goto block_0042E314;
            case 0x0042E320U:
                goto block_0042E320;
            case 0x0042E33CU:
                goto block_0042E33C;
            case 0x0042E348U:
                goto block_0042E348;
            case 0x0042E354U:
                goto block_0042E354;
            case 0x0042E36CU:
                goto block_0042E36C;
            case 0x0042E390U:
                goto block_0042E390;
            case 0x0042E3A0U:
                goto block_0042E3A0;
            case 0x0042E400U:
                goto block_0042E400;
            case 0x0042E414U:
                goto block_0042E414;
            case 0x0042E420U:
                goto block_0042E420;
            case 0x0042E42CU:
                goto block_0042E42C;
            case 0x0042E43CU:
                goto block_0042E43C;
            case 0x0042E450U:
                goto block_0042E450;
            case 0x0042E4F4U:
                goto block_0042E4F4;
            case 0x0042E504U:
                goto block_0042E504;
            case 0x0042E510U:
                goto block_0042E510;
            case 0x0042E51CU:
                goto block_0042E51C;
            case 0x0042E528U:
                goto block_0042E528;
            case 0x0042E540U:
                goto block_0042E540;
            case 0x0042E550U:
                goto block_0042E550;
            case 0x0042E568U:
                goto block_0042E568;
            case 0x0042E58CU:
                goto block_0042E58C;
            case 0x0042E5ECU:
                goto block_0042E5EC;
            case 0x0042E5F4U:
                goto block_0042E5F4;
            case 0x0042E618U:
                goto block_0042E618;
            case 0x0042E620U:
                goto block_0042E620;
            case 0x0042E630U:
                goto block_0042E630;
            case 0x0042E638U:
                goto block_0042E638;
            case 0x0042E644U:
                goto block_0042E644;
            case 0x0042E648U:
                goto block_0042E648;
            case 0x0042E654U:
                goto block_0042E654;
            case 0x0042E668U:
                goto block_0042E668;
            case 0x0042E66CU:
                goto block_0042E66C;
            case 0x0042E678U:
                goto block_0042E678;
            case 0x0042E67CU:
                goto block_0042E67C;
            case 0x0042E688U:
                goto block_0042E688;
            case 0x0042E690U:
                goto block_0042E690;
            case 0x0042E69CU:
                goto block_0042E69C;
            case 0x0042E6A0U:
                goto block_0042E6A0;
            case 0x0042E6ACU:
                goto block_0042E6AC;
            case 0x0042E6B0U:
                goto block_0042E6B0;
            case 0x0042E6BCU:
                goto block_0042E6BC;
            case 0x0042E6C0U:
                goto block_0042E6C0;
            case 0x0042E6CCU:
                goto block_0042E6CC;
            case 0x0042E6D4U:
                goto block_0042E6D4;
            case 0x0042E6E0U:
                goto block_0042E6E0;
            case 0x0042E6F0U:
                goto block_0042E6F0;
            case 0x0042E6F8U:
                goto block_0042E6F8;
            case 0x0042E704U:
                goto block_0042E704;
            case 0x0042E70CU:
                goto block_0042E70C;
            case 0x0042E724U:
                goto block_0042E724;
            case 0x0042E734U:
                goto block_0042E734;
            case 0x0042E738U:
                goto block_0042E738;
            case 0x0042E744U:
                goto block_0042E744;
            case 0x0042E764U:
                goto block_0042E764;
            case 0x0042E77CU:
                goto block_0042E77C;
            case 0x0042E794U:
                goto block_0042E794;
            case 0x0042E7A0U:
                goto block_0042E7A0;
            case 0x0042E7BCU:
                goto block_0042E7BC;
            case 0x0042E7D4U:
                goto block_0042E7D4;
            case 0x0042E7ECU:
                goto block_0042E7EC;
            case 0x0042E7F4U:
                goto block_0042E7F4;
            case 0x0042E800U:
                goto block_0042E800;
            case 0x0042E818U:
                goto block_0042E818;
            case 0x0042E834U:
                goto block_0042E834;
            case 0x0042E840U:
                goto block_0042E840;
            case 0x0042E844U:
                goto block_0042E844;
            case 0x0042E854U:
                goto block_0042E854;
            case 0x0042E860U:
                goto block_0042E860;
            case 0x0042E86CU:
                goto block_0042E86C;
            case 0x0042E874U:
                goto block_0042E874;
            case 0x0042E890U:
                goto block_0042E890;
            case 0x0042E89CU:
                goto block_0042E89C;
            case 0x0042E8A0U:
                goto block_0042E8A0;
            case 0x0042E8B0U:
                goto block_0042E8B0;
            case 0x0042E8BCU:
                goto block_0042E8BC;
            case 0x0042E8C8U:
                goto block_0042E8C8;
            case 0x0042E8D0U:
                goto block_0042E8D0;
            case 0x0042E8ECU:
                goto block_0042E8EC;
            case 0x0042E8F8U:
                goto block_0042E8F8;
            case 0x0042E8FCU:
                goto block_0042E8FC;
            case 0x0042E90CU:
                goto block_0042E90C;
            case 0x0042E910U:
                goto block_0042E910;
            case 0x0042E91CU:
                goto block_0042E91C;
            case 0x0042E928U:
                goto block_0042E928;
            case 0x0042E934U:
                goto block_0042E934;
            case 0x0042E938U:
                goto block_0042E938;
            case 0x0042E940U:
                goto block_0042E940;
            case 0x0042E95CU:
                goto block_0042E95C;
            case 0x0042E968U:
                goto block_0042E968;
            case 0x0042E96CU:
                goto block_0042E96C;
            case 0x0042E978U:
                goto block_0042E978;
            case 0x0042E97CU:
                goto block_0042E97C;
            case 0x0042E988U:
                goto block_0042E988;
            case 0x0042E98CU:
                goto block_0042E98C;
            case 0x0042E99CU:
                goto block_0042E99C;
            case 0x0042E9A0U:
                goto block_0042E9A0;
            case 0x0042E9B0U:
                goto block_0042E9B0;
            case 0x0042E9CCU:
                goto block_0042E9CC;
            case 0x0042E9D8U:
                goto block_0042E9D8;
            case 0x0042E9DCU:
                goto block_0042E9DC;
            case 0x0042E9E4U:
                goto block_0042E9E4;
            case 0x0042E9E8U:
                goto block_0042E9E8;
            case 0x0042E9F4U:
                goto block_0042E9F4;
            case 0x0042EA10U:
                goto block_0042EA10;
            case 0x0042EA1CU:
                goto block_0042EA1C;
            case 0x0042EA70U:
                goto block_0042EA70;
            case 0x0042EA88U:
                goto block_0042EA88;
            case 0x0042EAA0U:
                goto block_0042EAA0;
            case 0x0042EAACU:
                goto block_0042EAAC;
            case 0x0042EAB8U:
                goto block_0042EAB8;
            case 0x0042EAD4U:
                goto block_0042EAD4;
            case 0x0042EAE0U:
                goto block_0042EAE0;
            case 0x0042EB00U:
                goto block_0042EB00;
            case 0x0042EB14U:
                goto block_0042EB14;
            case 0x0042EB20U:
                goto block_0042EB20;
            case 0x0042EB30U:
                goto block_0042EB30;
            case 0x0042EB4CU:
                goto block_0042EB4C;
            case 0x0042EB60U:
                goto block_0042EB60;
            case 0x0042EB6CU:
                goto block_0042EB6C;
            case 0x0042EB7CU:
                goto block_0042EB7C;
            case 0x0042EB98U:
                goto block_0042EB98;
            case 0x0042EBACU:
                goto block_0042EBAC;
            case 0x0042EBB8U:
                goto block_0042EBB8;
            case 0x0042EBD0U:
                goto block_0042EBD0;
            case 0x0042EBECU:
                goto block_0042EBEC;
            case 0x0042EC00U:
                goto block_0042EC00;
            case 0x0042EC0CU:
                goto block_0042EC0C;
            case 0x0042EC24U:
                goto block_0042EC24;
            case 0x0042EC2CU:
                goto block_0042EC2C;
            case 0x0042EC38U:
                goto block_0042EC38;
            case 0x0042EC44U:
                goto block_0042EC44;
            case 0x0042EC48U:
                goto block_0042EC48;
            case 0x0042EC54U:
                goto block_0042EC54;
            case 0x0042EC5CU:
                goto block_0042EC5C;
            case 0x0042EC68U:
                goto block_0042EC68;
            case 0x0042EC7CU:
                goto block_0042EC7C;
            case 0x0042EC80U:
                goto block_0042EC80;
            case 0x0042EC8CU:
                goto block_0042EC8C;
            case 0x0042EC9CU:
                goto block_0042EC9C;
            case 0x0042ECB0U:
                goto block_0042ECB0;
            case 0x0042ECB4U:
                goto block_0042ECB4;
            case 0x0042ECC0U:
                goto block_0042ECC0;
            case 0x0042ECD0U:
                goto block_0042ECD0;
            case 0x0042ECE8U:
                goto block_0042ECE8;
            case 0x0042ECECU:
                goto block_0042ECEC;
            case 0x0042ECF8U:
                goto block_0042ECF8;
            case 0x0042ED00U:
                goto block_0042ED00;
            case 0x0042ED08U:
                goto block_0042ED08;
            case 0x0042ED20U:
                goto block_0042ED20;
            case 0x0042ED24U:
                goto block_0042ED24;
            case 0x0042ED30U:
                goto block_0042ED30;
            case 0x0042ED34U:
                goto block_0042ED34;
            case 0x0042ED3CU:
                goto block_0042ED3C;
            case 0x0042ED44U:
                goto block_0042ED44;
            case 0x0042ED50U:
                goto block_0042ED50;
            case 0x0042ED54U:
                goto block_0042ED54;
            case 0x0042ED60U:
                goto block_0042ED60;
            case 0x0042ED6CU:
                goto block_0042ED6C;
            case 0x0042ED74U:
                goto block_0042ED74;
            case 0x0042ED80U:
                goto block_0042ED80;
            case 0x0042EDD4U:
                goto block_0042EDD4;
            case 0x0042EDDCU:
                goto block_0042EDDC;
            case 0x0042EDE8U:
                goto block_0042EDE8;
            case 0x0042EDF4U:
                goto block_0042EDF4;
            case 0x0042EE00U:
                goto block_0042EE00;
            case 0x0042EE08U:
                goto block_0042EE08;
            case 0x0042EE14U:
                goto block_0042EE14;
            case 0x0042EE18U:
                goto block_0042EE18;
            case 0x0042EE20U:
                goto block_0042EE20;
            case 0x0042EE2CU:
                goto block_0042EE2C;
            case 0x0042EE38U:
                goto block_0042EE38;
            case 0x0042EE44U:
                goto block_0042EE44;
            case 0x0042EE50U:
                goto block_0042EE50;
            case 0x0042EE6CU:
                goto block_0042EE6C;
            case 0x0042EE78U:
                goto block_0042EE78;
            case 0x0042EE80U:
                goto block_0042EE80;
            case 0x0042EE8CU:
                goto block_0042EE8C;
            case 0x0042EE98U:
                goto block_0042EE98;
            case 0x0042EE9CU:
                goto block_0042EE9C;
            case 0x0042EEA4U:
                goto block_0042EEA4;
            case 0x0042EEB0U:
                goto block_0042EEB0;
            case 0x0042EEB8U:
                goto block_0042EEB8;
            case 0x0042EEC4U:
                goto block_0042EEC4;
            case 0x0042EED0U:
                goto block_0042EED0;
            case 0x0042EED8U:
                goto block_0042EED8;
            case 0x0042EEE4U:
                goto block_0042EEE4;
            case 0x0042EEF0U:
                goto block_0042EEF0;
            case 0x0042EEFCU:
                goto block_0042EEFC;
            case 0x0042EF08U:
                goto block_0042EF08;
            case 0x0042EF10U:
                goto block_0042EF10;
            case 0x0042EF1CU:
                goto block_0042EF1C;
            case 0x0042EF20U:
                goto block_0042EF20;
            case 0x0042EF28U:
                goto block_0042EF28;
            case 0x0042EF34U:
                goto block_0042EF34;
            case 0x0042EF40U:
                goto block_0042EF40;
            case 0x0042EF4CU:
                goto block_0042EF4C;
            case 0x0042EF58U:
                goto block_0042EF58;
            case 0x0042EF74U:
                goto block_0042EF74;
            case 0x0042EF80U:
                goto block_0042EF80;
            case 0x0042EF88U:
                goto block_0042EF88;
            case 0x0042EF94U:
                goto block_0042EF94;
            case 0x0042EFA0U:
                goto block_0042EFA0;
            case 0x0042EFA4U:
                goto block_0042EFA4;
            case 0x0042EFACU:
                goto block_0042EFAC;
            case 0x0042EFB8U:
                goto block_0042EFB8;
            case 0x0042EFBCU:
                goto block_0042EFBC;
            case 0x0042EFC8U:
                goto block_0042EFC8;
            case 0x0042EFD4U:
                goto block_0042EFD4;
            case 0x0042EFE0U:
                goto block_0042EFE0;
            case 0x0042EFECU:
                goto block_0042EFEC;
            case 0x0042EFF4U:
                goto block_0042EFF4;
            case 0x0042F000U:
                goto block_0042F000;
            case 0x0042F004U:
                goto block_0042F004;
            case 0x0042F00CU:
                goto block_0042F00C;
            case 0x0042F018U:
                goto block_0042F018;
            case 0x0042F024U:
                goto block_0042F024;
            case 0x0042F030U:
                goto block_0042F030;
            case 0x0042F03CU:
                goto block_0042F03C;
            case 0x0042F058U:
                goto block_0042F058;
            case 0x0042F064U:
                goto block_0042F064;
            case 0x0042F06CU:
                goto block_0042F06C;
            case 0x0042F078U:
                goto block_0042F078;
            case 0x0042F084U:
                goto block_0042F084;
            case 0x0042F088U:
                goto block_0042F088;
            case 0x0042F090U:
                goto block_0042F090;
            case 0x0042F09CU:
                goto block_0042F09C;
            case 0x0042F0A0U:
                goto block_0042F0A0;
            case 0x0042F0ACU:
                goto block_0042F0AC;
            case 0x0042F0B8U:
                goto block_0042F0B8;
            case 0x0042F0C4U:
                goto block_0042F0C4;
            case 0x0042F0D0U:
                goto block_0042F0D0;
            case 0x0042F0D8U:
                goto block_0042F0D8;
            case 0x0042F0E4U:
                goto block_0042F0E4;
            case 0x0042F0E8U:
                goto block_0042F0E8;
            case 0x0042F0F0U:
                goto block_0042F0F0;
            case 0x0042F0F8U:
                goto block_0042F0F8;
            case 0x0042F104U:
                goto block_0042F104;
            case 0x0042F110U:
                goto block_0042F110;
            case 0x0042F12CU:
                goto block_0042F12C;
            case 0x0042F138U:
                goto block_0042F138;
            case 0x0042F164U:
                goto block_0042F164;
            case 0x0042F170U:
                goto block_0042F170;
            case 0x0042F174U:
                goto block_0042F174;
            case 0x0042F17CU:
                goto block_0042F17C;
            case 0x0042F188U:
                goto block_0042F188;
            case 0x0042F18CU:
                goto block_0042F18C;
            case 0x0042F198U:
                goto block_0042F198;
            case 0x0042F1B4U:
                goto block_0042F1B4;
            case 0x0042F1C0U:
                goto block_0042F1C0;
            case 0x0042F1CCU:
                goto block_0042F1CC;
            case 0x0042F1D0U:
                goto block_0042F1D0;
            case 0x0042F1D8U:
                goto block_0042F1D8;
            case 0x0042F1E8U:
                goto block_0042F1E8;
            case 0x0042F1F0U:
                goto block_0042F1F0;
            case 0x0042F1FCU:
                goto block_0042F1FC;
            case 0x0042F20CU:
                goto block_0042F20C;
            case 0x0042F214U:
                goto block_0042F214;
            case 0x0042F220U:
                goto block_0042F220;
            case 0x0042F228U:
                goto block_0042F228;
            case 0x0042F22CU:
                goto block_0042F22C;
            case 0x0042F234U:
                goto block_0042F234;
            case 0x0042F23CU:
                goto block_0042F23C;
            case 0x0042F248U:
                goto block_0042F248;
            case 0x0042F250U:
                goto block_0042F250;
            case 0x0042F25CU:
                goto block_0042F25C;
            case 0x0042F268U:
                goto block_0042F268;
            case 0x0042F270U:
                goto block_0042F270;
            case 0x0042F27CU:
                goto block_0042F27C;
            case 0x0042F288U:
                goto block_0042F288;
            case 0x0042F294U:
                goto block_0042F294;
            case 0x0042F29CU:
                goto block_0042F29C;
            case 0x0042F2A8U:
                goto block_0042F2A8;
            case 0x0042F2B4U:
                goto block_0042F2B4;
            case 0x0042F2C0U:
                goto block_0042F2C0;
            case 0x0042F2C4U:
                goto block_0042F2C4;
            case 0x0042F2D0U:
                goto block_0042F2D0;
            case 0x0042F2DCU:
                goto block_0042F2DC;
            case 0x0042F2F0U:
                goto block_0042F2F0;
            case 0x0042F324U:
                goto block_0042F324;
            case 0x0042F330U:
                goto block_0042F330;
            case 0x0042F338U:
                goto block_0042F338;
            case 0x0042F33CU:
                goto block_0042F33C;
            case 0x0042F348U:
                goto block_0042F348;
            case 0x0042F350U:
                goto block_0042F350;
            case 0x0042F354U:
                goto block_0042F354;
            case 0x0042F358U:
                goto block_0042F358;
            case 0x0042F35CU:
                goto block_0042F35C;
            case 0x0042F360U:
                goto block_0042F360;
            case 0x0042F36CU:
                goto block_0042F36C;
            case 0x0042F370U:
                goto block_0042F370;
            case 0x0042F37CU:
                goto block_0042F37C;
            case 0x0042F384U:
                goto block_0042F384;
            case 0x0042F38CU:
                goto block_0042F38C;
            case 0x0042F390U:
                goto block_0042F390;
            case 0x0042F39CU:
                goto block_0042F39C;
            case 0x0042F3A0U:
                goto block_0042F3A0;
            case 0x0042F3ACU:
                goto block_0042F3AC;
            case 0x0042F3C0U:
                goto block_0042F3C0;
            case 0x0042F3D4U:
                goto block_0042F3D4;
            case 0x0042F3E8U:
                goto block_0042F3E8;
            case 0x0042F3F8U:
                goto block_0042F3F8;
            case 0x0042F400U:
                goto block_0042F400;
            case 0x0042F40CU:
                goto block_0042F40C;
            case 0x0042F418U:
                goto block_0042F418;
            case 0x0042F424U:
                goto block_0042F424;
            case 0x0042F45CU:
                goto block_0042F45C;
            case 0x0042F464U:
                goto block_0042F464;
            case 0x0042F470U:
                goto block_0042F470;
            case 0x0042F490U:
                goto block_0042F490;
            case 0x0042F49CU:
                goto block_0042F49C;
            case 0x0042F4A8U:
                goto block_0042F4A8;
            case 0x0042F4B0U:
                goto block_0042F4B0;
            case 0x0042F4BCU:
                goto block_0042F4BC;
            case 0x0042F4C8U:
                goto block_0042F4C8;
            case 0x0042F4D4U:
                goto block_0042F4D4;
            case 0x0042F4E0U:
                goto block_0042F4E0;
            case 0x0042F4E8U:
                goto block_0042F4E8;
            case 0x0042F4F8U:
                goto block_0042F4F8;
            case 0x0042F4FCU:
                goto block_0042F4FC;
            case 0x0042F524U:
                goto block_0042F524;
            case 0x0042F534U:
                goto block_0042F534;
            case 0x0042F558U:
                goto block_0042F558;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_0042E450;
    }
block_0042E450:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E450U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E450U);
        }
        goto block_0042E504;
    }
block_0042E4F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E4F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E4F4U);
        }
        {
            const uint32_t operand = r0;
            r3 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00001000U;
            r3 = r3 + operand;
        }
        {
            r2 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r3 + 0x56FU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0042E500U, address);
            }
        }
        goto block_0042E504;
    }
block_0042E504:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E504U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E504U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0042E43C; }
        goto block_0042E510;
    }
block_0042E510:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E510U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E510U);
        }
        {
            r1 = 0x00000013U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E51CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E51CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E51C;
    }
block_0042E51C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E51CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E51CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (flags.Z()) { goto block_0042E540; }
        goto block_0042E528;
    }
block_0042E528:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E528U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E528U);
        }
        {
            r0 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r11 + 0x573U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E52CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x572U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E530U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x571U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E534U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x570U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E538U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x575U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E53CU, address);
            }
        }
        goto block_0042E540;
    }
block_0042E540:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E540U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E540U);
        }
        {
            r0 = 0x00000118U;
        }
        {
            const uint32_t updatedAddress = r0 + r7;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E544U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0042E568; }
        goto block_0042E550;
    }
block_0042E550:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E550U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E550U);
        }
        {
            r0 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r11 + 0x573U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E554U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x572U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E558U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x571U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E55CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x570U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E560U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x575U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E564U, address);
            }
        }
        goto block_0042E568;
    }
block_0042E568:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E568U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E568U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E56CU, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x749U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E570U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x70U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E574U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042E578U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x60U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042E57CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E580U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000017U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x0042E590U + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E588U, address);
            }
            switch (value) {
            case 0x0042DF3CU:
                goto block_0042DF3C;
            case 0x0042DF58U:
                goto block_0042DF58;
            case 0x0042DF68U:
                goto block_0042DF68;
            case 0x0042DF8CU:
                goto block_0042DF8C;
            case 0x0042DF9CU:
                goto block_0042DF9C;
            case 0x0042DFB8U:
                goto block_0042DFB8;
            case 0x0042DFC8U:
                goto block_0042DFC8;
            case 0x0042DFD0U:
                goto block_0042DFD0;
            case 0x0042DFDCU:
                goto block_0042DFDC;
            case 0x0042DFE4U:
                goto block_0042DFE4;
            case 0x0042DFFCU:
                goto block_0042DFFC;
            case 0x0042E010U:
                goto block_0042E010;
            case 0x0042E020U:
                goto block_0042E020;
            case 0x0042E030U:
                goto block_0042E030;
            case 0x0042E040U:
                goto block_0042E040;
            case 0x0042E04CU:
                goto block_0042E04C;
            case 0x0042E058U:
                goto block_0042E058;
            case 0x0042E060U:
                goto block_0042E060;
            case 0x0042E078U:
                goto block_0042E078;
            case 0x0042E088U:
                goto block_0042E088;
            case 0x0042E0A8U:
                goto block_0042E0A8;
            case 0x0042E0B8U:
                goto block_0042E0B8;
            case 0x0042E0C0U:
                goto block_0042E0C0;
            case 0x0042E0CCU:
                goto block_0042E0CC;
            case 0x0042E0D4U:
                goto block_0042E0D4;
            case 0x0042E0ECU:
                goto block_0042E0EC;
            case 0x0042E0FCU:
                goto block_0042E0FC;
            case 0x0042E110U:
                goto block_0042E110;
            case 0x0042E11CU:
                goto block_0042E11C;
            case 0x0042E124U:
                goto block_0042E124;
            case 0x0042E130U:
                goto block_0042E130;
            case 0x0042E140U:
                goto block_0042E140;
            case 0x0042E150U:
                goto block_0042E150;
            case 0x0042E160U:
                goto block_0042E160;
            case 0x0042E16CU:
                goto block_0042E16C;
            case 0x0042E178U:
                goto block_0042E178;
            case 0x0042E188U:
                goto block_0042E188;
            case 0x0042E194U:
                goto block_0042E194;
            case 0x0042E1A4U:
                goto block_0042E1A4;
            case 0x0042E1B0U:
                goto block_0042E1B0;
            case 0x0042E1B8U:
                goto block_0042E1B8;
            case 0x0042E1D0U:
                goto block_0042E1D0;
            case 0x0042E1E0U:
                goto block_0042E1E0;
            case 0x0042E200U:
                goto block_0042E200;
            case 0x0042E20CU:
                goto block_0042E20C;
            case 0x0042E218U:
                goto block_0042E218;
            case 0x0042E224U:
                goto block_0042E224;
            case 0x0042E230U:
                goto block_0042E230;
            case 0x0042E248U:
                goto block_0042E248;
            case 0x0042E250U:
                goto block_0042E250;
            case 0x0042E254U:
                goto block_0042E254;
            case 0x0042E278U:
                goto block_0042E278;
            case 0x0042E284U:
                goto block_0042E284;
            case 0x0042E290U:
                goto block_0042E290;
            case 0x0042E29CU:
                goto block_0042E29C;
            case 0x0042E2A8U:
                goto block_0042E2A8;
            case 0x0042E2B4U:
                goto block_0042E2B4;
            case 0x0042E2C0U:
                goto block_0042E2C0;
            case 0x0042E2CCU:
                goto block_0042E2CC;
            case 0x0042E2D8U:
                goto block_0042E2D8;
            case 0x0042E2E4U:
                goto block_0042E2E4;
            case 0x0042E2F0U:
                goto block_0042E2F0;
            case 0x0042E308U:
                goto block_0042E308;
            case 0x0042E314U:
                goto block_0042E314;
            case 0x0042E320U:
                goto block_0042E320;
            case 0x0042E33CU:
                goto block_0042E33C;
            case 0x0042E348U:
                goto block_0042E348;
            case 0x0042E354U:
                goto block_0042E354;
            case 0x0042E36CU:
                goto block_0042E36C;
            case 0x0042E390U:
                goto block_0042E390;
            case 0x0042E3A0U:
                goto block_0042E3A0;
            case 0x0042E400U:
                goto block_0042E400;
            case 0x0042E414U:
                goto block_0042E414;
            case 0x0042E420U:
                goto block_0042E420;
            case 0x0042E42CU:
                goto block_0042E42C;
            case 0x0042E43CU:
                goto block_0042E43C;
            case 0x0042E450U:
                goto block_0042E450;
            case 0x0042E4F4U:
                goto block_0042E4F4;
            case 0x0042E504U:
                goto block_0042E504;
            case 0x0042E510U:
                goto block_0042E510;
            case 0x0042E51CU:
                goto block_0042E51C;
            case 0x0042E528U:
                goto block_0042E528;
            case 0x0042E540U:
                goto block_0042E540;
            case 0x0042E550U:
                goto block_0042E550;
            case 0x0042E568U:
                goto block_0042E568;
            case 0x0042E58CU:
                goto block_0042E58C;
            case 0x0042E5ECU:
                goto block_0042E5EC;
            case 0x0042E5F4U:
                goto block_0042E5F4;
            case 0x0042E618U:
                goto block_0042E618;
            case 0x0042E620U:
                goto block_0042E620;
            case 0x0042E630U:
                goto block_0042E630;
            case 0x0042E638U:
                goto block_0042E638;
            case 0x0042E644U:
                goto block_0042E644;
            case 0x0042E648U:
                goto block_0042E648;
            case 0x0042E654U:
                goto block_0042E654;
            case 0x0042E668U:
                goto block_0042E668;
            case 0x0042E66CU:
                goto block_0042E66C;
            case 0x0042E678U:
                goto block_0042E678;
            case 0x0042E67CU:
                goto block_0042E67C;
            case 0x0042E688U:
                goto block_0042E688;
            case 0x0042E690U:
                goto block_0042E690;
            case 0x0042E69CU:
                goto block_0042E69C;
            case 0x0042E6A0U:
                goto block_0042E6A0;
            case 0x0042E6ACU:
                goto block_0042E6AC;
            case 0x0042E6B0U:
                goto block_0042E6B0;
            case 0x0042E6BCU:
                goto block_0042E6BC;
            case 0x0042E6C0U:
                goto block_0042E6C0;
            case 0x0042E6CCU:
                goto block_0042E6CC;
            case 0x0042E6D4U:
                goto block_0042E6D4;
            case 0x0042E6E0U:
                goto block_0042E6E0;
            case 0x0042E6F0U:
                goto block_0042E6F0;
            case 0x0042E6F8U:
                goto block_0042E6F8;
            case 0x0042E704U:
                goto block_0042E704;
            case 0x0042E70CU:
                goto block_0042E70C;
            case 0x0042E724U:
                goto block_0042E724;
            case 0x0042E734U:
                goto block_0042E734;
            case 0x0042E738U:
                goto block_0042E738;
            case 0x0042E744U:
                goto block_0042E744;
            case 0x0042E764U:
                goto block_0042E764;
            case 0x0042E77CU:
                goto block_0042E77C;
            case 0x0042E794U:
                goto block_0042E794;
            case 0x0042E7A0U:
                goto block_0042E7A0;
            case 0x0042E7BCU:
                goto block_0042E7BC;
            case 0x0042E7D4U:
                goto block_0042E7D4;
            case 0x0042E7ECU:
                goto block_0042E7EC;
            case 0x0042E7F4U:
                goto block_0042E7F4;
            case 0x0042E800U:
                goto block_0042E800;
            case 0x0042E818U:
                goto block_0042E818;
            case 0x0042E834U:
                goto block_0042E834;
            case 0x0042E840U:
                goto block_0042E840;
            case 0x0042E844U:
                goto block_0042E844;
            case 0x0042E854U:
                goto block_0042E854;
            case 0x0042E860U:
                goto block_0042E860;
            case 0x0042E86CU:
                goto block_0042E86C;
            case 0x0042E874U:
                goto block_0042E874;
            case 0x0042E890U:
                goto block_0042E890;
            case 0x0042E89CU:
                goto block_0042E89C;
            case 0x0042E8A0U:
                goto block_0042E8A0;
            case 0x0042E8B0U:
                goto block_0042E8B0;
            case 0x0042E8BCU:
                goto block_0042E8BC;
            case 0x0042E8C8U:
                goto block_0042E8C8;
            case 0x0042E8D0U:
                goto block_0042E8D0;
            case 0x0042E8ECU:
                goto block_0042E8EC;
            case 0x0042E8F8U:
                goto block_0042E8F8;
            case 0x0042E8FCU:
                goto block_0042E8FC;
            case 0x0042E90CU:
                goto block_0042E90C;
            case 0x0042E910U:
                goto block_0042E910;
            case 0x0042E91CU:
                goto block_0042E91C;
            case 0x0042E928U:
                goto block_0042E928;
            case 0x0042E934U:
                goto block_0042E934;
            case 0x0042E938U:
                goto block_0042E938;
            case 0x0042E940U:
                goto block_0042E940;
            case 0x0042E95CU:
                goto block_0042E95C;
            case 0x0042E968U:
                goto block_0042E968;
            case 0x0042E96CU:
                goto block_0042E96C;
            case 0x0042E978U:
                goto block_0042E978;
            case 0x0042E97CU:
                goto block_0042E97C;
            case 0x0042E988U:
                goto block_0042E988;
            case 0x0042E98CU:
                goto block_0042E98C;
            case 0x0042E99CU:
                goto block_0042E99C;
            case 0x0042E9A0U:
                goto block_0042E9A0;
            case 0x0042E9B0U:
                goto block_0042E9B0;
            case 0x0042E9CCU:
                goto block_0042E9CC;
            case 0x0042E9D8U:
                goto block_0042E9D8;
            case 0x0042E9DCU:
                goto block_0042E9DC;
            case 0x0042E9E4U:
                goto block_0042E9E4;
            case 0x0042E9E8U:
                goto block_0042E9E8;
            case 0x0042E9F4U:
                goto block_0042E9F4;
            case 0x0042EA10U:
                goto block_0042EA10;
            case 0x0042EA1CU:
                goto block_0042EA1C;
            case 0x0042EA70U:
                goto block_0042EA70;
            case 0x0042EA88U:
                goto block_0042EA88;
            case 0x0042EAA0U:
                goto block_0042EAA0;
            case 0x0042EAACU:
                goto block_0042EAAC;
            case 0x0042EAB8U:
                goto block_0042EAB8;
            case 0x0042EAD4U:
                goto block_0042EAD4;
            case 0x0042EAE0U:
                goto block_0042EAE0;
            case 0x0042EB00U:
                goto block_0042EB00;
            case 0x0042EB14U:
                goto block_0042EB14;
            case 0x0042EB20U:
                goto block_0042EB20;
            case 0x0042EB30U:
                goto block_0042EB30;
            case 0x0042EB4CU:
                goto block_0042EB4C;
            case 0x0042EB60U:
                goto block_0042EB60;
            case 0x0042EB6CU:
                goto block_0042EB6C;
            case 0x0042EB7CU:
                goto block_0042EB7C;
            case 0x0042EB98U:
                goto block_0042EB98;
            case 0x0042EBACU:
                goto block_0042EBAC;
            case 0x0042EBB8U:
                goto block_0042EBB8;
            case 0x0042EBD0U:
                goto block_0042EBD0;
            case 0x0042EBECU:
                goto block_0042EBEC;
            case 0x0042EC00U:
                goto block_0042EC00;
            case 0x0042EC0CU:
                goto block_0042EC0C;
            case 0x0042EC24U:
                goto block_0042EC24;
            case 0x0042EC2CU:
                goto block_0042EC2C;
            case 0x0042EC38U:
                goto block_0042EC38;
            case 0x0042EC44U:
                goto block_0042EC44;
            case 0x0042EC48U:
                goto block_0042EC48;
            case 0x0042EC54U:
                goto block_0042EC54;
            case 0x0042EC5CU:
                goto block_0042EC5C;
            case 0x0042EC68U:
                goto block_0042EC68;
            case 0x0042EC7CU:
                goto block_0042EC7C;
            case 0x0042EC80U:
                goto block_0042EC80;
            case 0x0042EC8CU:
                goto block_0042EC8C;
            case 0x0042EC9CU:
                goto block_0042EC9C;
            case 0x0042ECB0U:
                goto block_0042ECB0;
            case 0x0042ECB4U:
                goto block_0042ECB4;
            case 0x0042ECC0U:
                goto block_0042ECC0;
            case 0x0042ECD0U:
                goto block_0042ECD0;
            case 0x0042ECE8U:
                goto block_0042ECE8;
            case 0x0042ECECU:
                goto block_0042ECEC;
            case 0x0042ECF8U:
                goto block_0042ECF8;
            case 0x0042ED00U:
                goto block_0042ED00;
            case 0x0042ED08U:
                goto block_0042ED08;
            case 0x0042ED20U:
                goto block_0042ED20;
            case 0x0042ED24U:
                goto block_0042ED24;
            case 0x0042ED30U:
                goto block_0042ED30;
            case 0x0042ED34U:
                goto block_0042ED34;
            case 0x0042ED3CU:
                goto block_0042ED3C;
            case 0x0042ED44U:
                goto block_0042ED44;
            case 0x0042ED50U:
                goto block_0042ED50;
            case 0x0042ED54U:
                goto block_0042ED54;
            case 0x0042ED60U:
                goto block_0042ED60;
            case 0x0042ED6CU:
                goto block_0042ED6C;
            case 0x0042ED74U:
                goto block_0042ED74;
            case 0x0042ED80U:
                goto block_0042ED80;
            case 0x0042EDD4U:
                goto block_0042EDD4;
            case 0x0042EDDCU:
                goto block_0042EDDC;
            case 0x0042EDE8U:
                goto block_0042EDE8;
            case 0x0042EDF4U:
                goto block_0042EDF4;
            case 0x0042EE00U:
                goto block_0042EE00;
            case 0x0042EE08U:
                goto block_0042EE08;
            case 0x0042EE14U:
                goto block_0042EE14;
            case 0x0042EE18U:
                goto block_0042EE18;
            case 0x0042EE20U:
                goto block_0042EE20;
            case 0x0042EE2CU:
                goto block_0042EE2C;
            case 0x0042EE38U:
                goto block_0042EE38;
            case 0x0042EE44U:
                goto block_0042EE44;
            case 0x0042EE50U:
                goto block_0042EE50;
            case 0x0042EE6CU:
                goto block_0042EE6C;
            case 0x0042EE78U:
                goto block_0042EE78;
            case 0x0042EE80U:
                goto block_0042EE80;
            case 0x0042EE8CU:
                goto block_0042EE8C;
            case 0x0042EE98U:
                goto block_0042EE98;
            case 0x0042EE9CU:
                goto block_0042EE9C;
            case 0x0042EEA4U:
                goto block_0042EEA4;
            case 0x0042EEB0U:
                goto block_0042EEB0;
            case 0x0042EEB8U:
                goto block_0042EEB8;
            case 0x0042EEC4U:
                goto block_0042EEC4;
            case 0x0042EED0U:
                goto block_0042EED0;
            case 0x0042EED8U:
                goto block_0042EED8;
            case 0x0042EEE4U:
                goto block_0042EEE4;
            case 0x0042EEF0U:
                goto block_0042EEF0;
            case 0x0042EEFCU:
                goto block_0042EEFC;
            case 0x0042EF08U:
                goto block_0042EF08;
            case 0x0042EF10U:
                goto block_0042EF10;
            case 0x0042EF1CU:
                goto block_0042EF1C;
            case 0x0042EF20U:
                goto block_0042EF20;
            case 0x0042EF28U:
                goto block_0042EF28;
            case 0x0042EF34U:
                goto block_0042EF34;
            case 0x0042EF40U:
                goto block_0042EF40;
            case 0x0042EF4CU:
                goto block_0042EF4C;
            case 0x0042EF58U:
                goto block_0042EF58;
            case 0x0042EF74U:
                goto block_0042EF74;
            case 0x0042EF80U:
                goto block_0042EF80;
            case 0x0042EF88U:
                goto block_0042EF88;
            case 0x0042EF94U:
                goto block_0042EF94;
            case 0x0042EFA0U:
                goto block_0042EFA0;
            case 0x0042EFA4U:
                goto block_0042EFA4;
            case 0x0042EFACU:
                goto block_0042EFAC;
            case 0x0042EFB8U:
                goto block_0042EFB8;
            case 0x0042EFBCU:
                goto block_0042EFBC;
            case 0x0042EFC8U:
                goto block_0042EFC8;
            case 0x0042EFD4U:
                goto block_0042EFD4;
            case 0x0042EFE0U:
                goto block_0042EFE0;
            case 0x0042EFECU:
                goto block_0042EFEC;
            case 0x0042EFF4U:
                goto block_0042EFF4;
            case 0x0042F000U:
                goto block_0042F000;
            case 0x0042F004U:
                goto block_0042F004;
            case 0x0042F00CU:
                goto block_0042F00C;
            case 0x0042F018U:
                goto block_0042F018;
            case 0x0042F024U:
                goto block_0042F024;
            case 0x0042F030U:
                goto block_0042F030;
            case 0x0042F03CU:
                goto block_0042F03C;
            case 0x0042F058U:
                goto block_0042F058;
            case 0x0042F064U:
                goto block_0042F064;
            case 0x0042F06CU:
                goto block_0042F06C;
            case 0x0042F078U:
                goto block_0042F078;
            case 0x0042F084U:
                goto block_0042F084;
            case 0x0042F088U:
                goto block_0042F088;
            case 0x0042F090U:
                goto block_0042F090;
            case 0x0042F09CU:
                goto block_0042F09C;
            case 0x0042F0A0U:
                goto block_0042F0A0;
            case 0x0042F0ACU:
                goto block_0042F0AC;
            case 0x0042F0B8U:
                goto block_0042F0B8;
            case 0x0042F0C4U:
                goto block_0042F0C4;
            case 0x0042F0D0U:
                goto block_0042F0D0;
            case 0x0042F0D8U:
                goto block_0042F0D8;
            case 0x0042F0E4U:
                goto block_0042F0E4;
            case 0x0042F0E8U:
                goto block_0042F0E8;
            case 0x0042F0F0U:
                goto block_0042F0F0;
            case 0x0042F0F8U:
                goto block_0042F0F8;
            case 0x0042F104U:
                goto block_0042F104;
            case 0x0042F110U:
                goto block_0042F110;
            case 0x0042F12CU:
                goto block_0042F12C;
            case 0x0042F138U:
                goto block_0042F138;
            case 0x0042F164U:
                goto block_0042F164;
            case 0x0042F170U:
                goto block_0042F170;
            case 0x0042F174U:
                goto block_0042F174;
            case 0x0042F17CU:
                goto block_0042F17C;
            case 0x0042F188U:
                goto block_0042F188;
            case 0x0042F18CU:
                goto block_0042F18C;
            case 0x0042F198U:
                goto block_0042F198;
            case 0x0042F1B4U:
                goto block_0042F1B4;
            case 0x0042F1C0U:
                goto block_0042F1C0;
            case 0x0042F1CCU:
                goto block_0042F1CC;
            case 0x0042F1D0U:
                goto block_0042F1D0;
            case 0x0042F1D8U:
                goto block_0042F1D8;
            case 0x0042F1E8U:
                goto block_0042F1E8;
            case 0x0042F1F0U:
                goto block_0042F1F0;
            case 0x0042F1FCU:
                goto block_0042F1FC;
            case 0x0042F20CU:
                goto block_0042F20C;
            case 0x0042F214U:
                goto block_0042F214;
            case 0x0042F220U:
                goto block_0042F220;
            case 0x0042F228U:
                goto block_0042F228;
            case 0x0042F22CU:
                goto block_0042F22C;
            case 0x0042F234U:
                goto block_0042F234;
            case 0x0042F23CU:
                goto block_0042F23C;
            case 0x0042F248U:
                goto block_0042F248;
            case 0x0042F250U:
                goto block_0042F250;
            case 0x0042F25CU:
                goto block_0042F25C;
            case 0x0042F268U:
                goto block_0042F268;
            case 0x0042F270U:
                goto block_0042F270;
            case 0x0042F27CU:
                goto block_0042F27C;
            case 0x0042F288U:
                goto block_0042F288;
            case 0x0042F294U:
                goto block_0042F294;
            case 0x0042F29CU:
                goto block_0042F29C;
            case 0x0042F2A8U:
                goto block_0042F2A8;
            case 0x0042F2B4U:
                goto block_0042F2B4;
            case 0x0042F2C0U:
                goto block_0042F2C0;
            case 0x0042F2C4U:
                goto block_0042F2C4;
            case 0x0042F2D0U:
                goto block_0042F2D0;
            case 0x0042F2DCU:
                goto block_0042F2DC;
            case 0x0042F2F0U:
                goto block_0042F2F0;
            case 0x0042F324U:
                goto block_0042F324;
            case 0x0042F330U:
                goto block_0042F330;
            case 0x0042F338U:
                goto block_0042F338;
            case 0x0042F33CU:
                goto block_0042F33C;
            case 0x0042F348U:
                goto block_0042F348;
            case 0x0042F350U:
                goto block_0042F350;
            case 0x0042F354U:
                goto block_0042F354;
            case 0x0042F358U:
                goto block_0042F358;
            case 0x0042F35CU:
                goto block_0042F35C;
            case 0x0042F360U:
                goto block_0042F360;
            case 0x0042F36CU:
                goto block_0042F36C;
            case 0x0042F370U:
                goto block_0042F370;
            case 0x0042F37CU:
                goto block_0042F37C;
            case 0x0042F384U:
                goto block_0042F384;
            case 0x0042F38CU:
                goto block_0042F38C;
            case 0x0042F390U:
                goto block_0042F390;
            case 0x0042F39CU:
                goto block_0042F39C;
            case 0x0042F3A0U:
                goto block_0042F3A0;
            case 0x0042F3ACU:
                goto block_0042F3AC;
            case 0x0042F3C0U:
                goto block_0042F3C0;
            case 0x0042F3D4U:
                goto block_0042F3D4;
            case 0x0042F3E8U:
                goto block_0042F3E8;
            case 0x0042F3F8U:
                goto block_0042F3F8;
            case 0x0042F400U:
                goto block_0042F400;
            case 0x0042F40CU:
                goto block_0042F40C;
            case 0x0042F418U:
                goto block_0042F418;
            case 0x0042F424U:
                goto block_0042F424;
            case 0x0042F45CU:
                goto block_0042F45C;
            case 0x0042F464U:
                goto block_0042F464;
            case 0x0042F470U:
                goto block_0042F470;
            case 0x0042F490U:
                goto block_0042F490;
            case 0x0042F49CU:
                goto block_0042F49C;
            case 0x0042F4A8U:
                goto block_0042F4A8;
            case 0x0042F4B0U:
                goto block_0042F4B0;
            case 0x0042F4BCU:
                goto block_0042F4BC;
            case 0x0042F4C8U:
                goto block_0042F4C8;
            case 0x0042F4D4U:
                goto block_0042F4D4;
            case 0x0042F4E0U:
                goto block_0042F4E0;
            case 0x0042F4E8U:
                goto block_0042F4E8;
            case 0x0042F4F8U:
                goto block_0042F4F8;
            case 0x0042F4FCU:
                goto block_0042F4FC;
            case 0x0042F524U:
                goto block_0042F524;
            case 0x0042F534U:
                goto block_0042F534;
            case 0x0042F558U:
                goto block_0042F558;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_0042E58C;
    }
block_0042E58C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E58CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E58CU);
        }
        goto block_0042F294;
    }
block_0042E5EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E5ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E5ECU);
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E5F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43d8_002F43D8(frame, context, state, 0x002F43D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E5F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E5F4;
    }
block_0042E5F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E5F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E5F4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = 0x00000104U;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E5FCU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x6CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E600U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E604U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = 0x00000002U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E610U, address);
            }
        }
        goto block_0042F294;
    }
block_0042E618:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E618U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E618U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0042E630; }
        goto block_0042E620;
    }
block_0042E620:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E620U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E620U);
        }
        {
            r0 = 0x00000104U;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E624U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r5 + 0x2CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E628U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E630U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_UpdateMessageGeometry_00439134(frame, context, state, 0x00439134U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E630U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E630;
    }
block_0042E630:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E630U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E630U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E638U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_GetRestrictionMask_00441678(frame, context, state, 0x00441678U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E638U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E638;
    }
block_0042E638:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E638U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E638U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042E688; }
        goto block_0042E644;
    }
block_0042E644:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E644U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E644U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E648U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseInput_GetHeldButtons_002F5CC4(frame, context, state, 0x002F5CC4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E648U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E648;
    }
block_0042E648:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E648U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E648U);
        }
        {
            const uint32_t value = r0 & 0x00000080U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x7CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042E64CU, address);
            }
        }
        if (flags.Z()) { goto block_0042E6E0; }
        goto block_0042E654;
    }
block_0042E654:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E654U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E654U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E654U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r5 + 0x7CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E660U, address);
            }
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0042E6E0; }
        goto block_0042E668;
    }
block_0042E668:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E668U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E668U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E66CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_HasAuxiliaryAction_002F00F4(frame, context, state, 0x002F00F4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E66CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E66C;
    }
block_0042E66C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E66CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E66CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042E6E0; }
        goto block_0042E678;
    }
block_0042E678:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E678U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E678U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E67CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_TogglePrimaryRestriction_002F009C(frame, context, state, 0x002F009CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E67CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E67C;
    }
block_0042E67C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E67CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E67CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x7CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042E67CU, address);
            }
        }
        {
        }
        goto block_0042E6E0;
    }
block_0042E688:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E688U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E688U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E690U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_GetContextMode_002F008C(frame, context, state, 0x002F008CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E690U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E690;
    }
block_0042E690:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E690U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E690U);
        }
        {
            const uint32_t value = r0 & 0x00000080U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042E6CC; }
        goto block_0042E69C;
    }
block_0042E69C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E69CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E69CU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E6A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_GetContextMode_002F008C(frame, context, state, 0x002F008CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E6A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E6A0;
    }
block_0042E6A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E6A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E6A0U);
        }
        {
            const uint32_t value = r0 & 0x00000040U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042E6CC; }
        goto block_0042E6AC;
    }
block_0042E6AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E6ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E6ACU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E6B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_GetContextMode_002F008C(frame, context, state, 0x002F008CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E6B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E6B0;
    }
block_0042E6B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E6B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E6B0U);
        }
        {
            const uint32_t value = r0 & 0x00000010U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042E6CC; }
        goto block_0042E6BC;
    }
block_0042E6BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E6BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E6BCU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E6C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_GetContextMode_002F008C(frame, context, state, 0x002F008CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E6C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E6C0;
    }
block_0042E6C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E6C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E6C0U);
        }
        {
            const uint32_t value = r0 & 0x00000020U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
        }
        if (flags.Z()) { goto block_0042E6E0; }
        goto block_0042E6CC;
    }
block_0042E6CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E6CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E6CCU);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E6D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_HasAuxiliaryAction_002F00F4(frame, context, state, 0x002F00F4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E6D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E6D4;
    }
block_0042E6D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E6D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E6D4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E6E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_TogglePrimaryRestriction_002F009C(frame, context, state, 0x002F009CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E6E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E6E0;
    }
block_0042E6E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E6E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E6E0U);
        }
        {
            const uint32_t updatedAddress = 0x0042E6E8U + 0x344U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E6E0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E6E4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0042E724; }
        goto block_0042E6F0;
    }
block_0042E6F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E6F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E6F0U);
        }
        {
            const uint32_t updatedAddress = 0x0042E6F8U + 0x334U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E6F0U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E6F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_StaticInitGuard_TryAcquire_003679B4(frame, context, state, 0x003679B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E6F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E6F8;
    }
block_0042E6F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E6F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E6F8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042E724; }
        goto block_0042E704;
    }
block_0042E704:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E704U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E704U);
        }
        {
            const uint32_t updatedAddress = 0x0042E70CU + 0x324U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E704U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E70CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_RendererGlobalState_Init_0036788C(frame, context, state, 0x0036788CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E70CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E70C;
    }
block_0042E70C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E70CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E70CU);
        }
        {
            const uint32_t updatedAddress = 0x0042E714U + 0x320U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E70CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0042E718U + 0x320U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E710U, address);
            }
            r1 = value;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x0042E720U + 0x30CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E718U, address);
            }
            r0 = value;
        }
        {
        }
        {
            r0 = r0;
        }
        goto block_0042E724;
    }
block_0042E724:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E724U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E724U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E724U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF38U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E728U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0042E7A0; }
        goto block_0042E734;
    }
block_0042E734:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E734U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E734U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E738U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E738U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E738;
    }
block_0042E738:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E738U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E738U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042E7A0; }
        goto block_0042E744;
    }
block_0042E744:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E744U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E744U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E744U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0042E750U + 792U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E748U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x0042E754U + 792U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E74CU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            r2 = 0x00000014U;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r1 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E764U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadAlphaRange_002F8B80(frame, context, state, 0x002F8B80U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E764U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E764;
    }
block_0042E764:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E764U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E764U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E76CU, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000012U;
        }
        {
            r1 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E77CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadAlphaRange_002F8B80(frame, context, state, 0x002F8B80U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E77CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E77C;
    }
block_0042E77C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E77CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E77CU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E784U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000013U;
        }
        {
            r1 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E794U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadAlphaRange_002F8B80(frame, context, state, 0x002F8B80U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E794U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E794;
    }
block_0042E794:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E794U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E794U);
        }
        {
        }
        {
        }
        goto block_0042E7EC;
    }
block_0042E7A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E7A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E7A0U);
        }
        {
            const uint32_t address = 0x0042E7A8U + 708U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E7A0U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E7A4U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000014U;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r1 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E7BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadAlphaRange_002F8B80(frame, context, state, 0x002F8B80U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E7BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E7BC;
    }
block_0042E7BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E7BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E7BCU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E7C4U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000012U;
        }
        {
            r1 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E7D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadAlphaRange_002F8B80(frame, context, state, 0x002F8B80U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E7D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E7D4;
    }
block_0042E7D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E7D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E7D4U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E7DCU, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000013U;
        }
        {
            r1 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E7ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadAlphaRange_002F8B80(frame, context, state, 0x002F8B80U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E7ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E7EC;
    }
block_0042E7EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E7ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E7ECU);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E7F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b164_0035B164(frame, context, state, 0x0035B164U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E7F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E7F4;
    }
block_0042E7F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E7F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E7F4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042E818; }
        goto block_0042E800;
    }
block_0042E800:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E800U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E800U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E800U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000014U;
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t address = 0x0042E814U + 596U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E80CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0042E818U + 596U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E810U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E818U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadAlphaRange_002F8B80(frame, context, state, 0x002F8B80U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E818U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E818;
    }
block_0042E818:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E818U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E818U);
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0042E81CU, address);
            }
        }
        {
            r3 = 0x00000026U;
        }
        {
            r2 = 0x00000040U;
        }
        {
            r1 = 0x000000CAU;
        }
        {
            r0 = 0x000000C0U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E834U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E834U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E834;
    }
block_0042E834:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E834U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E834U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042E874; }
        goto block_0042E840;
    }
block_0042E840:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E840U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E840U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E844U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E844U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E844;
    }
block_0042E844:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E844U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E844U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E848U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t value = r0 & 0x20000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x20000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0042F294; }
        goto block_0042E854;
    }
block_0042E854:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E854U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E854U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E854U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000003U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E860U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E860U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E860;
    }
block_0042E860:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E860U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E860U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042F294; }
        goto block_0042E86C;
    }
block_0042E86C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E86CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E86CU);
        }
        {
            r0 = 0x00000007U;
        }
        goto block_0042ED00;
    }
block_0042E874:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E874U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E874U);
        }
        {
            r3 = 0x00000001U;
        }
        {
            r2 = 0x00000040U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0042E87CU, address);
            }
        }
        {
            r3 = 0x00000026U;
        }
        {
            r1 = 0x000000CAU;
        }
        {
            r0 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E890U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E890U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E890;
    }
block_0042E890:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E890U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E890U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042E8D0; }
        goto block_0042E89C;
    }
block_0042E89C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E89CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E89CU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E8A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E8A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E8A0;
    }
block_0042E8A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E8A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E8A0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E8A4U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t value = r0 & 0x80000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x80000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0042EA70; }
        goto block_0042E8B0;
    }
block_0042E8B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E8B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E8B0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E8B0U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000003U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E8BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E8BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E8BC;
    }
block_0042E8BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E8BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E8BCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042EA70; }
        goto block_0042E8C8;
    }
block_0042E8C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E8C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E8C8U);
        }
        {
            r0 = 0x00000008U;
        }
        goto block_0042E938;
    }
block_0042E8D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E8D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E8D0U);
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0042E8D4U, address);
            }
        }
        {
            r3 = 0x00000026U;
        }
        {
            r2 = 0x00000040U;
        }
        {
            r1 = 0x000000CAU;
        }
        {
            r0 = 0x00000080U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E8ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E8ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E8EC;
    }
block_0042E8EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E8ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E8ECU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042E940; }
        goto block_0042E8F8;
    }
block_0042E8F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E8F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E8F8U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E8FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E8FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E8FC;
    }
block_0042E8FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E8FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E8FCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E900U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t value = r0 & 0x40000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x40000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0042EA70; }
        goto block_0042E90C;
    }
block_0042E90C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E90CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E90CU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E910U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b164_0035B164(frame, context, state, 0x0035B164U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E910U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E910;
    }
block_0042E910:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E910U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E910U);
        }
        {
            const uint32_t value = r0 ^ 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
        }
        if (flags.Z()) { goto block_0042EA70; }
        goto block_0042E91C;
    }
block_0042E91C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E91CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E91CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E91CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000003U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E928U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E928U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E928;
    }
block_0042E928:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E928U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E928U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042EA70; }
        goto block_0042E934;
    }
block_0042E934:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E934U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E934U);
        }
        {
            r0 = 0x00000009U;
        }
        goto block_0042E938;
    }
block_0042E938:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E938U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E938U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042E938U, address);
            }
        }
        goto block_0042EA70;
    }
block_0042E940:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E940U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E940U);
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0042E944U, address);
            }
        }
        {
            r3 = 0x00000034U;
        }
        {
            r2 = r3;
        }
        {
            r1 = 0x000000BAU;
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E95CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E95CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E95C;
    }
block_0042E95C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E95CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E95CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042E98C; }
        goto block_0042E968;
    }
block_0042E968:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E968U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E968U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E96CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E96CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E96C;
    }
block_0042E96C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E96CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E96CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042EA70; }
        goto block_0042E978;
    }
block_0042E978:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E978U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E978U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E97CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_ResolveContextState_002EFFF8(frame, context, state, 0x002EFFF8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E97CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E97C;
    }
block_0042E97C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E97CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E97CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r0 = 0x0000000AU;
        }
        if (flags.Z()) { goto block_0042E938; }
        goto block_0042E988;
    }
block_0042E988:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E988U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E988U);
        }
        goto block_0042EA70;
    }
block_0042E98C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E98CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E98CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E98CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x749U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E990U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0042E9DC; }
        goto block_0042E99C;
    }
block_0042E99C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E99CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E99CU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E9A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E9A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E9A0;
    }
block_0042E9A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E9A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E9A0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042E9A4U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t value = r0 & 0x10000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x10000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0042EA70; }
        goto block_0042E9B0;
    }
block_0042E9B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E9B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E9B0U);
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0042E9B4U, address);
            }
        }
        {
            r3 = 0x00000034U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r2 = r3;
        }
        {
            r0 = r1;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E9CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E9CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E9CC;
    }
block_0042E9CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E9CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E9CCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (flags.Z()) { goto block_0042EA70; }
        goto block_0042E9D8;
    }
block_0042E9D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E9D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E9D8U);
        }
        goto block_0042EA1C;
    }
block_0042E9DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E9DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E9DCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0042EA70; }
        goto block_0042E9E4;
    }
block_0042E9E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E9E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E9E4U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042E9E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042E9E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042E9E8;
    }
block_0042E9E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E9E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E9E8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042EA70; }
        goto block_0042E9F4;
    }
block_0042E9F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042E9F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042E9F4U);
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0042E9F8U, address);
            }
        }
        {
            r3 = 0x00000034U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r2 = r3;
        }
        {
            r0 = r1;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EA10U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EA10U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EA10;
    }
block_0042EA10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EA10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EA10U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (flags.Z()) { goto block_0042EA70; }
        goto block_0042EA1C;
    }
block_0042EA1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EA1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EA1CU);
        }
        {
            r0 = 0x0000000BU;
        }
        goto block_0042E938;
    }
block_0042EA70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EA70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EA70U);
        }
        {
            const uint32_t updatedAddress = 0x0042EA78U + 0xAECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EA70U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0042EA7CU + 0xAECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EA74U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x7U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EA78U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r2 + r0;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EA7CU, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0042EAAC; }
        goto block_0042EA88;
    }
block_0042EA88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EA88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EA88U);
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EA88U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r0;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EA8CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r1 = 0x00000008U;
        }
        if (flags.Z()) {
            r0 = 0x00000000U;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EAA0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_SetContextIcon_002EFEA0(frame, context, state, 0x002EFEA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EAA0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EAA0;
    }
block_0042EAA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EAA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EAA0U);
        }
        {
        }
        {
        }
        goto block_0042EAB8;
    }
block_0042EAAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EAACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EAACU);
        }
        {
            r1 = 0x00000007U;
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EAB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_SetContextIcon_002EFEA0(frame, context, state, 0x002EFEA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EAB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EAB8;
    }
block_0042EAB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EAB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EAB8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042EAB8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042EABCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042EAC0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042EAC4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042EAC8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x50U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042EACCU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EAD4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EAD4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EAD4;
    }
block_0042EAD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EAD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EAD4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042EC24; }
        goto block_0042EAE0;
    }
block_0042EAE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EAE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EAE0U);
        }
        {
            r3 = 0x00000001U;
        }
        {
            r1 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0042EAE8U, address);
            }
        }
        {
            r3 = 0x00000034U;
        }
        {
            const uint32_t operand = 0x00000108U;
            r11 = r1 + operand;
        }
        {
            r2 = r3;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EB00U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EB00U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EB00;
    }
block_0042EB00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EB00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EB00U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x0042EB0CU - 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EB04U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x83U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EB08U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0042EB30; }
        goto block_0042EB14;
    }
block_0042EB14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EB14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EB14U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EB14U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x04000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x04000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0042EB30; }
        goto block_0042EB20;
    }
block_0042EB20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EB20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EB20U);
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0042EB24U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042EB28U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0042EB2CU, address);
            }
        }
        goto block_0042EB30;
    }
block_0042EB30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EB30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EB30U);
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0042EB34U, address);
            }
        }
        {
            r3 = 0x00000034U;
        }
        {
            r2 = r3;
        }
        {
            r1 = 0x000000BAU;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EB4CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EB4CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EB4C;
    }
block_0042EB4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EB4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EB4CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x0042EB58U - 0x108U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EB50U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x84U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EB54U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0042EB7C; }
        goto block_0042EB60;
    }
block_0042EB60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EB60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EB60U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EB60U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x02000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x02000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0042EB7C; }
        goto block_0042EB6C;
    }
block_0042EB6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EB6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EB6CU);
        }
        {
            r0 = 0x00000006U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0042EB70U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042EB74U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0042EB78U, address);
            }
        }
        goto block_0042EB7C;
    }
block_0042EB7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EB7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EB7CU);
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0042EB80U, address);
            }
        }
        {
            r3 = 0x00000029U;
        }
        {
            r2 = r3;
        }
        {
            r1 = 0x00000043U;
        }
        {
            r0 = 0x0000011CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EB98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EB98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EB98;
    }
block_0042EB98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EB98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EB98U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x0042EBA4U - 0x154U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EB9CU, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x82U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EBA0U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0042EBD0; }
        goto block_0042EBAC;
    }
block_0042EBAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EBACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EBACU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EBACU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x01000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x01000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0042EBD0; }
        goto block_0042EBB8;
    }
block_0042EBB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EBB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EBB8U);
        }
        {
            const uint32_t updatedAddress = 0x0042EBC0U + 0x9ACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EBB8U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000400U;
        }
        {
            const uint32_t updatedAddress = r1 + 0xC4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042EBC0U, address);
            }
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042EBC8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0042EBCCU, address);
            }
        }
        goto block_0042EBD0;
    }
block_0042EBD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EBD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EBD0U);
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0042EBD4U, address);
            }
        }
        {
            r3 = 0x00000029U;
        }
        {
            r2 = r3;
        }
        {
            r1 = 0x0000006DU;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EBECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EBECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EBEC;
    }
block_0042EBEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EBECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EBECU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x0042EBF8U - 0x1A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EBF0U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r0 + 0x81U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EBF4U, address);
            }
            r0 = value;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0042EC24; }
        goto block_0042EC00;
    }
block_0042EC00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EC00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EC00U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EC00U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00800000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00800000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0042EC24; }
        goto block_0042EC0C;
    }
block_0042EC0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EC0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EC0CU);
        }
        {
            const uint32_t updatedAddress = 0x0042EC14U + 0x958U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EC0CU, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000800U;
        }
        {
            const uint32_t updatedAddress = r1 + 0xC4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042EC14U, address);
            }
        }
        {
            r0 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042EC1CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x50U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0042EC20U, address);
            }
        }
        goto block_0042EC24;
    }
block_0042EC24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EC24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EC24U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EC2CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Input_GetPressedButtonMask_0033B5EC(frame, context, state, 0x0033B5ECU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EC2CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EC2C;
    }
block_0042EC2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EC2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EC2CU);
        }
        {
            const uint32_t value = r0 & 0x00000008U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F294; }
        goto block_0042EC38;
    }
block_0042EC38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EC38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EC38U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EC38U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00400000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00400000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0042F294; }
        goto block_0042EC44;
    }
block_0042EC44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EC44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EC44U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EC48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b164_0035B164(frame, context, state, 0x0035B164U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EC48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EC48;
    }
block_0042EC48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EC48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EC48U);
        }
        {
            const uint32_t value = r0 ^ 0x00000001U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F294; }
        goto block_0042EC54;
    }
block_0042EC54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EC54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EC54U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EC5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43d8_002F43D8(frame, context, state, 0x002F43D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EC5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EC5C;
    }
block_0042EC5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EC5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EC5CU);
        }
        {
            r0 = 0x0000000EU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x5CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042EC60U, address);
            }
        }
        goto block_0042ED00;
    }
block_0042EC68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EC68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EC68U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0042EC68U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042EC6CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EC70U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0042EC8C; }
        goto block_0042EC7C;
    }
block_0042EC7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EC7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EC7CU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EC80U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EC80U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EC80;
    }
block_0042EC80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EC80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EC80U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042F294; }
        goto block_0042EC8C;
    }
block_0042EC8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EC8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EC8CU);
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042EC90U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042EC94U, address);
            }
        }
        goto block_0042F294;
    }
block_0042EC9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EC9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EC9CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0042EC9CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042ECA0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042ECA4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0042ECC0; }
        goto block_0042ECB0;
    }
block_0042ECB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042ECB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042ECB0U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042ECB4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042ECB4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042ECB4;
    }
block_0042ECB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042ECB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042ECB4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042F294; }
        goto block_0042ECC0;
    }
block_0042ECC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042ECC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042ECC0U);
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042ECC4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042ECC8U, address);
            }
        }
        goto block_0042F294;
    }
block_0042ECD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042ECD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042ECD0U);
        }
        {
            const uint32_t updatedAddress = 0x0042ECD8U + 0x894U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042ECD0U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000400U;
        }
        {
            const uint32_t updatedAddress = r1 + 0xC4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042ECD8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042ECDCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0042ECF8; }
        goto block_0042ECE8;
    }
block_0042ECE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042ECE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042ECE8U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042ECECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042ECECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042ECEC;
    }
block_0042ECEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042ECECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042ECECU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042F294; }
        goto block_0042ECF8;
    }
block_0042ECF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042ECF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042ECF8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042ECF8U, address);
            }
        }
        goto block_0042ED34;
    }
block_0042ED00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042ED00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042ED00U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042ED00U, address);
            }
        }
        goto block_0042F294;
    }
block_0042ED08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042ED08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042ED08U);
        }
        {
            const uint32_t updatedAddress = 0x0042ED10U + 0x85CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042ED08U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000800U;
        }
        {
            const uint32_t updatedAddress = r1 + 0xC4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042ED10U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042ED14U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0042ED30; }
        goto block_0042ED20;
    }
block_0042ED20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042ED20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042ED20U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042ED24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042ED24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042ED24;
    }
block_0042ED24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042ED24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042ED24U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042F294; }
        goto block_0042ED30;
    }
block_0042ED30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042ED30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042ED30U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x50U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042ED30U, address);
            }
        }
        goto block_0042ED34;
    }
block_0042ED34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042ED34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042ED34U);
        }
        {
            r0 = 0x00000002U;
        }
        goto block_0042ED00;
    }
block_0042ED3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042ED3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042ED3CU);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042ED44U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042ED44U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042ED44;
    }
block_0042ED44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042ED44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042ED44U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042ED6C; }
        goto block_0042ED50;
    }
block_0042ED50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042ED50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042ED50U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042ED54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_kaleido_draw_ui_overlay_split_002efd88_002EFD88(frame, context, state, 0x002EFD88U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042ED54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042ED54;
    }
block_0042ED54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042ED54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042ED54U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042ED54U, address);
            }
            r0 = value;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042ED60U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_ClearOffsets_00343270(frame, context, state, 0x00343270U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042ED60U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042ED60;
    }
block_0042ED60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042ED60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042ED60U);
        }
        {
        }
        {
        }
        goto block_0042F0E8;
    }
block_0042ED6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042ED6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042ED6CU);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042ED74U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_kaleido_draw_ui_overlay_split_002ef9b4_002EF9B4(frame, context, state, 0x002EF9B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042ED74U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042ED74;
    }
block_0042ED74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042ED74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042ED74U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F294; }
        goto block_0042ED80;
    }
block_0042ED80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042ED80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042ED80U);
        }
        {
            const uint32_t updatedAddress = 0x0042ED88U - 0x338U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042ED80U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0x5CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042ED84U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0042ED90U + 0x7E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042ED88U, address);
            }
            r12 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x48U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042ED8CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0042ED9CU + 0x7D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042ED94U, address);
            }
            r1 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042ED9CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r9 + 0x5CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042EDA0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r2 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EDA4U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EDA8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r12 + 0x4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EDACU, address);
            }
            r12 = value;
        }
        {
            r3 = r3 & r1;
        }
        {
            const uint32_t updatedAddress = 0x0042EDBCU + 0x7BCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EDB4U, address);
            }
            r1 = value;
        }
        {
            r3 = Oot3dAotShiftRegister(r3, 2U, r12, false).Value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r3, 1U);
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x20U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EDC0U, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r1 + 0x20U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EDC8U, address);
            }
            r0 = value;
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r2 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042EDCCU, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_0042EDDC; }
        goto block_0042EDD4;
    }
block_0042EDD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EDD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EDD4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r2 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042EDD8U, address);
            }
        }
        goto block_0042EDDC;
    }
block_0042EDDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EDDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EDDCU);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = r1;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EDE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseInput_SetTouchEnabled_002FD84C(frame, context, state, 0x002FD84CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EDE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EDE8;
    }
block_0042EDE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EDE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EDE8U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042EDECU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EDF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseSystemMenu_Open_0043ACA8(frame, context, state, 0x0043ACA8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EDF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EDF4;
    }
block_0042EDF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EDF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EDF4U);
        }
        {
        }
        {
        }
        goto block_0042F294;
    }
block_0042EE00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EE00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EE00U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EE08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_AnimatePageTransition_002EF684(frame, context, state, 0x002EF684U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EE08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EE08;
    }
block_0042EE08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EE08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EE08U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F294; }
        goto block_0042EE14;
    }
block_0042EE14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EE14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EE14U);
        }
        goto block_0042F248;
    }
block_0042EE18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EE18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EE18U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EE20U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EE20U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EE20;
    }
block_0042EE20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EE20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EE20U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F0E8; }
        goto block_0042EE2C;
    }
block_0042EE2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EE2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EE2CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EE2CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x20000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x20000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0042F0E8; }
        goto block_0042EE38;
    }
block_0042EE38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EE38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EE38U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EE38U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000003U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EE44U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EE44U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EE44;
    }
block_0042EE44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EE44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EE44U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F294; }
        goto block_0042EE50;
    }
block_0042EE50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EE50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EE50U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0042EE54U, address);
            }
        }
        {
            r3 = 0x00000026U;
        }
        {
            r2 = 0x00000040U;
        }
        {
            r1 = 0x000000CAU;
        }
        {
            r0 = 0x000000C0U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EE6CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EE6CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EE6C;
    }
block_0042EE6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EE6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EE6CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042EE8C; }
        goto block_0042EE78;
    }
block_0042EE78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EE78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EE78U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EE80U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43d8_002F43D8(frame, context, state, 0x002F43D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EE80U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EE80;
    }
block_0042EE80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EE80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EE80U);
        }
        {
            r0 = 0x0000000CU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x5CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042EE84U, address);
            }
        }
        goto block_0042ED00;
    }
block_0042EE8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EE8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EE8CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EE8CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0042F294; }
        goto block_0042EE98;
    }
block_0042EE98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EE98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EE98U);
        }
        goto block_0042F0E8;
    }
block_0042EE9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EE9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EE9CU);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EEA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EEA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EEA4;
    }
block_0042EEA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EEA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EEA4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0042EED0; }
        goto block_0042EEB0;
    }
block_0042EEB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EEB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EEB0U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EEB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_kaleido_draw_ui_overlay_split_002efd88_002EFD88(frame, context, state, 0x002EFD88U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EEB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EEB8;
    }
block_0042EEB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EEB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EEB8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EEB8U, address);
            }
            r0 = value;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EEC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_ClearOffsets_00343270(frame, context, state, 0x00343270U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EEC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EEC4;
    }
block_0042EEC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EEC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EEC4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0042EEC4U, address);
            }
        }
        {
        }
        goto block_0042F294;
    }
block_0042EED0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EED0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EED0U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EED8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_kaleido_draw_ui_overlay_split_002ef9b4_002EF9B4(frame, context, state, 0x002EF9B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EED8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EED8;
    }
block_0042EED8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EED8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EED8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F294; }
        goto block_0042EEE4;
    }
block_0042EEE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EEE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EEE4U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = r1;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EEF0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseInput_SetTouchEnabled_002FD84C(frame, context, state, 0x002FD84CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EEF0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EEF0;
    }
block_0042EEF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EEF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EEF0U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042EEF4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EEFCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseGearPage_SetMode_002F8A34(frame, context, state, 0x002F8A34U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EEFCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EEFC;
    }
block_0042EEFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EEFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EEFCU);
        }
        {
        }
        {
        }
        goto block_0042F294;
    }
block_0042EF08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EF08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EF08U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EF10U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_AnimatePageTransition_002EF684(frame, context, state, 0x002EF684U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EF10U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EF10;
    }
block_0042EF10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EF10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EF10U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F294; }
        goto block_0042EF1C;
    }
block_0042EF1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EF1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EF1CU);
        }
        goto block_0042F248;
    }
block_0042EF20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EF20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EF20U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EF28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EF28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EF28;
    }
block_0042EF28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EF28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EF28U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F0E8; }
        goto block_0042EF34;
    }
block_0042EF34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EF34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EF34U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EF34U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x80000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x80000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0042F0E8; }
        goto block_0042EF40;
    }
block_0042EF40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EF40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EF40U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EF40U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000003U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EF4CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EF4CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EF4C;
    }
block_0042EF4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EF4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EF4CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F294; }
        goto block_0042EF58;
    }
block_0042EF58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EF58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EF58U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            r2 = 0x00000040U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0042EF60U, address);
            }
        }
        {
            r3 = 0x00000026U;
        }
        {
            r1 = 0x000000CAU;
        }
        {
            r0 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EF74U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EF74U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EF74;
    }
block_0042EF74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EF74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EF74U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042EF94; }
        goto block_0042EF80;
    }
block_0042EF80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EF80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EF80U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EF88U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43d8_002F43D8(frame, context, state, 0x002F43D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EF88U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EF88;
    }
block_0042EF88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EF88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EF88U);
        }
        {
            r0 = 0x00000010U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x5CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042EF8CU, address);
            }
        }
        goto block_0042ED00;
    }
block_0042EF94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EF94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EF94U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042EF94U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0042F294; }
        goto block_0042EFA0;
    }
block_0042EFA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EFA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EFA0U);
        }
        goto block_0042F0E8;
    }
block_0042EFA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EFA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EFA4U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EFACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EFACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EFAC;
    }
block_0042EFAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EFACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EFACU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042EEB0; }
        goto block_0042EFB8;
    }
block_0042EFB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EFB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EFB8U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EFBCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_kaleido_draw_ui_overlay_split_002ef9b4_002EF9B4(frame, context, state, 0x002EF9B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EFBCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EFBC;
    }
block_0042EFBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EFBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EFBCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F294; }
        goto block_0042EFC8;
    }
block_0042EFC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EFC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EFC8U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = r1;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EFD4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseInput_SetTouchEnabled_002FD84C(frame, context, state, 0x002FD84CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EFD4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EFD4;
    }
block_0042EFD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EFD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EFD4U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042EFD8U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EFE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseGearPage_ApplyTransitionMode_002F0444(frame, context, state, 0x002F0444U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EFE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EFE0;
    }
block_0042EFE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EFE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EFE0U);
        }
        {
        }
        {
        }
        goto block_0042F294;
    }
block_0042EFEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EFECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EFECU);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042EFF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_AnimatePageTransition_002EF684(frame, context, state, 0x002EF684U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042EFF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042EFF4;
    }
block_0042EFF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042EFF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042EFF4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F294; }
        goto block_0042F000;
    }
block_0042F000:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F000U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F000U);
        }
        goto block_0042F248;
    }
block_0042F004:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F004U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F004U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F00CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F00CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F00C;
    }
block_0042F00C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F00CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F00CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F0E8; }
        goto block_0042F018;
    }
block_0042F018:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F018U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F018U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F018U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x40000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x40000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0042F0E8; }
        goto block_0042F024;
    }
block_0042F024:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F024U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F024U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F024U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000003U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F030U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00374be8_00374BE8(frame, context, state, 0x00374BE8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F030U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F030;
    }
block_0042F030:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F030U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F030U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F294; }
        goto block_0042F03C;
    }
block_0042F03C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F03CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F03CU);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0042F040U, address);
            }
        }
        {
            r3 = 0x00000026U;
        }
        {
            r2 = 0x00000040U;
        }
        {
            r1 = 0x000000CAU;
        }
        {
            r0 = 0x00000080U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F058U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F058U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F058;
    }
block_0042F058:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F058U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F058U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F078; }
        goto block_0042F064;
    }
block_0042F064:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F064U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F064U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F06CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43d8_002F43D8(frame, context, state, 0x002F43D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F06CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F06C;
    }
block_0042F06C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F06CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F06CU);
        }
        {
            r0 = 0x00000014U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x5CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042F070U, address);
            }
        }
        goto block_0042ED00;
    }
block_0042F078:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F078U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F078U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F078U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0042F294; }
        goto block_0042F084;
    }
block_0042F084:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F084U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F084U);
        }
        goto block_0042F0E8;
    }
block_0042F088:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F088U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F088U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F090U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F090U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F090;
    }
block_0042F090:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F090U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F090U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042EEB0; }
        goto block_0042F09C;
    }
block_0042F09C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F09CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F09CU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F0A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_kaleido_draw_ui_overlay_split_002ef9b4_002EF9B4(frame, context, state, 0x002EF9B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F0A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F0A0;
    }
block_0042F0A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F0A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F0A0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F294; }
        goto block_0042F0AC;
    }
block_0042F0AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F0ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F0ACU);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = r1;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F0B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseInput_SetTouchEnabled_002FD84C(frame, context, state, 0x002FD84CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F0B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F0B8;
    }
block_0042F0B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F0B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F0B8U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042F0BCU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F0C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseUi_ResetInteractionState_002F8708(frame, context, state, 0x002F8708U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F0C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F0C4;
    }
block_0042F0C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F0C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F0C4U);
        }
        {
        }
        {
        }
        goto block_0042F294;
    }
block_0042F0D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F0D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F0D0U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F0D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_AnimatePageTransition_002EF684(frame, context, state, 0x002EF684U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F0D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F0D8;
    }
block_0042F0D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F0D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F0D8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F294; }
        goto block_0042F0E4;
    }
block_0042F0E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F0E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F0E4U);
        }
        goto block_0042F248;
    }
block_0042F0E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F0E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F0E8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0042F0E8U, address);
            }
        }
        goto block_0042F294;
    }
block_0042F0F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F0F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F0F0U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F0F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F0F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F0F8;
    }
block_0042F0F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F0F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F0F8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F0E8; }
        goto block_0042F104;
    }
block_0042F104:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F104U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F104U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F104U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x10000000U;
            Oot3dAotSetLogicalFlags(flags, value, (0x10000000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0042F0E8; }
        goto block_0042F110;
    }
block_0042F110:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F110U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F110U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0042F114U, address);
            }
        }
        {
            r3 = 0x00000034U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r2 = r3;
        }
        {
            r0 = r1;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F12CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F12CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F12C;
    }
block_0042F12C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F12CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F12CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (flags.Z()) { goto block_0042F164; }
        goto block_0042F138;
    }
block_0042F138:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F138U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F138U);
        }
        {
            r0 = 0x00000230U;
        }
        {
            const uint32_t updatedAddress = r0 + r8;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F13CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x38U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042F144U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0042F148U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F14CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x749U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F150U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x0042F160U + 0x40CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F158U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r0 + 0xC4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0042F15CU, address);
            }
        }
        goto block_0042F294;
    }
block_0042F164:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F164U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F164U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F164U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0042F0E8; }
        goto block_0042F170;
    }
block_0042F170:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F170U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F170U);
        }
        goto block_0042F294;
    }
block_0042F174:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F174U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F174U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F17CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F17CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F17C;
    }
block_0042F17C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F17CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F17CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F0E8; }
        goto block_0042F188;
    }
block_0042F188:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F188U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F188U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F18CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_ResolveContextState_002EFFF8(frame, context, state, 0x002EFFF8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F18CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F18C;
    }
block_0042F18C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F18CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F18CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F0E8; }
        goto block_0042F198;
    }
block_0042F198:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F198U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F198U);
        }
        {
            r3 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0042F19CU, address);
            }
        }
        {
            r3 = 0x00000034U;
        }
        {
            r2 = r3;
        }
        {
            r1 = 0x000000BAU;
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F1B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TouchInput_IsRectActive_0033F428(frame, context, state, 0x0033F428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F1B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F1B4;
    }
block_0042F1B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F1B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F1B4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0x60U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0042F1B8U, address);
            }
        }
        if (!(flags.Z())) { goto block_0042F0E8; }
        goto block_0042F1C0;
    }
block_0042F1C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F1C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F1C0U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F1C0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0042F0E8; }
        goto block_0042F1CC;
    }
block_0042F1CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F1CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F1CCU);
        }
        goto block_0042F294;
    }
block_0042F1D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F1D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F1D0U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F1D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_002f43e8_002F43E8(frame, context, state, 0x002F43E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F1D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F1D8;
    }
block_0042F1D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F1D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F1D8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F1DCU, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0042EEB0; }
        goto block_0042F1E8;
    }
block_0042F1E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F1E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F1E8U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F1F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_kaleido_draw_ui_overlay_split_002ef9b4_002EF9B4(frame, context, state, 0x002EF9B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F1F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F1F0;
    }
block_0042F1F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F1F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F1F0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F294; }
        goto block_0042F1FC;
    }
block_0042F1FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F1FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F1FCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042F1FCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F200U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0042F220; }
        goto block_0042F20C;
    }
block_0042F20C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F20CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F20CU);
        }
        {
            r0 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F214U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseWorldMap_ResetSelection_0043C038(frame, context, state, 0x0043C038U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F214U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F214;
    }
block_0042F214:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F214U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F214U);
        }
        {
        }
        {
        }
        goto block_0042F22C;
    }
block_0042F220:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F220U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F220U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0042F294; }
        goto block_0042F228;
    }
block_0042F228:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F228U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F228U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F22CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseWorldMap_ResetToDestinationMode_0043BDE4(frame, context, state, 0x0043BDE4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F22CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F22C;
    }
block_0042F22C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F22CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F22CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x74U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0042F22CU, address);
            }
        }
        goto block_0042F294;
    }
block_0042F234:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F234U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F234U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F23CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_AnimatePageTransition_002EF684(frame, context, state, 0x002EF684U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F23CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F23C;
    }
block_0042F23C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F23CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F23CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F294; }
        goto block_0042F248;
    }
block_0042F248:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F248U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F248U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F248U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F250U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_ClearOffsets_00343270(frame, context, state, 0x00343270U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F250U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F250;
    }
block_0042F250:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F250U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F250U);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F25CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_kaleido_draw_ui_overlay_split_002efd88_002EFD88(frame, context, state, 0x002EFD88U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F25CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F25C;
    }
block_0042F25C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F25CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F25CU);
        }
        {
        }
        {
        }
        goto block_0042F0E8;
    }
block_0042F268:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F268U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F268U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F270U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_kaleido_draw_ui_overlay_split_002ef9b4_002EF9B4(frame, context, state, 0x002EF9B4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F270U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F270;
    }
block_0042F270:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F270U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F270U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0042F294; }
        goto block_0042F27C;
    }
block_0042F27C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F27CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F27CU);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = r1;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F288U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseInput_SetTouchEnabled_002FD84C(frame, context, state, 0x002FD84CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F288U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F288;
    }
block_0042F288:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F288U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F288U);
        }
        {
            r0 = 0x00000017U;
        }
        {
        }
        goto block_0042ED00;
    }
block_0042F294:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F294U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F294U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F29CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_RefreshIconLayout_004439C4(frame, context, state, 0x004439C4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F29CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F29C;
    }
block_0042F29C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F29CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F29CU);
        }
        {
            r0 = 0x00000000U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F2A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseInventory_SyncAndRefresh_0033C25C(frame, context, state, 0x0033C25CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F2A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F2A8;
    }
block_0042F2A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F2A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F2A8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F2A8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F2B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderGroup_DrawAnimatedMask_002F0E08(frame, context, state, 0x002F0E08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F2B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F2B4;
    }
block_0042F2B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F2B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F2B4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F2B4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0042F2DC; }
        goto block_0042F2C0;
    }
block_0042F2C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F2C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F2C0U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F2C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_ResolveActionStates_002EF2C0(frame, context, state, 0x002EF2C0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F2C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F2C4;
    }
block_0042F2C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F2C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F2C4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F2C4U, address);
            }
            r0 = value;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F2D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_UpdateActionGridGeometry_002EEF74(frame, context, state, 0x002EEF74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F2D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F2D0;
    }
block_0042F2D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F2D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F2D0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F2D0U, address);
            }
            r0 = value;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F2DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderGroup_DrawPositionTexColor_002F0C84(frame, context, state, 0x002F0C84U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F2DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F2DC;
    }
block_0042F2DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F2DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F2DCU);
        }
        {
            const uint32_t updatedAddress = 0x0042F2E4U - 0x894U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F2DCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x54U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F2E0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x48U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F2E4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r2, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0042F348; }
        goto block_0042F2F0;
    }
block_0042F2F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F2F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F2F0U);
        }
        {
            const uint32_t updatedAddress = 0x0042F2F8U + 0x278U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F2F0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0042F2FCU + 0x278U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F2F4U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x54U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0042F2F8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F2FCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r2 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F300U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r3 + 0x4U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F304U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0042F310U + 0x268U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F308U, address);
            }
            r12 = value;
        }
        {
            r0 = r0 & r2;
        }
        {
            r0 = Oot3dAotShiftRegister(r0, 2U, r3, false).Value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r0 = r12 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x20U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F318U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0042F33C; }
        goto block_0042F324;
    }
block_0042F324:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F324U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F324U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F324U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F330U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseCounter_UpdateDigitGeometry_002FCB04(frame, context, state, 0x002FCB04U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F330U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F330;
    }
block_0042F330:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F330U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F330U);
        }
        {
        }
        {
        }
        goto block_0042F338;
    }
block_0042F338:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F338U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F338U);
        }
        goto block_0042F348;
    }
block_0042F33C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F33CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F33CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F33CU, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F348U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseCounter_UpdateDigitGeometry_002FCB04(frame, context, state, 0x002FCB04U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F348U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F348;
    }
block_0042F348:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F348U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F348U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0042F3F8; }
        goto block_0042F350;
    }
block_0042F350:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F350U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F350U);
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r13 + operand;
        }
        goto block_0042F354;
    }
block_0042F354:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F354U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F354U);
        }
        {
            r1 = 0x00000000U;
        }
        goto block_0042F358;
    }
block_0042F358:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F358U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F358U);
        }
        {
            r2 = r1;
        }
        goto block_0042F35C;
    }
block_0042F35C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F35CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F35CU);
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0042F35CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0042F35CU,
                                           firstAddress + 4U);
            }
        }
        goto block_0042F360;
    }
block_0042F360:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F360U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F360U);
        }
        {
            r3 = 0x0000001BU;
        }
        {
            const uint32_t address = 0x0042F36CU + 528U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F364U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = 0x00000001U;
        }
        goto block_0042F36C;
    }
block_0042F36C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F36CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F36CU);
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0042F36CU, address);
            }
        }
        goto block_0042F370;
    }
block_0042F370:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F370U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F370U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F370U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F37CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetVec2Range_002F9430(frame, context, state, 0x002F9430U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F37CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F37C;
    }
block_0042F37C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F37CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F37CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F37CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0042F388U + 504U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F380U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        goto block_0042F384;
    }
block_0042F384:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F384U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F384U);
        }
        {
            const uint32_t address = 0x0042F38CU + 504U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F384U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F38CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseCounter_UpdateDigitPositions_002FCC88(frame, context, state, 0x002FCC88U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F38CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F38C;
    }
block_0042F38C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F38CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F38CU);
        }
        {
            const uint32_t address = 0x0042F394U + 500U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F38CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_0042F390;
    }
block_0042F390:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F390U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F390U);
        }
        {
            r0 = 0x00000104U;
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0042F394U, address);
            }
        }
        {
            const uint32_t address = r13 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0042F398U, address);
            }
        }
        goto block_0042F39C;
    }
block_0042F39C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F39CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F39CU);
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F39CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        goto block_0042F3A0;
    }
block_0042F3A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F3A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F3A0U);
        }
        {
            const uint32_t operand = 0x00000003U;
            r0 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0042F3F8; }
        goto block_0042F3AC;
    }
block_0042F3AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F3ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F3ACU);
        }
        {
            const uint32_t updatedAddress = r9 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F3ACU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0042F3B8U + 0x1D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F3B0U, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r6;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F3B4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0042F3F8; }
        goto block_0042F3C0;
    }
block_0042F3C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F3C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F3C0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F3C0U, address);
            }
            r0 = value;
        }
        {
            r3 = 0x0000001BU;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F3D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetVec2Range_002F9430(frame, context, state, 0x002F9430U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F3D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F3D4;
    }
block_0042F3D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F3D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F3D4U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x92U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F3D4U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + r6;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F3DCU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            const uint32_t updatedAddress = r5 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F3E0U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F3E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseCounter_UpdateDigitGeometry_002FCB04(frame, context, state, 0x002FCB04U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F3E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F3E8;
    }
block_0042F3E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F3E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F3E8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F3E8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0042F3F4U + 412U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F3ECU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0042F3F8U + 412U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F3F0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F3F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseCounter_UpdateDigitPositions_002FCC88(frame, context, state, 0x002FCC88U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F3F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F3F8;
    }
block_0042F3F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F3F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F3F8U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F400U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_UpdateHealthMeterGeometry_0044425C(frame, context, state, 0x0044425CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F400U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F400;
    }
block_0042F400:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F400U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F400U);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F40CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_RefreshPrimaryActionIcon_00444D00(frame, context, state, 0x00444D00U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F40CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F40C;
    }
block_0042F40C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F40CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F40CU);
        }
        {
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F418U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_UpdateHoldProgressGeometry_0044483C(frame, context, state, 0x0044483CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F418U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F418;
    }
block_0042F418:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F418U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F418U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r8, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0042F490; }
        goto block_0042F424;
    }
block_0042F424:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F424U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F424U);
        }
        {
            r0 = 0x00000230U;
        }
        {
            const uint32_t updatedAddress = r0 + r8;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F428U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = r13 + 0x28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F42CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t address = 0x0042F43CU + 352U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F434U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x749U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F438U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0042F444U + 0x154U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F43CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F440U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F444U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0042F448U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0042F44CU, address);
            }
        }
        if (!(flags.Z())) {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0042F450U, address);
            }
        }
        if (!(flags.Z())) {
            const uint32_t address = 0x0042F45CU + 300U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F454U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (!(flags.Z())) { goto block_0042F470; }
        goto block_0042F45C;
    }
block_0042F45C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F45CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F45CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0042F4FC; }
        goto block_0042F464;
    }
block_0042F464:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F464U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F464U);
        }
        {
            const uint32_t address = 0x0042F46CU + 304U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F464U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0042F468U, address);
            }
        }
        {
            const uint32_t address = 0x0042F474U + 300U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F46CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_0042F470;
    }
block_0042F470:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F470U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F470U);
        }
        {
            r3 = 0x0000001CU;
        }
        {
            const uint32_t address = r13 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0042F474U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0042F478U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F47CU, address);
            }
            r0 = value;
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x00000004U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r1 = r13 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F490U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetQuadTexcoords_002FC40C(frame, context, state, 0x002FC40CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F490U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F490;
    }
block_0042F490:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F490U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F490U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r8, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0042F4A8; }
        goto block_0042F49C;
    }
block_0042F49C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F49CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F49CU);
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F4A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_RefreshActionSet_00444564(frame, context, state, 0x00444564U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F4A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F4A8;
    }
block_0042F4A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F4A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F4A8U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F4B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseTouchButtons_RefreshItemAvailability_00444AB0(frame, context, state, 0x00444AB0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F4B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F4B0;
    }
block_0042F4B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F4B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F4B0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x14U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F4B0U, address);
            }
            r0 = value;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F4BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_Refresh_002F8160(frame, context, state, 0x002F8160U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F4BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F4BC;
    }
block_0042F4BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F4BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F4BCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0x18U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F4BCU, address);
            }
            r0 = value;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F4C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseIconGroup_Refresh_002F8160(frame, context, state, 0x002F8160U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F4C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F4C8;
    }
block_0042F4C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F4C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F4C8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F4C8U, address);
            }
            r0 = value;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F4D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseQuadGroup_UpdateAndSubmit_002F94A8(frame, context, state, 0x002F94A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F4D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F4D4;
    }
block_0042F4D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F4D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F4D4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F4D4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0042F534; }
        goto block_0042F4E0;
    }
block_0042F4E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F4E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F4E0U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0042F524; }
        goto block_0042F4E8;
    }
block_0042F4E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F4E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F4E8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0042F558; }
        goto block_0042F4F8;
    }
block_0042F4F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F4F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F4F8U);
        }
        goto block_0042F534;
    }
block_0042F4FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F4FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F4FCU);
        }
        {
            const uint32_t updatedAddress = 0x0042F504U - 0xAACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F4FCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0042F508U + 156U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F500U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F504U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xB2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F50CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0042F510U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000020U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t address = 0x0042F520U + 104U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F518U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (flags.Z()) {
            const uint32_t address = 0x0042F524U + 124U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F51CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_0042F470;
    }
block_0042F524:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F524U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F524U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000019U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0042F558; }
        goto block_0042F534;
    }
block_0042F534:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F534U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F534U);
        }
        {
            r3 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0042F540U + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F538U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0042F540U, address);
            }
        }
        {
            const uint32_t address = 0x0042F54CU + 52U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F544U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000014U;
            r1 = r13 + operand;
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0042F54CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0042F550U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0042F558U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_PauseRenderBuffer_SetVec2Range_002F9430(frame, context, state, 0x002F9430U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0042F558U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0042F558;
    }
block_0042F558:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0042F558U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0042F558U);
        }
        {
            const uint32_t operand = 0x00000038U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0042F55CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0042F55CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0042F560U,
                                           firstAddress + 0U);
            }
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0042F560U,
                                           firstAddress + 4U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0042F560U,
                                           firstAddress + 8U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0042F560U,
                                           firstAddress + 12U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0042F560U,
                                           firstAddress + 16U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0042F560U,
                                           firstAddress + 20U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0042F560U,
                                           firstAddress + 24U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0042F560U,
                                           firstAddress + 28U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0042F560U,
                                           firstAddress + 32U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0042F560U,
                                           firstAddress + 36U);
            }
            r3 = value3;
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 40U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

} // namespace Oot3dNativeGame::GeneratedWholeAot
