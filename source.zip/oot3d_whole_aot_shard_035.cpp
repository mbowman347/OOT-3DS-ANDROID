#include "oot3d_whole_aot_generated_internal.h"
#include "oot3d_native_a32_memory.h"

#include <atomic>

namespace Oot3dNativeGame::GeneratedWholeAot {
namespace a32 = oot3d::recomp::a32;

Oot3dWholeAotFlow Execute_address_taken_00138E04_00138E04(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_address_taken_00154DAC_00154DAC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EnKo_Init_00165684(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0017bf98_0017BF98(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_BgMoriHineri_Init_0027A254(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_sin_idx8_002CFCA0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_ChangeCameraStatus_00320D7C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_cos_idx8_00338F60(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Interface_ChangeAlpha_0034BE04(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0034be30_0034BE30(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_ProcessInitChain_003510B0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_DynaPolyActor_Init_003532E8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_InitActor_00353C9C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_DynaPoly_SetBgActor_00353EC8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_DynaPolyInfo_Alloc_00353FD4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_TitleCard_InitBossName_00354248(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Player_SetRuntimeFlag200_0035AF04(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0035b494_0035B494(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Object_GetIndex_00363C10(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_SetBGM_003655D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EffectSsDust_SpawnUpdateRateScaled_00365D20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CutsceneContext_StartUnskippable_00367374(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CutsceneContext_StartSkippable_00367494(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_CameraSetAtEye_00367B14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_set_byte_1b6_00367C48(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_clear_byte_1b6_00367C54(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00367c60_00367C60(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Message_StartTextbox_00367C7C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_CreateSubCamera_00367D74(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ModelHandle_HideMesh_0036932C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ModelHandle_LoadPlayerResource_0036A924(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SpawnAsChild_0036AA20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_GetLastFrame_0036AE14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Flags_GetTreasure_0036BCB4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_GetCamera_0036C5BC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0036cae4_0036CAE4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0036e288_0036E288(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Flags_GetSwitch_0036E864(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Player_SetCsActionWithHaltedActors_0036E980(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_ClearCameraAndRestoreMain_0036E9B8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EffectSsKiraKira_SpawnDispersed_0036EA98(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_QueueSeqCmd_0036EC40(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_PlaySfx_0036F59C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_ApproachZeroF_0036FC20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_MorphToLoop_00370350(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_sins_0037103C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Message_QueueTextRequest_003716F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_ZeroFloat_00371E50(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_coss_00372298(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ModelHandle_ShowMesh_0037266C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_CosF_Core_00372674(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_SinF_003727F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ModelHandle_LoadAll_00372F38(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_field_80x4_positive_00373074(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_ApproachF_00373500(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_OnFrameImpl_003736FC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_CenteredFloat_003738A8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_Kill_00374428(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_MorphToPlayOnce_00374A58(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlaySoundGeneral_0037547C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlayActorSound2_00375BCC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_Change_00375c08_00375C08(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Message_GetState_003769D8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);

Oot3dWholeAotFlow Execute_address_taken_00138E04_00138E04(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00138E04U:
        goto block_00138E04;
    case 0x00138E38U:
        goto block_00138E38;
    case 0x00138E48U:
        goto block_00138E48;
    case 0x00138E74U:
        goto block_00138E74;
    case 0x00138E84U:
        goto block_00138E84;
    case 0x00138E94U:
        goto block_00138E94;
    case 0x00138EA0U:
        goto block_00138EA0;
    case 0x00138EB4U:
        goto block_00138EB4;
    case 0x00138EC4U:
        goto block_00138EC4;
    case 0x00138F14U:
        goto block_00138F14;
    case 0x00138F24U:
        goto block_00138F24;
    case 0x00138FB8U:
        goto block_00138FB8;
    case 0x00138FC4U:
        goto block_00138FC4;
    case 0x00138FD4U:
        goto block_00138FD4;
    case 0x00138FE8U:
        goto block_00138FE8;
    case 0x00139004U:
        goto block_00139004;
    case 0x00139050U:
        goto block_00139050;
    case 0x00139070U:
        goto block_00139070;
    case 0x00139078U:
        goto block_00139078;
    case 0x00139090U:
        goto block_00139090;
    case 0x0013909CU:
        goto block_0013909C;
    case 0x001390B8U:
        goto block_001390B8;
    case 0x001390D8U:
        goto block_001390D8;
    case 0x001390F0U:
        goto block_001390F0;
    case 0x00139144U:
        goto block_00139144;
    case 0x00139150U:
        goto block_00139150;
    case 0x0013915CU:
        goto block_0013915C;
    case 0x00139168U:
        goto block_00139168;
    case 0x00139178U:
        goto block_00139178;
    case 0x00139184U:
        goto block_00139184;
    case 0x0013919CU:
        goto block_0013919C;
    case 0x00139228U:
        goto block_00139228;
    case 0x00139244U:
        goto block_00139244;
    case 0x00139250U:
        goto block_00139250;
    case 0x0013926CU:
        goto block_0013926C;
    case 0x00139274U:
        goto block_00139274;
    case 0x00139280U:
        goto block_00139280;
    case 0x00139290U:
        goto block_00139290;
    case 0x001392C8U:
        goto block_001392C8;
    case 0x00139304U:
        goto block_00139304;
    case 0x00139314U:
        goto block_00139314;
    case 0x00139324U:
        goto block_00139324;
    case 0x00139330U:
        goto block_00139330;
    case 0x00139340U:
        goto block_00139340;
    case 0x00139354U:
        goto block_00139354;
    case 0x0013936CU:
        goto block_0013936C;
    case 0x00139380U:
        goto block_00139380;
    case 0x00139390U:
        goto block_00139390;
    case 0x001393A4U:
        goto block_001393A4;
    case 0x001393B8U:
        goto block_001393B8;
    case 0x001393C4U:
        goto block_001393C4;
    case 0x001393D0U:
        goto block_001393D0;
    case 0x001393F4U:
        goto block_001393F4;
    case 0x00139400U:
        goto block_00139400;
    case 0x001394D0U:
        goto block_001394D0;
    case 0x001394DCU:
        goto block_001394DC;
    case 0x00139504U:
        goto block_00139504;
    case 0x00139518U:
        goto block_00139518;
    case 0x00139524U:
        goto block_00139524;
    case 0x00139538U:
        goto block_00139538;
    case 0x0013959CU:
        goto block_0013959C;
    case 0x001395B4U:
        goto block_001395B4;
    case 0x001395D4U:
        goto block_001395D4;
    case 0x001395F0U:
        goto block_001395F0;
    case 0x00139608U:
        goto block_00139608;
    case 0x00139640U:
        goto block_00139640;
    case 0x00139664U:
        goto block_00139664;
    case 0x00139674U:
        goto block_00139674;
    case 0x001396A0U:
        goto block_001396A0;
    case 0x001396B4U:
        goto block_001396B4;
    case 0x001396C0U:
        goto block_001396C0;
    case 0x001396D0U:
        goto block_001396D0;
    case 0x001396F4U:
        goto block_001396F4;
    case 0x00139700U:
        goto block_00139700;
    case 0x00139768U:
        goto block_00139768;
    case 0x00139774U:
        goto block_00139774;
    case 0x0013978CU:
        goto block_0013978C;
    case 0x00139798U:
        goto block_00139798;
    case 0x001397A4U:
        goto block_001397A4;
    case 0x001397B4U:
        goto block_001397B4;
    case 0x001397C0U:
        goto block_001397C0;
    case 0x001397D8U:
        goto block_001397D8;
    case 0x001397FCU:
        goto block_001397FC;
    case 0x0013981CU:
        goto block_0013981C;
    case 0x0013983CU:
        goto block_0013983C;
    case 0x00139858U:
        goto block_00139858;
    case 0x00139870U:
        goto block_00139870;
    case 0x0013987CU:
        goto block_0013987C;
    case 0x001398A0U:
        goto block_001398A0;
    case 0x001398B0U:
        goto block_001398B0;
    case 0x001398DCU:
        goto block_001398DC;
    case 0x001398E8U:
        goto block_001398E8;
    case 0x00139984U:
        goto block_00139984;
    case 0x00139994U:
        goto block_00139994;
    case 0x0013999CU:
        goto block_0013999C;
    case 0x001399B4U:
        goto block_001399B4;
    case 0x001399C4U:
        goto block_001399C4;
    case 0x001399D8U:
        goto block_001399D8;
    case 0x001399E8U:
        goto block_001399E8;
    case 0x001399F4U:
        goto block_001399F4;
    case 0x001399FCU:
        goto block_001399FC;
    case 0x00139A1CU:
        goto block_00139A1C;
    case 0x00139A3CU:
        goto block_00139A3C;
    case 0x00139A5CU:
        goto block_00139A5C;
    case 0x00139A7CU:
        goto block_00139A7C;
    case 0x00139A9CU:
        goto block_00139A9C;
    case 0x00139ABCU:
        goto block_00139ABC;
    case 0x00139AF8U:
        goto block_00139AF8;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00138E04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00138E04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00138E04U);
        }
        {
            const uint32_t firstAddress = r13 - 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00138E04U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00138E04U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00138E04U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00138E04U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00138E04U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00138E04U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00138E04U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00138E04U,
                                           firstAddress + 28U);
            }
            r13 = r13 - 32U;
        }
        {
            r5 = r0;
        }
        {
            r8 = r1;
        }
        {
            r10 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = 0x00138E1CU + 0x38CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138E14U, address);
            }
            r0 = value;
        }
        {
            r13 -= 32U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00138E18U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00138E18U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00138E18U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00138E18U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x00138E18U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x00138E18U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x00138E18U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x00138E18U,
                                           firstAddress + 28U);
            }
        }
        {
            const uint32_t operand = 0x00000038U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + r1;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138E20U, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138E24U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00138E2CU, address);
            }
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00138E38U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00138E38U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00138E38;
    }
block_00138E38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00138E38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00138E38U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r4 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138E3CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x00138E4CU + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138E44U, address);
            }
            switch (value) {
            case 0x00138E04U:
                goto block_00138E04;
            case 0x00138E38U:
                goto block_00138E38;
            case 0x00138E48U:
                goto block_00138E48;
            case 0x00138E74U:
                goto block_00138E74;
            case 0x00138E84U:
                goto block_00138E84;
            case 0x00138E94U:
                goto block_00138E94;
            case 0x00138EA0U:
                goto block_00138EA0;
            case 0x00138EB4U:
                goto block_00138EB4;
            case 0x00138EC4U:
                goto block_00138EC4;
            case 0x00138F14U:
                goto block_00138F14;
            case 0x00138F24U:
                goto block_00138F24;
            case 0x00138FB8U:
                goto block_00138FB8;
            case 0x00138FC4U:
                goto block_00138FC4;
            case 0x00138FD4U:
                goto block_00138FD4;
            case 0x00138FE8U:
                goto block_00138FE8;
            case 0x00139004U:
                goto block_00139004;
            case 0x00139050U:
                goto block_00139050;
            case 0x00139070U:
                goto block_00139070;
            case 0x00139078U:
                goto block_00139078;
            case 0x00139090U:
                goto block_00139090;
            case 0x0013909CU:
                goto block_0013909C;
            case 0x001390B8U:
                goto block_001390B8;
            case 0x001390D8U:
                goto block_001390D8;
            case 0x001390F0U:
                goto block_001390F0;
            case 0x00139144U:
                goto block_00139144;
            case 0x00139150U:
                goto block_00139150;
            case 0x0013915CU:
                goto block_0013915C;
            case 0x00139168U:
                goto block_00139168;
            case 0x00139178U:
                goto block_00139178;
            case 0x00139184U:
                goto block_00139184;
            case 0x0013919CU:
                goto block_0013919C;
            case 0x00139228U:
                goto block_00139228;
            case 0x00139244U:
                goto block_00139244;
            case 0x00139250U:
                goto block_00139250;
            case 0x0013926CU:
                goto block_0013926C;
            case 0x00139274U:
                goto block_00139274;
            case 0x00139280U:
                goto block_00139280;
            case 0x00139290U:
                goto block_00139290;
            case 0x001392C8U:
                goto block_001392C8;
            case 0x00139304U:
                goto block_00139304;
            case 0x00139314U:
                goto block_00139314;
            case 0x00139324U:
                goto block_00139324;
            case 0x00139330U:
                goto block_00139330;
            case 0x00139340U:
                goto block_00139340;
            case 0x00139354U:
                goto block_00139354;
            case 0x0013936CU:
                goto block_0013936C;
            case 0x00139380U:
                goto block_00139380;
            case 0x00139390U:
                goto block_00139390;
            case 0x001393A4U:
                goto block_001393A4;
            case 0x001393B8U:
                goto block_001393B8;
            case 0x001393C4U:
                goto block_001393C4;
            case 0x001393D0U:
                goto block_001393D0;
            case 0x001393F4U:
                goto block_001393F4;
            case 0x00139400U:
                goto block_00139400;
            case 0x001394D0U:
                goto block_001394D0;
            case 0x001394DCU:
                goto block_001394DC;
            case 0x00139504U:
                goto block_00139504;
            case 0x00139518U:
                goto block_00139518;
            case 0x00139524U:
                goto block_00139524;
            case 0x00139538U:
                goto block_00139538;
            case 0x0013959CU:
                goto block_0013959C;
            case 0x001395B4U:
                goto block_001395B4;
            case 0x001395D4U:
                goto block_001395D4;
            case 0x001395F0U:
                goto block_001395F0;
            case 0x00139608U:
                goto block_00139608;
            case 0x00139640U:
                goto block_00139640;
            case 0x00139664U:
                goto block_00139664;
            case 0x00139674U:
                goto block_00139674;
            case 0x001396A0U:
                goto block_001396A0;
            case 0x001396B4U:
                goto block_001396B4;
            case 0x001396C0U:
                goto block_001396C0;
            case 0x001396D0U:
                goto block_001396D0;
            case 0x001396F4U:
                goto block_001396F4;
            case 0x00139700U:
                goto block_00139700;
            case 0x00139768U:
                goto block_00139768;
            case 0x00139774U:
                goto block_00139774;
            case 0x0013978CU:
                goto block_0013978C;
            case 0x00139798U:
                goto block_00139798;
            case 0x001397A4U:
                goto block_001397A4;
            case 0x001397B4U:
                goto block_001397B4;
            case 0x001397C0U:
                goto block_001397C0;
            case 0x001397D8U:
                goto block_001397D8;
            case 0x001397FCU:
                goto block_001397FC;
            case 0x0013981CU:
                goto block_0013981C;
            case 0x0013983CU:
                goto block_0013983C;
            case 0x00139858U:
                goto block_00139858;
            case 0x00139870U:
                goto block_00139870;
            case 0x0013987CU:
                goto block_0013987C;
            case 0x001398A0U:
                goto block_001398A0;
            case 0x001398B0U:
                goto block_001398B0;
            case 0x001398DCU:
                goto block_001398DC;
            case 0x001398E8U:
                goto block_001398E8;
            case 0x00139984U:
                goto block_00139984;
            case 0x00139994U:
                goto block_00139994;
            case 0x0013999CU:
                goto block_0013999C;
            case 0x001399B4U:
                goto block_001399B4;
            case 0x001399C4U:
                goto block_001399C4;
            case 0x001399D8U:
                goto block_001399D8;
            case 0x001399E8U:
                goto block_001399E8;
            case 0x001399F4U:
                goto block_001399F4;
            case 0x001399FCU:
                goto block_001399FC;
            case 0x00139A1CU:
                goto block_00139A1C;
            case 0x00139A3CU:
                goto block_00139A3C;
            case 0x00139A5CU:
                goto block_00139A5C;
            case 0x00139A7CU:
                goto block_00139A7C;
            case 0x00139A9CU:
                goto block_00139A9C;
            case 0x00139ABCU:
                goto block_00139ABC;
            case 0x00139AF8U:
                goto block_00139AF8;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_00138E48;
    }
block_00138E48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00138E48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00138E48U);
        }
        goto block_001399D8;
    }
block_00138E74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00138E74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00138E74U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r8 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00138E84U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartSkippable_00367494(frame, context, state, 0x00367494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00138E84U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00138E84;
    }
block_00138E84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00138E84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00138E84U);
        }
        {
            r2 = 0x00000008U;
        }
        {
            r1 = r5;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00138E94U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00138E94U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00138E94;
    }
block_00138E94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00138E94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00138E94U);
        }
        {
            r0 = r8;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00138EA0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CreateSubCamera_00367D74(frame, context, state, 0x00367D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00138EA0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00138EA0;
    }
block_00138EA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00138EA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00138EA0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00138EA0U, address);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00138EB4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00138EB4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00138EB4;
    }
block_00138EB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00138EB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00138EB4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138EB4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x00000007U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00138EC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00138EC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00138EC4;
    }
block_00138EC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00138EC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00138EC4U);
        }
        {
            const uint32_t address = 0x00138ECCU + 736U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138EC4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x00138ED0U + 0x2ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138EC8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r5 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00138ECCU, address);
            }
        }
        {
            const uint32_t address = 0x00138ED8U + 728U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138ED0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r7 = 0x00000000U;
        }
        {
            const uint32_t address = r5 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00138ED8U, address);
            }
        }
        {
            const uint32_t address = 0x00138EE4U + 720U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138EDCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = r7;
        }
        {
            const uint32_t address = r5 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00138EE4U, address);
            }
        }
        {
            const uint32_t address = 0x00138EF0U + 712U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138EE8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x00138EF4U + 716U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138EECU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 196U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00138EF0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x00138EF4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x3D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138EF8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x00138F04U + 704U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138EFCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r1 | 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x3D0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00138F04U, address);
            }
        }
        {
            r1 = r8;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00138F14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00138F14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00138F14;
    }
block_00138F14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00138F14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00138F14U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00138F18U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x00138F1CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00138F20U, address);
            }
        }
        goto block_00138F24;
    }
block_00138F24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00138F24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00138F24U);
        }
        {
            const uint32_t address = 0x00138F2CU + 668U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138F24U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x00138F30U + 636U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138F28U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = r6 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00138F2CU, address);
            }
        }
        {
            const uint32_t address = 0x00138F38U + 660U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138F30U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00138F34U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00138F38U, address);
            }
        }
        {
            r0 = 0x00008000U;
        }
        {
            const uint32_t updatedAddress = r6 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00138F40U, address);
            }
        }
        {
            r0 = 0x0000000DU;
        }
        {
            const uint32_t updatedAddress = r5 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00138F48U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138F4CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x00138F58U + 636U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138F50U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x00138F5CU + 636U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138F54U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) {
            const uint32_t operand = 0x00003000U;
            r0 = r8 + operand;
        }
        if (!(flags.C())) {
            const uint32_t address = r0 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00138F60U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138F64U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) {
            const uint32_t updatedAddress = 0x00138F74U + 0x25CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138F6CU, address);
            }
            r1 = value;
        }
        if (flags.C()) {
            r0 = 0x00000000U;
        }
        if (flags.C()) {
            const uint32_t updatedAddress = r1 + r8;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00138F74U, address);
            }
        }
        {
            const uint32_t address = r4 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00138F78U, address);
            }
        }
        {
            const uint32_t address = r4 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00138F7CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = r4 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00138F84U, address);
            }
        }
        {
            const uint32_t address = r0 + 816U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138F88U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x00138F94U + 584U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138F8CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00138F90U, address);
            }
        }
        {
            const uint32_t address = r0 + 820U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138F94U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00138F98U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x00138FA4U + 572U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138F9CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00138FA0U, address);
            }
        }
        {
            const uint32_t address = r0 + 824U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138FA4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00138FA8U, address);
            }
        }
        {
            const uint32_t address = r0 + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138FACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00138FB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00138FB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00138FB8;
    }
block_00138FB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00138FB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00138FB8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_001399D8; }
        goto block_00138FC4;
    }
block_00138FC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00138FC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00138FC4U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r1 = 0x00000003U;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00138FD4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToLoop_00370350(frame, context, state, 0x00370350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00138FD4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00138FD4;
    }
block_00138FD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00138FD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00138FD4U);
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00138FD8U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00138FE0U, address);
            }
        }
        goto block_001399E8;
    }
block_00138FE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00138FE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00138FE8U);
        }
        {
            const uint32_t address = 0x00138FF0U + 500U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138FE8U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x00138FF8U + 496U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00138FF0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r1 = r8;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139004U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139004U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139004;
    }
block_00139004:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139004U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139004U);
        }
        {
            r0 = 0x0000000DU;
        }
        {
            const uint32_t address = 0x00139010U + 476U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139008U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013900CU, address);
            }
        }
        {
            const uint32_t address = r4 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139010U, address);
            }
        }
        {
            const uint32_t address = 0x0013901CU + 468U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139014U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r6 = r5 + operand;
        }
        {
            const uint32_t address = r4 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013901CU, address);
            }
        }
        {
            const uint32_t address = 0x00139028U + 460U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139020U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139024U, address);
            }
        }
        {
            const uint32_t address = r6 + 816U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139028U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013902CU, address);
            }
        }
        {
            const uint32_t address = r6 + 820U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139030U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139034U, address);
            }
        }
        {
            const uint32_t address = r6 + 824U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139038U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013903CU, 0xEE300A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139040U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139044U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_00139078; }
        goto block_00139050;
    }
block_00139050:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139050U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139050U);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00139054U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            r2 = r0;
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00139060U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0013906CU + 0x18CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139064U, address);
            }
            r1 = value;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139070U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139070U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139070;
    }
block_00139070:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139070U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139070U);
        }
        {
            const uint32_t address = 0x00139078U + 388U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139070U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 760U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139074U, address);
            }
        }
        goto block_00139078;
    }
block_00139078:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139078U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139078U);
        }
        {
            const uint32_t updatedAddress = 0x00139080U + 0x180U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139078U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013907CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x0000001FU;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x0013908CU + 0x178U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139084U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            r0 = r5;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x00139090U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139090U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139090;
    }
block_00139090:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139090U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139090U);
        }
        {
        }
        {
        }
        goto block_001399D8;
    }
block_0013909C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013909CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013909CU);
        }
        {
            const uint32_t address = 0x001390A4U + 312U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013909CU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x001390ACU + 348U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001390A4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            r1 = r8;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001390B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001390B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001390B8;
    }
block_001390B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001390B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001390B8U);
        }
        {
            r0 = 0x0000000EU;
        }
        {
            const uint32_t operand = 0x00000800U;
            r6 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001390C0U, address);
            }
        }
        {
            const uint32_t address = r6 + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001390C4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x001390D0U + 0x13CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001390C8U, address);
            }
            r7 = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r7, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_001390F0; }
        goto block_001390D8;
    }
block_001390D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001390D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001390D8U);
        }
        {
            const uint32_t updatedAddress = 0x001390E0U + 0x120U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001390D8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001390DCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x0000001FU;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x001390ECU + 0x118U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001390E4U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            r0 = r5;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x001390F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001390F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001390F0;
    }
block_001390F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001390F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001390F0U);
        }
        {
            const uint32_t address = 0x001390F8U + 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001390F0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x001390FCU + 288U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001390F4U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = r4 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001390F8U, address);
            }
        }
        {
            const uint32_t address = 0x00139104U + 272U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001390FCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x00139108U + 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139100U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = r4 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139104U, address);
            }
        }
        {
            const uint32_t address = 0x00139110U + 264U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139108U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013910CU, address);
            }
        }
        {
            const uint32_t address = r6 + 816U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139110U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139114U, 0xEE300A48U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139118U, address);
            }
        }
        {
            const uint32_t address = r6 + 820U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013911CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139120U, 0xEE300A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139124U, 0xEE300A68U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139128U, address);
            }
        }
        {
            const uint32_t address = r6 + 824U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013912CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139130U, address);
            }
        }
        {
            const uint32_t address = r6 + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139134U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r7, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00139228; }
        goto block_00139144;
    }
block_00139144:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139144U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139144U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139144U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000096U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_00139228; }
        goto block_00139150;
    }
block_00139150:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139150U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139150U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r8 + operand;
        }
        {
            const uint32_t operand = 0x000008A0U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013915CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_GetState_003769D8(frame, context, state, 0x003769D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013915CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013915C;
    }
block_0013915C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013915CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013915CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_00139228; }
        goto block_00139168;
    }
block_00139168:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139168U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139168U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t address = 0x00139174U + 56U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013916CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139178U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139178U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139178;
    }
block_00139178:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139178U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139178U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139184U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139184U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139184;
    }
block_00139184:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139184U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139184U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t updatedAddress = 0x00139190U + 0x94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139188U, address);
            }
            r1 = value;
        }
        {
            r0 = r5;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139190U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r6 + 760U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139194U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013919CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013919CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013919C;
    }
block_0013919C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013919CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013919CU);
        }
        {
        }
        {
        }
        goto block_001399D8;
    }
block_00139228:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139228U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139228U);
        }
        {
            const uint32_t address = r6 + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139228U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x00139234U + 828U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013922CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x00139238U - 88U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139230U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r5 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139238U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[21];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139244U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139244U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139244;
    }
block_00139244:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139244U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139244U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_00139314; }
        goto block_00139250;
    }
block_00139250:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139250U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139250U);
        }
        {
            r7 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0013925CU - 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139254U, address);
            }
            frame.Guest.vfp[23] = value;
        }
        {
            const uint32_t address = 0x00139260U + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139258U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = 0x00139264U + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013925CU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x00139268U + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139260U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x0013926CU - 192U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139264U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            r9 = 0x00000032U;
        }
        goto block_0013926C;
    }
block_0013926C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013926CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013926CU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139274U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139274U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139274;
    }
block_00139274:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139274U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139274U);
        }
        {
            const uint32_t address = r13 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139274U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[22];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139280U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139280U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139280;
    }
block_00139280:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139280U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139280U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139280U, 0xEE300A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139284U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139290U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139290U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139290;
    }
block_00139290:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139290U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139290U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139290U, 0xEE300A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139294U, address);
            }
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x00139298U, address);
            }
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0013929CU, address);
            }
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x001392A0U, address);
            }
        }
        {
            const uint32_t address = r6 + 828U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001392A4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001392A8U, address);
            }
        }
        {
            const uint32_t address = r6 + 832U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001392ACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001392B0U, 0xEE300A68U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001392B4U, address);
            }
        }
        {
            const uint32_t address = r6 + 836U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001392B8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001392BCU, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[23];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001392C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001392C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001392C8;
    }
block_001392C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001392C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001392C8U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001392C8U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r3 = 0x00000011U;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r9;
            r0 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x001392E8U + 0x298U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001392E0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001392E4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x001392E4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x001392E4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001392E4U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x0000002CU;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r3 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001392F0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000020U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000014U;
            r1 = r13 + operand;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139304U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EffectSsDust_SpawnUpdateRateScaled_00365D20(frame, context, state, 0x00365D20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139304U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139304;
    }
block_00139304:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139304U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139304U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r7 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r7 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000028U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0013926C; }
        goto block_00139314;
    }
block_00139314:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139314U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139314U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[21];
        }
        {
            const uint32_t address = r6 + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139318U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139324U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139324U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139324;
    }
block_00139324:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139324U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139324U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_001399D8; }
        goto block_00139330;
    }
block_00139330:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139330U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139330U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t address = 0x0013933CU - 400U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139334U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139340U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToLoop_00370350(frame, context, state, 0x00370350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139340U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139340;
    }
block_00139340:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139340U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139340U);
        }
        {
            r0 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00139344U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013934CU, address);
            }
        }
        goto block_001399E8;
    }
block_00139354:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139354U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139354U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x00139360U - 344U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139358U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x00139364U - 392U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013935CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r8;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013936CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013936CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013936C;
    }
block_0013936C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013936CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013936CU);
        }
        {
            r0 = 0x0000000EU;
        }
        {
            const uint32_t updatedAddress = r5 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00139370U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139374U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001399D8; }
        goto block_00139380;
    }
block_00139380:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139380U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139380U);
        }
        {
            const uint32_t updatedAddress = 0x00139388U + 0x1FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139380U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139390U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139390U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139390;
    }
block_00139390:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139390U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139390U);
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00139394U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013939CU, address);
            }
        }
        goto block_001399E8;
    }
block_001393A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001393A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001393A4U);
        }
        {
            r0 = 0x0000000EU;
        }
        {
            const uint32_t updatedAddress = r5 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001393A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001393ACU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000046U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_001399E8; }
        goto block_001393B8;
    }
block_001393B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001393B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001393B8U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r8 + operand;
        }
        {
            const uint32_t operand = 0x000008A0U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001393C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_GetState_003769D8(frame, context, state, 0x003769D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001393C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001393C4;
    }
block_001393C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001393C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001393C4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_001399D8; }
        goto block_001393D0;
    }
block_001393D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001393D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001393D0U);
        }
        {
            r0 = 0x00000006U;
        }
        {
            const uint32_t address = 0x001393DCU - 560U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001393D4U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001393D8U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001393E4U, address);
            }
        }
        {
            r1 = 0x00000004U;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001393F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001393F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001393F4;
    }
block_001393F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001393F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001393F4U);
        }
        {
            r1 = 0x00000004U;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139400U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139400U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139400;
    }
block_00139400:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139400U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139400U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = 0x00139410U - 512U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139408U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x00139414U - 612U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013940CU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = 0x00139418U - 508U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139410U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            const uint32_t address = 0x0013941CU - 576U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139414U, address);
            }
            frame.Guest.vfp[5] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139418U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = 0x00139424U + 0x16CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013941CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r0 + 760U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139420U, address);
            }
        }
        {
            const uint32_t address = 0x0013942CU + 348U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139424U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 120U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139428U, address);
            }
        }
        {
            const uint32_t address = r4 + 116U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0013942CU, address);
            }
        }
        {
            const uint32_t address = 0x00139438U + 340U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139430U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x00139434U, address);
            }
        }
        {
            const uint32_t address = r4 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139438U, address);
            }
        }
        {
            const uint32_t address = r4 + 76U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0013943CU, address);
            }
        }
        {
            const uint32_t address = r0 + 816U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139440U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139444U, 0xEE700AC2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x00139448U, address);
            }
        }
        {
            const uint32_t address = r0 + 820U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013944CU, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139450U, 0xEE322A22U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[4], frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0013945CU - 572U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139454U, address);
            }
            frame.Guest.vfp[5] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139458U, 0xEE322A62U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[4], frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 96U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[4])) {
                return Oot3dAotMemoryFault(context, 0x0013945CU, address);
            }
        }
        {
            const uint32_t address = r0 + 824U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139460U, address);
            }
            frame.Guest.vfp[5] = value;
        }
        {
            r0 = r5;
        }
        {
            const uint32_t address = r4 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[5])) {
                return Oot3dAotMemoryFault(context, 0x00139468U, address);
            }
        }
        {
            const uint32_t address = r4 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013946CU, address);
            }
            frame.Guest.vfp[6] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139470U, 0xEE331A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[6], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139474U, 0xEEB01AC1U};
            frame.Guest.vfp[2] = frame.Guest.vfp[2] & 0x7FFFFFFFU;
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x00139478U, address);
            }
        }
        {
            const uint32_t address = r4 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013947CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139480U, 0xEE310A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139484U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            const uint32_t address = r4 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139488U, address);
            }
        }
        {
            const uint32_t address = r4 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013948CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139490U, 0xEE300A61U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139494U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            const uint32_t address = r4 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139498U, address);
            }
        }
        {
            const uint32_t address = r4 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013949CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001394A0U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001394A4U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            const uint32_t address = r4 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001394A8U, address);
            }
        }
        {
            const uint32_t address = r4 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001394ACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001394B0U, 0xEE300A42U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001394B4U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            const uint32_t address = r4 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001394B8U, address);
            }
        }
        {
            const uint32_t address = r4 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001394BCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001394C0U, 0xEE300A62U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001394C4U, 0xEEB00AC0U};
            frame.Guest.vfp[0] = frame.Guest.vfp[0] & 0x7FFFFFFFU;
        }
        {
            const uint32_t address = r4 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001394C8U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001394D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001394D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001394D0;
    }
block_001394D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001394D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001394D0U);
        }
        {
        }
        {
        }
        goto block_001399D8;
    }
block_001394DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001394DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001394DCU);
        }
        {
            const uint32_t address = 0x001394E4U - 772U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001394DCU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r0 = 0x0000000EU;
        }
        {
            const uint32_t updatedAddress = r5 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001394E4U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r5 + operand;
        }
        {
            r10 = 0x00000001U;
        }
        {
            const uint32_t address = 0x001394FCU + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001394F4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x00139500U + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001394F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000074U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139504U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139504U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139504;
    }
block_00139504:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139504U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139504U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r6 = r5 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r6 + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013950CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139518U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139518U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139518;
    }
block_00139518:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139518U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139518U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_001399D8; }
        goto block_00139524;
    }
block_00139524:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139524U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139524U);
        }
        {
            r1 = 0x00000005U;
        }
        {
            const uint32_t address = 0x00139530U - 900U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139528U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r5 + operand;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139538U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToLoop_00370350(frame, context, state, 0x00370350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139538U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139538;
    }
block_00139538:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139538U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139538U);
        }
        {
            const uint32_t address = 0x00139540U - 836U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139538U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = 0x00000007U;
        }
        {
            const uint32_t address = r6 + 760U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139540U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00139544U, address);
            }
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000C00U;
            r0 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00139550U, address);
            }
        }
        {
            const uint32_t address = r0 + 644U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00139554U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00139558U, address);
            }
        }
        {
            r0 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r5 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00139560U, address);
            }
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r8 + operand;
        }
        {
            const uint32_t address = r0 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00139568U, address);
            }
        }
        goto block_001399D8;
    }
block_0013959C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013959CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013959CU);
        }
        {
            r2 = 0x0000000AU;
        }
        {
            const uint32_t address = 0x001395A8U - 916U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001395A0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x001395ACU + 848U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001395A4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r8;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001395B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001395B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001395B4;
    }
block_001395B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001395B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001395B4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001395B4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) {
            const uint32_t address = 0x001395C4U + 828U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001395BCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (!(flags.C())) {
            const uint32_t operand = 0x00003000U;
            r0 = r8 + operand;
        }
        if (!(flags.C())) {
            const uint32_t address = r0 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001395C4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001395C8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001396A0; }
        goto block_001395D4;
    }
block_001395D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001395D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001395D4U);
        }
        {
            r0 = 0x00000008U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001395D8U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t address = 0x001395E8U + 792U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001395E0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001395E4U, address);
            }
        }
        {
            const uint32_t address = r4 + 148U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001395E8U, address);
            }
        }
        goto block_001396A0;
    }
block_001395F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001395F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001395F0U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x001395FCU - 1000U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001395F4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x00139600U + 772U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001395F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r8;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139608U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139608U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139608;
    }
block_00139608:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139608U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139608U);
        }
        {
            const uint32_t address = 0x00139610U + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139608U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013960CU, address);
            }
        }
        {
            const uint32_t address = 0x00139618U + 756U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139610U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139614U, address);
            }
        }
        {
            const uint32_t address = 0x00139620U + 752U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139618U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013961CU, address);
            }
        }
        {
            const uint32_t address = 0x00139628U + 728U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139620U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139624U, address);
            }
        }
        {
            const uint32_t address = r4 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139628U, address);
            }
        }
        {
            const uint32_t address = 0x00139634U + 736U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013962CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139630U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139634U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00139664; }
        goto block_00139640;
    }
block_00139640:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139640U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139640U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x0013964CU - 212U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139644U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x00139650U + 712U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139648U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013964CU, 0xEEB80A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139650U, 0xEE600A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0013965CU + 704U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139654U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139658U, 0xEE000A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013965CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        goto block_00139664;
    }
block_00139664:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139664U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139664U);
        }
        {
            r1 = 0x00006300U;
        }
        {
            r0 = static_cast<uint32_t>(static_cast<uint64_t>(r0) * r1);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139674U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139674U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139674;
    }
block_00139674:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139674U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139674U);
        }
        {
            const uint32_t address = 0x0013967CU - 228U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139674U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x00139680U + 0x2A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139678U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x00139684U + 0x2A0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013967CU, address);
            }
            r2 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139680U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = 0x0013968CU + 0x29CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139684U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t address = r4 + 148U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013968CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x00139690U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001396A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001396A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001396A0;
    }
block_001396A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001396A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001396A0U);
        }
        {
            r0 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r5 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001396A4U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x001396B0U + 0x27CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001396A8U, address);
            }
            r1 = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001396B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001396B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001396B4;
    }
block_001396B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001396B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001396B4U);
        }
        {
            const uint32_t operand = 0x00000E60U;
            r0 = r5 + operand;
        }
        {
            r1 = 0x00000007U;
        }
        {
            r2 = 0x0000000AU;
        }
        goto block_001396C0;
    }
block_001396C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001396C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001396C0U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001396C0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r1 = r1 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x001396C8U, address);
            }
            r0 = updatedAddress;
        }
        if (!(flags.Z())) { goto block_001396C0; }
        goto block_001396D0;
    }
block_001396D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001396D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001396D0U);
        }
        {
            const uint32_t updatedAddress = 0x001396D8U + 0x25CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001396D0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x001396DCU + 0x254U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001396D4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x001396E0U + 600U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001396D8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x001396E4U - 348U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001396DCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r1 + r5;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001396E0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000C00U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = 0x001396F0U + 588U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001396E8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000284U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001396F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001396F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001396F4;
    }
block_001396F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001396F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001396F4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001396F4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001399D8; }
        goto block_00139700;
    }
block_00139700:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139700U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139700U);
        }
        {
            r0 = 0x00000009U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00139704U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t address = 0x00139714U + 556U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013970CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00139710U, address);
            }
        }
        {
            const uint32_t address = r4 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139714U, address);
            }
        }
        {
            const uint32_t address = 0x00139720U + 548U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139718U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = r4 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139720U, address);
            }
        }
        {
            const uint32_t address = 0x0013972CU + 540U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139724U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x00139730U + 556U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139728U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013972CU, address);
            }
        }
        {
            const uint32_t address = 0x00139738U + 532U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139730U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r8;
        }
        {
            const uint32_t address = r4 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139738U, address);
            }
        }
        {
            const uint32_t address = 0x00139744U + 524U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013973CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r5;
        }
        {
            const uint32_t address = r4 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139744U, address);
            }
        }
        {
            const uint32_t address = 0x00139750U + 516U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139748U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013974CU, address);
            }
        }
        {
            const uint32_t address = 0x00139758U + 424U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139750U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 116U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139754U, address);
            }
        }
        {
            const uint32_t address = 0x00139760U + 504U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139758U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 152U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013975CU, address);
            }
        }
        {
            const uint32_t address = 0x00139768U + 504U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139760U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139768U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139768U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139768;
    }
block_00139768:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139768U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139768U);
        }
        {
        }
        {
        }
        goto block_001399D8;
    }
block_00139774:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139774U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139774U);
        }
        {
            r2 = 0x00000014U;
        }
        {
            const uint32_t address = 0x00139780U + 476U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139778U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x00139784U + 384U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013977CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r8;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013978CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013978CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013978C;
    }
block_0013978C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013978CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013978CU);
        }
        {
            const uint32_t updatedAddress = 0x00139794U + 0x198U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013978CU, address);
            }
            r1 = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139798U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139798U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139798;
    }
block_00139798:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139798U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139798U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139798U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001397B4; }
        goto block_001397A4;
    }
block_001397A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001397A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001397A4U);
        }
        {
            r2 = 0x00000039U;
        }
        {
            r1 = r5;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001397B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001397B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001397B4;
    }
block_001397B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001397B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001397B4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001397B4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_00139870; }
        goto block_001397C0;
    }
block_001397C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001397C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001397C0U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = 0x001397CCU + 408U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001397C4U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x001397D0U - 568U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001397C8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000098U;
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001397D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001397D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001397D8;
    }
block_001397D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001397D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001397D8U);
        }
        {
            const uint32_t address = r4 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001397D8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x001397E4U + 388U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001397DCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x001397E8U - 608U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001397E0U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r5 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001397E8U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = 0x001397F8U + 372U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001397F0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001397FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001397FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001397FC;
    }
block_001397FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001397FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001397FCU);
        }
        {
            const uint32_t address = r4 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001397FCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x00139808U + 360U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139800U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r5 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013980CU, 0xEE201A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x00139818U + 348U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139810U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013981CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013981CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013981C;
    }
block_0013981C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013981CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013981CU);
        }
        {
            const uint32_t address = r4 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013981CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x00139828U + 336U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139820U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000018U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013982CU, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = 0x0013983CU + 320U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139834U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013983CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013983CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013983C;
    }
block_0013983C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013983CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013983CU);
        }
        {
            const uint32_t address = r4 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013983CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r5 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139848U, 0xEE201A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x00139854U + 300U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013984CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139858U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139858U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139858;
    }
block_00139858:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139858U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139858U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = 0x0013986CU - 728U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139864U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000074U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139870U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139870U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139870;
    }
block_00139870:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139870U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139870U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139870U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001398A0; }
        goto block_0013987C;
    }
block_0013987C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013987CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013987CU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x00139888U - 784U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139880U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0013988CU + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139884U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139888U, 0xEEB80A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013988CU, 0xEE600A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x00139898U + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139890U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139894U, 0xEE000A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139898U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        goto block_001398A0;
    }
block_001398A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001398A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001398A0U);
        }
        {
            r1 = 0x00006300U;
        }
        {
            r0 = static_cast<uint32_t>(static_cast<uint64_t>(r0) * r1);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001398B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001398B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001398B0;
    }
block_001398B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001398B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001398B0U);
        }
        {
            const uint32_t address = r4 + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001398B0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x001398BCU + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001398B4U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x001398C0U + 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001398B8U, address);
            }
            r2 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x001398BCU, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = 0x001398C8U + 0x60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001398C0U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t address = r4 + 148U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x001398C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x001398CCU, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001398DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001398DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001398DC;
    }
block_001398DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001398DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001398DCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001398DCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000096U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_00139984; }
        goto block_001398E8;
    }
block_001398E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001398E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001398E8U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001398ECU, address);
            }
        }
        {
            r1 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r5 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x001398F4U, address);
            }
        }
        goto block_00139994;
    }
block_00139984:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139984U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139984U);
        }
        {
            r1 = 0x00000010U;
        }
        {
            const uint32_t updatedAddress = r5 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00139988U, address);
            }
        }
        {
            r1 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00139990U, address);
            }
        }
        goto block_00139994;
    }
block_00139994:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139994U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139994U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000C3U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_001399B4; }
        goto block_0013999C;
    }
block_0013999C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013999CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013999CU);
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = 0x001399A8U + 348U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001399A0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x001399ACU - 72U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001399A4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x001399B0U + 344U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001399A8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000009CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001399B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001399B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001399B4;
    }
block_001399B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001399B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001399B4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001399B4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r0 - operand;
        }
        {
            const uint32_t operand = 0x0000004AU;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r1 = r1 - operand;
        }
        if (!(flags.Z())) { goto block_001399D8; }
        goto block_001399C4;
    }
block_001399C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001399C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001399C4U);
        }
        {
            const uint32_t updatedAddress = 0x001399CCU + 0x140U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001399C4U, address);
            }
            r1 = value;
        }
        {
            r3 = 0x00000005U;
        }
        {
            r2 = 0x00000014U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001399D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_QueueTextRequest_003716F0(frame, context, state, 0x003716F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001399D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001399D8;
    }
block_001399D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001399D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001399D8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001399D8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000064U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) {
            r0 = 0x00000014U;
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t updatedAddress = r5 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001399E4U, address);
            }
        }
        goto block_001399E8;
    }
block_001399E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001399E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001399E8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001399E8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00139AF8; }
        goto block_001399F4;
    }
block_001399F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001399F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001399F4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r10, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00139ABC; }
        goto block_001399FC;
    }
block_001399FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001399FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001399FCU);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001399FCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139A00U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139A0CU, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139A10U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 68U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139A14U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139A1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139A1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139A1C;
    }
block_00139A1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139A1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139A1CU);
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139A1CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139A20U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139A2CU, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139A30U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 72U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139A34U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139A3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139A3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139A3C;
    }
block_00139A3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139A3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139A3CU);
        }
        {
            const uint32_t address = r4 + 52U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139A3CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139A40U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139A4CU, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139A50U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 76U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139A54U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139A5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139A5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139A5C;
    }
block_00139A5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139A5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139A5CU);
        }
        {
            const uint32_t address = r4 + 56U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139A5CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139A60U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000014U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139A6CU, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139A70U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139A74U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139A7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139A7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139A7C;
    }
block_00139A7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139A7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139A7CU);
        }
        {
            const uint32_t address = r4 + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139A7CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139A80U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000018U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139A8CU, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139A90U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 96U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139A94U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139A9CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139A9CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139A9C;
    }
block_00139A9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139A9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139A9CU);
        }
        {
            const uint32_t address = r4 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139A9CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139AA0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139AACU, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139AB0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 100U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139AB4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139ABCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139ABCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139ABC;
    }
block_00139ABC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139ABCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139ABCU);
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000014U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x0000002CU;
            r0 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00139AC8U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00139AC8U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00139AC8U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r6 = value6;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00139ACCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00139ACCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00139ACCU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00001000U;
            r3 = r5 + operand;
        }
        {
            const uint32_t address = r13 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139AD4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 148U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139AD8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000008U;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x0000002CU;
            r2 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00139AE4U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = r8;
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00139AECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00139AF0U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00139AF8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CameraSetAtEye_00367B14(frame, context, state, 0x00367B14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00139AF8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00139AF8;
    }
block_00139AF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00139AF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00139AF8U);
        }
        {
            const uint32_t operand = 0x00000038U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00139AFCU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00139AFCU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00139AFCU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00139AFCU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00139AFCU,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00139AFCU,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00139AFCU,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00139AFCU,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            r13 += 32U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00139B00U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00139B00U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00139B00U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00139B00U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00139B00U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00139B00U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00139B00U,
                                           firstAddress + 24U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00139B00U,
                                           firstAddress + 28U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r13 = r13 + 32U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_address_taken_00154DAC_00154DAC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00154DACU:
        goto block_00154DAC;
    case 0x00154DD8U:
        goto block_00154DD8;
    case 0x00154DE0U:
        goto block_00154DE0;
    case 0x00154DECU:
        goto block_00154DEC;
    case 0x00154DF4U:
        goto block_00154DF4;
    case 0x00154E00U:
        goto block_00154E00;
    case 0x00154E08U:
        goto block_00154E08;
    case 0x00154E10U:
        goto block_00154E10;
    case 0x00154E28U:
        goto block_00154E28;
    case 0x00154E3CU:
        goto block_00154E3C;
    case 0x00154E48U:
        goto block_00154E48;
    case 0x00154E60U:
        goto block_00154E60;
    case 0x00154E68U:
        goto block_00154E68;
    case 0x00154E74U:
        goto block_00154E74;
    case 0x00154E8CU:
        goto block_00154E8C;
    case 0x00154E94U:
        goto block_00154E94;
    case 0x00154EA0U:
        goto block_00154EA0;
    case 0x00154EB8U:
        goto block_00154EB8;
    case 0x00154EC4U:
        goto block_00154EC4;
    case 0x00154ED8U:
        goto block_00154ED8;
    case 0x00154EECU:
        goto block_00154EEC;
    case 0x00154EF4U:
        goto block_00154EF4;
    case 0x00154F04U:
        goto block_00154F04;
    case 0x00154F18U:
        goto block_00154F18;
    case 0x00154F30U:
        goto block_00154F30;
    case 0x00154F38U:
        goto block_00154F38;
    case 0x00154F44U:
        goto block_00154F44;
    case 0x00154F6CU:
        goto block_00154F6C;
    case 0x00154F80U:
        goto block_00154F80;
    case 0x00154FA0U:
        goto block_00154FA0;
    case 0x00154FA8U:
        goto block_00154FA8;
    case 0x00154FC0U:
        goto block_00154FC0;
    case 0x00154FE0U:
        goto block_00154FE0;
    case 0x00154FE8U:
        goto block_00154FE8;
    case 0x00155000U:
        goto block_00155000;
    case 0x00155020U:
        goto block_00155020;
    case 0x00155034U:
        goto block_00155034;
    case 0x00155050U:
        goto block_00155050;
    case 0x00155060U:
        goto block_00155060;
    case 0x00155074U:
        goto block_00155074;
    case 0x0015508CU:
        goto block_0015508C;
    case 0x001550A8U:
        goto block_001550A8;
    case 0x001550B8U:
        goto block_001550B8;
    case 0x001550E4U:
        goto block_001550E4;
    case 0x001550F8U:
        goto block_001550F8;
    case 0x00155108U:
        goto block_00155108;
    case 0x00155114U:
        goto block_00155114;
    case 0x0015511CU:
        goto block_0015511C;
    case 0x00155138U:
        goto block_00155138;
    case 0x00155144U:
        goto block_00155144;
    case 0x00155150U:
        goto block_00155150;
    case 0x0015515CU:
        goto block_0015515C;
    case 0x00155168U:
        goto block_00155168;
    case 0x00155180U:
        goto block_00155180;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00154DAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154DACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154DACU);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00154DACU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00154DACU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00154DACU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00154DACU,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00154DACU,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00154DACU,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00154DACU,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x00154DACU,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00154DACU,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            const uint32_t operand = 0x00000100U;
            r5 = r0 + operand;
        }
        {
            r8 = r1;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t operand = 0x00003800U;
            r0 = r8 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            r13 -= 8U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00154DC4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00154DC4U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0xC0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00154DCCU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            r6 = r0;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00154DD8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_field_80x4_positive_00373074(frame, context, state, 0x00373074U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00154DD8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00154DD8;
    }
block_00154DD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154DD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154DD8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00154F38; }
        goto block_00154DE0;
    }
block_00154DE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154DE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154DE0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xC1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00154DE0U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00154DECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_field_80x4_positive_00373074(frame, context, state, 0x00373074U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00154DECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00154DEC;
    }
block_00154DEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154DECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154DECU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00154F38; }
        goto block_00154DF4;
    }
block_00154DF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154DF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154DF4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xC2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00154DF4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_00154E10; }
        goto block_00154E00;
    }
block_00154E00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154E00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154E00U);
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00154E08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_field_80x4_positive_00373074(frame, context, state, 0x00373074U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00154E08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00154E08;
    }
block_00154E08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154E08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154E08U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00154F38; }
        goto block_00154E10;
    }
block_00154E10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154E10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154E10U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xC0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00154E10U, address);
            }
            r0 = value;
        }
        {
            r9 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00154E18U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00154E1CU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_00154F44; }
        goto block_00154E28;
    }
block_00154E28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154E28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154E28U);
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00154E34U, address);
            }
        }
        if (!(flags.Z())) { goto block_00154E60; }
        goto block_00154E3C;
    }
block_00154E3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154E3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154E3CU);
        }
        {
            r1 = 0x0000006FU;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00154E48U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Object_GetIndex_00363C10(frame, context, state, 0x00363C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00154E48U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00154E48;
    }
block_00154E48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154E48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154E48U);
        }
        {
            r10 = 0x00000000U;
        }
        {
            r6 = 0x0000005CU;
        }
        {
            r11 = r10;
        }
        {
            r7 = 0x0000006FU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00154E58U, address);
            }
        }
        goto block_00154ED8;
    }
block_00154E60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154E60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154E60U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00154E8C; }
        goto block_00154E68;
    }
block_00154E68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154E68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154E68U);
        }
        {
            r1 = 0x0000005CU;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00154E74U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Object_GetIndex_00363C10(frame, context, state, 0x00363C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00154E74U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00154E74;
    }
block_00154E74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154E74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154E74U);
        }
        {
            r10 = 0x00000000U;
        }
        {
            r6 = 0x0000006FU;
        }
        {
            r11 = r10;
        }
        {
            r7 = 0x0000005CU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00154E84U, address);
            }
        }
        goto block_00154ED8;
    }
block_00154E8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154E8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154E8CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00154EB8; }
        goto block_00154E94;
    }
block_00154E94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154E94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154E94U);
        }
        {
            r1 = 0x00000071U;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00154EA0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Object_GetIndex_00363C10(frame, context, state, 0x00363C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00154EA0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00154EA0;
    }
block_00154EA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154EA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154EA0U);
        }
        {
            r10 = 0x00000000U;
        }
        {
            r6 = 0x00000070U;
        }
        {
            r11 = r10;
        }
        {
            r7 = 0x00000071U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00154EB0U, address);
            }
        }
        goto block_00154ED8;
    }
block_00154EB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154EB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154EB8U);
        }
        {
            r1 = 0x00000070U;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00154EC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Object_GetIndex_00363C10(frame, context, state, 0x00363C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00154EC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00154EC4;
    }
block_00154EC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154EC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154EC4U);
        }
        {
            r10 = 0x00000000U;
        }
        {
            r6 = 0x00000071U;
        }
        {
            r11 = r10;
        }
        {
            r7 = 0x00000070U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00154ED4U, address);
            }
        }
        goto block_00154ED8;
    }
block_00154ED8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154ED8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154ED8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xC0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00154ED8U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t updatedAddress = 0x00154EE8U + 0x2A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00154EE0U, address);
            }
            r0 = value;
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t updatedAddress = r4 + 0x1BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00154EE4U, address);
            }
        }
        if ((flags.N()) == (flags.V())) { goto block_00154EF4; }
        goto block_00154EEC;
    }
block_00154EEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154EECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154EECU);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00154EF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Kill_00374428(frame, context, state, 0x00374428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00154EF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00154EF4;
    }
block_00154EF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154EF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154EF4U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00154F04U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00154F04U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00154F04;
    }
block_00154F04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154F04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154F04U);
        }
        {
            const uint32_t source = Oot3dAotRor(r6, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            r3 = r10;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00154F18U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadPlayerResource_0036A924(frame, context, state, 0x0036A924U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00154F18U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00154F18;
    }
block_00154F18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154F18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154F18U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x248U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00154F18U, address);
            }
        }
        {
            const uint32_t source = Oot3dAotRor(r7, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            r3 = r11;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00154F30U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadPlayerResource_0036A924(frame, context, state, 0x0036A924U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00154F30U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00154F30;
    }
block_00154F30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154F30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154F30U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x24CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00154F30U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x250U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00154F34U, address);
            }
        }
        goto block_00154F38;
    }
block_00154F38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154F38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154F38U);
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00154F3CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00154F3CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00154F40U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00154F40U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00154F40U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00154F40U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00154F40U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00154F40U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00154F40U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x00154F40U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00154F40U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
block_00154F44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154F44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154F44U);
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            r0 = r0;
        }
        {
            const uint32_t updatedAddress = 0x00154F58U + 0x23CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00154F50U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x00154F54U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x00154F60U + 0x238U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00154F58U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x140U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00154F5CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00154F60U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00154FA0; }
        goto block_00154F6C;
    }
block_00154F6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154F6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154F6CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00154F6CU, address);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00154F80U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyInfo_Alloc_00353FD4(frame, context, state, 0x00353FD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00154F80U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00154F80;
    }
block_00154F80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154F80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154F80U);
        }
        {
            const uint32_t operand = 0x00000010U;
            r1 = r13 + operand;
        }
        {
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00154F88U, address);
            }
        }
        {
            r10 = 0x00000000U;
        }
        {
            r6 = 0x0000005CU;
        }
        {
            r11 = r10;
        }
        {
            r7 = 0x0000006FU;
        }
        goto block_00155050;
    }
block_00154FA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154FA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154FA0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00154FE0; }
        goto block_00154FA8;
    }
block_00154FA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154FA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154FA8U);
        }
        {
            const uint32_t updatedAddress = 0x00154FB0U + 0x1ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00154FA8U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r8;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00154FB4U, address);
            }
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00154FC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyInfo_Alloc_00353FD4(frame, context, state, 0x00353FD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00154FC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00154FC0;
    }
block_00154FC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154FC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154FC0U);
        }
        {
            const uint32_t operand = 0x00000010U;
            r1 = r13 + operand;
        }
        {
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00154FC8U, address);
            }
        }
        {
            r10 = 0x00000000U;
        }
        {
            r6 = 0x0000006FU;
        }
        {
            r11 = r10;
        }
        {
            r7 = 0x0000005CU;
        }
        goto block_00155050;
    }
block_00154FE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154FE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154FE0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00155020; }
        goto block_00154FE8;
    }
block_00154FE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00154FE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00154FE8U);
        }
        {
            const uint32_t updatedAddress = 0x00154FF0U + 0x1B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00154FE8U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r8;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00154FF4U, address);
            }
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00155000U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyInfo_Alloc_00353FD4(frame, context, state, 0x00353FD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00155000U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00155000;
    }
block_00155000:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00155000U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00155000U);
        }
        {
            const uint32_t operand = 0x00000010U;
            r1 = r13 + operand;
        }
        {
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00155008U, address);
            }
        }
        {
            r10 = 0x00000000U;
        }
        {
            r6 = 0x00000070U;
        }
        {
            r11 = r10;
        }
        {
            r7 = 0x00000071U;
        }
        goto block_00155050;
    }
block_00155020:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00155020U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00155020U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x00155020U, address);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00155034U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyInfo_Alloc_00353FD4(frame, context, state, 0x00353FD4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00155034U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00155034;
    }
block_00155034:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00155034U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00155034U);
        }
        {
            const uint32_t operand = 0x00000010U;
            r1 = r13 + operand;
        }
        {
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0015503CU, address);
            }
        }
        {
            r10 = 0x00000000U;
        }
        {
            r6 = 0x00000071U;
        }
        {
            r11 = r10;
        }
        {
            r7 = 0x00000070U;
        }
        goto block_00155050;
    }
block_00155050:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00155050U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00155050U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00155060U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadAll_00372F38(frame, context, state, 0x00372F38U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00155060U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00155060;
    }
block_00155060:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00155060U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00155060U);
        }
        {
            const uint32_t source = Oot3dAotRor(r6, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            r3 = r10;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00155074U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadPlayerResource_0036A924(frame, context, state, 0x0036A924U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00155074U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00155074;
    }
block_00155074:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00155074U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00155074U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x248U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00155074U, address);
            }
        }
        {
            const uint32_t source = Oot3dAotRor(r7, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            r3 = r11;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0015508CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadPlayerResource_0036A924(frame, context, state, 0x0036A924U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0015508CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0015508C;
    }
block_0015508C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0015508CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0015508CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x24CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0015508CU, address);
            }
        }
        {
            r3 = 0x00000021U;
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t updatedAddress = r4 + 0x250U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r9))) {
                return Oot3dAotMemoryFault(context, 0x001550A0U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001550A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_LoadPlayerResource_0036A924(frame, context, state, 0x0036A924U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001550A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001550A8;
    }
block_001550A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001550A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001550A8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x254U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001550A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xC2U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001550ACU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetAddFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00155168; }
        goto block_001550B8;
    }
block_001550B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001550B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001550B8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001550B8U, address);
            }
        }
        {
            r3 = 0x00000000U;
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x001550C4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x001550C4U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001550C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x001550CCU, address);
            }
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x000001C4U;
            r2 = r4 + operand;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001550E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_InitActor_00353C9C(frame, context, state, 0x00353C9CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001550E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001550E4;
    }
block_001550E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001550E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001550E4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xC0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001550E4U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x0000000EU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001550ECU, address);
            }
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001550F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Flags_GetTreasure_0036BCB4(frame, context, state, 0x0036BCB4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001550F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001550F8;
    }
block_001550F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001550F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001550F8U);
        }
        {
            const uint32_t address = 0x00155100U + 164U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001550F8U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        if (flags.Z()) { goto block_0015511C; }
        goto block_00155108;
    }
block_00155108:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00155108U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00155108U);
        }
        {
            r1 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x000001C4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00155114U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00155114U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00155114;
    }
block_00155114:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00155114U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00155114U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00155118U, 0xEEF80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        goto block_0015511C;
    }
block_0015511C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0015511CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0015511CU);
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[16];
        }
        {
            r2 = 0x00000002U;
        }
        {
            const uint32_t address = 0x0015512CU + 124U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00155124U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r2;
        }
        {
            const uint32_t operand = 0x000001C4U;
            r0 = r4 + operand;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00155138U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_Change_00375c08_00375C08(frame, context, state, 0x00375C08U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00155138U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00155138;
    }
block_00155138:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00155138U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00155138U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00155138U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000002U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00155144U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_ShowMesh_0037266C(frame, context, state, 0x0037266CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00155144U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00155144;
    }
block_00155144:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00155144U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00155144U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00155144U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00155150U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_ShowMesh_0037266C(frame, context, state, 0x0037266CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00155150U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00155150;
    }
block_00155150:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00155150U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00155150U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00155150U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000003U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0015515CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_HideMesh_0036932C(frame, context, state, 0x0036932CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0015515CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0015515C;
    }
block_0015515C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0015515CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0015515CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0015515CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00155168U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_HideMesh_0036932C(frame, context, state, 0x0036932CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00155168U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00155168;
    }
block_00155168:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00155168U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00155168U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r8 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0015516CU, address);
            }
            r3 = value;
        }
        {
            r2 = r4;
        }
        {
            const uint32_t operand = 0x000002E8U;
            r1 = r1 + operand;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00155180U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPoly_SetBgActor_00353EC8(frame, context, state, 0x00353EC8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00155180U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00155180;
    }
block_00155180:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00155180U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00155180U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00155180U, address);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00155188U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00155188U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            r13 += 8U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0015518CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0015518CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0015518CU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0015518CU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0015518CU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0015518CU,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0015518CU,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0015518CU,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0015518CU,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_EnKo_Init_00165684(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00165684U:
        goto block_00165684;
    case 0x001656A4U:
        goto block_001656A4;
    case 0x001656B8U:
        goto block_001656B8;
    case 0x001656C8U:
        goto block_001656C8;
    case 0x00165700U:
        goto block_00165700;
    case 0x00165710U:
        goto block_00165710;
    case 0x00165720U:
        goto block_00165720;
    case 0x00165730U:
        goto block_00165730;
    case 0x00165744U:
        goto block_00165744;
    case 0x00165754U:
        goto block_00165754;
    case 0x0016575CU:
        goto block_0016575C;
    case 0x00165774U:
        goto block_00165774;
    case 0x0016577CU:
        goto block_0016577C;
    case 0x00165784U:
        goto block_00165784;
    case 0x0016578CU:
        goto block_0016578C;
    case 0x0016579CU:
        goto block_0016579C;
    case 0x001657ACU:
        goto block_001657AC;
    case 0x001657C0U:
        goto block_001657C0;
    case 0x001657C4U:
        goto block_001657C4;
    case 0x001657CCU:
        goto block_001657CC;
    case 0x001657D4U:
        goto block_001657D4;
    case 0x001657DCU:
        goto block_001657DC;
    case 0x00165800U:
        goto block_00165800;
    case 0x00165808U:
        goto block_00165808;
    case 0x0016581CU:
        goto block_0016581C;
    case 0x0016582CU:
        goto block_0016582C;
    case 0x00165834U:
        goto block_00165834;
    case 0x0016584CU:
        goto block_0016584C;
    case 0x00165850U:
        goto block_00165850;
    case 0x00165868U:
        goto block_00165868;
    case 0x0016586CU:
        goto block_0016586C;
    case 0x00165878U:
        goto block_00165878;
    case 0x00165888U:
        goto block_00165888;
    case 0x0016589CU:
        goto block_0016589C;
    case 0x001658A0U:
        goto block_001658A0;
    case 0x001658B0U:
        goto block_001658B0;
    case 0x001658B4U:
        goto block_001658B4;
    case 0x001658C0U:
        goto block_001658C0;
    case 0x001658D0U:
        goto block_001658D0;
    case 0x001658E0U:
        goto block_001658E0;
    case 0x001658E4U:
        goto block_001658E4;
    case 0x001658F0U:
        goto block_001658F0;
    case 0x00165900U:
        goto block_00165900;
    case 0x00165914U:
        goto block_00165914;
    case 0x00165918U:
        goto block_00165918;
    case 0x00165928U:
        goto block_00165928;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00165684:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00165684U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00165684U);
        }
        {
            const uint32_t firstAddress = r13 - 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00165684U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00165684U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00165684U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x00165684U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x00165684U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x00165684U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00165684U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00165684U,
                                           firstAddress + 28U);
            }
            r13 = r13 - 32U;
        }
        {
            r4 = r0;
        }
        {
            r5 = r1;
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00165694U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & 0x000000FFU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_00165754; }
        goto block_001656A4;
    }
block_001656A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001656A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001656A4U);
        }
        {
            const uint32_t operand = 0x00003800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            r1 = 0x000000C5U;
        }
        {
            r9 = r0;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x001656B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Object_GetIndex_00363C10(frame, context, state, 0x00363C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001656B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001656B8;
    }
block_001656B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001656B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001656B8U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int8_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x22FU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001656C0U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_00165754; }
        goto block_001656C8;
    }
block_001656C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001656C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001656C8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001656C8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x001656D4U + 0x25CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001656CCU, address);
            }
            r10 = value;
        }
        {
            r0 = r0 & 0x000000FFU;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r1 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 3U);
            r0 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = 0x001656E4U + 0x248U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001656DCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + r0;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001656E0U, address);
            }
            r7 = value;
        }
        {
            const uint32_t operand = r1;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x1U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001656E8U, address);
            }
            r8 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x6U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001656ECU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 3U);
            r0 = r10 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001656F4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00165700U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Object_GetIndex_00363C10(frame, context, state, 0x00363C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00165700U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00165700;
    }
block_00165700:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00165700U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00165700U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int8_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x22EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00165708U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_00165754; }
        goto block_00165710;
    }
block_00165710:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00165710U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00165710U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r8, 3U);
            r0 = r10 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00165714U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00165720U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Object_GetIndex_00363C10(frame, context, state, 0x00363C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00165720U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00165720;
    }
block_00165720:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00165720U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00165720U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int8_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x22DU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00165728U, address);
            }
        }
        if ((flags.N()) != (flags.V())) { goto block_00165754; }
        goto block_00165730;
    }
block_00165730:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00165730U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00165730U);
        }
        {
            const uint32_t operand = 0x00000030U;
            r0 = r10 - operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r7, 4U);
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00165738U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00165744U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Object_GetIndex_00363C10(frame, context, state, 0x00363C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00165744U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00165744;
    }
block_00165744:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00165744U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00165744U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int8_t>(source));
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x22CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0016574CU, address);
            }
        }
        if ((flags.N()) == (flags.V())) { goto block_0016575C; }
        goto block_00165754;
    }
block_00165754:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00165754U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00165754U);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0016575CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Kill_00374428(frame, context, state, 0x00374428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0016575CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0016575C;
    }
block_0016575C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0016575CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0016575CU);
        }
        {
            r0 = 0x00000104U;
        }
        {
            const uint32_t updatedAddress = 0x00165768U + 0x1CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00165760U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r5;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00165764U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t updatedAddress = 0x00165770U + 0x1C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00165768U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000029U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if (flags.Z()) { goto block_001658B4; }
        goto block_00165774;
    }
block_00165774:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00165774U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00165774U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_001657C4; }
        goto block_0016577C;
    }
block_0016577C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0016577CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0016577CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000026U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_00165850; }
        goto block_00165784;
    }
block_00165784:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00165784U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00165784U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000027U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0016586C; }
        goto block_0016578C;
    }
block_0016578C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0016578CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0016578CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000028U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00165790U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00165800; }
        goto block_0016579C;
    }
block_0016579C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0016579CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0016579CU);
        }
        {
            const uint32_t updatedAddress = r2 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0016579CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001657A0U, address);
            }
            r1 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_00165800; }
        goto block_001657AC;
    }
block_001657AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001657ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001657ACU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001657ACU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t value = r0 & 0x000000FFU;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) {
            r0 = r0 & 0x000000FFU;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000004U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00165808; }
        goto block_001657C0;
    }
block_001657C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001657C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001657C0U);
        }
        goto block_00165800;
    }
block_001657C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001657C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001657C4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_001658E4; }
        goto block_001657CC;
    }
block_001657CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001657CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001657CCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000055U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0016581C; }
        goto block_001657D4;
    }
block_001657D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001657D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001657D4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000005BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00165800; }
        goto block_001657DC;
    }
block_001657DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001657DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001657DCU);
        }
        {
            const uint32_t updatedAddress = 0x001657E4U + 0x158U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001657DCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x001657E8U + 0x158U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001657E0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2DU;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001657E4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r1;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001657E8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000031U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            r0 = 0x00000000U;
        }
        if (flags.Z()) {
            r0 = 0x00000001U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00165808; }
        goto block_00165800;
    }
block_00165800:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00165800U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00165800U);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00165808U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Kill_00374428(frame, context, state, 0x00374428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00165808U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00165808;
    }
block_00165808:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00165808U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00165808U);
        }
        {
            const uint32_t updatedAddress = 0x00165810U + 0x134U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00165808U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xC98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0016580CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xCA4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00165810U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x228U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00165814U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00165818U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00165818U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00165818U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x00165818U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x00165818U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x00165818U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x00165818U,
                                           firstAddress + 24U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x00165818U,
                                           firstAddress + 28U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r13 = r13 + 32U;
            return Oot3dAotReturned(value15);
        }
    }
block_0016581C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0016581CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0016581CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0016581CU, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & 0x000000FFU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0x3U));
        }
        if (!(flags.C())) { goto block_00165834; }
        goto block_0016582C;
    }
block_0016582C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0016582CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0016582CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00165800; }
        goto block_00165834;
    }
block_00165834:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00165834U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00165834U);
        }
        {
            const uint32_t updatedAddress = r2 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00165834U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00165838U, address);
            }
            r1 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00165840U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00165808; }
        goto block_0016584C;
    }
block_0016584C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0016584CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0016584CU);
        }
        goto block_00165800;
    }
block_00165850:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00165850U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00165850U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00165850U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & 0x000000FFU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00165808; }
        goto block_00165868;
    }
block_00165868:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00165868U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00165868U);
        }
        goto block_00165800;
    }
block_0016586C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0016586CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0016586CU);
        }
        {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0016586CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) { goto block_001658A0; }
        goto block_00165878;
    }
block_00165878:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00165878U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00165878U);
        }
        {
            const uint32_t updatedAddress = r2 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00165878U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0016587CU, address);
            }
            r1 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001658A0; }
        goto block_00165888;
    }
block_00165888:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00165888U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00165888U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00165888U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & 0x000000FFU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000009U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00165808; }
        goto block_0016589C;
    }
block_0016589C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0016589CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0016589CU);
        }
        goto block_00165800;
    }
block_001658A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001658A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001658A0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001658A0U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & 0x000000FFU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000009U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00165808; }
        goto block_001658B0;
    }
block_001658B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001658B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001658B0U);
        }
        goto block_00165800;
    }
block_001658B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001658B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001658B4U);
        }
        {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001658B4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00165800; }
        goto block_001658C0;
    }
block_001658C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001658C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001658C0U);
        }
        {
            const uint32_t updatedAddress = r2 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001658C0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001658C4U, address);
            }
            r1 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_00165800; }
        goto block_001658D0;
    }
block_001658D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001658D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001658D0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001658D0U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & 0x000000FFU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00165808; }
        goto block_001658E0;
    }
block_001658E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001658E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001658E0U);
        }
        goto block_00165800;
    }
block_001658E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001658E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001658E4U);
        }
        {
            const uint32_t updatedAddress = r2 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001658E4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.Z())) { goto block_00165918; }
        goto block_001658F0;
    }
block_001658F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001658F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001658F0U);
        }
        {
            const uint32_t updatedAddress = r2 + 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001658F0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001658F4U, address);
            }
            r1 = value;
        }
        {
            const auto shifted = Oot3dAotShiftImmediate(
                r1, 0U, 0U, flags.C());
            const uint32_t value = r0 & shifted.Value;
            Oot3dAotSetLogicalFlags(flags, value, shifted.Carry, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_00165918; }
        goto block_00165900;
    }
block_00165900:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00165900U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00165900U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00165900U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & 0x000000FFU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000005U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00165808; }
        goto block_00165914;
    }
block_00165914:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00165914U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00165914U);
        }
        goto block_00165800;
    }
block_00165918:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00165918U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00165918U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00165918U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & 0x000000FFU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00165808; }
        goto block_00165928;
    }
block_00165928:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00165928U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00165928U);
        }
        goto block_00165800;
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_0017bf98_0017BF98(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0017BF98U:
        goto block_0017BF98;
    case 0x0017C000U:
        goto block_0017C000;
    case 0x0017C010U:
        goto block_0017C010;
    case 0x0017C070U:
        goto block_0017C070;
    case 0x0017C07CU:
        goto block_0017C07C;
    case 0x0017C0C4U:
        goto block_0017C0C4;
    case 0x0017C0D4U:
        goto block_0017C0D4;
    case 0x0017C0E0U:
        goto block_0017C0E0;
    case 0x0017C0F4U:
        goto block_0017C0F4;
    case 0x0017C104U:
        goto block_0017C104;
    case 0x0017C11CU:
        goto block_0017C11C;
    case 0x0017C14CU:
        goto block_0017C14C;
    case 0x0017C174U:
        goto block_0017C174;
    case 0x0017C18CU:
        goto block_0017C18C;
    case 0x0017C1C4U:
        goto block_0017C1C4;
    case 0x0017C1D0U:
        goto block_0017C1D0;
    case 0x0017C1E4U:
        goto block_0017C1E4;
    case 0x0017C220U:
        goto block_0017C220;
    case 0x0017C224U:
        goto block_0017C224;
    case 0x0017C25CU:
        goto block_0017C25C;
    case 0x0017C26CU:
        goto block_0017C26C;
    case 0x0017C280U:
        goto block_0017C280;
    case 0x0017C2F0U:
        goto block_0017C2F0;
    case 0x0017C308U:
        goto block_0017C308;
    case 0x0017C314U:
        goto block_0017C314;
    case 0x0017C320U:
        goto block_0017C320;
    case 0x0017C330U:
        goto block_0017C330;
    case 0x0017C33CU:
        goto block_0017C33C;
    case 0x0017C358U:
        goto block_0017C358;
    case 0x0017C364U:
        goto block_0017C364;
    case 0x0017C398U:
        goto block_0017C398;
    case 0x0017C3B0U:
        goto block_0017C3B0;
    case 0x0017C3CCU:
        goto block_0017C3CC;
    case 0x0017C3E4U:
        goto block_0017C3E4;
    case 0x0017C40CU:
        goto block_0017C40C;
    case 0x0017C424U:
        goto block_0017C424;
    case 0x0017C430U:
        goto block_0017C430;
    case 0x0017C440U:
        goto block_0017C440;
    case 0x0017C454U:
        goto block_0017C454;
    case 0x0017C458U:
        goto block_0017C458;
    case 0x0017C464U:
        goto block_0017C464;
    case 0x0017C46CU:
        goto block_0017C46C;
    case 0x0017C474U:
        goto block_0017C474;
    case 0x0017C48CU:
        goto block_0017C48C;
    case 0x0017C4A0U:
        goto block_0017C4A0;
    case 0x0017C4C0U:
        goto block_0017C4C0;
    case 0x0017C4DCU:
        goto block_0017C4DC;
    case 0x0017C4E8U:
        goto block_0017C4E8;
    case 0x0017C4FCU:
        goto block_0017C4FC;
    case 0x0017C514U:
        goto block_0017C514;
    case 0x0017C520U:
        goto block_0017C520;
    case 0x0017C538U:
        goto block_0017C538;
    case 0x0017C544U:
        goto block_0017C544;
    case 0x0017C55CU:
        goto block_0017C55C;
    case 0x0017C570U:
        goto block_0017C570;
    case 0x0017C588U:
        goto block_0017C588;
    case 0x0017C598U:
        goto block_0017C598;
    case 0x0017C5A4U:
        goto block_0017C5A4;
    case 0x0017C5B0U:
        goto block_0017C5B0;
    case 0x0017C5CCU:
        goto block_0017C5CC;
    case 0x0017C5E4U:
        goto block_0017C5E4;
    case 0x0017C5F8U:
        goto block_0017C5F8;
    case 0x0017C614U:
        goto block_0017C614;
    case 0x0017C668U:
        goto block_0017C668;
    case 0x0017C670U:
        goto block_0017C670;
    case 0x0017C68CU:
        goto block_0017C68C;
    case 0x0017C6B8U:
        goto block_0017C6B8;
    case 0x0017C6D0U:
        goto block_0017C6D0;
    case 0x0017C744U:
        goto block_0017C744;
    case 0x0017C758U:
        goto block_0017C758;
    case 0x0017C770U:
        goto block_0017C770;
    case 0x0017C77CU:
        goto block_0017C77C;
    case 0x0017C78CU:
        goto block_0017C78C;
    case 0x0017C7A0U:
        goto block_0017C7A0;
    case 0x0017C7BCU:
        goto block_0017C7BC;
    case 0x0017C7C8U:
        goto block_0017C7C8;
    case 0x0017C7E4U:
        goto block_0017C7E4;
    case 0x0017C7FCU:
        goto block_0017C7FC;
    case 0x0017C814U:
        goto block_0017C814;
    case 0x0017C820U:
        goto block_0017C820;
    case 0x0017C868U:
        goto block_0017C868;
    case 0x0017C87CU:
        goto block_0017C87C;
    case 0x0017C894U:
        goto block_0017C894;
    case 0x0017C8A8U:
        goto block_0017C8A8;
    case 0x0017C8B4U:
        goto block_0017C8B4;
    case 0x0017C8D4U:
        goto block_0017C8D4;
    case 0x0017C93CU:
        goto block_0017C93C;
    case 0x0017C944U:
        goto block_0017C944;
    case 0x0017C95CU:
        goto block_0017C95C;
    case 0x0017C970U:
        goto block_0017C970;
    case 0x0017C994U:
        goto block_0017C994;
    case 0x0017C9ACU:
        goto block_0017C9AC;
    case 0x0017C9C0U:
        goto block_0017C9C0;
    case 0x0017C9D8U:
        goto block_0017C9D8;
    case 0x0017C9E4U:
        goto block_0017C9E4;
    case 0x0017C9F8U:
        goto block_0017C9F8;
    case 0x0017CA04U:
        goto block_0017CA04;
    case 0x0017CA14U:
        goto block_0017CA14;
    case 0x0017CA28U:
        goto block_0017CA28;
    case 0x0017CA70U:
        goto block_0017CA70;
    case 0x0017CA7CU:
        goto block_0017CA7C;
    case 0x0017CA98U:
        goto block_0017CA98;
    case 0x0017CAB0U:
        goto block_0017CAB0;
    case 0x0017CAC8U:
        goto block_0017CAC8;
    case 0x0017CAD4U:
        goto block_0017CAD4;
    case 0x0017CAE8U:
        goto block_0017CAE8;
    case 0x0017CB00U:
        goto block_0017CB00;
    case 0x0017CB14U:
        goto block_0017CB14;
    case 0x0017CB20U:
        goto block_0017CB20;
    case 0x0017CB44U:
        goto block_0017CB44;
    case 0x0017CB5CU:
        goto block_0017CB5C;
    case 0x0017CB70U:
        goto block_0017CB70;
    case 0x0017CB84U:
        goto block_0017CB84;
    case 0x0017CB94U:
        goto block_0017CB94;
    case 0x0017CBA0U:
        goto block_0017CBA0;
    case 0x0017CBACU:
        goto block_0017CBAC;
    case 0x0017CBB8U:
        goto block_0017CBB8;
    case 0x0017CBD0U:
        goto block_0017CBD0;
    case 0x0017CBE8U:
        goto block_0017CBE8;
    case 0x0017CBF8U:
        goto block_0017CBF8;
    case 0x0017CCA4U:
        goto block_0017CCA4;
    case 0x0017CCB0U:
        goto block_0017CCB0;
    case 0x0017CCBCU:
        goto block_0017CCBC;
    case 0x0017CCCCU:
        goto block_0017CCCC;
    case 0x0017CD20U:
        goto block_0017CD20;
    case 0x0017CDB4U:
        goto block_0017CDB4;
    case 0x0017CDC4U:
        goto block_0017CDC4;
    case 0x0017CDD0U:
        goto block_0017CDD0;
    case 0x0017CE18U:
        goto block_0017CE18;
    case 0x0017CE30U:
        goto block_0017CE30;
    case 0x0017CE44U:
        goto block_0017CE44;
    case 0x0017CE50U:
        goto block_0017CE50;
    case 0x0017CE5CU:
        goto block_0017CE5C;
    case 0x0017CE68U:
        goto block_0017CE68;
    case 0x0017CE88U:
        goto block_0017CE88;
    case 0x0017CE94U:
        goto block_0017CE94;
    case 0x0017CEA8U:
        goto block_0017CEA8;
    case 0x0017CEB4U:
        goto block_0017CEB4;
    case 0x0017CEC4U:
        goto block_0017CEC4;
    case 0x0017CECCU:
        goto block_0017CECC;
    case 0x0017CED8U:
        goto block_0017CED8;
    case 0x0017CEE8U:
        goto block_0017CEE8;
    case 0x0017CEF4U:
        goto block_0017CEF4;
    case 0x0017CF00U:
        goto block_0017CF00;
    case 0x0017CF0CU:
        goto block_0017CF0C;
    case 0x0017CF24U:
        goto block_0017CF24;
    case 0x0017CF3CU:
        goto block_0017CF3C;
    case 0x0017CF5CU:
        goto block_0017CF5C;
    case 0x0017CF68U:
        goto block_0017CF68;
    case 0x0017CF78U:
        goto block_0017CF78;
    case 0x0017CF84U:
        goto block_0017CF84;
    case 0x0017CF90U:
        goto block_0017CF90;
    case 0x0017CF9CU:
        goto block_0017CF9C;
    case 0x0017CFB4U:
        goto block_0017CFB4;
    case 0x0017CFE4U:
        goto block_0017CFE4;
    case 0x0017CFFCU:
        goto block_0017CFFC;
    case 0x0017D010U:
        goto block_0017D010;
    case 0x0017D018U:
        goto block_0017D018;
    case 0x0017D028U:
        goto block_0017D028;
    case 0x0017D034U:
        goto block_0017D034;
    case 0x0017D048U:
        goto block_0017D048;
    case 0x0017D05CU:
        goto block_0017D05C;
    case 0x0017D068U:
        goto block_0017D068;
    case 0x0017D078U:
        goto block_0017D078;
    case 0x0017D088U:
        goto block_0017D088;
    case 0x0017D090U:
        goto block_0017D090;
    case 0x0017D09CU:
        goto block_0017D09C;
    case 0x0017D0A8U:
        goto block_0017D0A8;
    case 0x0017D0B4U:
        goto block_0017D0B4;
    case 0x0017D0C8U:
        goto block_0017D0C8;
    case 0x0017D0DCU:
        goto block_0017D0DC;
    case 0x0017D0ECU:
        goto block_0017D0EC;
    case 0x0017D0F8U:
        goto block_0017D0F8;
    case 0x0017D108U:
        goto block_0017D108;
    case 0x0017D114U:
        goto block_0017D114;
    case 0x0017D11CU:
        goto block_0017D11C;
    case 0x0017D130U:
        goto block_0017D130;
    case 0x0017D144U:
        goto block_0017D144;
    case 0x0017D164U:
        goto block_0017D164;
    case 0x0017D17CU:
        goto block_0017D17C;
    case 0x0017D188U:
        goto block_0017D188;
    case 0x0017D1ACU:
        goto block_0017D1AC;
    case 0x0017D1BCU:
        goto block_0017D1BC;
    case 0x0017D218U:
        goto block_0017D218;
    case 0x0017D230U:
        goto block_0017D230;
    case 0x0017D244U:
        goto block_0017D244;
    case 0x0017D280U:
        goto block_0017D280;
    case 0x0017D28CU:
        goto block_0017D28C;
    case 0x0017D29CU:
        goto block_0017D29C;
    case 0x0017D2A4U:
        goto block_0017D2A4;
    case 0x0017D2B0U:
        goto block_0017D2B0;
    case 0x0017D2BCU:
        goto block_0017D2BC;
    case 0x0017D2C8U:
        goto block_0017D2C8;
    case 0x0017D2E8U:
        goto block_0017D2E8;
    case 0x0017D2F8U:
        goto block_0017D2F8;
    case 0x0017D33CU:
        goto block_0017D33C;
    case 0x0017D348U:
        goto block_0017D348;
    case 0x0017D354U:
        goto block_0017D354;
    case 0x0017D360U:
        goto block_0017D360;
    case 0x0017D374U:
        goto block_0017D374;
    case 0x0017D388U:
        goto block_0017D388;
    case 0x0017D394U:
        goto block_0017D394;
    case 0x0017D3C0U:
        goto block_0017D3C0;
    case 0x0017D3C8U:
        goto block_0017D3C8;
    case 0x0017D3E8U:
        goto block_0017D3E8;
    case 0x0017D408U:
        goto block_0017D408;
    case 0x0017D420U:
        goto block_0017D420;
    case 0x0017D434U:
        goto block_0017D434;
    case 0x0017D44CU:
        goto block_0017D44C;
    case 0x0017D458U:
        goto block_0017D458;
    case 0x0017D468U:
        goto block_0017D468;
    case 0x0017D474U:
        goto block_0017D474;
    case 0x0017D494U:
        goto block_0017D494;
    case 0x0017D49CU:
        goto block_0017D49C;
    case 0x0017D4BCU:
        goto block_0017D4BC;
    case 0x0017D4D4U:
        goto block_0017D4D4;
    case 0x0017D4ECU:
        goto block_0017D4EC;
    case 0x0017D4F8U:
        goto block_0017D4F8;
    case 0x0017D504U:
        goto block_0017D504;
    case 0x0017D510U:
        goto block_0017D510;
    case 0x0017D5ACU:
        goto block_0017D5AC;
    case 0x0017D604U:
        goto block_0017D604;
    case 0x0017D61CU:
        goto block_0017D61C;
    case 0x0017D644U:
        goto block_0017D644;
    case 0x0017D650U:
        goto block_0017D650;
    case 0x0017D664U:
        goto block_0017D664;
    case 0x0017D67CU:
        goto block_0017D67C;
    case 0x0017D688U:
        goto block_0017D688;
    case 0x0017D694U:
        goto block_0017D694;
    case 0x0017D6A0U:
        goto block_0017D6A0;
    case 0x0017D6B4U:
        goto block_0017D6B4;
    case 0x0017D6C4U:
        goto block_0017D6C4;
    case 0x0017D6D0U:
        goto block_0017D6D0;
    case 0x0017D6E0U:
        goto block_0017D6E0;
    case 0x0017D6ECU:
        goto block_0017D6EC;
    case 0x0017D718U:
        goto block_0017D718;
    case 0x0017D730U:
        goto block_0017D730;
    case 0x0017D744U:
        goto block_0017D744;
    case 0x0017D758U:
        goto block_0017D758;
    case 0x0017D768U:
        goto block_0017D768;
    case 0x0017D7A0U:
        goto block_0017D7A0;
    case 0x0017D7B0U:
        goto block_0017D7B0;
    case 0x0017D7BCU:
        goto block_0017D7BC;
    case 0x0017D7C8U:
        goto block_0017D7C8;
    case 0x0017D7D4U:
        goto block_0017D7D4;
    case 0x0017D834U:
        goto block_0017D834;
    case 0x0017D84CU:
        goto block_0017D84C;
    case 0x0017D878U:
        goto block_0017D878;
    case 0x0017D8B8U:
        goto block_0017D8B8;
    case 0x0017D8D8U:
        goto block_0017D8D8;
    case 0x0017D8E4U:
        goto block_0017D8E4;
    case 0x0017D8F4U:
        goto block_0017D8F4;
    case 0x0017D90CU:
        goto block_0017D90C;
    case 0x0017D914U:
        goto block_0017D914;
    case 0x0017D938U:
        goto block_0017D938;
    case 0x0017D94CU:
        goto block_0017D94C;
    case 0x0017D958U:
        goto block_0017D958;
    case 0x0017D968U:
        goto block_0017D968;
    case 0x0017D978U:
        goto block_0017D978;
    case 0x0017D9A4U:
        goto block_0017D9A4;
    case 0x0017D9B0U:
        goto block_0017D9B0;
    case 0x0017DA2CU:
        goto block_0017DA2C;
    case 0x0017DA38U:
        goto block_0017DA38;
    case 0x0017DA4CU:
        goto block_0017DA4C;
    case 0x0017DA68U:
        goto block_0017DA68;
    case 0x0017DA7CU:
        goto block_0017DA7C;
    case 0x0017DACCU:
        goto block_0017DACC;
    case 0x0017DB18U:
        goto block_0017DB18;
    case 0x0017DB50U:
        goto block_0017DB50;
    case 0x0017DB5CU:
        goto block_0017DB5C;
    case 0x0017DB80U:
        goto block_0017DB80;
    case 0x0017DB8CU:
        goto block_0017DB8C;
    case 0x0017DBC8U:
        goto block_0017DBC8;
    case 0x0017DBE4U:
        goto block_0017DBE4;
    case 0x0017DBF4U:
        goto block_0017DBF4;
    case 0x0017DC00U:
        goto block_0017DC00;
    case 0x0017DC10U:
        goto block_0017DC10;
    case 0x0017DC24U:
        goto block_0017DC24;
    case 0x0017DC30U:
        goto block_0017DC30;
    case 0x0017DC38U:
        goto block_0017DC38;
    case 0x0017DC58U:
        goto block_0017DC58;
    case 0x0017DC78U:
        goto block_0017DC78;
    case 0x0017DC98U:
        goto block_0017DC98;
    case 0x0017DCB8U:
        goto block_0017DCB8;
    case 0x0017DCD8U:
        goto block_0017DCD8;
    case 0x0017DCF8U:
        goto block_0017DCF8;
    case 0x0017DD5CU:
        goto block_0017DD5C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0017BF98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017BF98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017BF98U);
        }
        {
            const uint32_t firstAddress = r13 - 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0017BF98U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0017BF98U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0017BF98U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0017BF98U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0017BF98U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0017BF98U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0017BF98U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0017BF98U,
                                           firstAddress + 28U);
            }
            r13 = r13 - 32U;
        }
        {
            r4 = r0;
        }
        {
            r6 = r1;
        }
        {
            r8 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = 0x0017BFB0U + 0x2E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017BFA8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0017BFB4U + 740U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017BFACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r13 -= 32U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017BFB0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0017BFB0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0017BFB0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0017BFB0U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x0017BFB0U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0017BFB0U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x0017BFB0U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x0017BFB0U,
                                           firstAddress + 28U);
            }
        }
        {
            const uint32_t operand = 0x00000048U;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + r1;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017BFB8U, address);
            }
            r7 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017BFC4U + 0x2D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017BFBCU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017BFC0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00001400U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 776U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017BFC8U, address);
            }
        }
        {
            const uint32_t address = 0x0017BFD4U + 716U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017BFCCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 780U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017BFD0U, address);
            }
        }
        {
            const uint32_t address = 0x0017BFDCU + 712U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017BFD4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 784U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017BFD8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017BFDCU, address);
            }
            r1 = value;
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017BFE4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 808U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017BFE8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017BFECU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017BFF4U, address);
            }
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C000U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C000U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C000;
    }
block_0017C000:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C000U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C000U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r5 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C004U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000017U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x0017C014U + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C00CU, address);
            }
            switch (value) {
            case 0x0017BF98U:
                goto block_0017BF98;
            case 0x0017C000U:
                goto block_0017C000;
            case 0x0017C010U:
                goto block_0017C010;
            case 0x0017C070U:
                goto block_0017C070;
            case 0x0017C07CU:
                goto block_0017C07C;
            case 0x0017C0C4U:
                goto block_0017C0C4;
            case 0x0017C0D4U:
                goto block_0017C0D4;
            case 0x0017C0E0U:
                goto block_0017C0E0;
            case 0x0017C0F4U:
                goto block_0017C0F4;
            case 0x0017C104U:
                goto block_0017C104;
            case 0x0017C11CU:
                goto block_0017C11C;
            case 0x0017C14CU:
                goto block_0017C14C;
            case 0x0017C174U:
                goto block_0017C174;
            case 0x0017C18CU:
                goto block_0017C18C;
            case 0x0017C1C4U:
                goto block_0017C1C4;
            case 0x0017C1D0U:
                goto block_0017C1D0;
            case 0x0017C1E4U:
                goto block_0017C1E4;
            case 0x0017C220U:
                goto block_0017C220;
            case 0x0017C224U:
                goto block_0017C224;
            case 0x0017C25CU:
                goto block_0017C25C;
            case 0x0017C26CU:
                goto block_0017C26C;
            case 0x0017C280U:
                goto block_0017C280;
            case 0x0017C2F0U:
                goto block_0017C2F0;
            case 0x0017C308U:
                goto block_0017C308;
            case 0x0017C314U:
                goto block_0017C314;
            case 0x0017C320U:
                goto block_0017C320;
            case 0x0017C330U:
                goto block_0017C330;
            case 0x0017C33CU:
                goto block_0017C33C;
            case 0x0017C358U:
                goto block_0017C358;
            case 0x0017C364U:
                goto block_0017C364;
            case 0x0017C398U:
                goto block_0017C398;
            case 0x0017C3B0U:
                goto block_0017C3B0;
            case 0x0017C3CCU:
                goto block_0017C3CC;
            case 0x0017C3E4U:
                goto block_0017C3E4;
            case 0x0017C40CU:
                goto block_0017C40C;
            case 0x0017C424U:
                goto block_0017C424;
            case 0x0017C430U:
                goto block_0017C430;
            case 0x0017C440U:
                goto block_0017C440;
            case 0x0017C454U:
                goto block_0017C454;
            case 0x0017C458U:
                goto block_0017C458;
            case 0x0017C464U:
                goto block_0017C464;
            case 0x0017C46CU:
                goto block_0017C46C;
            case 0x0017C474U:
                goto block_0017C474;
            case 0x0017C48CU:
                goto block_0017C48C;
            case 0x0017C4A0U:
                goto block_0017C4A0;
            case 0x0017C4C0U:
                goto block_0017C4C0;
            case 0x0017C4DCU:
                goto block_0017C4DC;
            case 0x0017C4E8U:
                goto block_0017C4E8;
            case 0x0017C4FCU:
                goto block_0017C4FC;
            case 0x0017C514U:
                goto block_0017C514;
            case 0x0017C520U:
                goto block_0017C520;
            case 0x0017C538U:
                goto block_0017C538;
            case 0x0017C544U:
                goto block_0017C544;
            case 0x0017C55CU:
                goto block_0017C55C;
            case 0x0017C570U:
                goto block_0017C570;
            case 0x0017C588U:
                goto block_0017C588;
            case 0x0017C598U:
                goto block_0017C598;
            case 0x0017C5A4U:
                goto block_0017C5A4;
            case 0x0017C5B0U:
                goto block_0017C5B0;
            case 0x0017C5CCU:
                goto block_0017C5CC;
            case 0x0017C5E4U:
                goto block_0017C5E4;
            case 0x0017C5F8U:
                goto block_0017C5F8;
            case 0x0017C614U:
                goto block_0017C614;
            case 0x0017C668U:
                goto block_0017C668;
            case 0x0017C670U:
                goto block_0017C670;
            case 0x0017C68CU:
                goto block_0017C68C;
            case 0x0017C6B8U:
                goto block_0017C6B8;
            case 0x0017C6D0U:
                goto block_0017C6D0;
            case 0x0017C744U:
                goto block_0017C744;
            case 0x0017C758U:
                goto block_0017C758;
            case 0x0017C770U:
                goto block_0017C770;
            case 0x0017C77CU:
                goto block_0017C77C;
            case 0x0017C78CU:
                goto block_0017C78C;
            case 0x0017C7A0U:
                goto block_0017C7A0;
            case 0x0017C7BCU:
                goto block_0017C7BC;
            case 0x0017C7C8U:
                goto block_0017C7C8;
            case 0x0017C7E4U:
                goto block_0017C7E4;
            case 0x0017C7FCU:
                goto block_0017C7FC;
            case 0x0017C814U:
                goto block_0017C814;
            case 0x0017C820U:
                goto block_0017C820;
            case 0x0017C868U:
                goto block_0017C868;
            case 0x0017C87CU:
                goto block_0017C87C;
            case 0x0017C894U:
                goto block_0017C894;
            case 0x0017C8A8U:
                goto block_0017C8A8;
            case 0x0017C8B4U:
                goto block_0017C8B4;
            case 0x0017C8D4U:
                goto block_0017C8D4;
            case 0x0017C93CU:
                goto block_0017C93C;
            case 0x0017C944U:
                goto block_0017C944;
            case 0x0017C95CU:
                goto block_0017C95C;
            case 0x0017C970U:
                goto block_0017C970;
            case 0x0017C994U:
                goto block_0017C994;
            case 0x0017C9ACU:
                goto block_0017C9AC;
            case 0x0017C9C0U:
                goto block_0017C9C0;
            case 0x0017C9D8U:
                goto block_0017C9D8;
            case 0x0017C9E4U:
                goto block_0017C9E4;
            case 0x0017C9F8U:
                goto block_0017C9F8;
            case 0x0017CA04U:
                goto block_0017CA04;
            case 0x0017CA14U:
                goto block_0017CA14;
            case 0x0017CA28U:
                goto block_0017CA28;
            case 0x0017CA70U:
                goto block_0017CA70;
            case 0x0017CA7CU:
                goto block_0017CA7C;
            case 0x0017CA98U:
                goto block_0017CA98;
            case 0x0017CAB0U:
                goto block_0017CAB0;
            case 0x0017CAC8U:
                goto block_0017CAC8;
            case 0x0017CAD4U:
                goto block_0017CAD4;
            case 0x0017CAE8U:
                goto block_0017CAE8;
            case 0x0017CB00U:
                goto block_0017CB00;
            case 0x0017CB14U:
                goto block_0017CB14;
            case 0x0017CB20U:
                goto block_0017CB20;
            case 0x0017CB44U:
                goto block_0017CB44;
            case 0x0017CB5CU:
                goto block_0017CB5C;
            case 0x0017CB70U:
                goto block_0017CB70;
            case 0x0017CB84U:
                goto block_0017CB84;
            case 0x0017CB94U:
                goto block_0017CB94;
            case 0x0017CBA0U:
                goto block_0017CBA0;
            case 0x0017CBACU:
                goto block_0017CBAC;
            case 0x0017CBB8U:
                goto block_0017CBB8;
            case 0x0017CBD0U:
                goto block_0017CBD0;
            case 0x0017CBE8U:
                goto block_0017CBE8;
            case 0x0017CBF8U:
                goto block_0017CBF8;
            case 0x0017CCA4U:
                goto block_0017CCA4;
            case 0x0017CCB0U:
                goto block_0017CCB0;
            case 0x0017CCBCU:
                goto block_0017CCBC;
            case 0x0017CCCCU:
                goto block_0017CCCC;
            case 0x0017CD20U:
                goto block_0017CD20;
            case 0x0017CDB4U:
                goto block_0017CDB4;
            case 0x0017CDC4U:
                goto block_0017CDC4;
            case 0x0017CDD0U:
                goto block_0017CDD0;
            case 0x0017CE18U:
                goto block_0017CE18;
            case 0x0017CE30U:
                goto block_0017CE30;
            case 0x0017CE44U:
                goto block_0017CE44;
            case 0x0017CE50U:
                goto block_0017CE50;
            case 0x0017CE5CU:
                goto block_0017CE5C;
            case 0x0017CE68U:
                goto block_0017CE68;
            case 0x0017CE88U:
                goto block_0017CE88;
            case 0x0017CE94U:
                goto block_0017CE94;
            case 0x0017CEA8U:
                goto block_0017CEA8;
            case 0x0017CEB4U:
                goto block_0017CEB4;
            case 0x0017CEC4U:
                goto block_0017CEC4;
            case 0x0017CECCU:
                goto block_0017CECC;
            case 0x0017CED8U:
                goto block_0017CED8;
            case 0x0017CEE8U:
                goto block_0017CEE8;
            case 0x0017CEF4U:
                goto block_0017CEF4;
            case 0x0017CF00U:
                goto block_0017CF00;
            case 0x0017CF0CU:
                goto block_0017CF0C;
            case 0x0017CF24U:
                goto block_0017CF24;
            case 0x0017CF3CU:
                goto block_0017CF3C;
            case 0x0017CF5CU:
                goto block_0017CF5C;
            case 0x0017CF68U:
                goto block_0017CF68;
            case 0x0017CF78U:
                goto block_0017CF78;
            case 0x0017CF84U:
                goto block_0017CF84;
            case 0x0017CF90U:
                goto block_0017CF90;
            case 0x0017CF9CU:
                goto block_0017CF9C;
            case 0x0017CFB4U:
                goto block_0017CFB4;
            case 0x0017CFE4U:
                goto block_0017CFE4;
            case 0x0017CFFCU:
                goto block_0017CFFC;
            case 0x0017D010U:
                goto block_0017D010;
            case 0x0017D018U:
                goto block_0017D018;
            case 0x0017D028U:
                goto block_0017D028;
            case 0x0017D034U:
                goto block_0017D034;
            case 0x0017D048U:
                goto block_0017D048;
            case 0x0017D05CU:
                goto block_0017D05C;
            case 0x0017D068U:
                goto block_0017D068;
            case 0x0017D078U:
                goto block_0017D078;
            case 0x0017D088U:
                goto block_0017D088;
            case 0x0017D090U:
                goto block_0017D090;
            case 0x0017D09CU:
                goto block_0017D09C;
            case 0x0017D0A8U:
                goto block_0017D0A8;
            case 0x0017D0B4U:
                goto block_0017D0B4;
            case 0x0017D0C8U:
                goto block_0017D0C8;
            case 0x0017D0DCU:
                goto block_0017D0DC;
            case 0x0017D0ECU:
                goto block_0017D0EC;
            case 0x0017D0F8U:
                goto block_0017D0F8;
            case 0x0017D108U:
                goto block_0017D108;
            case 0x0017D114U:
                goto block_0017D114;
            case 0x0017D11CU:
                goto block_0017D11C;
            case 0x0017D130U:
                goto block_0017D130;
            case 0x0017D144U:
                goto block_0017D144;
            case 0x0017D164U:
                goto block_0017D164;
            case 0x0017D17CU:
                goto block_0017D17C;
            case 0x0017D188U:
                goto block_0017D188;
            case 0x0017D1ACU:
                goto block_0017D1AC;
            case 0x0017D1BCU:
                goto block_0017D1BC;
            case 0x0017D218U:
                goto block_0017D218;
            case 0x0017D230U:
                goto block_0017D230;
            case 0x0017D244U:
                goto block_0017D244;
            case 0x0017D280U:
                goto block_0017D280;
            case 0x0017D28CU:
                goto block_0017D28C;
            case 0x0017D29CU:
                goto block_0017D29C;
            case 0x0017D2A4U:
                goto block_0017D2A4;
            case 0x0017D2B0U:
                goto block_0017D2B0;
            case 0x0017D2BCU:
                goto block_0017D2BC;
            case 0x0017D2C8U:
                goto block_0017D2C8;
            case 0x0017D2E8U:
                goto block_0017D2E8;
            case 0x0017D2F8U:
                goto block_0017D2F8;
            case 0x0017D33CU:
                goto block_0017D33C;
            case 0x0017D348U:
                goto block_0017D348;
            case 0x0017D354U:
                goto block_0017D354;
            case 0x0017D360U:
                goto block_0017D360;
            case 0x0017D374U:
                goto block_0017D374;
            case 0x0017D388U:
                goto block_0017D388;
            case 0x0017D394U:
                goto block_0017D394;
            case 0x0017D3C0U:
                goto block_0017D3C0;
            case 0x0017D3C8U:
                goto block_0017D3C8;
            case 0x0017D3E8U:
                goto block_0017D3E8;
            case 0x0017D408U:
                goto block_0017D408;
            case 0x0017D420U:
                goto block_0017D420;
            case 0x0017D434U:
                goto block_0017D434;
            case 0x0017D44CU:
                goto block_0017D44C;
            case 0x0017D458U:
                goto block_0017D458;
            case 0x0017D468U:
                goto block_0017D468;
            case 0x0017D474U:
                goto block_0017D474;
            case 0x0017D494U:
                goto block_0017D494;
            case 0x0017D49CU:
                goto block_0017D49C;
            case 0x0017D4BCU:
                goto block_0017D4BC;
            case 0x0017D4D4U:
                goto block_0017D4D4;
            case 0x0017D4ECU:
                goto block_0017D4EC;
            case 0x0017D4F8U:
                goto block_0017D4F8;
            case 0x0017D504U:
                goto block_0017D504;
            case 0x0017D510U:
                goto block_0017D510;
            case 0x0017D5ACU:
                goto block_0017D5AC;
            case 0x0017D604U:
                goto block_0017D604;
            case 0x0017D61CU:
                goto block_0017D61C;
            case 0x0017D644U:
                goto block_0017D644;
            case 0x0017D650U:
                goto block_0017D650;
            case 0x0017D664U:
                goto block_0017D664;
            case 0x0017D67CU:
                goto block_0017D67C;
            case 0x0017D688U:
                goto block_0017D688;
            case 0x0017D694U:
                goto block_0017D694;
            case 0x0017D6A0U:
                goto block_0017D6A0;
            case 0x0017D6B4U:
                goto block_0017D6B4;
            case 0x0017D6C4U:
                goto block_0017D6C4;
            case 0x0017D6D0U:
                goto block_0017D6D0;
            case 0x0017D6E0U:
                goto block_0017D6E0;
            case 0x0017D6ECU:
                goto block_0017D6EC;
            case 0x0017D718U:
                goto block_0017D718;
            case 0x0017D730U:
                goto block_0017D730;
            case 0x0017D744U:
                goto block_0017D744;
            case 0x0017D758U:
                goto block_0017D758;
            case 0x0017D768U:
                goto block_0017D768;
            case 0x0017D7A0U:
                goto block_0017D7A0;
            case 0x0017D7B0U:
                goto block_0017D7B0;
            case 0x0017D7BCU:
                goto block_0017D7BC;
            case 0x0017D7C8U:
                goto block_0017D7C8;
            case 0x0017D7D4U:
                goto block_0017D7D4;
            case 0x0017D834U:
                goto block_0017D834;
            case 0x0017D84CU:
                goto block_0017D84C;
            case 0x0017D878U:
                goto block_0017D878;
            case 0x0017D8B8U:
                goto block_0017D8B8;
            case 0x0017D8D8U:
                goto block_0017D8D8;
            case 0x0017D8E4U:
                goto block_0017D8E4;
            case 0x0017D8F4U:
                goto block_0017D8F4;
            case 0x0017D90CU:
                goto block_0017D90C;
            case 0x0017D914U:
                goto block_0017D914;
            case 0x0017D938U:
                goto block_0017D938;
            case 0x0017D94CU:
                goto block_0017D94C;
            case 0x0017D958U:
                goto block_0017D958;
            case 0x0017D968U:
                goto block_0017D968;
            case 0x0017D978U:
                goto block_0017D978;
            case 0x0017D9A4U:
                goto block_0017D9A4;
            case 0x0017D9B0U:
                goto block_0017D9B0;
            case 0x0017DA2CU:
                goto block_0017DA2C;
            case 0x0017DA38U:
                goto block_0017DA38;
            case 0x0017DA4CU:
                goto block_0017DA4C;
            case 0x0017DA68U:
                goto block_0017DA68;
            case 0x0017DA7CU:
                goto block_0017DA7C;
            case 0x0017DACCU:
                goto block_0017DACC;
            case 0x0017DB18U:
                goto block_0017DB18;
            case 0x0017DB50U:
                goto block_0017DB50;
            case 0x0017DB5CU:
                goto block_0017DB5C;
            case 0x0017DB80U:
                goto block_0017DB80;
            case 0x0017DB8CU:
                goto block_0017DB8C;
            case 0x0017DBC8U:
                goto block_0017DBC8;
            case 0x0017DBE4U:
                goto block_0017DBE4;
            case 0x0017DBF4U:
                goto block_0017DBF4;
            case 0x0017DC00U:
                goto block_0017DC00;
            case 0x0017DC10U:
                goto block_0017DC10;
            case 0x0017DC24U:
                goto block_0017DC24;
            case 0x0017DC30U:
                goto block_0017DC30;
            case 0x0017DC38U:
                goto block_0017DC38;
            case 0x0017DC58U:
                goto block_0017DC58;
            case 0x0017DC78U:
                goto block_0017DC78;
            case 0x0017DC98U:
                goto block_0017DC98;
            case 0x0017DCB8U:
                goto block_0017DCB8;
            case 0x0017DCD8U:
                goto block_0017DCD8;
            case 0x0017DCF8U:
                goto block_0017DCF8;
            case 0x0017DD5CU:
                goto block_0017DD5C;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_0017C010;
    }
block_0017C010:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C010U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C010U);
        }
        goto block_0017DC24;
    }
block_0017C070:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C070U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C070U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C07CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetRuntimeFlag200_0035AF04(frame, context, state, 0x0035AF04U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C07CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C07C;
    }
block_0017C07C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C07CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C07CU);
        }
        {
            const uint32_t address = 0x0017C084U + 548U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C07CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x0017C088U + 548U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C080U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r7 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017C084U, address);
            }
        }
        {
            const uint32_t address = r7 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017C088U, address);
            }
        }
        {
            const uint32_t address = r7 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C08CU, address);
            }
        }
        {
            const uint32_t address = 0x0017C098U + 536U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C090U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017C094U, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C098U, address);
            }
        }
        {
            const uint32_t address = 0x0017C0A4U + 528U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C09CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r10 = 0x00000000U;
        }
        {
            const uint32_t address = r4 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C0A4U, address);
            }
        }
        {
            const uint32_t address = 0x0017C0B0U + 520U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C0A8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r6 + operand;
        }
        {
            const uint32_t address = r4 + 196U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C0B0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            r0 = r6;
        }
        {
            const uint32_t updatedAddress = r4 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0017C0BCU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C0C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartSkippable_00367494(frame, context, state, 0x00367494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C0C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C0C4;
    }
block_0017C0C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C0C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C0C4U);
        }
        {
            r2 = 0x00000008U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C0D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C0D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C0D4;
    }
block_0017C0D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C0D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C0D4U);
        }
        {
            r0 = r6;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C0E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CreateSubCamera_00367D74(frame, context, state, 0x00367D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C0E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C0E0;
    }
block_0017C0E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C0E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C0E0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C0E0U, address);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C0F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C0F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C0F4;
    }
block_0017C0F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C0F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C0F4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C0F4U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x00000007U;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C104U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C104U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C104;
    }
block_0017C104:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C104U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C104U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017C110U + 428U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C108U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017C114U + 428U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C10CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C11CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C11CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C11C;
    }
block_0017C11C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C11CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C11CU);
        }
        {
            const uint32_t updatedAddress = 0x0017C124U + 0x178U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C11CU, address);
            }
            r9 = value;
        }
        {
            const uint32_t address = 0x0017C128U + 412U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C120U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C124U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00001400U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 788U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017C12CU, address);
            }
        }
        {
            const uint32_t address = r0 + 792U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017C130U, address);
            }
        }
        {
            const uint32_t address = r0 + 796U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017C134U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0017C140U + 0x188U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C138U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r5 + 124U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C13CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xFAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C140U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000100U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000100U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) { goto block_0017C1D0; }
        goto block_0017C14C;
    }
block_0017C14C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C14CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C14CU);
        }
        {
            r0 = 0x00000011U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C150U, address);
            }
        }
        {
            const uint32_t address = 0x0017C15CU + 368U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C154U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0017C158U, address);
            }
        }
        {
            const uint32_t address = r7 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C15CU, address);
            }
        }
        {
            const uint32_t address = 0x0017C168U + 360U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C160U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = 0x0000000EU;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0xA2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0017C16CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C174U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToLoop_00370350(frame, context, state, 0x00370350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C174U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C174;
    }
block_0017C174:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C174U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C174U);
        }
        {
            const uint32_t address = 0x0017C17CU + 344U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C174U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            r1 = 0x0000000BU;
        }
        {
            const uint32_t address = r0 + 760U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C180U, address);
            }
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C18CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034be30_0034BE30(frame, context, state, 0x0034BE30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C18CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C18C;
    }
block_0017C18C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C18CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C18CU);
        }
        {
            const uint32_t updatedAddress = 0x0017C194U + 0x144U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C18CU, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xAC4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C194U, address);
            }
        }
        {
            r0 = 0x000000A5U;
        }
        {
            const uint32_t updatedAddress = r1 + r4;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C19CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0017C1A8U + 0x134U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C1A0U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000140U;
        }
        {
            const uint32_t updatedAddress = r1 + 0xB2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C1A8U, address);
            }
        }
        {
            const uint32_t operand = 0x00007000U;
            r1 = r6 + operand;
        }
        {
            r0 = 0x000000D3U;
        }
        {
            const uint32_t updatedAddress = r1 + 0xF40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C1B4U, address);
            }
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r1;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C1C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_SetBGM_003655D0(frame, context, state, 0x003655D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C1C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C1C4;
    }
block_0017C1C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C1C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C1C4U);
        }
        {
        }
        {
        }
        goto block_0017C224;
    }
block_0017C1D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C1D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C1D0U);
        }
        {
            r7 = 0x00000001U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t updatedAddress = r5 + 0xA2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0017C1DCU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C1E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034be30_0034BE30(frame, context, state, 0x0034BE30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C1E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C1E4;
    }
block_0017C1E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C1E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C1E4U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0017C1E8U, address);
            }
        }
        {
            r3 = 0x00002000U;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0017C1F4U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0017C1FCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0017C200U, address);
            }
        }
        {
            const uint32_t address = 0x0017C20CU + 212U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C204U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017C210U + 212U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C208U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000178U;
            r3 = r7 + operand;
        }
        {
            r1 = r4;
        }
        {
            r2 = r6;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C220U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SpawnAsChild_0036AA20(frame, context, state, 0x0036AA20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C220U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C220;
    }
block_0017C220:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C220U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C220U);
        }
        {
            const uint32_t updatedAddress = r9 + 0x4CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C220U, address);
            }
        }
        goto block_0017C224;
    }
block_0017C224:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C224U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C224U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r2 = 0x00000000U;
        }
        {
            r3 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0017C230U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0017C238U, address);
            }
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0017C244U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0017C250U + 0x98U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C248U, address);
            }
            r3 = value;
        }
        {
            r1 = r4;
        }
        {
            r2 = r6;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C25CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SpawnAsChild_0036AA20(frame, context, state, 0x0036AA20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C25CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C25C;
    }
block_0017C25C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C25CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C25CU);
        }
        {
            const uint32_t updatedAddress = r9 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C25CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0017C268U + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C260U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00001400U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 772U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C268U, address);
            }
        }
        goto block_0017C26C;
    }
block_0017C26C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C26CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C26CU);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C270U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C274U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000069U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0017DC24; }
        goto block_0017C280;
    }
block_0017C280:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C280U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C280U);
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C284U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C28CU, address);
            }
        }
        goto block_0017DC24;
    }
block_0017C2F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C2F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C2F0U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017C2FCU - 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C2F4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017C300U + 988U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C2F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C308U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C308U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C308;
    }
block_0017C308:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C308U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C308U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C314U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034be30_0034BE30(frame, context, state, 0x0034BE30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C314U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C314;
    }
block_0017C314:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C314U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C314U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C314U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017C330; }
        goto block_0017C320;
    }
block_0017C320:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C320U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C320U);
        }
        {
            r2 = 0x00000005U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C330U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C330U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C330;
    }
block_0017C330:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C330U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C330U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C330U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000014U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017C358; }
        goto block_0017C33C;
    }
block_0017C33C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C33CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C33CU);
        }
        {
            const uint32_t updatedAddress = 0x0017C344U + 0x39CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C33CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017C348U + 0x39CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C340U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r7;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C344U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xF4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C348U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = r1;
            r1 = r0 - operand;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C358U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_PlaySfx_0036F59C(frame, context, state, 0x0036F59CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C358U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C358;
    }
block_0017C358:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C358U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C358U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C358U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000035U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017DC24; }
        goto block_0017C364;
    }
block_0017C364:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C364U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C364U);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C368U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017C378U - 208U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C370U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017C37CU - 184U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C374U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C378U, address);
            }
        }
        {
            const uint32_t address = r5 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C37CU, address);
            }
        }
        {
            const uint32_t address = r5 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017C380U, address);
            }
        }
        {
            const uint32_t address = 0x0017C38CU + 860U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C384U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017C388U, address);
            }
        }
        {
            const uint32_t address = r5 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C38CU, address);
            }
        }
        {
            const uint32_t address = 0x0017C398U + 852U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C390U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 140U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C394U, address);
            }
        }
        goto block_0017C398;
    }
block_0017C398:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C398U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C398U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017C3A4U - 232U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C39CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017C3A8U + 840U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C3A0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C3B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C3B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C3B0;
    }
block_0017C3B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C3B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C3B0U);
        }
        {
            r7 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017C3BCU - 276U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C3B4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0017C3BCU, address);
            }
        }
        {
            const uint32_t address = r0 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C3C0U, address);
            }
        }
        {
            const uint32_t address = r5 + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C3C4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C3CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_SinF_003727F0(frame, context, state, 0x003727F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C3CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C3CC;
    }
block_0017C3CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C3CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C3CCU);
        }
        {
            const uint32_t address = r5 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C3CCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017C3D8U + 784U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C3D0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017C3D4U, 0xEE400A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017C3D8U, address);
            }
        }
        {
            const uint32_t address = r5 + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C3DCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C3E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_CosF_Core_00372674(frame, context, state, 0x00372674U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C3E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C3E4;
    }
block_0017C3E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C3E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C3E4U);
        }
        {
            const uint32_t address = r5 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C3E4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017C3F0U + 772U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C3E8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017C3F4U, 0xEE400A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017C400U - 352U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C3F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017C3FCU, address);
            }
        }
        {
            const uint32_t address = r5 + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C400U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017C40CU + 748U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C404U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C40CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C40CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C40C;
    }
block_0017C40C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C40CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C40CU);
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017C418U + 740U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C410U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017C41CU + 740U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C414U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017C420U + 740U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C418U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C424U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C424U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C424;
    }
block_0017C424:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C424U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C424U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C424U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000012CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017DC24; }
        goto block_0017C430;
    }
block_0017C430:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C430U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C430U);
        }
        {
            r2 = 0x00000008U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C440U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C440U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C440;
    }
block_0017C440:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C440U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C440U);
        }
        {
            r0 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C444U, address);
            }
        }
        {
            r1 = 0x00000002U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C454U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034be30_0034BE30(frame, context, state, 0x0034BE30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C454U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C454;
    }
block_0017C454:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C454U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C454U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0017C454U, address);
            }
        }
        goto block_0017C458;
    }
block_0017C458:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C458U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C458U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C458U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0017C4FC; }
        goto block_0017C464;
    }
block_0017C464:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C464U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C464U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0017C520; }
        goto block_0017C46C;
    }
block_0017C46C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C46CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C46CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017C4C0; }
        goto block_0017C474;
    }
block_0017C474:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C474U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C474U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017C480U - 452U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C478U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017C484U + 644U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C47CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C48CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C48CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C48C;
    }
block_0017C48C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C48CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C48CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C48CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0017C4C0; }
        goto block_0017C4A0;
    }
block_0017C4A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C4A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C4A0U);
        }
        {
            const uint32_t address = r5 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C4A0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017C4ACU + 608U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C4A4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017C4A8U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017C4B4U + 604U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C4ACU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C4B0U, address);
            }
        }
        {
            const uint32_t address = r5 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C4B4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017C4B8U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C4BCU, address);
            }
        }
        goto block_0017C4C0;
    }
block_0017C4C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C4C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C4C0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C4C0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) {
            r1 = 0x00000023U;
        }
        if (flags.C()) {
            r1 = 0x00000004U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000005AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0017C4D4U, address);
            }
        }
        if (!(flags.Z())) { goto block_0017DC24; }
        goto block_0017C4DC;
    }
block_0017C4DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C4DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C4DCU);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C4E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034be30_0034BE30(frame, context, state, 0x0034BE30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C4E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C4E8;
    }
block_0017C4E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C4E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C4E8U);
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C4ECU, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C4F4U, address);
            }
        }
        goto block_0017DC24;
    }
block_0017C4FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C4FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C4FCU);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017C508U - 588U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C500U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017C50CU + 484U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C504U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C514U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C514U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C514;
    }
block_0017C514:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C514U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C514U);
        }
        {
        }
        {
        }
        goto block_0017C48C;
    }
block_0017C520:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C520U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C520U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017C52CU - 624U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C524U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017C530U + 484U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C528U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C538U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C538U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C538;
    }
block_0017C538:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C538U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C538U);
        }
        {
        }
        {
        }
        goto block_0017C48C;
    }
block_0017C544:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C544U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C544U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017C550U - 660U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C548U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017C554U - 648U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C54CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C55CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C55CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C55C;
    }
block_0017C55C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C55CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C55CU);
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C560U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C564U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0017C598; }
        goto block_0017C570;
    }
block_0017C570:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C570U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C570U);
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t address = 0x0017C57CU + 388U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C574U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C578U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C57CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017C598; }
        goto block_0017C588;
    }
block_0017C588:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C588U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C588U);
        }
        {
            r2 = 0x0000004BU;
        }
        {
            r1 = r4;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C598U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C598U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C598;
    }
block_0017C598:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C598U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C598U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C598U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000069U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017DC24; }
        goto block_0017C5A4;
    }
block_0017C5A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C5A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C5A4U);
        }
        {
            r1 = 0x00000003U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C5B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034be30_0034BE30(frame, context, state, 0x0034BE30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C5B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C5B0;
    }
block_0017C5B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C5B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C5B0U);
        }
        {
            r0 = 0x00000006U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C5B4U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C5BCU, address);
            }
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C5C4U, address);
            }
        }
        goto block_0017DC24;
    }
block_0017C5CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C5CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C5CCU);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017C5D8U - 796U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C5D0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017C5DCU + 316U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C5D4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C5E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C5E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C5E4;
    }
block_0017C5E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C5E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C5E4U);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C5E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C5ECU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017DC24; }
        goto block_0017C5F8;
    }
block_0017C5F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C5F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C5F8U);
        }
        {
            r0 = 0x00000007U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C5FCU, address);
            }
        }
        {
            r7 = 0x00000000U;
        }
        {
            r1 = 0x00000004U;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0017C60CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C614U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034be30_0034BE30(frame, context, state, 0x0034BE30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C614U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C614;
    }
block_0017C614:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C614U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C614U);
        }
        {
            const uint32_t address = 0x0017C61CU + 256U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C614U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017C624U - 892U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C61CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = r0 + 780U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C620U, address);
            }
        }
        {
            const uint32_t address = r0 + 772U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017C624U, address);
            }
        }
        {
            const uint32_t address = 0x0017C630U + 240U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C628U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 792U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017C62CU, address);
            }
        }
        {
            const uint32_t address = r0 + 768U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C630U, address);
            }
        }
        {
            const uint32_t address = 0x0017C63CU + 180U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C634U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0017C640U + 0xE8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C638U, address);
            }
            r3 = value;
        }
        {
            const uint32_t address = r0 + 776U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C63CU, address);
            }
        }
        {
            const uint32_t address = r0 + 800U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017C640U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0017C64CU + 0xD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C644U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017C650U + 0xDCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C648U, address);
            }
            r2 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + r4;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0017C650U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0017C654U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0017C664U + 0xCCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C65CU, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C668U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C668U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C668;
    }
block_0017C668:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C668U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C668U);
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t address = r0 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017C66CU, address);
            }
        }
        goto block_0017C670;
    }
block_0017C670:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C670U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C670U);
        }
        {
            const uint32_t address = 0x0017C678U + 188U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C670U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017C680U - 964U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C678U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C68CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C68CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C68C;
    }
block_0017C68C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C68CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C68CU);
        }
        {
            const uint32_t address = 0x0017C694U + 164U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C68CU, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x0017C698U + 104U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C690U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x0017C69CU + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C694U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            r0 = 0x00000006U;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C6A8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000304U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C6B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C6B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C6B8;
    }
block_0017C6B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C6B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C6B8U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017C6C8U + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C6C0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017C6CCU + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C6C4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000030CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C6D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C6D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C6D0;
    }
block_0017C6D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C6D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C6D0U);
        }
        {
        }
        {
        }
        goto block_0017C744;
    }
block_0017C744:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C744U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C744U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x0017C750U + 756U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C748U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017C754U + 756U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C74CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000B00U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C758U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C758U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C758;
    }
block_0017C758:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C758U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C758U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017C76CU + 736U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C764U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000308U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C770U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C770U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C770;
    }
block_0017C770:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C770U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C770U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C770U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000024U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_0017C814; }
        goto block_0017C77C;
    }
block_0017C77C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C77CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C77CU);
        }
        {
            r0 = 0x00000041U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C780U, address);
            }
        }
        {
        }
        if (!(flags.Z())) { goto block_0017C7BC; }
        goto block_0017C78C;
    }
block_0017C78C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C78CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C78CU);
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t address = r0 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017C790U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C794U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000024U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017C7BC; }
        goto block_0017C7A0;
    }
block_0017C7A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C7A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C7A0U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = r0 + 780U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C7A4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 796U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C7A8U, address);
            }
        }
        {
            const uint32_t address = r0 + 772U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C7ACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 792U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C7B0U, address);
            }
        }
        {
            const uint32_t address = r0 + 800U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0017C7B4U, address);
            }
        }
        goto block_0017C7C8;
    }
block_0017C7BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C7BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C7BCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C7BCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000024U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_0017C814; }
        goto block_0017C7C8;
    }
block_0017C7C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C7C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C7C8U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x0017C7D4U + 636U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C7CCU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x0017C7D8U + 636U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C7D0U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t operand = 0x00000B20U;
            r0 = r4 + operand;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C7E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C7E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C7E4;
    }
block_0017C7E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C7E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C7E4U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000318U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C7FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C7FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C7FC;
    }
block_0017C7FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C7FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C7FCU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017C810U + 584U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C808U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x0000031CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C814U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C814U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C814;
    }
block_0017C814:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C814U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C814U);
        }
        {
            r1 = 0x00000004U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C820U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034be30_0034BE30(frame, context, state, 0x0034BE30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C820U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C820;
    }
block_0017C820:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C820U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C820U);
        }
        {
            const uint32_t address = r5 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C820U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017C82CU + 560U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C824U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017C828U, 0xEE700A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017C82CU, address);
            }
        }
        {
            const uint32_t address = r5 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C830U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017C834U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017C840U + 544U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C838U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C83CU, address);
            }
        }
        {
            const uint32_t address = r5 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C840U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017C844U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017C850U + 532U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C848U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C84CU, address);
            }
        }
        {
            const uint32_t address = r5 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C850U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017C854U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C858U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C85CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000005AU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0017DC24; }
        goto block_0017C868;
    }
block_0017C868:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C868U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C868U);
        }
        {
            r0 = 0x00000008U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C86CU, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C874U, address);
            }
        }
        goto block_0017DC24;
    }
block_0017C87C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C87CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C87CU);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017C888U + 480U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C880U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017C88CU + 480U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C884U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C894U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C894U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C894;
    }
block_0017C894:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C894U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C894U);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C898U, address);
            }
        }
        {
            r1 = 0x00000005U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C8A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034be30_0034BE30(frame, context, state, 0x0034BE30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C8A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C8A8;
    }
block_0017C8A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C8A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C8A8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C8A8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017DC24; }
        goto block_0017C8B4;
    }
block_0017C8B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C8B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C8B4U);
        }
        {
            r0 = 0x00000009U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C8B8U, address);
            }
        }
        {
            r7 = 0x00000000U;
        }
        {
            r2 = 0x00000008U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r6;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0017C8CCU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C8D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C8D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C8D4;
    }
block_0017C8D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C8D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C8D4U);
        }
        {
            const uint32_t updatedAddress = 0x0017C8DCU - 0x640U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C8D4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0017C8E0U - 452U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C8D8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017C8E4U + 368U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C8DCU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t updatedAddress = 0x0017C8E8U - 0x1C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C8E0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C8E4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017C8F0U - 0x1C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C8E8U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017C8F4U - 0x1C8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C8ECU, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0017C8F4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = r0 + 780U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C8FCU, address);
            }
        }
        {
            const uint32_t address = r0 + 772U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017C900U, address);
            }
        }
        {
            const uint32_t address = 0x0017C90CU - 492U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C904U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 792U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017C908U, address);
            }
        }
        {
            const uint32_t address = r0 + 768U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C90CU, address);
            }
        }
        {
            const uint32_t address = 0x0017C918U - 552U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C910U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 776U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017C914U, address);
            }
        }
        {
            const uint32_t address = r0 + 800U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017C918U, address);
            }
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r1 + r4;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C920U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0017C924U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0017C934U - 0x204U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C92CU, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C93CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C93CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C93C;
    }
block_0017C93C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C93CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C93CU);
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t address = r0 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017C940U, address);
            }
        }
        goto block_0017C944;
    }
block_0017C944:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C944U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C944U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017C950U + 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C948U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017C954U - 588U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C94CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C95CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C95CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C95C;
    }
block_0017C95C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C95CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C95CU);
        }
        {
            r0 = 0x00000007U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C960U, address);
            }
        }
        {
            r1 = 0x00000006U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C970U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034be30_0034BE30(frame, context, state, 0x0034BE30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C970U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C970;
    }
block_0017C970:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C970U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C970U);
        }
        {
            const uint32_t address = 0x0017C978U - 576U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C970U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x0017C97CU - 636U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C974U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x0017C980U - 608U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C978U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000304U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C994U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C994U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C994;
    }
block_0017C994:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C994U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C994U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017C9A4U - 616U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C99CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017C9A8U - 616U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C9A0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000030CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C9ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C9ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C9AC;
    }
block_0017C9AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C9ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C9ACU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x0017C9B8U + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C9B0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017C9BCU + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C9B4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000B00U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C9C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C9C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C9C0;
    }
block_0017C9C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C9C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C9C0U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017C9D4U + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C9CCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000308U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017C9D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017C9D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017C9D8;
    }
block_0017C9D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C9D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C9D8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C9D8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0017C9F8; }
        goto block_0017C9E4;
    }
block_0017C9E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C9E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C9E4U);
        }
        {
            const uint32_t updatedAddress = 0x0017C9ECU - 0x750U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C9E4U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x4CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C9ECU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017C9F4U, address);
            }
        }
        goto block_0017C9F8;
    }
block_0017C9F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017C9F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017C9F8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017C9F8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000024U, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C())) { goto block_0017DC24; }
        goto block_0017CA04;
    }
block_0017CA04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CA04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CA04U);
        }
        {
            r0 = 0x0000004BU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CA08U, address);
            }
        }
        {
        }
        if (!(flags.Z())) { goto block_0017CA70; }
        goto block_0017CA14;
    }
block_0017CA14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CA14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CA14U);
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t address = r0 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017CA18U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CA1CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000024U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017CA70; }
        goto block_0017CA28;
    }
block_0017CA28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CA28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CA28U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = r0 + 780U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CA2CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 796U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017CA30U, address);
            }
        }
        {
            const uint32_t address = r0 + 772U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CA34U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 792U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017CA38U, address);
            }
        }
        {
            const uint32_t address = r0 + 800U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0017CA3CU, address);
            }
        }
        goto block_0017CA7C;
    }
block_0017CA70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CA70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CA70U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CA70U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000024U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_0017DC24; }
        goto block_0017CA7C;
    }
block_0017CA7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CA7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CA7CU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x0017CA88U - 56U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CA80U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x0017CA8CU - 56U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CA84U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t operand = 0x00000B20U;
            r0 = r4 + operand;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CA98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CA98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CA98;
    }
block_0017CA98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CA98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CA98U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017CAACU - 888U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CAA4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000318U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CAB0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CAB0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CAB0;
    }
block_0017CAB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CAB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CAB0U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017CAC4U - 108U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CABCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x0000031CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CAC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CAC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CAC8;
    }
block_0017CAC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CAC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CAC8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CAC8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0017DC24; }
        goto block_0017CAD4;
    }
block_0017CAD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CAD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CAD4U);
        }
        {
            r0 = 0x0000000AU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CAD8U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CAE0U, address);
            }
        }
        goto block_0017DC24;
    }
block_0017CAE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CAE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CAE8U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017CAF4U + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CAECU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017CAF8U + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CAF0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CB00U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CB00U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CB00;
    }
block_0017CB00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CB00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CB00U);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CB04U, address);
            }
        }
        {
            r1 = 0x00000007U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CB14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034be30_0034BE30(frame, context, state, 0x0034BE30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CB14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CB14;
    }
block_0017CB14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CB14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CB14U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CB14U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000028U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0017DC24; }
        goto block_0017CB20;
    }
block_0017CB20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CB20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CB20U);
        }
        {
            r0 = 0x0000000BU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CB24U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CB2CU, address);
            }
        }
        {
            const uint32_t address = 0x0017CB38U - 228U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CB30U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = r0 + 772U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017CB38U, address);
            }
        }
        {
            const uint32_t address = r0 + 792U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017CB3CU, address);
            }
        }
        goto block_0017DC24;
    }
block_0017CB44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CB44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CB44U);
        }
        {
            const uint32_t address = 0x0017CB4CU - 228U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CB44U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r6;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CB5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CB5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CB5C;
    }
block_0017CB5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CB5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CB5CU);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CB60U, address);
            }
        }
        {
            r1 = 0x00000008U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CB70U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034be30_0034BE30(frame, context, state, 0x0034BE30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CB70U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CB70;
    }
block_0017CB70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CB70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CB70U);
        }
        {
            const uint32_t address = 0x0017CB78U + 636U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CB70U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = r7 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0017CB74U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CB78U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000014U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017CBAC; }
        goto block_0017CB84;
    }
block_0017CB84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CB84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CB84U);
        }
        {
            r2 = 0x00000017U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CB94U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CB94U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CB94;
    }
block_0017CB94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CB94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CB94U);
        }
        {
            r0 = 0x0000000BU;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CBA0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Interface_ChangeAlpha_0034BE04(frame, context, state, 0x0034BE04U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CBA0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CBA0;
    }
block_0017CBA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CBA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CBA0U);
        }
        {
            const uint32_t updatedAddress = 0x0017CBA8U + 0x250U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CBA0U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r1 + r6;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CBA8U, address);
            }
        }
        goto block_0017CBAC;
    }
block_0017CBAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CBACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CBACU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CBACU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000019U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0017CBD0; }
        goto block_0017CBB8;
    }
block_0017CBB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CBB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CBB8U);
        }
        {
            const uint32_t updatedAddress = 0x0017CBC0U - 0x8E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CBB8U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000140U;
        }
        {
            const uint32_t updatedAddress = r1 + 0xB2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CBC0U, address);
            }
        }
        {
            const uint32_t operand = 0x00007000U;
            r1 = r6 + operand;
        }
        {
            r0 = 0x000000D3U;
        }
        {
            const uint32_t updatedAddress = r1 + 0xF40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CBCCU, address);
            }
        }
        goto block_0017CBD0;
    }
block_0017CBD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CBD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CBD0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CBD0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0017CBDCU + 544U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CBD4U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000019U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x0017CBE4U + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CBDCU, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            r0 = r7;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CBE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_PlaySfx_0036F59C(frame, context, state, 0x0036F59CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CBE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CBE8;
    }
block_0017CBE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CBE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CBE8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CBE8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000019U;
            r1 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x0000003CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0017CDB4; }
        goto block_0017CBF8;
    }
block_0017CBF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CBF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CBF8U);
        }
        {
            const uint32_t operand = 0x00000019U;
            r0 = r0 - operand;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x0017CC08U + 512U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CC00U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000028U;
            r7 = r7 + operand;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r9 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017CC0CU, 0xEEF80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017CC18U + 492U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CC10U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017CC14U, 0xEE208A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[16], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = r0;
        }
        {
            const uint32_t firstAddress = r7;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0017CC1CU,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0017CC1CU,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0017CC1CU,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0017CC20U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0017CC20U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0017CC20U,
                                           firstAddress + 8U);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017CC24U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = 0x000000FFU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017CC2CU, 0xEE700A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017CC30U, 0xEE609A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017CC3CU - 488U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CC34U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017CC44U, address);
            }
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0017CC48U, address);
            }
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0017CC4CU, address);
            }
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017CC50U, address);
            }
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0017CC54U, address);
            }
        }
        {
            const uint32_t address = r13 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0017CC58U, address);
            }
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0017CC5CU, address);
            }
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017CC60U, address);
            }
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017CC64U, address);
            }
        }
        {
            const uint32_t address = 0x0017CC70U + 412U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CC68U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017CC74U + 412U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CC6CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x14U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CC70U, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017CC74U, 0xEE280A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = r13 + 0x15U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CC78U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CC7CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CC80U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x11U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CC84U, address);
            }
        }
        {
            r0 = 0x00000064U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x12U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CC8CU, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017CC90U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017CC9CU + 376U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CC94U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017CC98U, 0xEE20AA20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[20], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CCA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_sins_0037103C(frame, context, state, 0x0037103CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CCA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CCA4;
    }
block_0017CCA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CCA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CCA4U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017CCA4U, 0xEE60AA28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[21], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CCB0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_coss_00372298(frame, context, state, 0x00372298U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CCB0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CCB0;
    }
block_0017CCB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CCB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CCB0U);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017CCB0U, 0xEE20BA28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[22], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CCBCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_sins_0037103C(frame, context, state, 0x0037103CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CCBCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CCBC;
    }
block_0017CCBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CCBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CCBCU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017CCBCU, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017CCC0U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CCCCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_coss_00372298(frame, context, state, 0x00372298U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CCCCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CCCC;
    }
block_0017CCCC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CCCCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CCCCU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017CCCCU, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            r3 = 0x00000010U;
        }
        {
            r2 = 0x000003E8U;
        }
        {
            const uint32_t operand = 0x00000010U;
            r1 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000014U;
            r0 = r13 + operand;
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017CCE0U, address);
            }
        }
        {
            const uint32_t address = r13 + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CCE4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017CCE8U, 0xEE300A2AU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[21], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017CCECU, address);
            }
        }
        {
            const uint32_t address = r13 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CCF0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017CCF4U, 0xEE080A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017CCF8U, address);
            }
        }
        {
            const uint32_t address = r13 + 68U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CCFCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017CD00U, 0xEE300A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017CD04U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0017CD08U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0017CD08U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0017CD08U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0017CD08U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000030U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000024U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r1 = r13 + operand;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CD20U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EffectSsKiraKira_SpawnDispersed_0036EA98(frame, context, state, 0x0036EA98U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CD20U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CD20;
    }
block_0017CD20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CD20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CD20U);
        }
        {
            const uint32_t firstAddress = r7;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0017CD20U,
                                           firstAddress + 0U);
            }
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0017CD20U,
                                           firstAddress + 4U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0017CD20U,
                                           firstAddress + 8U);
            }
            r0 = value0;
            r1 = value1;
            r2 = value2;
        }
        {
            const uint32_t firstAddress = r9;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0017CD24U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0017CD24U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0017CD24U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000018U;
            r1 = r13 + operand;
        }
        {
            const uint32_t address = r13 + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CD2CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CD30U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000030U;
            r0 = r13 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017CD38U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 60U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017CD3CU, address);
            }
        }
        {
            const uint32_t address = r13 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CD40U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017CD44U, 0xEE090A89U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 64U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017CD48U, address);
            }
        }
        {
            const uint32_t address = r13 + 68U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CD4CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 32U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CD50U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017CD54U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017CD58U, address);
            }
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0017CD5CU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0017CD5CU,
                                           firstAddress + 4U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0017CD5CU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r7 = value7;
        }
        {
            const uint32_t operand = 0x00000010U;
            r1 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0017CD64U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0017CD64U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0017CD64U,
                                           firstAddress + 8U);
            }
        }
        {
            r3 = 0x00000010U;
        }
        {
            const uint32_t updatedAddress = 0x0017CD74U - 0xAD8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CD6CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r13 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CD70U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r2 = 0x000003E8U;
        }
        {
            const uint32_t address = r0 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CD78U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017CD7CU, 0xEE600A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017CD80U, address);
            }
        }
        {
            const uint32_t address = r13 + 56U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CD84U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017CD88U, 0xEE200A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017CD8CU, address);
            }
        }
        {
            const uint32_t address = r0 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CD90U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000014U;
            r0 = r13 + operand;
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017CD98U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0017CD9CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0017CD9CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0017CD9CU,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0017CD9CU,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000030U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000024U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r1 = r13 + operand;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CDB4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EffectSsKiraKira_SpawnDispersed_0036EA98(frame, context, state, 0x0036EA98U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CDB4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CDB4;
    }
block_0017CDB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CDB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CDB4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CDB4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000064U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            r0 = 0x00000001U;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CDC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Interface_ChangeAlpha_0034BE04(frame, context, state, 0x0034BE04U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CDC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CDC4;
    }
block_0017CDC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CDC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CDC4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CDC4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000078U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0017DC24; }
        goto block_0017CDD0;
    }
block_0017CDD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CDD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CDD0U);
        }
        {
            const uint32_t updatedAddress = 0x0017CDD8U + 0x20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CDD0U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x0000000CU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CDD8U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CDE0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + r6;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CDE4U, address);
            }
        }
        goto block_0017DC24;
    }
block_0017CE18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CE18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CE18U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017CE24U - 56U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CE1CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017CE28U + 928U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CE20U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CE30U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CE30U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CE30;
    }
block_0017CE30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CE30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CE30U);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CE34U, address);
            }
        }
        {
            r1 = 0x00000009U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CE44U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034be30_0034BE30(frame, context, state, 0x0034BE30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CE44U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CE44;
    }
block_0017CE44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CE44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CE44U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CE44U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017CE88; }
        goto block_0017CE50;
    }
block_0017CE50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CE50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CE50U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CE5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_SetBGM_003655D0(frame, context, state, 0x003655D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CE5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CE5C;
    }
block_0017CE5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CE5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CE5CU);
        }
        {
            r1 = 0x00000009U;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CE68U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CE68U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CE68;
    }
block_0017CE68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CE68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CE68U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            r1 = 0x00000009U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017CE74U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 760U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017CE78U, address);
            }
        }
        {
            const uint32_t address = 0x0017CE84U + 840U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CE7CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CE88U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CE88U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CE88;
    }
block_0017CE88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CE88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CE88U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CE88U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0017CECC; }
        goto block_0017CE94;
    }
block_0017CE94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CE94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CE94U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r7 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017CEA0U + 816U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CE98U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r7 + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CE9CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CEA8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CEA8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CEA8;
    }
block_0017CEA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CEA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CEA8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0017CECC; }
        goto block_0017CEB4;
    }
block_0017CEB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CEB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CEB4U);
        }
        {
            r1 = 0x0000000BU;
        }
        {
            const uint32_t address = 0x0017CEC0U + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CEB8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CEC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToLoop_00370350(frame, context, state, 0x00370350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CEC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CEC4;
    }
block_0017CEC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CEC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CEC4U);
        }
        {
            const uint32_t address = 0x0017CECCU + 780U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CEC4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r7 + 760U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017CEC8U, address);
            }
        }
        goto block_0017CECC;
    }
block_0017CECC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CECCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CECCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CECCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000050U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017CEE8; }
        goto block_0017CED8;
    }
block_0017CED8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CED8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CED8U);
        }
        {
            const uint32_t updatedAddress = 0x0017CEE0U + 0x2FCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CED8U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CEE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CEE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CEE8;
    }
block_0017CEE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CEE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CEE8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CEE8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000B4U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0017DC24; }
        goto block_0017CEF4;
    }
block_0017CEF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CEF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CEF4U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = 0x000008A0U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CF00U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_GetState_003769D8(frame, context, state, 0x003769D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CF00U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CF00;
    }
block_0017CF00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CF00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CF00U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (!(flags.Z())) { goto block_0017DC24; }
        goto block_0017CF0C;
    }
block_0017CF0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CF0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CF0CU);
        }
        {
            r0 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CF10U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CF18U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CF1CU, address);
            }
        }
        goto block_0017DC24;
    }
block_0017CF24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CF24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CF24U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017CF30U + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CF28U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017CF34U + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CF2CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CF3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CF3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CF3C;
    }
block_0017CF3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CF3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CF3CU);
        }
        {
            r7 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017CF48U + 652U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CF40U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0017CF48U, address);
            }
        }
        {
            const uint32_t address = r0 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017CF4CU, address);
            }
        }
        {
            r1 = 0x0000000AU;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CF5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034be30_0034BE30(frame, context, state, 0x0034BE30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CF5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CF5C;
    }
block_0017CF5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CF5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CF5CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CF5CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017CF78; }
        goto block_0017CF68;
    }
block_0017CF68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CF68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CF68U);
        }
        {
            const uint32_t updatedAddress = 0x0017CF70U + 0x278U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CF68U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CF78U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CF78U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CF78;
    }
block_0017CF78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CF78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CF78U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CF78U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000064U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0017DC24; }
        goto block_0017CF84;
    }
block_0017CF84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CF84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CF84U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = 0x000008A0U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CF90U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_GetState_003769D8(frame, context, state, 0x003769D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CF90U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CF90;
    }
block_0017CF90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CF90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CF90U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0017DC24; }
        goto block_0017CF9C;
    }
block_0017CF9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CF9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CF9CU);
        }
        {
            r0 = 0x00000010U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CFA0U, address);
            }
        }
        {
            r1 = 0x0000000BU;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r7))) {
                return Oot3dAotMemoryFault(context, 0x0017CFACU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CFB4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034be30_0034BE30(frame, context, state, 0x0034BE30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CFB4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CFB4;
    }
block_0017CFB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CFB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CFB4U);
        }
        {
            const uint32_t updatedAddress = 0x0017CFBCU - 0xD20U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CFB4U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xAC4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CFBCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x4CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CFC0U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CFC8U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0017CFD4U - 0xCFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CFCCU, address);
            }
            r1 = value;
        }
        {
            r0 = 0x000000A5U;
        }
        {
            const uint32_t updatedAddress = r1 + r4;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CFD4U, address);
            }
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017CFDCU, address);
            }
        }
        goto block_0017DC24;
    }
block_0017CFE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CFE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CFE4U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017CFF0U + 496U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CFE8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017CFF4U + 504U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017CFECU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017CFFCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017CFFCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017CFFC;
    }
block_0017CFFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017CFFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017CFFCU);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D000U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D004U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000014U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0017D048; }
        goto block_0017D010;
    }
block_0017D010:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D010U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D010U);
        }
        {
        }
        if (!(flags.Z())) { goto block_0017DC24; }
        goto block_0017D018;
    }
block_0017D018:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D018U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D018U);
        }
        {
            r1 = 0x00000008U;
        }
        {
            const uint32_t address = 0x0017D024U + 424U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D01CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D028U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D028U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D028;
    }
block_0017D028:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D028U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D028U);
        }
        {
            r1 = 0x00000008U;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D034U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D034U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D034;
    }
block_0017D034:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D034U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D034U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017D03CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 760U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D040U, address);
            }
        }
        goto block_0017D090;
    }
block_0017D048:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D048U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D048U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r7 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017D054U + 380U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D04CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r7 + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D050U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D05CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D05CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D05C;
    }
block_0017D05C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D05CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D05CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0017D090; }
        goto block_0017D068;
    }
block_0017D068:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D068U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D068U);
        }
        {
            const uint32_t updatedAddress = 0x0017D070U + 0x180U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D068U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D078U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D078U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D078;
    }
block_0017D078:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D078U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D078U);
        }
        {
            const uint32_t address = 0x0017D080U + 332U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D078U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = 0x0000000EU;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D088U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToLoop_00370350(frame, context, state, 0x00370350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D088U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D088;
    }
block_0017D088:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D088U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D088U);
        }
        {
            const uint32_t address = 0x0017D090U + 328U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D088U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r7 + 760U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D08CU, address);
            }
        }
        goto block_0017D090;
    }
block_0017D090:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D090U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D090U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D090U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000064U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0017DC24; }
        goto block_0017D09C;
    }
block_0017D09C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D09CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D09CU);
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = 0x000008A0U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D0A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_GetState_003769D8(frame, context, state, 0x003769D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D0A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D0A8;
    }
block_0017D0A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D0A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D0A8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (!(flags.Z())) { goto block_0017DC24; }
        goto block_0017D0B4;
    }
block_0017D0B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D0B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D0B4U);
        }
        {
            r0 = 0x00000011U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D0B8U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D0C0U, address);
            }
        }
        goto block_0017DC24;
    }
block_0017D0C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D0C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D0C8U);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D0CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D0D0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000014U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017D108; }
        goto block_0017D0DC;
    }
block_0017D0DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D0DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D0DCU);
        }
        {
            r1 = 0x00000006U;
        }
        {
            const uint32_t address = 0x0017D0E8U + 228U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D0E0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D0ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D0ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D0EC;
    }
block_0017D0EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D0ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D0ECU);
        }
        {
            r1 = 0x00000006U;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D0F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D0F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D0F8;
    }
block_0017D0F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D0F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D0F8U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017D100U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 760U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D104U, address);
            }
        }
        goto block_0017D108;
    }
block_0017D108:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D108U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D108U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D108U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0017DC24; }
        goto block_0017D114;
    }
block_0017D114:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D114U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D114U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000003EU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0017D130; }
        goto block_0017D11C;
    }
block_0017D11C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D11CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D11CU);
        }
        {
            const uint32_t updatedAddress = 0x0017D124U - 0xE88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D11CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0017D128U + 204U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D120U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D124U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00001400U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 788U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D12CU, address);
            }
        }
        goto block_0017D130;
    }
block_0017D130:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D130U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D130U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D130U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000039U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x0017D140U + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D138U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            r0 = r4;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D144U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D144U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D144;
    }
block_0017D144:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D144U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D144U);
        }
        {
            const uint32_t address = r5 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D144U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017D150U + 172U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D148U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000007CU;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017D154U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017D160U + 160U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D158U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017D164U + 160U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D15CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D164U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D164U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D164;
    }
block_0017D164:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D164U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D164U);
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017D170U + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D168U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017D174U + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D16CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017D178U + 148U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D170U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000074U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D17CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D17CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D17C;
    }
block_0017D17C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D17CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D17CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D17CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000046U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017DC24; }
        goto block_0017D188;
    }
block_0017D188:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D188U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D188U);
        }
        {
            r0 = 0x00000012U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D18CU, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017D19CU + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D194U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D198U, address);
            }
        }
        {
            const uint32_t address = r5 + 124U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D19CU, address);
            }
        }
        {
            r1 = 0x0000000CU;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D1ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034be30_0034BE30(frame, context, state, 0x0034BE30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D1ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D1AC;
    }
block_0017D1AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D1ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D1ACU);
        }
        {
            const uint32_t updatedAddress = 0x0017D1B4U + 0x60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D1ACU, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D1BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D1BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D1BC;
    }
block_0017D1BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D1BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D1BCU);
        }
        {
        }
        {
        }
        goto block_0017DC24;
    }
block_0017D218:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D218U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D218U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017D224U - 68U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D21CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017D228U + 912U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D220U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D230U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D230U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D230;
    }
block_0017D230:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D230U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D230U);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D234U, address);
            }
        }
        {
            r1 = 0x0000000CU;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D244U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034be30_0034BE30(frame, context, state, 0x0034BE30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D244U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D244;
    }
block_0017D244:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D244U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D244U);
        }
        {
            const uint32_t address = r5 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D244U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017D250U + 876U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D248U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017D254U + 876U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D24CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r7 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017D254U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017D260U + 868U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D258U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = r5 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D260U, address);
            }
        }
        {
            const uint32_t address = r5 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D264U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017D268U, 0xEE300A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D26CU, address);
            }
        }
        {
            const uint32_t address = r7 + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D270U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017D274U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017D280U - 176U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D278U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D280U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D280U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D280;
    }
block_0017D280:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D280U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D280U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0017D2A4; }
        goto block_0017D28C;
    }
block_0017D28C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D28CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D28CU);
        }
        {
            r1 = 0x00000007U;
        }
        {
            const uint32_t address = 0x0017D298U - 204U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D290U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D29CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToLoop_00370350(frame, context, state, 0x00370350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D29CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D29C;
    }
block_0017D29C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D29CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D29CU);
        }
        {
            const uint32_t address = 0x0017D2A4U - 204U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D29CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r7 + 760U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D2A0U, address);
            }
        }
        goto block_0017D2A4;
    }
block_0017D2A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D2A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D2A4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D2A4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000032U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0017DC24; }
        goto block_0017D2B0;
    }
block_0017D2B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D2B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D2B0U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = 0x000008A0U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D2BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_GetState_003769D8(frame, context, state, 0x003769D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D2BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D2BC;
    }
block_0017D2BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D2BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D2BCU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0017DC24; }
        goto block_0017D2C8;
    }
block_0017D2C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D2C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D2C8U);
        }
        {
            r0 = 0x00000013U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D2CCU, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            r2 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D2D8U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0017D2E4U + 0x2E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D2DCU, address);
            }
            r1 = value;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D2E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D2E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D2E8;
    }
block_0017D2E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D2E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D2E8U);
        }
        {
            const uint32_t address = 0x0017D2F0U - 292U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D2E8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = 0x0000000CU;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D2F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D2F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D2F8;
    }
block_0017D2F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D2F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D2F8U);
        }
        {
            const uint32_t address = 0x0017D300U - 300U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D2F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r7 + 780U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017D2FCU, address);
            }
        }
        {
            const uint32_t address = r7 + 772U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D300U, address);
            }
        }
        {
            const uint32_t address = 0x0017D30CU + 704U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D304U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r7 + 792U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D308U, address);
            }
        }
        {
            const uint32_t address = r7 + 768U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017D30CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0017D318U - 0xBF4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D310U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = 0x0017D31CU - 312U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D314U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t address = r7 + 776U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017D31CU, address);
            }
        }
        {
            const uint32_t address = r7 + 800U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D320U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + r4;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D324U, address);
            }
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        {
            r1 = 0x00000004U;
        }
        {
            const uint32_t address = r0 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D330U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D334U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D33CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_ShowMesh_0037266C(frame, context, state, 0x0037266CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D33CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D33C;
    }
block_0017D33C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D33CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D33CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D33CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000006U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D348U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_ShowMesh_0037266C(frame, context, state, 0x0037266CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D348U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D348;
    }
block_0017D348:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D348U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D348U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D348U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000005U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D354U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_HideMesh_0036932C(frame, context, state, 0x0036932CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D354U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D354;
    }
block_0017D354:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D354U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D354U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D354U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000007U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D360U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ModelHandle_HideMesh_0036932C(frame, context, state, 0x0036932CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D360U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D360;
    }
block_0017D360:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D360U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D360U);
        }
        {
            r0 = 0x00000008U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D364U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D368U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000050U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_0017D388; }
        goto block_0017D374;
    }
block_0017D374:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D374U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D374U);
        }
        {
            r0 = 0x00000009U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D378U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t address = 0x0017D384U - 436U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D37CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (flags.Z()) {
            const uint32_t operand = 0x00003000U;
            r0 = r6 + operand;
        }
        if (flags.Z()) {
            const uint32_t address = r0 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D384U, address);
            }
        }
        goto block_0017D388;
    }
block_0017D388:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D388U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D388U);
        }
        {
            r1 = 0x0000000CU;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D394U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034be30_0034BE30(frame, context, state, 0x0034BE30U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D394U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D394;
    }
block_0017D394:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D394U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D394U);
        }
        {
            const uint32_t address = r5 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D394U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017D3A0U + 540U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D398U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017D39CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017D3A8U + 536U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D3A0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D3A4U, address);
            }
        }
        {
            const uint32_t address = r5 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D3A8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017D3ACU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D3B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D3B4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_0017D44C; }
        goto block_0017D3C0;
    }
block_0017D3C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D3C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D3C0U);
        }
        {
        }
        if (!(flags.Z())) { goto block_0017D3E8; }
        goto block_0017D3C8;
    }
block_0017D3C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D3C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D3C8U);
        }
        {
            const uint32_t updatedAddress = 0x0017D3D0U - 0xCA8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D3C8U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017D3D4U - 0xCA8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D3CCU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017D3D8U - 0xCA8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D3D0U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0017D3D8U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D3E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D3E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D3E8;
    }
block_0017D3E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D3E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D3E8U);
        }
        {
            const uint32_t address = 0x0017D3F0U + 480U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D3E8U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x0017D3F4U - 548U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D3ECU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = 0x0017D404U + 456U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D3FCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000304U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D408U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D408U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D408;
    }
block_0017D408:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D408U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D408U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017D418U + 444U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D410U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017D41CU + 444U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D414U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000030CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D420U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D420U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D420;
    }
block_0017D420:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D420U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D420U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = 0x0017D42CU + 432U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D424U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017D430U + 432U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D428U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000B00U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D434U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D434U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D434;
    }
block_0017D434:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D434U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D434U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017D448U + 412U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D440U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000308U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D44CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D44CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D44C;
    }
block_0017D44C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D44CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D44CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D44CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017D468; }
        goto block_0017D458;
    }
block_0017D458:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D458U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D458U);
        }
        {
            r1 = 0x0000000DU;
        }
        {
            const uint32_t address = 0x0017D464U - 664U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D45CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D468U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToLoop_00370350(frame, context, state, 0x00370350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D468U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D468;
    }
block_0017D468:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D468U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D468U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D468U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000051U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017D494; }
        goto block_0017D474;
    }
block_0017D474:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D474U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D474U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017D480U + 332U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D478U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 780U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D47CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 796U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017D480U, address);
            }
        }
        {
            const uint32_t address = r0 + 772U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D484U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 792U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017D488U, address);
            }
        }
        {
            const uint32_t address = r0 + 800U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D48CU, address);
            }
        }
        goto block_0017D49C;
    }
block_0017D494:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D494U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D494U);
        }
        {
        }
        if (!(flags.C())) { goto block_0017DC24; }
        goto block_0017D49C;
    }
block_0017D49C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D49CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D49CU);
        }
        {
            const uint32_t operand = 0x00000B20U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017D4A8U + 320U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D4A0U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x0017D4ACU - 732U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D4A4U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x0017D4B0U - 732U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D4A8U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D4BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D4BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D4BC;
    }
block_0017D4BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D4BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D4BCU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017D4D0U + 284U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D4C8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000318U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D4D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D4D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D4D4;
    }
block_0017D4D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D4D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D4D4U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017D4E8U + 264U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D4E0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x0000031CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D4ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D4ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D4EC;
    }
block_0017D4EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D4ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D4ECU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D4ECU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000078U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0017DC24; }
        goto block_0017D4F8;
    }
block_0017D4F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D4F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D4F8U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = 0x000008A0U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D504U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_GetState_003769D8(frame, context, state, 0x003769D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D504U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D504;
    }
block_0017D504:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D504U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D504U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0017DC24; }
        goto block_0017D510;
    }
block_0017D510:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D510U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D510U);
        }
        {
            const uint32_t updatedAddress = 0x0017D518U - 0x720U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D510U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017D520U + 212U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D518U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017D524U - 832U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D51CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r1 + r6;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D520U, address);
            }
        }
        {
            r1 = 0x00000014U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0017D528U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D52CU, address);
            }
        }
        {
            const uint32_t address = r5 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D530U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0017D540U + 0xC0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D538U, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017D53CU, 0xEE300A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 68U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D540U, address);
            }
        }
        {
            const uint32_t address = r5 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D544U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017D548U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 72U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D54CU, address);
            }
        }
        {
            const uint32_t address = r5 + 16U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D550U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = 0x0017D55CU + 156U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D554U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017D558U, 0xEE711A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[3], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 76U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0017D55CU, address);
            }
        }
        {
            const uint32_t address = r5 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0017D560U, address);
            }
        }
        {
            const uint32_t address = r5 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017D564U, address);
            }
        }
        {
            const uint32_t address = r5 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D568U, address);
            }
        }
        {
            const uint32_t address = r5 + 20U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D56CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017D570U, 0xEE700A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 92U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017D574U, address);
            }
        }
        {
            const uint32_t address = r5 + 24U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D578U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 96U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017D57CU, address);
            }
        }
        {
            const uint32_t address = r5 + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D580U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017D584U, address);
            }
        }
        {
            const uint32_t address = r5 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D588U, address);
            }
        }
        {
            const uint32_t address = 0x0017D594U + 104U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D58CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 116U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017D590U, address);
            }
        }
        {
            const uint32_t address = r5 + 120U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D594U, address);
            }
        }
        {
            const uint32_t address = 0x0017D5A0U - 928U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D598U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 784U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017D59CU, address);
            }
        }
        {
            const uint32_t address = r0 + 788U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D5A0U, address);
            }
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D5ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D5ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D5AC;
    }
block_0017D5AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D5ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D5ACU);
        }
        {
        }
        {
        }
        goto block_0017DC24;
    }
block_0017D604:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D604U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D604U);
        }
        {
            r2 = 0x00000004U;
        }
        {
            const uint32_t address = 0x0017D610U - 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D608U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017D614U + 932U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D60CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D61CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D61CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D61C;
    }
block_0017D61C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D61CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D61CU);
        }
        {
            const uint32_t address = 0x0017D624U + 924U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D61CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r0 = 0x0000000AU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D624U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        {
            r8 = 0x00000001U;
        }
        {
            const uint32_t address = 0x0017D63CU + 896U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D634U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017D640U + 900U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D638U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000074U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D644U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D644U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D644;
    }
block_0017D644:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D644U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D644U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D644U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000003CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0017D688; }
        goto block_0017D650;
    }
block_0017D650:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D650U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D650U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x0017D65CU + 876U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D654U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017D660U - 148U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D658U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000B10U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D664U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D664U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D664;
    }
block_0017D664:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D664U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D664U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017D674U + 856U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D66CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017D678U - 124U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D670U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000314U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D67CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D67CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D67C;
    }
block_0017D67C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D67CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D67CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D67CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0017DC24; }
        goto block_0017D688;
    }
block_0017D688:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D688U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D688U);
        }
        {
            const uint32_t updatedAddress = 0x0017D690U + 0x340U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D688U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D694U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D694U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D694;
    }
block_0017D694:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D694U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D694U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D694U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0017DC24; }
        goto block_0017D6A0;
    }
block_0017D6A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D6A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D6A0U);
        }
        {
            r1 = 0x00000002U;
        }
        {
            const uint32_t address = 0x0017D6ACU + 808U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D6A4U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r0 = r6;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D6B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0036cae4_0036CAE4(frame, context, state, 0x0036CAE4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D6B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D6B4;
    }
block_0017D6B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D6B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D6B4U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r1 = 0x00000002U;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D6C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0036cae4_0036CAE4(frame, context, state, 0x0036CAE4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D6C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D6C4;
    }
block_0017D6C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D6C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D6C4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D6C4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017D6E0; }
        goto block_0017D6D0;
    }
block_0017D6D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D6D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D6D0U);
        }
        {
            r2 = 0x0000004AU;
        }
        {
            r1 = r4;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D6E0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D6E0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D6E0;
    }
block_0017D6E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D6E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D6E0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D6E0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0017DC24; }
        goto block_0017D6EC;
    }
block_0017D6EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D6ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D6ECU);
        }
        {
            r0 = 0x00000015U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D6F0U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D6F8U, address);
            }
        }
        {
            const uint32_t address = 0x0017D704U + 724U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D6FCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = r0 + 772U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D704U, address);
            }
        }
        {
            const uint32_t address = r0 + 792U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D708U, address);
            }
        }
        {
            const uint32_t address = 0x0017D714U + 712U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D70CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 788U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D710U, address);
            }
        }
        goto block_0017D768;
    }
block_0017D718:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D718U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D718U);
        }
        {
            r2 = 0x00000004U;
        }
        {
            const uint32_t address = 0x0017D724U - 304U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D71CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017D728U + 696U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D720U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D730U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D730U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D730;
    }
block_0017D730:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D730U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D730U);
        }
        {
            r0 = 0x0000000BU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D734U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0017D740U + 0x290U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D738U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D744U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D744U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D744;
    }
block_0017D744:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D744U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D744U);
        }
        {
            const uint32_t address = 0x0017D74CU + 648U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D744U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r1 = 0x00000002U;
        }
        {
            r0 = r6;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D758U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0036cae4_0036CAE4(frame, context, state, 0x0036CAE4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D758U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D758;
    }
block_0017D758:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D758U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D758U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r1 = 0x00000002U;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D768U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0036cae4_0036CAE4(frame, context, state, 0x0036CAE4U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D768U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D768;
    }
block_0017D768:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D768U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D768U);
        }
        {
            const uint32_t address = 0x0017D770U + 628U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D768U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017D774U + 628U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D76CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D770U, address);
            }
        }
        {
            const uint32_t address = r5 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017D774U, address);
            }
        }
        {
            const uint32_t address = r5 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D778U, address);
            }
        }
        {
            const uint32_t address = 0x0017D784U + 616U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D77CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D780U, address);
            }
        }
        {
            const uint32_t address = 0x0017D78CU + 612U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D784U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D788U, address);
            }
        }
        {
            const uint32_t address = 0x0017D794U + 580U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D78CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D790U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D794U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000014U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017D7B0; }
        goto block_0017D7A0;
    }
block_0017D7A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D7A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D7A0U);
        }
        {
            const uint32_t updatedAddress = 0x0017D7A8U + 0x24CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D7A0U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D7B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D7B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D7B0;
    }
block_0017D7B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D7B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D7B0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D7B0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000B4U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0017DC24; }
        goto block_0017D7BC;
    }
block_0017D7BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D7BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D7BCU);
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = 0x000008A0U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D7C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_GetState_003769D8(frame, context, state, 0x003769D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D7C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D7C8;
    }
block_0017D7C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D7C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D7C8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_0017DC24; }
        goto block_0017D7D4;
    }
block_0017D7D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D7D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D7D4U);
        }
        {
            r0 = 0x00000016U;
        }
        {
            const uint32_t updatedAddress = 0x0017D7E0U + 0x218U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D7D8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D7DCU, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D7E4U, address);
            }
        }
        {
            r0 = 0x0000002DU;
        }
        {
            const uint32_t updatedAddress = r1 + r4;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D7ECU, address);
            }
        }
        {
            r0 = 0x000000FEU;
        }
        {
            const uint32_t updatedAddress = r5 + 0xA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D7F4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017D804U + 504U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D7FCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 816U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D800U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017D80CU - 576U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D804U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017D808U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017D814U + 492U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D80CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D810U, address);
            }
        }
        {
            const uint32_t address = r0 + 820U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D814U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017D818U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D81CU, address);
            }
        }
        {
            const uint32_t address = r0 + 824U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D820U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017D82CU - 560U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D824U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017D828U, address);
            }
        }
        {
            const uint32_t address = r0 + 784U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0017D82CU, address);
            }
        }
        {
            const uint32_t address = r0 + 788U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D830U, address);
            }
        }
        goto block_0017D834;
    }
block_0017D834:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D834U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D834U);
        }
        {
            r2 = 0x00000004U;
        }
        {
            const uint32_t address = 0x0017D840U + 452U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D838U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017D844U + 452U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D83CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D84CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b494_0035B494(frame, context, state, 0x0035B494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D84CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D84C;
    }
block_0017D84C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D84CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D84CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D84CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0017D858U + 420U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D850U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x0017D85CU + 356U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D854U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) {
            r0 = 0x0000000CU;
        }
        if ((flags.C()) && !(flags.Z())) {
            r0 = 0x00000000U;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r4 + 0xACCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D86CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000B10U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D878U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D878U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D878;
    }
block_0017D878:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D878U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D878U);
        }
        {
            const uint32_t address = 0x0017D880U + 356U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D878U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r7 = r4 + operand;
        }
        {
            const uint32_t address = r5 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D880U, address);
            }
        }
        {
            const uint32_t address = 0x0017D88CU + 384U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D884U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017D890U + 368U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D888U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D88CU, address);
            }
        }
        {
            const uint32_t address = 0x0017D898U + 376U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D890U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017D89CU + 380U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D894U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = r5 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D898U, address);
            }
        }
        {
            const uint32_t address = r7 + 820U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D89CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017D8ACU + 360U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D8A4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017D8A8U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00000018U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D8B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D8B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D8B8;
    }
block_0017D8B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D8B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D8B8U);
        }
        {
            const uint32_t address = r7 + 816U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D8B8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017D8C4U, 0xEE300A68U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000014U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = 0x0017D8D4U - 784U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D8CCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            r10 = r0;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D8D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D8D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D8D8;
    }
block_0017D8D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D8D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D8D8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D8D8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017D94C; }
        goto block_0017D8E4;
    }
block_0017D8E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D8E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D8E4U);
        }
        {
            const uint32_t operand = 0x00003800U;
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            r1 = 0x0000017CU;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D8F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Object_GetIndex_00363C10(frame, context, state, 0x00363C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D8F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D8F4;
    }
block_0017D8F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D8F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D8F4U);
        }
        {
            const uint32_t address = 0x0017D8FCU + 220U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D8F4U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1A4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D8F8U, address);
            }
        }
        {
            r1 = 0x00000016U;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D90CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D90CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D90C;
    }
block_0017D90C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D90CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D90CU);
        }
        {
            const uint32_t operand = 0x000001A8U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D914U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D914U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D914;
    }
block_0017D914:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D914U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D914U);
        }
        {
            const uint32_t updatedAddress = 0x0017D91CU + 0x104U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D914U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r4 + 196U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0017D918U, address);
            }
        }
        {
            const uint32_t address = 0x0017D924U + 248U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D91CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0017D928U - 0x730U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D920U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D924U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00001400U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 796U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017D92CU, address);
            }
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D938U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D938U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D938;
    }
block_0017D938:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D938U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D938U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = 0x0017D944U + 0xE0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D93CU, address);
            }
            r1 = value;
        }
        {
            r2 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0xAC4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D944U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D94CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_QueueSeqCmd_0036EC40(frame, context, state, 0x0036EC40U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D94CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D94C;
    }
block_0017D94C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D94CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D94CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D94CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017D9B0; }
        goto block_0017D958;
    }
block_0017D958:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D958U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D958U);
        }
        {
            const uint32_t operand = 0x00003800U;
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            r1 = 0x000000E1U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D968U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Object_GetIndex_00363C10(frame, context, state, 0x00363C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D968U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D968;
    }
block_0017D968:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D968U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D968U);
        }
        {
            const uint32_t updatedAddress = 0x0017D970U + 0xB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D968U, address);
            }
            r9 = value;
        }
        {
            const uint32_t updatedAddress = r9 + 0xFAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D96CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000100U;
            Oot3dAotSetLogicalFlags(flags, value, (0x00000100U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0017D9A4; }
        goto block_0017D978;
    }
block_0017D978:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D978U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D978U);
        }
        {
            r3 = 0x00000040U;
        }
        {
            r2 = 0x00000100U;
        }
        {
            r1 = 0x000000B4U;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0017D984U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0017D984U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0017D984U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x978U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D98CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t address = 0x0017D998U + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D990U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r3 = 0x000000C8U;
        }
        {
            const uint32_t operand = 0x0000024CU;
            r1 = r1 + operand;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017D9A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TitleCard_InitBossName_00354248(frame, context, state, 0x00354248U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017D9A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017D9A4;
    }
block_0017D9A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D9A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D9A4U);
        }
        {
            const uint32_t updatedAddress = r9 + 0xFAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017D9A4U, address);
            }
            r0 = value;
        }
        {
            r0 = r0 | 0x00000100U;
        }
        {
            const uint32_t updatedAddress = r9 + 0xFAU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017D9ACU, address);
            }
        }
        goto block_0017D9B0;
    }
block_0017D9B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017D9B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017D9B0U);
        }
        {
        }
        goto block_0017DA2C;
    }
block_0017DA2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DA2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DA2CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DA2CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_0017DC00; }
        goto block_0017DA38;
    }
block_0017DA38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DA38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DA38U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xAC5U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017DA3CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0017DA48U + 0x2D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DA40U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DA4CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DA4CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DA4C;
    }
block_0017DA4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DA4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DA4CU);
        }
        {
            const uint32_t address = 0x0017DA54U + 720U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DA4CU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x0017DA58U + 720U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DA50U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x0017DA5CU + 720U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DA54U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x0000002CU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DA68U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DA68U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DA68;
    }
block_0017DA68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DA68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DA68U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = 0x0017DA74U + 700U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DA6CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017DA78U + 700U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DA70U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000030U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DA7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DA7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DA7C;
    }
block_0017DA7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DA7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DA7CU);
        }
        {
            const uint32_t updatedAddress = 0x0017DA84U - 0x64U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DA7CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0017DA88U + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DA80U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017DA8CU + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DA84U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017DA90U + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DA88U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DA8CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00001400U;
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 776U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017DA94U, address);
            }
        }
        {
            const uint32_t address = r0 + 780U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017DA98U, address);
            }
        }
        {
            const uint32_t address = r0 + 784U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017DA9CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DAA0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0017DAACU + 664U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DAA4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DAACU, 0xEEB80A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DAB0U, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DAB4U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DAB8U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DABCU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DACCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_sin_idx8_002CFCA0(frame, context, state, 0x002CFCA0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DACCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DACC;
    }
block_0017DACC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DACCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DACCU);
        }
        {
            const uint32_t address = 0x0017DAD4U + 628U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DACCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DAD0U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 756U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DAD4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DAD8U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017DADCU, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DAE0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DAE4U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017DAF0U + 604U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DAE8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017DAECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DAF0U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DAF8U, 0xEEB80A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromUnsigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DAFCU, 0xEE200A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DB00U, 0xEE200A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DB04U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DB08U, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DB18U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DB18U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DB18;
    }
block_0017DB18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DB18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DB18U);
        }
        {
            const uint32_t address = 0x0017DB20U + 560U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DB18U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000002F4U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DB24U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r7 + 756U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DB28U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DB2CU, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017DB30U, address);
            }
        }
        {
            const uint32_t address = r4 + 264U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DB34U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DB38U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[1];
        }
        {
            const uint32_t address = r4 + 96U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017DB44U, address);
            }
        }
        {
            const uint32_t address = 0x0017DB50U + 516U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DB48U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DB50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DB50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DB50;
    }
block_0017DB50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DB50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DB50U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xFFCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DB50U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0017DC00; }
        goto block_0017DB5C;
    }
block_0017DB5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DB5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DB5CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DB5CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000005U;
            r1 = r1 - operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r1, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        {
            const uint32_t updatedAddress = r5 + 0xA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0017DB6CU, address);
            }
        }
        if ((flags.N()) != (flags.V())) {
            r1 = 0x00000000U;
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t updatedAddress = r5 + 0xA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0017DB74U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000B4U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017DC00; }
        goto block_0017DB80;
    }
block_0017DB80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DB80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DB80U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DB8CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DB8CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DB8C;
    }
block_0017DB8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DB8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DB8CU);
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r7 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0017DB98U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0017DB98U,
                                           firstAddress + 4U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0017DB98U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r9 = value9;
        }
        {
            const uint32_t firstAddress = r7;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0017DB9CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0017DB9CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0017DB9CU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x000000A4U;
            r7 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0017DBA4U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0017DBA4U,
                                           firstAddress + 4U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0017DBA4U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r9 = value9;
        }
        {
            const uint32_t operand = 0x00000080U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r7;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0017DBACU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0017DBACU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0017DBACU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t firstAddress = r10;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0017DBB0U,
                                           firstAddress + 0U);
            }
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0017DBB0U,
                                           firstAddress + 4U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0017DBB0U,
                                           firstAddress + 8U);
            }
            r1 = value1;
            r2 = value2;
            r3 = value3;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0017DBB4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0017DBB4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0017DBB4U,
                                           firstAddress + 8U);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DBBCU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DBC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ClearCameraAndRestoreMain_0036E9B8(frame, context, state, 0x0036E9B8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DBC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DBC8;
    }
block_0017DBC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DBC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DBC8U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r5 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017DBCCU, address);
            }
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r6 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017DBD4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DBE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartUnskippable_00367374(frame, context, state, 0x00367374U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DBE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DBE4;
    }
block_0017DBE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DBE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DBE4U);
        }
        {
            r2 = 0x00000007U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DBF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DBF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DBF4;
    }
block_0017DBF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DBF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DBF4U);
        }
        {
            r1 = r6;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DC00U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0036e288_0036E288(frame, context, state, 0x0036E288U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DC00U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DC00;
    }
block_0017DC00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DC00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DC00U);
        }
        {
            const uint32_t updatedAddress = 0x0017DC08U - 0x1E8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DC00U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DC04U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0017DC24; }
        goto block_0017DC10;
    }
block_0017DC10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DC10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DC10U);
        }
        {
            const uint32_t address = 0x0017DC18U - 576U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DC10U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017DC1CU + 316U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DC14U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017DC18U, address);
            }
        }
        {
            const uint32_t address = r0 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017DC1CU, address);
            }
        }
        {
            const uint32_t address = r0 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017DC20U, address);
            }
        }
        goto block_0017DC24;
    }
block_0017DC24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DC24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DC24U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DC24U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0017DD5C; }
        goto block_0017DC30;
    }
block_0017DC30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DC30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DC30U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r8, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0017DCF8; }
        goto block_0017DC38;
    }
block_0017DC38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DC38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DC38U);
        }
        {
            const uint32_t address = r5 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DC38U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DC3CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000008U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DC48U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DC4CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 68U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DC50U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DC58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DC58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DC58;
    }
block_0017DC58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DC58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DC58U);
        }
        {
            const uint32_t address = r5 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DC58U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DC5CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000000CU;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DC68U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DC6CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 72U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DC70U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DC78U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DC78U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DC78;
    }
block_0017DC78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DC78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DC78U);
        }
        {
            const uint32_t address = r5 + 52U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DC78U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DC7CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000010U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DC88U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DC8CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 76U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DC90U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DC98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DC98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DC98;
    }
block_0017DC98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DC98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DC98U);
        }
        {
            const uint32_t address = r5 + 56U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DC98U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DC9CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000014U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DCA8U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DCACU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DCB0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DCB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DCB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DCB8;
    }
block_0017DCB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DCB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DCB8U);
        }
        {
            const uint32_t address = r5 + 60U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DCB8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DCBCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00000018U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DCC8U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DCCCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 96U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DCD0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DCD8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DCD8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DCD8;
    }
block_0017DCD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DCD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DCD8U);
        }
        {
            const uint32_t address = r5 + 64U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DCD8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DCDCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DCE8U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DCECU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 100U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DCF0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DCF8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DCF8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DCF8;
    }
block_0017DCF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DCF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DCF8U);
        }
        {
            const uint32_t updatedAddress = r5 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DCF8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000048U;
            r13 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00001000U;
            r3 = r4 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0017DD04U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0017DD04U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0017DD04U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0017DD04U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0017DD04U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0017DD04U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0017DD04U,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0017DD04U,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            r13 += 32U;
        }
        {
            const uint32_t operand = 0x00001000U;
            r2 = r4 + operand;
        }
        {
            r0 = r6;
        }
        {
            const uint32_t operand = 0x00000008U;
            r3 = r3 + operand;
        }
        {
            const uint32_t operand = 0x00000014U;
            r2 = r2 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0017DD18U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0017DD18U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0017DD18U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0017DD18U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0017DD18U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0017DD18U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0017DD18U,
                                           firstAddress + 24U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x0017DD18U,
                                           firstAddress + 28U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r14 = value14;
            r13 = r13 + 32U;
        }
        return Oot3dAotBranch(0x00367B14U);
    }
block_0017DD5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DD5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DD5CU);
        }
        {
            const uint32_t operand = 0x00000048U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0017DD60U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0017DD60U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0017DD60U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0017DD60U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0017DD60U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0017DD60U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0017DD60U,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0017DD60U,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            r13 += 32U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0017DD64U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0017DD64U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0017DD64U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0017DD64U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0017DD64U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0017DD64U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0017DD64U,
                                           firstAddress + 24U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0017DD64U,
                                           firstAddress + 28U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r13 = r13 + 32U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_BgMoriHineri_Init_0027A254(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0027A254U:
        goto block_0027A254;
    case 0x0027A268U:
        goto block_0027A268;
    case 0x0027A274U:
        goto block_0027A274;
    case 0x0027A28CU:
        goto block_0027A28C;
    case 0x0027A2A0U:
        goto block_0027A2A0;
    case 0x0027A2ACU:
        goto block_0027A2AC;
    case 0x0027A2C8U:
        goto block_0027A2C8;
    case 0x0027A2D4U:
        goto block_0027A2D4;
    case 0x0027A2E8U:
        goto block_0027A2E8;
    case 0x0027A2F4U:
        goto block_0027A2F4;
    case 0x0027A310U:
        goto block_0027A310;
    case 0x0027A31CU:
        goto block_0027A31C;
    case 0x0027A32CU:
        goto block_0027A32C;
    case 0x0027A338U:
        goto block_0027A338;
    case 0x0027A344U:
        goto block_0027A344;
    case 0x0027A350U:
        goto block_0027A350;
    case 0x0027A358U:
        goto block_0027A358;
    case 0x0027A364U:
        goto block_0027A364;
    case 0x0027A374U:
        goto block_0027A374;
    case 0x0027A380U:
        goto block_0027A380;
    case 0x0027A388U:
        goto block_0027A388;
    case 0x0027A394U:
        goto block_0027A394;
    case 0x0027A3A4U:
        goto block_0027A3A4;
    case 0x0027A3B0U:
        goto block_0027A3B0;
    case 0x0027A3BCU:
        goto block_0027A3BC;
    case 0x0027A3CCU:
        goto block_0027A3CC;
    case 0x0027A3D0U:
        goto block_0027A3D0;
    case 0x0027A3D8U:
        goto block_0027A3D8;
    case 0x0027A3E4U:
        goto block_0027A3E4;
    case 0x0027A3F8U:
        goto block_0027A3F8;
    case 0x0027A400U:
        goto block_0027A400;
    case 0x0027A410U:
        goto block_0027A410;
    case 0x0027A420U:
        goto block_0027A420;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0027A254:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A254U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A254U);
        }
        {
            const uint32_t firstAddress = r13 - 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0027A254U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0027A254U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0027A254U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0027A254U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0027A254U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0027A254U,
                                           firstAddress + 20U);
            }
            r13 = r13 - 24U;
        }
        {
            r6 = r1;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t updatedAddress = 0x0027A268U + 0x1BCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027A260U, address);
            }
            r1 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027A268U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_ProcessInitChain_003510B0(frame, context, state, 0x003510B0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027A268U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027A268;
    }
block_0027A268:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A268U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A268U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027A274U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_DynaPolyActor_Init_003532E8(frame, context, state, 0x003532E8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027A274U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027A274;
    }
block_0027A274:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A274U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A274U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027A274U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000100U;
            r7 = r4 + operand;
        }
        {
            r5 = r0 & 0x00004000U;
            Oot3dAotSetLogicalFlags(flags, r5, (0x00004000U & 0x80000000U) != 0U, static_cast<Oot3dAotFlagMask>(0xEU));
        }
        {
            r8 = r0 & 0x0000003FU;
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = r4 + 0x1C3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r8))) {
                return Oot3dAotMemoryFault(context, 0x0027A284U, address);
            }
        }
        if (!(flags.Z())) { goto block_0027A2AC; }
        goto block_0027A28C;
    }
block_0027A28C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A28CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A28CU);
        }
        {
            r0 = Oot3dAotLsl(r0, 18U);
        }
        {
            r1 = Oot3dAotLsr(r0, 26U);
        }
        {
            r0 = r6;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0027A298U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027A2A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Flags_GetSwitch_0036E864(frame, context, state, 0x0036E864U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027A2A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027A2A0;
    }
block_0027A2A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A2A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A2A0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027A2A8U, address);
            }
        }
        goto block_0027A2AC;
    }
block_0027A2AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A2ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A2ACU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027A2ACU, address);
            }
            r0 = value;
        }
        {
            r0 = r0 & 0x00008000U;
        }
        {
            r1 = Oot3dAotLsr(r0, 14U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0027A2B8U, address);
            }
        }
        {
            r1 = r8;
        }
        {
            r0 = r6;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027A2C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Flags_GetSwitch_0036E864(frame, context, state, 0x0036E864U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027A2C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027A2C8;
    }
block_0027A2C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A2C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A2C8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (flags.Z()) { goto block_0027A2F4; }
        goto block_0027A2D4;
    }
block_0027A2D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A2D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A2D4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027A2D4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r1 = 0x00000001U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0027A2E0U, address);
            }
        }
        if (flags.Z()) { goto block_0027A2F4; }
        goto block_0027A2E8;
    }
block_0027A2E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A2E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A2E8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r1 = 0x00000003U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0027A2F0U, address);
            }
        }
        goto block_0027A2F4;
    }
block_0027A2F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A2F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A2F4U);
        }
        {
            r1 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0027A2F8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027A2FCU, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00003800U;
            r0 = r6 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0027A350; }
        goto block_0027A310;
    }
block_0027A310:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A310U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A310U);
        }
        {
            r1 = 0x0000005CU;
        }
        {
            r8 = r0;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027A31CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Object_GetIndex_00363C10(frame, context, state, 0x00363C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027A31CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027A31C;
    }
block_0027A31C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A31CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A31CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027A31CU, address);
            }
        }
        {
            r1 = 0x0000006FU;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027A32CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Object_GetIndex_00363C10(frame, context, state, 0x00363C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027A32CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027A32C;
    }
block_0027A32C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A32CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A32CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027A330U, address);
            }
        }
        if (!(flags.Z())) { goto block_0027A3D8; }
        goto block_0027A338;
    }
block_0027A338:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A338U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A338U);
        }
        {
            r1 = 0x0000000EU;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027A344U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Object_GetIndex_00363C10(frame, context, state, 0x00363C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027A344U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027A344;
    }
block_0027A344:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A344U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A344U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027A344U, address);
            }
        }
        {
        }
        goto block_0027A3E4;
    }
block_0027A350:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A350U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A350U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0027A380; }
        goto block_0027A358;
    }
block_0027A358:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A358U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A358U);
        }
        {
            r1 = 0x0000006FU;
        }
        {
            r8 = r0;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027A364U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Object_GetIndex_00363C10(frame, context, state, 0x00363C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027A364U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027A364;
    }
block_0027A364:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A364U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A364U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027A364U, address);
            }
        }
        {
            r1 = 0x0000005CU;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027A374U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Object_GetIndex_00363C10(frame, context, state, 0x00363C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027A374U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027A374;
    }
block_0027A374:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A374U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A374U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027A374U, address);
            }
        }
        {
        }
        goto block_0027A3D0;
    }
block_0027A380:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A380U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A380U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000002U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0027A3B0; }
        goto block_0027A388;
    }
block_0027A388:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A388U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A388U);
        }
        {
            r1 = 0x00000070U;
        }
        {
            r8 = r0;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027A394U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Object_GetIndex_00363C10(frame, context, state, 0x00363C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027A394U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027A394;
    }
block_0027A394:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A394U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A394U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027A394U, address);
            }
        }
        {
            r1 = 0x00000071U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027A3A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Object_GetIndex_00363C10(frame, context, state, 0x00363C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027A3A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027A3A4;
    }
block_0027A3A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A3A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A3A4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027A3A4U, address);
            }
        }
        {
        }
        goto block_0027A3D0;
    }
block_0027A3B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A3B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A3B0U);
        }
        {
            r1 = 0x00000071U;
        }
        {
            r8 = r0;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027A3BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Object_GetIndex_00363C10(frame, context, state, 0x00363C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027A3BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027A3BC;
    }
block_0027A3BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A3BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A3BCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027A3BCU, address);
            }
        }
        {
            r1 = 0x00000070U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027A3CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Object_GetIndex_00363C10(frame, context, state, 0x00363C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027A3CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027A3CC;
    }
block_0027A3CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A3CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A3CCU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1C1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027A3CCU, address);
            }
        }
        goto block_0027A3D0;
    }
block_0027A3D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A3D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A3D0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r5, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0027A3E4; }
        goto block_0027A3D8;
    }
block_0027A3D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A3D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A3D8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027A3D8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000004U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x1CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027A3E0U, address);
            }
        }
        goto block_0027A3E4;
    }
block_0027A3E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A3E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A3E4U);
        }
        {
            const uint32_t updatedAddress = r7 + 0xC0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027A3E4U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int8_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t updatedAddress = 0x0027A3F4U + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027A3ECU, address);
            }
            r0 = value;
        }
        if ((flags.N()) == (flags.V())) {
            const uint32_t updatedAddress = r4 + 0x1BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0027A3F0U, address);
            }
        }
        if ((flags.N()) == (flags.V())) { goto block_0027A400; }
        goto block_0027A3F8;
    }
block_0027A3F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A3F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A3F8U);
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0027A400U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_Kill_00374428(frame, context, state, 0x00374428U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0027A400U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0027A400;
    }
block_0027A400:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A400U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A400U);
        }
        {
            const uint32_t updatedAddress = 0x0027A408U + 0x24U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027A400U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r6;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0027A404U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0027A420; }
        goto block_0027A410;
    }
block_0027A410:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A410U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A410U);
        }
        {
            r0 = r6;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0027A414U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0027A414U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0027A414U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0027A414U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0027A414U,
                                           firstAddress + 16U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x0027A414U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r14 = value14;
            r13 = r13 + 24U;
        }
        {
            r1 = 0x0000000CU;
        }
        return Oot3dAotBranch(0x0032B13CU);
    }
block_0027A420:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0027A420U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0027A420U);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0027A420U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0027A420U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0027A420U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0027A420U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0027A420U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0027A420U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_0034be30_0034BE30(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0034BE30U:
        goto block_0034BE30;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0034BE30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0034BE30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0034BE30U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 1U);
            r2 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0034BE3CU + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034BE34U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 2U);
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034BE40U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r2;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0034BE48U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0034BE4CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x2U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034BE50U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r2;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0034BE58U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0034BE5CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034BE60U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r2;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0034BE68U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0034BE6CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x6U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034BE70U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r2;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0034BE78U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0034BE7CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x8U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034BE80U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r2;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0034BE88U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0034BE8CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0xAU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0034BE90U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            frame.Guest.vfp[0] = r1;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0034BE98U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0034BE9CU, address);
            }
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_0035b494_0035B494(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0035B494U:
        goto block_0035B494;
    case 0x0035B4B8U:
        goto block_0035B4B8;
    case 0x0035B4C8U:
        goto block_0035B4C8;
    case 0x0035B4D0U:
        goto block_0035B4D0;
    case 0x0035B4D8U:
        goto block_0035B4D8;
    case 0x0035B4E0U:
        goto block_0035B4E0;
    case 0x0035B4E4U:
        goto block_0035B4E4;
    case 0x0035B4F8U:
        goto block_0035B4F8;
    case 0x0035B508U:
        goto block_0035B508;
    case 0x0035B510U:
        goto block_0035B510;
    case 0x0035B534U:
        goto block_0035B534;
    case 0x0035B554U:
        goto block_0035B554;
    case 0x0035B560U:
        goto block_0035B560;
    case 0x0035B564U:
        goto block_0035B564;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0035B494:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B494U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B494U);
        }
        {
            const uint32_t firstAddress = r13 - 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0035B494U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0035B494U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0035B494U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0035B494U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0035B494U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0035B494U,
                                           firstAddress + 20U);
            }
            r13 = r13 - 24U;
        }
        {
            r5 = r0;
        }
        {
            r0 = r1;
        }
        {
            r6 = r2;
        }
        {
            r13 -= 16U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0035B4A4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0035B4A4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0035B4A4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0035B4A4U,
                                           firstAddress + 12U);
            }
        }
        {
            frame.Guest.vfp[18] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[17] = frame.Guest.vfp[1];
        }
        {
            r1 = ~(0x00000000U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B4B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B4B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B4B8;
    }
block_0035B4B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B4B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B4B8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r7 = r0;
        }
        {
            const uint32_t operand = 0x00001000U;
            r4 = r5 + operand;
        }
        if ((flags.N()) == (flags.V())) { goto block_0035B4D8; }
        goto block_0035B4C8;
    }
block_0035B4C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B4C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B4C8U);
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B4D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_set_byte_1b6_00367C48(frame, context, state, 0x00367C48U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B4D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B4D0;
    }
block_0035B4D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B4D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B4D0U);
        }
        {
            const uint32_t address = 0x0035B4D8U + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0035B4D0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_0035B564;
    }
block_0035B4D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B4D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B4D8U);
        }
        {
            r0 = r7;
        }
        if (!(flags.Z())) { goto block_0035B508; }
        goto block_0035B4E0;
    }
block_0035B4E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B4E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B4E0U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B4E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_clear_byte_1b6_00367C54(frame, context, state, 0x00367C54U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B4E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B4E4;
    }
block_0035B4E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B4E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B4E4U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            r0 = r7;
        }
        {
            const uint32_t address = r4 + 164U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0035B4ECU, address);
            }
        }
        {
            const uint32_t address = r4 + 168U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0035B4F0U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B4F8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00367c60_00367C60(frame, context, state, 0x00367C60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B4F8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B4F8;
    }
block_0035B4F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B4F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B4F8U);
        }
        {
            const uint32_t address = r4 + 168U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0035B4F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r7 + 324U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0035B4FCU, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0035B500U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0035B500U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0035B500U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0035B500U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0035B504U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0035B504U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0035B504U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0035B504U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0035B504U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0035B504U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
block_0035B508:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B508U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B508U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B510U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_clear_byte_1b6_00367C54(frame, context, state, 0x00367C54U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B510U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B510;
    }
block_0035B510:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B510U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B510U);
        }
        {
            frame.Guest.vfp[1] = r6;
        }
        {
            const uint32_t address = 0x0035B51CU + 88U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0035B514U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000000A4U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0035B528U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0035B52CU, 0xEEC80A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B534U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B534U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B534;
    }
block_0035B534:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B534U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B534U);
        }
        {
            frame.Guest.vfp[0] = r6;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000000A8U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0035B544U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0035B548U, 0xEEC80A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B554U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B554U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B554;
    }
block_0035B554:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B554U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B554U);
        }
        {
            const uint32_t address = r4 + 164U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0035B554U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B560U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00367c60_00367C60(frame, context, state, 0x00367C60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B560U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B560;
    }
block_0035B560:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B560U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B560U);
        }
        {
            const uint32_t address = r4 + 168U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0035B560U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_0035B564;
    }
block_0035B564:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B564U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B564U);
        }
        {
            const uint32_t address = r7 + 324U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0035B564U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0035B568U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0035B568U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0035B568U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0035B568U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0035B56CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0035B56CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0035B56CU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0035B56CU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0035B56CU,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0035B56CU,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Object_GetIndex_00363C10(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00363C10U:
        goto block_00363C10;
    case 0x00363C30U:
        goto block_00363C30;
    case 0x00363C48U:
        goto block_00363C48;
    case 0x00363C4CU:
        goto block_00363C4C;
    case 0x00363C54U:
        goto block_00363C54;
    case 0x00363C60U:
        goto block_00363C60;
    case 0x00363C68U:
        goto block_00363C68;
    case 0x00363C80U:
        goto block_00363C80;
    case 0x00363C94U:
        goto block_00363C94;
    case 0x00363CA0U:
        goto block_00363CA0;
    case 0x00363CACU:
        goto block_00363CAC;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00363C10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00363C10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00363C10U);
        }
        {
            const uint32_t updatedAddress = r13 - 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r4))) {
                return Oot3dAotMemoryFault(context, 0x00363C10U, address);
            }
            r13 = updatedAddress;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00363C14U, address);
            }
            r4 = value;
        }
        {
            r12 = r0;
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00000000U;
            Oot3dAotSetAddFlags(flags, r4, operand, static_cast<Oot3dAotFlagMask>(0x4U));
            r0 = r4 + operand;
        }
        if (!(flags.Z())) {
            r0 = r4 & 0x00000001U;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00363C60; }
        goto block_00363C30;
    }
block_00363C30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00363C30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00363C30U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r2, 7U);
            r3 = r12 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00363C34U, address);
            }
            r3 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t operand = 0x00000000U;
            r3 = operand - r3;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00363C54; }
        goto block_00363C48;
    }
block_00363C48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00363C48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00363C48U);
        }
        {
            r0 = r2;
        }
        goto block_00363C4C;
    }
block_00363C4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00363C4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00363C4CU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = r13;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00363C4CU, address);
            }
            r4 = value;
            r13 = updatedAddress;
        }
        return Oot3dAotReturned(r14);
    }
block_00363C54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00363C54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00363C54U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r2 = r2 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r0, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) { goto block_00363C30; }
        goto block_00363C60;
    }
block_00363C60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00363C60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00363C60U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_00363CAC; }
        goto block_00363C68;
    }
block_00363C68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00363C68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00363C68U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 7U);
            r3 = r12 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00363C6CU, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t operand = 0x00000000U;
            r2 = operand - r2;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00363C4C; }
        goto block_00363C80;
    }
block_00363C80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00363C80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00363C80U);
        }
        {
            const uint32_t updatedAddress = r3 + 0x84U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00363C80U, address);
            }
            r2 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) != (flags.V())) {
            const uint32_t operand = 0x00000000U;
            r2 = operand - r2;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_00363CA0; }
        goto block_00363C94;
    }
block_00363C94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00363C94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00363C94U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = r13;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00363C94U, address);
            }
            r4 = value;
            r13 = updatedAddress;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        return Oot3dAotReturned(r14);
    }
block_00363CA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00363CA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00363CA0U);
        }
        {
            const uint32_t operand = 0x00000002U;
            r0 = r0 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r4, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_00363C68; }
        goto block_00363CAC;
    }
block_00363CAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00363CACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00363CACU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = r13;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00363CACU, address);
            }
            r4 = value;
            r13 = updatedAddress;
        }
        {
            r0 = ~(0x00000000U);
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_0036cae4_0036CAE4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0036CAE4U:
        goto block_0036CAE4;
    case 0x0036CAF4U:
        goto block_0036CAF4;
    case 0x0036CB00U:
        goto block_0036CB00;
    case 0x0036CB58U:
        goto block_0036CB58;
    case 0x0036CB6CU:
        goto block_0036CB6C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0036CAE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036CAE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036CAE4U);
        }
        {
            const uint32_t operand = 0x00005000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r13 - 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0036CAE8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0036CAE8U,
                                           firstAddress + 4U);
            }
            r13 = r13 - 8U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xC28U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036CAECU, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000000U;
        }
        goto block_0036CAF4;
    }
block_0036CAF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036CAF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036CAF4U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036CAF4U, address);
            }
            r3 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r3, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0036CB58; }
        goto block_0036CB00;
    }
block_0036CB00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036CB00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036CB00U);
        }
        {
            const uint32_t updatedAddress = 0x0036CB08U + 0x6CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036CB00U, address);
            }
            r4 = value;
        }
        {
            r2 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0036CB08U, address);
            }
        }
        {
            const uint32_t operand = 0x00000004U;
            r5 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r4;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0036CB10U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0036CB10U,
                                           firstAddress + 4U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x0036CB10U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r12 = value12;
        }
        {
            const uint32_t address = 0x0036CB1CU + 92U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036CB14U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t firstAddress = r5;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0036CB18U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0036CB18U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r12)) {
                return Oot3dAotMemoryFault(context, 0x0036CB18U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x00000010U;
            r5 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0036CB20U, address);
            }
        }
        {
            const uint32_t firstAddress = r4;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0036CB24U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0036CB24U,
                                           firstAddress + 4U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x0036CB24U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r12 = value12;
        }
        {
            const uint32_t address = 0x0036CB30U + 76U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036CB28U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t firstAddress = r5;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0036CB2CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0036CB2CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r12)) {
                return Oot3dAotMemoryFault(context, 0x0036CB2CU,
                                           firstAddress + 8U);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0036CB30U, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t firstAddress = r4;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0036CB34U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0036CB34U,
                                           firstAddress + 4U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x0036CB34U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r12 = value12;
        }
        {
            const uint32_t operand = 0x0000001CU;
            r5 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r5;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0036CB3CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0036CB3CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r12)) {
                return Oot3dAotMemoryFault(context, 0x0036CB3CU,
                                           firstAddress + 8U);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = r0 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0036CB44U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0036CB48U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0036CB4CU, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0036CB50U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0036CB50U,
                                           firstAddress + 4U);
            }
            r4 = value4;
            r5 = value5;
            r13 = r13 + 8U;
        }
        return Oot3dAotReturned(r14);
    }
block_0036CB58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036CB58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036CB58U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r2 = r2 + operand;
        }
        {
            const uint32_t operand = 0x0000004CU;
            r0 = r0 + operand;
        }
        {
            const uint32_t source = Oot3dAotRor(r2, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) != (flags.V())) { goto block_0036CAF4; }
        goto block_0036CB6C;
    }
block_0036CB6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036CB6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036CB6CU);
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0036CB6CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0036CB6CU,
                                           firstAddress + 4U);
            }
            r4 = value4;
            r5 = value5;
            r13 = r13 + 8U;
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_oot3d_field_80x4_positive_00373074(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00373074U:
        goto block_00373074;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00373074:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00373074U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00373074U);
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 7U);
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00373078U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) {
            r0 = 0x00000000U;
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) {
            r0 = 0x00000001U;
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

} // namespace Oot3dNativeGame::GeneratedWholeAot
