#include "oot3d_whole_aot_generated_internal.h"
#include "oot3d_native_a32_memory.h"

#include <atomic>

namespace Oot3dNativeGame::GeneratedWholeAot {
namespace a32 = oot3d::recomp::a32;

Oot3dWholeAotFlow Execute_FUN_0013a9b4_0013A9B4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0017dd68_0017DD68(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_ChangeCameraStatus_00320D7C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_cos_idx8_00338F60(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0034bdb8_0034BDB8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FaceAnimationSet_InitFromModel_0034E994(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_InitActorAlt_00353E78(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_TitleCard_InitBossName_00354248(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_ZAR_GetCMBByIndex_00358EF8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Player_SetRuntimeFlag200_0035AF04(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0035b1cc_0035B1CC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0035b2d0_0035B2D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Object_GetIndex_00363C10(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_SetBGM_003655D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_EffectSsDust_SpawnUpdateRateScaled_00365D20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CutsceneContext_StartUnskippable_00367374(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CutsceneContext_StartSkippable_00367494(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_set_byte_1b6_00367C48(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_clear_byte_1b6_00367C54(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_00367c60_00367C60(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Message_StartTextbox_00367C7C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_CreateSubCamera_00367D74(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SpawnAsChild_0036AA20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_GetLastFrame_0036AE14(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_AnimationResource_GetLastFrameByIndex_0036AE18(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_GetCamera_0036C5BC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Player_SetCsActionWithHaltedActors_0036E980(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Gameplay_ClearCameraAndRestoreMain_0036E9B8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_QueueSeqCmd_0036EC40(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Actor_SpawnFloorDustRing_0036F00C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0036f57c_0036F57C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_FUN_0036fadc_0036FADC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_ApproachZeroF_0036FC20(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_CameraQuake_Request_0036FCA8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_MorphToLoop_00370350(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Message_QueueTextRequest_003716F0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_ZeroFloat_00371E50(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_MessageContext_ResetDisplay_003725E0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_oot3d_field_80x4_positive_00373074(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_ApproachF_00373500(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_OnFrameImpl_003736FC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Rand_CenteredFloat_003738A8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Animation_MorphToPlayOnce_00374A58(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlaySoundGeneral_0037547C(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Math_Atan2S_003758B0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Audio_PlayActorSound2_00375BCC(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);
Oot3dWholeAotFlow Execute_Message_GetState_003769D8(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc);

Oot3dWholeAotFlow Execute_FUN_0013a9b4_0013A9B4(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0013A9B4U:
        goto block_0013A9B4;
    case 0x0013A9E4U:
        goto block_0013A9E4;
    case 0x0013AA6CU:
        goto block_0013AA6C;
    case 0x0013AA74U:
        goto block_0013AA74;
    case 0x0013AA7CU:
        goto block_0013AA7C;
    case 0x0013AA98U:
        goto block_0013AA98;
    case 0x0013AAA0U:
        goto block_0013AAA0;
    case 0x0013AAA8U:
        goto block_0013AAA8;
    case 0x0013AAB0U:
        goto block_0013AAB0;
    case 0x0013AAB8U:
        goto block_0013AAB8;
    case 0x0013AAC0U:
        goto block_0013AAC0;
    case 0x0013AADCU:
        goto block_0013AADC;
    case 0x0013AB28U:
        goto block_0013AB28;
    case 0x0013AB40U:
        goto block_0013AB40;
    case 0x0013AB54U:
        goto block_0013AB54;
    case 0x0013AB5CU:
        goto block_0013AB5C;
    case 0x0013AB64U:
        goto block_0013AB64;
    case 0x0013AB7CU:
        goto block_0013AB7C;
    case 0x0013AB90U:
        goto block_0013AB90;
    case 0x0013ABA0U:
        goto block_0013ABA0;
    case 0x0013ABACU:
        goto block_0013ABAC;
    case 0x0013ABC8U:
        goto block_0013ABC8;
    case 0x0013ABDCU:
        goto block_0013ABDC;
    case 0x0013ABE8U:
        goto block_0013ABE8;
    case 0x0013ABF4U:
        goto block_0013ABF4;
    case 0x0013AC08U:
        goto block_0013AC08;
    case 0x0013AC18U:
        goto block_0013AC18;
    case 0x0013AC28U:
        goto block_0013AC28;
    case 0x0013AC60U:
        goto block_0013AC60;
    case 0x0013AC78U:
        goto block_0013AC78;
    case 0x0013AC84U:
        goto block_0013AC84;
    case 0x0013ACA0U:
        goto block_0013ACA0;
    case 0x0013ACACU:
        goto block_0013ACAC;
    case 0x0013ACC4U:
        goto block_0013ACC4;
    case 0x0013ACD0U:
        goto block_0013ACD0;
    case 0x0013ACF0U:
        goto block_0013ACF0;
    case 0x0013ACFCU:
        goto block_0013ACFC;
    case 0x0013AD14U:
        goto block_0013AD14;
    case 0x0013AD38U:
        goto block_0013AD38;
    case 0x0013AD44U:
        goto block_0013AD44;
    case 0x0013AD4CU:
        goto block_0013AD4C;
    case 0x0013AD58U:
        goto block_0013AD58;
    case 0x0013AD64U:
        goto block_0013AD64;
    case 0x0013AD7CU:
        goto block_0013AD7C;
    case 0x0013AD84U:
        goto block_0013AD84;
    case 0x0013AD94U:
        goto block_0013AD94;
    case 0x0013ADA4U:
        goto block_0013ADA4;
    case 0x0013AE34U:
        goto block_0013AE34;
    case 0x0013AE40U:
        goto block_0013AE40;
    case 0x0013AE50U:
        goto block_0013AE50;
    case 0x0013AED0U:
        goto block_0013AED0;
    case 0x0013AEE8U:
        goto block_0013AEE8;
    case 0x0013AF04U:
        goto block_0013AF04;
    case 0x0013AF24U:
        goto block_0013AF24;
    case 0x0013AF50U:
        goto block_0013AF50;
    case 0x0013AF6CU:
        goto block_0013AF6C;
    case 0x0013AF88U:
        goto block_0013AF88;
    case 0x0013AFA0U:
        goto block_0013AFA0;
    case 0x0013AFC8U:
        goto block_0013AFC8;
    case 0x0013B00CU:
        goto block_0013B00C;
    case 0x0013B024U:
        goto block_0013B024;
    case 0x0013B034U:
        goto block_0013B034;
    case 0x0013B040U:
        goto block_0013B040;
    case 0x0013B04CU:
        goto block_0013B04C;
    case 0x0013B060U:
        goto block_0013B060;
    case 0x0013B074U:
        goto block_0013B074;
    case 0x0013B088U:
        goto block_0013B088;
    case 0x0013B094U:
        goto block_0013B094;
    case 0x0013B0A4U:
        goto block_0013B0A4;
    case 0x0013B0BCU:
        goto block_0013B0BC;
    case 0x0013B0C8U:
        goto block_0013B0C8;
    case 0x0013B0ECU:
        goto block_0013B0EC;
    case 0x0013B0F8U:
        goto block_0013B0F8;
    case 0x0013B110U:
        goto block_0013B110;
    case 0x0013B134U:
        goto block_0013B134;
    case 0x0013B13CU:
        goto block_0013B13C;
    case 0x0013B15CU:
        goto block_0013B15C;
    case 0x0013B170U:
        goto block_0013B170;
    case 0x0013B1A0U:
        goto block_0013B1A0;
    case 0x0013B1B0U:
        goto block_0013B1B0;
    case 0x0013B1BCU:
        goto block_0013B1BC;
    case 0x0013B1CCU:
        goto block_0013B1CC;
    case 0x0013B1D8U:
        goto block_0013B1D8;
    case 0x0013B1E8U:
        goto block_0013B1E8;
    case 0x0013B238U:
        goto block_0013B238;
    case 0x0013B244U:
        goto block_0013B244;
    case 0x0013B280U:
        goto block_0013B280;
    case 0x0013B290U:
        goto block_0013B290;
    case 0x0013B2A0U:
        goto block_0013B2A0;
    case 0x0013B2ACU:
        goto block_0013B2AC;
    case 0x0013B2C4U:
        goto block_0013B2C4;
    case 0x0013B2F0U:
        goto block_0013B2F0;
    case 0x0013B30CU:
        goto block_0013B30C;
    case 0x0013B328U:
        goto block_0013B328;
    case 0x0013B338U:
        goto block_0013B338;
    case 0x0013B344U:
        goto block_0013B344;
    case 0x0013B350U:
        goto block_0013B350;
    case 0x0013B35CU:
        goto block_0013B35C;
    case 0x0013B370U:
        goto block_0013B370;
    case 0x0013B380U:
        goto block_0013B380;
    case 0x0013B39CU:
        goto block_0013B39C;
    case 0x0013B3A8U:
        goto block_0013B3A8;
    case 0x0013B3CCU:
        goto block_0013B3CC;
    case 0x0013B3E4U:
        goto block_0013B3E4;
    case 0x0013B3FCU:
        goto block_0013B3FC;
    case 0x0013B424U:
        goto block_0013B424;
    case 0x0013B444U:
        goto block_0013B444;
    case 0x0013B464U:
        goto block_0013B464;
    case 0x0013B47CU:
        goto block_0013B47C;
    case 0x0013B49CU:
        goto block_0013B49C;
    case 0x0013B4BCU:
        goto block_0013B4BC;
    case 0x0013B4D8U:
        goto block_0013B4D8;
    case 0x0013B4E8U:
        goto block_0013B4E8;
    case 0x0013B4F0U:
        goto block_0013B4F0;
    case 0x0013B4FCU:
        goto block_0013B4FC;
    case 0x0013B50CU:
        goto block_0013B50C;
    case 0x0013B53CU:
        goto block_0013B53C;
    case 0x0013B578U:
        goto block_0013B578;
    case 0x0013B588U:
        goto block_0013B588;
    case 0x0013B598U:
        goto block_0013B598;
    case 0x0013B5C8U:
        goto block_0013B5C8;
    case 0x0013B5D4U:
        goto block_0013B5D4;
    case 0x0013B5E0U:
        goto block_0013B5E0;
    case 0x0013B5F4U:
        goto block_0013B5F4;
    case 0x0013B674U:
        goto block_0013B674;
    case 0x0013B684U:
        goto block_0013B684;
    case 0x0013B690U:
        goto block_0013B690;
    case 0x0013B740U:
        goto block_0013B740;
    case 0x0013B758U:
        goto block_0013B758;
    case 0x0013B768U:
        goto block_0013B768;
    case 0x0013B774U:
        goto block_0013B774;
    case 0x0013B794U:
        goto block_0013B794;
    case 0x0013B7A8U:
        goto block_0013B7A8;
    case 0x0013B7C0U:
        goto block_0013B7C0;
    case 0x0013B7D0U:
        goto block_0013B7D0;
    case 0x0013B7DCU:
        goto block_0013B7DC;
    case 0x0013B7F0U:
        goto block_0013B7F0;
    case 0x0013B800U:
        goto block_0013B800;
    case 0x0013B80CU:
        goto block_0013B80C;
    case 0x0013B81CU:
        goto block_0013B81C;
    case 0x0013B828U:
        goto block_0013B828;
    case 0x0013B85CU:
        goto block_0013B85C;
    case 0x0013B86CU:
        goto block_0013B86C;
    case 0x0013B878U:
        goto block_0013B878;
    case 0x0013B8A4U:
        goto block_0013B8A4;
    case 0x0013B8B0U:
        goto block_0013B8B0;
    case 0x0013B8D0U:
        goto block_0013B8D0;
    case 0x0013B8F0U:
        goto block_0013B8F0;
    case 0x0013B910U:
        goto block_0013B910;
    case 0x0013B920U:
        goto block_0013B920;
    case 0x0013B938U:
        goto block_0013B938;
    case 0x0013B94CU:
        goto block_0013B94C;
    case 0x0013B960U:
        goto block_0013B960;
    case 0x0013B96CU:
        goto block_0013B96C;
    case 0x0013B978U:
        goto block_0013B978;
    case 0x0013B988U:
        goto block_0013B988;
    case 0x0013B9A0U:
        goto block_0013B9A0;
    case 0x0013B9B8U:
        goto block_0013B9B8;
    case 0x0013B9C4U:
        goto block_0013B9C4;
    case 0x0013B9D8U:
        goto block_0013B9D8;
    case 0x0013B9F0U:
        goto block_0013B9F0;
    case 0x0013B9FCU:
        goto block_0013B9FC;
    case 0x0013BA0CU:
        goto block_0013BA0C;
    case 0x0013BA18U:
        goto block_0013BA18;
    case 0x0013BA28U:
        goto block_0013BA28;
    case 0x0013BA3CU:
        goto block_0013BA3C;
    case 0x0013BA48U:
        goto block_0013BA48;
    case 0x0013BA5CU:
        goto block_0013BA5C;
    case 0x0013BA70U:
        goto block_0013BA70;
    case 0x0013BA7CU:
        goto block_0013BA7C;
    case 0x0013BA98U:
        goto block_0013BA98;
    case 0x0013BAA4U:
        goto block_0013BAA4;
    case 0x0013BAACU:
        goto block_0013BAAC;
    case 0x0013BAB8U:
        goto block_0013BAB8;
    case 0x0013BAC8U:
        goto block_0013BAC8;
    case 0x0013BB34U:
        goto block_0013BB34;
    case 0x0013BB44U:
        goto block_0013BB44;
    case 0x0013BB50U:
        goto block_0013BB50;
    case 0x0013BB60U:
        goto block_0013BB60;
    case 0x0013BB68U:
        goto block_0013BB68;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0013A9B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013A9B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013A9B4U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0013A9B4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0013A9B4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0013A9B4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0013A9B4U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0013A9B4U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0013A9B4U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0013A9B4U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x0013A9B4U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0013A9B4U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r5 = r0;
        }
        {
            r9 = r1;
        }
        {
            const uint32_t updatedAddress = 0x0013A9C8U + 0x3E4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013A9C0U, address);
            }
            r0 = value;
        }
        {
            r13 -= 48U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0013A9C4U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0013A9C4U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0013A9C4U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0013A9C4U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x0013A9C4U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0013A9C4U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, frame.Guest.vfp[22])) {
                return Oot3dAotMemoryFault(context, 0x0013A9C4U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, frame.Guest.vfp[23])) {
                return Oot3dAotMemoryFault(context, 0x0013A9C4U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x0013A9C4U,
                                           firstAddress + 32U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 36U, frame.Guest.vfp[25])) {
                return Oot3dAotMemoryFault(context, 0x0013A9C4U,
                                           firstAddress + 36U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 40U, frame.Guest.vfp[26])) {
                return Oot3dAotMemoryFault(context, 0x0013A9C4U,
                                           firstAddress + 40U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 44U, frame.Guest.vfp[27])) {
                return Oot3dAotMemoryFault(context, 0x0013A9C4U,
                                           firstAddress + 44U);
            }
        }
        {
            const uint32_t operand = 0x0000004CU;
            r13 = r13 - operand;
        }
        {
            const uint32_t updatedAddress = r0 + r1;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013A9CCU, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013A9D0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013A9D8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013A9E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013A9E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013A9E4;
    }
block_0013A9E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013A9E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013A9E4U);
        }
        {
            const uint32_t address = 0x0013A9ECU + 964U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013A9E4U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r4 = r5 + operand;
        }
        {
            const uint32_t address = 0x0013A9F4U + 960U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013A9ECU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = r4 + 696U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0013A9F0U, address);
            }
        }
        {
            const uint32_t address = 0x0013A9FCU + 948U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013A9F4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 700U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0013A9F8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000A00U;
            r8 = r5 + operand;
        }
        {
            const uint32_t address = r4 + 704U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013AA00U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x98U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AA04U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r9 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x48U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0013AA10U, address);
            }
        }
        {
            const uint32_t operand = 0x00003000U;
            r1 = r9 + operand;
        }
        {
            const uint32_t operand = 0x00000258U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0013AA1CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000002ACU;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0013AA30U + 0x3ACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AA28U, address);
            }
            r11 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0013AA2CU, address);
            }
        }
        {
            const uint32_t address = 0x0013AA38U + 896U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AA30U, address);
            }
            frame.Guest.vfp[23] = value;
        }
        {
            const uint32_t address = 0x0013AA3CU + 896U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AA34U, address);
            }
            frame.Guest.vfp[24] = value;
        }
        {
            const uint32_t address = 0x0013AA40U + 896U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AA38U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            const uint32_t address = 0x0013AA44U + 896U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AA3CU, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x0013AA48U + 896U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AA40U, address);
            }
            frame.Guest.vfp[22] = value;
        }
        {
            const uint32_t address = 0x0013AA4CU + 896U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AA44U, address);
            }
            frame.Guest.vfp[21] = value;
        }
        {
            const uint32_t address = 0x0013AA50U + 896U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AA48U, address);
            }
            frame.Guest.vfp[26] = value;
        }
        {
            const uint32_t address = 0x0013AA54U + 896U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AA4CU, address);
            }
            frame.Guest.vfp[25] = value;
        }
        {
            const uint32_t address = 0x0013AA58U + 896U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AA50U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t operand = 0x00005000U;
            r1 = r9 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r10 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00003000U;
            r7 = r9 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x3CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0013AA64U, address);
            }
        }
        if (flags.Z()) { goto block_0013B2AC; }
        goto block_0013AA6C;
    }
block_0013AA6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AA6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AA6CU);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0013AA98; }
        goto block_0013AA74;
    }
block_0013AA74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AA74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AA74U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x0013AA80U + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AA78U, address);
            }
            switch (value) {
            case 0x0013A9B4U:
                goto block_0013A9B4;
            case 0x0013A9E4U:
                goto block_0013A9E4;
            case 0x0013AA6CU:
                goto block_0013AA6C;
            case 0x0013AA74U:
                goto block_0013AA74;
            case 0x0013AA7CU:
                goto block_0013AA7C;
            case 0x0013AA98U:
                goto block_0013AA98;
            case 0x0013AAA0U:
                goto block_0013AAA0;
            case 0x0013AAA8U:
                goto block_0013AAA8;
            case 0x0013AAB0U:
                goto block_0013AAB0;
            case 0x0013AAB8U:
                goto block_0013AAB8;
            case 0x0013AAC0U:
                goto block_0013AAC0;
            case 0x0013AADCU:
                goto block_0013AADC;
            case 0x0013AB28U:
                goto block_0013AB28;
            case 0x0013AB40U:
                goto block_0013AB40;
            case 0x0013AB54U:
                goto block_0013AB54;
            case 0x0013AB5CU:
                goto block_0013AB5C;
            case 0x0013AB64U:
                goto block_0013AB64;
            case 0x0013AB7CU:
                goto block_0013AB7C;
            case 0x0013AB90U:
                goto block_0013AB90;
            case 0x0013ABA0U:
                goto block_0013ABA0;
            case 0x0013ABACU:
                goto block_0013ABAC;
            case 0x0013ABC8U:
                goto block_0013ABC8;
            case 0x0013ABDCU:
                goto block_0013ABDC;
            case 0x0013ABE8U:
                goto block_0013ABE8;
            case 0x0013ABF4U:
                goto block_0013ABF4;
            case 0x0013AC08U:
                goto block_0013AC08;
            case 0x0013AC18U:
                goto block_0013AC18;
            case 0x0013AC28U:
                goto block_0013AC28;
            case 0x0013AC60U:
                goto block_0013AC60;
            case 0x0013AC78U:
                goto block_0013AC78;
            case 0x0013AC84U:
                goto block_0013AC84;
            case 0x0013ACA0U:
                goto block_0013ACA0;
            case 0x0013ACACU:
                goto block_0013ACAC;
            case 0x0013ACC4U:
                goto block_0013ACC4;
            case 0x0013ACD0U:
                goto block_0013ACD0;
            case 0x0013ACF0U:
                goto block_0013ACF0;
            case 0x0013ACFCU:
                goto block_0013ACFC;
            case 0x0013AD14U:
                goto block_0013AD14;
            case 0x0013AD38U:
                goto block_0013AD38;
            case 0x0013AD44U:
                goto block_0013AD44;
            case 0x0013AD4CU:
                goto block_0013AD4C;
            case 0x0013AD58U:
                goto block_0013AD58;
            case 0x0013AD64U:
                goto block_0013AD64;
            case 0x0013AD7CU:
                goto block_0013AD7C;
            case 0x0013AD84U:
                goto block_0013AD84;
            case 0x0013AD94U:
                goto block_0013AD94;
            case 0x0013ADA4U:
                goto block_0013ADA4;
            case 0x0013AE34U:
                goto block_0013AE34;
            case 0x0013AE40U:
                goto block_0013AE40;
            case 0x0013AE50U:
                goto block_0013AE50;
            case 0x0013AED0U:
                goto block_0013AED0;
            case 0x0013AEE8U:
                goto block_0013AEE8;
            case 0x0013AF04U:
                goto block_0013AF04;
            case 0x0013AF24U:
                goto block_0013AF24;
            case 0x0013AF50U:
                goto block_0013AF50;
            case 0x0013AF6CU:
                goto block_0013AF6C;
            case 0x0013AF88U:
                goto block_0013AF88;
            case 0x0013AFA0U:
                goto block_0013AFA0;
            case 0x0013AFC8U:
                goto block_0013AFC8;
            case 0x0013B00CU:
                goto block_0013B00C;
            case 0x0013B024U:
                goto block_0013B024;
            case 0x0013B034U:
                goto block_0013B034;
            case 0x0013B040U:
                goto block_0013B040;
            case 0x0013B04CU:
                goto block_0013B04C;
            case 0x0013B060U:
                goto block_0013B060;
            case 0x0013B074U:
                goto block_0013B074;
            case 0x0013B088U:
                goto block_0013B088;
            case 0x0013B094U:
                goto block_0013B094;
            case 0x0013B0A4U:
                goto block_0013B0A4;
            case 0x0013B0BCU:
                goto block_0013B0BC;
            case 0x0013B0C8U:
                goto block_0013B0C8;
            case 0x0013B0ECU:
                goto block_0013B0EC;
            case 0x0013B0F8U:
                goto block_0013B0F8;
            case 0x0013B110U:
                goto block_0013B110;
            case 0x0013B134U:
                goto block_0013B134;
            case 0x0013B13CU:
                goto block_0013B13C;
            case 0x0013B15CU:
                goto block_0013B15C;
            case 0x0013B170U:
                goto block_0013B170;
            case 0x0013B1A0U:
                goto block_0013B1A0;
            case 0x0013B1B0U:
                goto block_0013B1B0;
            case 0x0013B1BCU:
                goto block_0013B1BC;
            case 0x0013B1CCU:
                goto block_0013B1CC;
            case 0x0013B1D8U:
                goto block_0013B1D8;
            case 0x0013B1E8U:
                goto block_0013B1E8;
            case 0x0013B238U:
                goto block_0013B238;
            case 0x0013B244U:
                goto block_0013B244;
            case 0x0013B280U:
                goto block_0013B280;
            case 0x0013B290U:
                goto block_0013B290;
            case 0x0013B2A0U:
                goto block_0013B2A0;
            case 0x0013B2ACU:
                goto block_0013B2AC;
            case 0x0013B2C4U:
                goto block_0013B2C4;
            case 0x0013B2F0U:
                goto block_0013B2F0;
            case 0x0013B30CU:
                goto block_0013B30C;
            case 0x0013B328U:
                goto block_0013B328;
            case 0x0013B338U:
                goto block_0013B338;
            case 0x0013B344U:
                goto block_0013B344;
            case 0x0013B350U:
                goto block_0013B350;
            case 0x0013B35CU:
                goto block_0013B35C;
            case 0x0013B370U:
                goto block_0013B370;
            case 0x0013B380U:
                goto block_0013B380;
            case 0x0013B39CU:
                goto block_0013B39C;
            case 0x0013B3A8U:
                goto block_0013B3A8;
            case 0x0013B3CCU:
                goto block_0013B3CC;
            case 0x0013B3E4U:
                goto block_0013B3E4;
            case 0x0013B3FCU:
                goto block_0013B3FC;
            case 0x0013B424U:
                goto block_0013B424;
            case 0x0013B444U:
                goto block_0013B444;
            case 0x0013B464U:
                goto block_0013B464;
            case 0x0013B47CU:
                goto block_0013B47C;
            case 0x0013B49CU:
                goto block_0013B49C;
            case 0x0013B4BCU:
                goto block_0013B4BC;
            case 0x0013B4D8U:
                goto block_0013B4D8;
            case 0x0013B4E8U:
                goto block_0013B4E8;
            case 0x0013B4F0U:
                goto block_0013B4F0;
            case 0x0013B4FCU:
                goto block_0013B4FC;
            case 0x0013B50CU:
                goto block_0013B50C;
            case 0x0013B53CU:
                goto block_0013B53C;
            case 0x0013B578U:
                goto block_0013B578;
            case 0x0013B588U:
                goto block_0013B588;
            case 0x0013B598U:
                goto block_0013B598;
            case 0x0013B5C8U:
                goto block_0013B5C8;
            case 0x0013B5D4U:
                goto block_0013B5D4;
            case 0x0013B5E0U:
                goto block_0013B5E0;
            case 0x0013B5F4U:
                goto block_0013B5F4;
            case 0x0013B674U:
                goto block_0013B674;
            case 0x0013B684U:
                goto block_0013B684;
            case 0x0013B690U:
                goto block_0013B690;
            case 0x0013B740U:
                goto block_0013B740;
            case 0x0013B758U:
                goto block_0013B758;
            case 0x0013B768U:
                goto block_0013B768;
            case 0x0013B774U:
                goto block_0013B774;
            case 0x0013B794U:
                goto block_0013B794;
            case 0x0013B7A8U:
                goto block_0013B7A8;
            case 0x0013B7C0U:
                goto block_0013B7C0;
            case 0x0013B7D0U:
                goto block_0013B7D0;
            case 0x0013B7DCU:
                goto block_0013B7DC;
            case 0x0013B7F0U:
                goto block_0013B7F0;
            case 0x0013B800U:
                goto block_0013B800;
            case 0x0013B80CU:
                goto block_0013B80C;
            case 0x0013B81CU:
                goto block_0013B81C;
            case 0x0013B828U:
                goto block_0013B828;
            case 0x0013B85CU:
                goto block_0013B85C;
            case 0x0013B86CU:
                goto block_0013B86C;
            case 0x0013B878U:
                goto block_0013B878;
            case 0x0013B8A4U:
                goto block_0013B8A4;
            case 0x0013B8B0U:
                goto block_0013B8B0;
            case 0x0013B8D0U:
                goto block_0013B8D0;
            case 0x0013B8F0U:
                goto block_0013B8F0;
            case 0x0013B910U:
                goto block_0013B910;
            case 0x0013B920U:
                goto block_0013B920;
            case 0x0013B938U:
                goto block_0013B938;
            case 0x0013B94CU:
                goto block_0013B94C;
            case 0x0013B960U:
                goto block_0013B960;
            case 0x0013B96CU:
                goto block_0013B96C;
            case 0x0013B978U:
                goto block_0013B978;
            case 0x0013B988U:
                goto block_0013B988;
            case 0x0013B9A0U:
                goto block_0013B9A0;
            case 0x0013B9B8U:
                goto block_0013B9B8;
            case 0x0013B9C4U:
                goto block_0013B9C4;
            case 0x0013B9D8U:
                goto block_0013B9D8;
            case 0x0013B9F0U:
                goto block_0013B9F0;
            case 0x0013B9FCU:
                goto block_0013B9FC;
            case 0x0013BA0CU:
                goto block_0013BA0C;
            case 0x0013BA18U:
                goto block_0013BA18;
            case 0x0013BA28U:
                goto block_0013BA28;
            case 0x0013BA3CU:
                goto block_0013BA3C;
            case 0x0013BA48U:
                goto block_0013BA48;
            case 0x0013BA5CU:
                goto block_0013BA5C;
            case 0x0013BA70U:
                goto block_0013BA70;
            case 0x0013BA7CU:
                goto block_0013BA7C;
            case 0x0013BA98U:
                goto block_0013BA98;
            case 0x0013BAA4U:
                goto block_0013BAA4;
            case 0x0013BAACU:
                goto block_0013BAAC;
            case 0x0013BAB8U:
                goto block_0013BAB8;
            case 0x0013BAC8U:
                goto block_0013BAC8;
            case 0x0013BB34U:
                goto block_0013BB34;
            case 0x0013BB44U:
                goto block_0013BB44;
            case 0x0013BB50U:
                goto block_0013BB50;
            case 0x0013BB60U:
                goto block_0013BB60;
            case 0x0013BB68U:
                goto block_0013BB68;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_0013AA7C;
    }
block_0013AA7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AA7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AA7CU);
        }
        goto block_0013BA70;
    }
block_0013AA98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AA98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AA98U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0013B8B0; }
        goto block_0013AAA0;
    }
block_0013AAA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AAA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AAA0U);
        }
        {
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_0013AB54; }
        goto block_0013AAA8;
    }
block_0013AAA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AAA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AAA8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0013B3CC; }
        goto block_0013AAB0;
    }
block_0013AAB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AAB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AAB0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0013B740; }
        goto block_0013AAB8;
    }
block_0013AAB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AAB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AAB8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000009U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013BA70; }
        goto block_0013AAC0;
    }
block_0013AAC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AAC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AAC0U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = 0x0013AACCU + 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AAC4U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r9;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013AADCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013AADCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013AADC;
    }
block_0013AADC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AADCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AADCU);
        }
        {
            r0 = 0x00000018U;
        }
        {
            const uint32_t address = 0x0013AAE8U + 764U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AAE0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013AAE4U, address);
            }
        }
        {
            const uint32_t address = r4 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013AAE8U, address);
            }
        }
        {
            const uint32_t address = 0x0013AAF4U + 756U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AAECU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013AAF0U, address);
            }
        }
        {
            const uint32_t address = 0x0013AAFCU + 752U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AAF4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013AAF8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AAFCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AB00U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013AB04U, address);
            }
        }
        {
            const uint32_t address = r0 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AB08U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013AB0CU, 0xEE300A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013AB10U, address);
            }
        }
        {
            const uint32_t address = r0 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AB14U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013AB18U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AB1CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000005AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0013BA70; }
        goto block_0013AB28;
    }
block_0013AB28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AB28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AB28U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            r2 = 0x00000000U;
        }
        {
            r1 = r9;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013AB40U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013AB40U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013AB40;
    }
block_0013AB40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AB40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AB40U);
        }
        {
            r0 = 0x0000000AU;
        }
        {
            const uint32_t updatedAddress = r8 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013AB44U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0013AB48U, address);
            }
        }
        {
            const uint32_t address = r4 + 780U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0013AB4CU, address);
            }
        }
        goto block_0013BA70;
    }
block_0013AB54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AB54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AB54U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000014U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0013BA48; }
        goto block_0013AB5C;
    }
block_0013AB5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AB5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AB5CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013BA70; }
        goto block_0013AB64;
    }
block_0013AB64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AB64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AB64U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[23];
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0013AB74U + 636U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AB6CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r9;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013AB7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013AB7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013AB7C;
    }
block_0013AB7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AB7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AB7CU);
        }
        {
            r0 = 0x00000017U;
        }
        {
            const uint32_t updatedAddress = r5 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013AB80U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AB84U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000053U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013BA70; }
        goto block_0013AB90;
    }
block_0013AB90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AB90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AB90U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r1 = 0x00000017U;
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013ABA0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013ABA0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013ABA0;
    }
block_0013ABA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013ABA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013ABA0U);
        }
        {
            r1 = 0x00000017U;
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013ABACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013ABACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013ABAC;
    }
block_0013ABAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013ABACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013ABACU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r2 = 0x00000062U;
        }
        {
            r1 = r5;
        }
        {
            r0 = r9;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013ABBCU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 140U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013ABC0U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013ABC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013ABC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013ABC8;
    }
block_0013ABC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013ABC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013ABC8U);
        }
        {
            r0 = 0x00000008U;
        }
        {
            const uint32_t updatedAddress = r8 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013ABCCU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0013ABD8U + 0x21CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013ABD0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013ABD4U, address);
            }
        }
        goto block_0013BA70;
    }
block_0013ABDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013ABDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013ABDCU);
        }
        {
            const uint32_t updatedAddress = r13 + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013ABDCU, address);
            }
            r1 = value;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013ABE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartSkippable_00367494(frame, context, state, 0x00367494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013ABE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013ABE8;
    }
block_0013ABE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013ABE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013ABE8U);
        }
        {
            r0 = r9;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013ABF4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CreateSubCamera_00367D74(frame, context, state, 0x00367D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013ABF4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013ABF4;
    }
block_0013ABF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013ABF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013ABF4U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x9AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013ABF4U, address);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013AC08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013AC08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013AC08;
    }
block_0013AC08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AC08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AC08U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x9AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AC08U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x00000007U;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013AC18U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013AC18U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013AC18;
    }
block_0013AC18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AC18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AC18U);
        }
        {
            r2 = 0x00000008U;
        }
        {
            r1 = r5;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013AC28U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013AC28U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013AC28;
    }
block_0013AC28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AC28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AC28U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r8 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013AC2CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0013AC30U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AC34U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000009U;
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013AC40U, address);
            }
        }
        {
            const uint32_t address = r4 + 544U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0013AC44U, address);
            }
        }
        {
            const uint32_t address = r5 + 108U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0013AC48U, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x18U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0013AC4CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r8 + 0x16U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0013AC50U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x9EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0013AC54U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA32U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0013AC58U, address);
            }
        }
        {
            const uint32_t address = r7 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0013AC5CU, address);
            }
        }
        goto block_0013AC60;
    }
block_0013AC60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AC60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AC60U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[23];
        }
        {
            r2 = 0x00000005U;
        }
        {
            const uint32_t address = 0x0013AC70U + 392U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AC68U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r9;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013AC78U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013AC78U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013AC78;
    }
block_0013AC78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AC78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AC78U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AC78U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000087U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0013ACAC; }
        goto block_0013AC84;
    }
block_0013AC84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AC84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AC84U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r0 = 0x00000014U;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[26];
        }
        {
            const uint32_t updatedAddress = r5 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013AC90U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AC94U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013ACA0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013ACA0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013ACA0;
    }
block_0013ACA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013ACA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013ACA0U);
        }
        {
        }
        {
        }
        goto block_0013ACC4;
    }
block_0013ACAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013ACACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013ACACU);
        }
        {
            r0 = 0x00000015U;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r5 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013ACB4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013ACB8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0013ACC4U + 312U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013ACBCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013ACC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013ACC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013ACC4;
    }
block_0013ACC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013ACC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013ACC4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013ACC4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013ACF0; }
        goto block_0013ACD0;
    }
block_0013ACD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013ACD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013ACD0U);
        }
        {
            const uint32_t updatedAddress = 0x0013ACD8U + 0x128U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013ACD0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0013ACDCU + 0x128U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013ACD4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0013ACE0U + 0x128U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013ACD8U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0013ACE0U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013ACF0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013ACF0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013ACF0;
    }
block_0013ACF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013ACF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013ACF0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013ACF0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000087U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0013AD38; }
        goto block_0013ACFC;
    }
block_0013ACFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013ACFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013ACFCU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = 0x0013AD0CU + 256U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AD04U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0013AD10U + 256U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AD08U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000027CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013AD14U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013AD14U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013AD14;
    }
block_0013AD14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AD14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AD14U);
        }
        {
            const uint32_t updatedAddress = 0x0013AD1CU + 0xE4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AD14U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0013AD20U + 0xE4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AD18U, address);
            }
            r2 = value;
        }
        {
            const uint32_t address = r4 + 632U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0013AD1CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0013AD28U + 0xECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AD20U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0013AD24U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013AD38U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013AD38U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013AD38;
    }
block_0013AD38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AD38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AD38U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AD38U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000A5U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_0013AD84; }
        goto block_0013AD44;
    }
block_0013AD44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AD44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AD44U);
        }
        {
        }
        if (!(flags.Z())) { goto block_0013AD64; }
        goto block_0013AD4C;
    }
block_0013AD4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AD4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AD4CU);
        }
        {
            const uint32_t updatedAddress = 0x0013AD54U + 0xC4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AD4CU, address);
            }
            r1 = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013AD58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013AD58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013AD58;
    }
block_0013AD58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AD58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AD58U);
        }
        {
            const uint32_t updatedAddress = 0x0013AD60U + 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AD58U, address);
            }
            r1 = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013AD64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013AD64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013AD64;
    }
block_0013AD64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AD64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AD64U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[25];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = 0x0013AD74U + 172U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AD6CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0013AD78U + 172U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AD70U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000208U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013AD7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013AD7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013AD7C;
    }
block_0013AD7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AD7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AD7CU);
        }
        {
            const uint32_t address = 0x0013AD84U + 164U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AD7CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 616U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013AD80U, address);
            }
        }
        goto block_0013AD84;
    }
block_0013AD84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AD84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AD84U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x0013AD90U + 156U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AD88U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013AD94U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013AD94U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013AD94;
    }
block_0013AD94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AD94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AD94U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t updatedAddress = 0x0013ADA0U + 0x90U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AD98U, address);
            }
            r1 = value;
        }
        if (!(flags.Z())) {
            r0 = r5;
        }
        if (!(flags.Z())) {
            ++context.Stats.DirectCalls;
            r14 = 0x0013ADA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013ADA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013ADA4;
    }
block_0013ADA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013ADA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013ADA4U);
        }
        {
        }
        goto block_0013AE34;
    }
block_0013AE34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AE34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AE34U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AE34U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000B4U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013AE50; }
        goto block_0013AE40;
    }
block_0013AE40:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AE40U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AE40U);
        }
        {
            r2 = 0x00000063U;
        }
        {
            r1 = r5;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013AE50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013AE50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013AE50;
    }
block_0013AE50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AE50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AE50U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r0 = 0x00004000U;
        }
        {
            const uint32_t address = 0x0013AE60U + 800U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AE58U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013AE5CU, address);
            }
        }
        {
            const uint32_t address = r5 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013AE60U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013AE64U, address);
            }
        }
        {
            const uint32_t address = r6 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0013AE68U, address);
            }
        }
        {
            r0 = 0x0000C000U;
        }
        {
            const uint32_t address = r6 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x0013AE70U, address);
            }
        }
        {
            const uint32_t operand = 0x0000E000U;
            r1 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r6 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013AE78U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AE7CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0013AE88U + 756U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AE80U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013AE84U, address);
            }
        }
        {
            const uint32_t address = r0 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0013AE88U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0013AE8CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0013AE90U, address);
            }
        }
        {
            const uint32_t address = r4 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x0013AE94U, address);
            }
        }
        {
            const uint32_t address = r4 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0013AE98U, address);
            }
        }
        {
            const uint32_t address = r4 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0013AE9CU, address);
            }
        }
        {
            const uint32_t address = r4 + 180U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AEA0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013AEA4U, address);
            }
        }
        {
            const uint32_t address = r4 + 184U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AEA8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013AEACU, address);
            }
        }
        {
            const uint32_t address = r4 + 188U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AEB0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013AEB4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AEB8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000CBU, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) {
            r0 = 0x00000002U;
        }
        if ((flags.C()) && !(flags.Z())) {
            const uint32_t updatedAddress = r8 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013AEC4U, address);
            }
        }
        if ((flags.C()) && !(flags.Z())) {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0013AEC8U, address);
            }
        }
        goto block_0013BA70;
    }
block_0013AED0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AED0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AED0U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[23];
        }
        {
            r2 = 0x00000005U;
        }
        {
            const uint32_t address = 0x0013AEE0U + 676U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AED8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r9;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013AEE8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013AEE8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013AEE8;
    }
block_0013AEE8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AEE8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AEE8U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r0 = 0x00000016U;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[26];
        }
        {
            const uint32_t updatedAddress = r5 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013AEF4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AEF8U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013AF04U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013AF04U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013AF04;
    }
block_0013AF04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AF04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AF04U);
        }
        {
            const uint32_t updatedAddress = 0x0013AF0CU - 0x10CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AF04U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0013AF10U - 0x10CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AF08U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0013AF14U - 0x100U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AF0CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0013AF14U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013AF24U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013AF24U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013AF24;
    }
block_0013AF24:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AF24U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AF24U);
        }
        {
            const uint32_t address = r4 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x0013AF24U, address);
            }
        }
        {
            const uint32_t address = r4 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0013AF28U, address);
            }
        }
        {
            const uint32_t address = r4 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0013AF2CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AF30U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0013AF3CU + 588U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AF34U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x0013AF40U - 284U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AF38U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            const uint32_t address = r0 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AF44U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AF48U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013AF50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013AF50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013AF50;
    }
block_0013AF50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AF50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AF50U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AF50U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[25];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            const uint32_t address = r0 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AF5CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000AB0U;
            r0 = r5 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013AF64U, 0xEE300A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013AF6CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013AF6CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013AF6C;
    }
block_0013AF6C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AF6CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AF6CU);
        }
        {
            const uint32_t updatedAddress = r11 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AF6CU, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            const uint32_t address = r0 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AF78U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000002B4U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013AF88U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013AF88U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013AF88;
    }
block_0013AF88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AF88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AF88U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AF88U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r0 = 0x00000003U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r8 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013AF94U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0013AF98U, address);
            }
        }
        goto block_0013BA70;
    }
block_0013AFA0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AFA0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AFA0U);
        }
        {
            const uint32_t updatedAddress = 0x0013AFA8U - 0x1A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AFA0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0013AFACU - 0x1A8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AFA4U, address);
            }
            r2 = value;
        }
        {
            r0 = 0x00000016U;
        }
        {
            const uint32_t updatedAddress = r5 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013AFACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0013AFB0U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0013AFC0U - 0x1ACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AFB8U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013AFC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013AFC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013AFC8;
    }
block_0013AFC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013AFC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013AFC8U);
        }
        {
            const uint32_t address = 0x0013AFD0U - 492U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AFC8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013AFCCU, address);
            }
        }
        {
            const uint32_t address = 0x0013AFD8U - 496U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AFD0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013AFD4U, address);
            }
        }
        {
            const uint32_t address = 0x0013AFE0U - 500U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AFD8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013AFDCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AFE0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AFE4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013AFE8U, address);
            }
        }
        {
            const uint32_t address = r0 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AFECU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013AFF0U, 0xEE300A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013AFF4U, address);
            }
        }
        {
            const uint32_t address = r0 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013AFF8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013AFFCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B000U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013B034; }
        goto block_0013B00C;
    }
block_0013B00C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B00CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B00CU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[23];
        }
        {
            r2 = 0x00000002U;
        }
        {
            const uint32_t address = 0x0013B01CU + 368U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B014U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r9;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B024U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B024U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B024;
    }
block_0013B024:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B024U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B024U);
        }
        {
            const uint32_t updatedAddress = 0x0013B02CU + 0x164U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B024U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B034U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B034U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B034;
    }
block_0013B034:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B034U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B034U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B034U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000078U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0013BA70; }
        goto block_0013B040;
    }
block_0013B040:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B040U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B040U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r9 + operand;
        }
        {
            const uint32_t operand = 0x000008A0U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B04CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_GetState_003769D8(frame, context, state, 0x003769D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B04CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B04C;
    }
block_0013B04C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B04CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B04CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r0 = 0x00000004U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r8 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013B054U, address);
            }
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0013B058U, address);
            }
        }
        goto block_0013BA70;
    }
block_0013B060:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B060U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B060U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B060U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) {
            r0 = 0x00000016U;
        }
        if (!(flags.C()) || (flags.Z())) {
            const uint32_t updatedAddress = r5 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013B06CU, address);
            }
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0013B0BC; }
        goto block_0013B074;
    }
block_0013B074:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B074U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B074U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[25];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000278U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B088U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B088U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B088;
    }
block_0013B088:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B088U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B088U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B088U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013B0A4; }
        goto block_0013B094;
    }
block_0013B094:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B094U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B094U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B094U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x0000000AU;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0013B0A0U, address);
            }
        }
        goto block_0013B0A4;
    }
block_0013B0A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B0A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B0A4U);
        }
        {
            r0 = 0x00000017U;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r5 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013B0ACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B0B0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0013B0BCU + 216U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B0B4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B0BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B0BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B0BC;
    }
block_0013B0BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B0BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B0BCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B0BCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000096U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013BA70; }
        goto block_0013B0C8;
    }
block_0013B0C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B0C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B0C8U);
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r8 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013B0CCU, address);
            }
        }
        {
            r0 = 0x0000003CU;
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013B0D4U, address);
            }
        }
        {
            const uint32_t address = r5 + 616U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0013B0D8U, address);
            }
        }
        {
            r2 = 0x00000064U;
        }
        {
            r1 = r5;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B0ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B0ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B0EC;
    }
block_0013B0EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B0ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B0ECU);
        }
        {
        }
        {
        }
        goto block_0013BA70;
    }
block_0013B0F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B0F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B0F8U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[22];
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = r9;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B110U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B110U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B110;
    }
block_0013B110:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B110U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B110U);
        }
        {
            r0 = 0x00000017U;
        }
        {
            const uint32_t updatedAddress = r5 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013B114U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B118U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0013B124U + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B11CU, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r7 = r5 + operand;
        }
        {
            const uint32_t operand = 0x0000005AU;
            r1 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t operand = 0x00000288U;
            r7 = r7 + operand;
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0013B1A0; }
        goto block_0013B134;
    }
block_0013B134:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B134U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B134U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000005DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013B15C; }
        goto block_0013B13C;
    }
block_0013B13C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B13CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B13CU);
        }
        {
            const uint32_t updatedAddress = 0x0013B144U - 0x344U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B13CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0013B148U - 0x344U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B140U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0013B14CU + 0x50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B144U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0013B14CU, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B15CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B15CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B15C;
    }
block_0013B15C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B15CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B15CU);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[21];
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B170U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B170U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B170;
    }
block_0013B170:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B170U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B170U);
        }
        {
        }
        {
        }
        goto block_0013B1B0;
    }
block_0013B1A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B1A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B1A0U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[19];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B1B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B1B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B1B0;
    }
block_0013B1B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B1B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B1B0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B1B0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000069U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013B1CC; }
        goto block_0013B1BC;
    }
block_0013B1BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B1BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B1BCU);
        }
        {
            r2 = 0x00000065U;
        }
        {
            r1 = r5;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B1CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B1CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B1CC;
    }
block_0013B1CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B1CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B1CCU);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B1CCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000E1U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013B1E8; }
        goto block_0013B1D8;
    }
block_0013B1D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B1D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B1D8U);
        }
        {
            r2 = 0x00000066U;
        }
        {
            r1 = r5;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B1E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B1E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B1E8;
    }
block_0013B1E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B1E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B1E8U);
        }
        {
            const uint32_t address = r4 + 520U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[25])) {
                return Oot3dAotMemoryFault(context, 0x0013B1E8U, address);
            }
        }
        {
            const uint32_t address = r6 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x0013B1ECU, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x0013B1F0U, address);
            }
        }
        {
            const uint32_t address = r4 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0013B1F4U, address);
            }
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B1F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B1FCU, 0xEE300A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B200U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B204U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B208U, 0xEE300A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B20CU, address);
            }
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B210U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B214U, address);
            }
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B218U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B21CU, 0xEE300A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B220U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B224U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B228U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B22CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000F9U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013BA70; }
        goto block_0013B238;
    }
block_0013B238:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B238U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B238U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B244U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B244U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B244;
    }
block_0013B244:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B244U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B244U);
        }
        {
            const uint32_t operand = 0x00000AA0U;
            r1 = r5 + operand;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r6 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0013B24CU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0013B24CU,
                                           firstAddress + 4U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0013B24CU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r7 = value7;
        }
        {
            const uint32_t firstAddress = r6;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0013B250U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0013B250U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0013B250U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x000000A4U;
            r6 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0013B258U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0013B258U,
                                           firstAddress + 4U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0013B258U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r7 = value7;
        }
        {
            const uint32_t operand = 0x00000080U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r6;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0013B260U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0013B260U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0013B260U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B264U, address);
            }
            r1 = value;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0013B268U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0013B268U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0013B268U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r6 = value6;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0013B26CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0013B26CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0013B26CU,
                                           firstAddress + 8U);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r8 + 0x9AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B274U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B280U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ClearCameraAndRestoreMain_0036E9B8(frame, context, state, 0x0036E9B8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B280U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B280;
    }
block_0013B280:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B280U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B280U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x9AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0013B280U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B284U, address);
            }
            r1 = value;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B290U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartUnskippable_00367374(frame, context, state, 0x00367374U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B290U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B290;
    }
block_0013B290:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B290U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B290U);
        }
        {
            r2 = 0x00000007U;
        }
        {
            r1 = r5;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B2A0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B2A0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B2A0;
    }
block_0013B2A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B2A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B2A0U);
        }
        {
            r0 = 0x00000006U;
        }
        {
            const uint32_t updatedAddress = r8 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013B2A4U, address);
            }
        }
        goto block_0013BA70;
    }
block_0013B2AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B2ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B2ACU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[22];
        }
        {
            r2 = ~(0x00000000U);
        }
        {
            r1 = r9;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B2C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B2C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B2C4;
    }
block_0013B2C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B2C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B2C4U);
        }
        {
            r0 = 0x00000017U;
        }
        {
            const uint32_t updatedAddress = r5 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013B2C8U, address);
            }
        }
        {
            const uint32_t address = r4 + 180U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B2CCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B2D0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B2D4U, 0xEE70BA60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[23], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 188U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B2D8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B2DCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B2E0U, 0xEE709A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[19], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[23];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[19];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B2F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_Atan2S_003758B0(frame, context, state, 0x003758B0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B2F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B2F0;
    }
block_0013B2F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B2F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B2F0U);
        }
        {
            const uint32_t updatedAddress = r6 + 0xBEU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B2F0U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = r1;
            r0 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = 0x0013B300U + 0x3D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B2F8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r1;
            r0 = value;
        }
        {
            r1 = Oot3dAotLsl(r1, 1U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0013BA70; }
        goto block_0013B30C;
    }
block_0013B30C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B30CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B30CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B30CU, 0xEE2B0AABU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[23], frame.Guest.vfp[23], frame.Guest.fpscr));
        }
        {
            const uint32_t updatedAddress = 0x0013B318U + 0x3C4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B310U, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B314U, 0xEE090AA9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32MultiplyAccumulate(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B318U, 0xEEB10AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32SquareRoot(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x9U));
        }
        if ((flags.N()) == (flags.V())) { goto block_0013BA70; }
        goto block_0013B328;
    }
block_0013B328:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B328U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B328U);
        }
        {
            const uint32_t updatedAddress = 0x0013B330U + 0x3B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B328U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r6;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B32CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) { goto block_0013BA70; }
        goto block_0013B338;
    }
block_0013B338:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B338U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B338U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x1A9U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B338U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000003U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013BA70; }
        goto block_0013B344;
    }
block_0013B344:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B344U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B344U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x48U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B344U, address);
            }
            r1 = value;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B350U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartSkippable_00367494(frame, context, state, 0x00367494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B350U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B350;
    }
block_0013B350:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B350U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B350U);
        }
        {
            r0 = r9;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B35CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CreateSubCamera_00367D74(frame, context, state, 0x00367D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B35CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B35C;
    }
block_0013B35C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B35CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B35CU);
        }
        {
            const uint32_t updatedAddress = r8 + 0x9AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013B35CU, address);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B370U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B370U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B370;
    }
block_0013B370:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B370U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B370U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x9AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B370U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x00000007U;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B380U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B380U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B380;
    }
block_0013B380:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B380U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B380U);
        }
        {
            r0 = 0x00000007U;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t updatedAddress = r8 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013B388U, address);
            }
        }
        {
            r1 = 0x00000016U;
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r5 + operand;
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0013B394U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B39CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B39CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B39C;
    }
block_0013B39C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B39CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B39CU);
        }
        {
            r1 = 0x00000016U;
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B3A8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B3A8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B3A8;
    }
block_0013B3A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B3A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B3A8U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r2 = 0x00000061U;
        }
        {
            r1 = r5;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B3B4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 140U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B3B8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B3BCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xBA4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B3C0U, address);
            }
            r3 = value;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.IndirectCalls;
            r14 = 0x0013B3CCU;
            commitState();
            const Oot3dWholeAotFlow callFlow =
                ExecuteOot3dWholeAotIndirect(
                    r3, frame, context, state);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B3CCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B3CC;
    }
block_0013B3CC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B3CCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B3CCU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0013B3DCU + 776U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B3D4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r9;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B3E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B3E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B3E4;
    }
block_0013B3E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B3E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B3E4U);
        }
        {
            r0 = 0x00000017U;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r5 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013B3ECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B3F0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0013B3FCU + 748U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B3F4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B3FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B3FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B3FC;
    }
block_0013B3FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B3FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B3FCU);
        }
        {
            const uint32_t address = r6 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x0013B3FCU, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[24])) {
                return Oot3dAotMemoryFault(context, 0x0013B400U, address);
            }
        }
        {
            r0 = 0x0000C000U;
        }
        {
            const uint32_t updatedAddress = r6 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013B408U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B40CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000062U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000003CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013B464; }
        goto block_0013B424;
    }
block_0013B424:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B424U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B424U);
        }
        {
            const uint32_t updatedAddress = 0x0013B42CU - 0x62CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B424U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0013B430U - 0x62CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B428U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0013B434U + 0x2B8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B42CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0013B434U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B444U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B444U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B444;
    }
block_0013B444:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B444U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B444U);
        }
        {
            const uint32_t updatedAddress = 0x0013B44CU - 0x64CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B444U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0013B450U - 0x64CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B448U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0013B454U + 0x29CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B44CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0013B454U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B464U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B464U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B464;
    }
block_0013B464:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B464U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B464U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B464U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000021U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000035U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000006CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000044U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013B588; }
        goto block_0013B47C;
    }
block_0013B47C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B47CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B47CU);
        }
        {
            const uint32_t updatedAddress = 0x0013B484U - 0x684U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B47CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0013B488U - 0x684U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B480U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0013B48CU - 0x670U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B484U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0013B48CU, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B49CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B49CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B49C;
    }
block_0013B49C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B49CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B49CU);
        }
        {
            const uint32_t updatedAddress = 0x0013B4A4U - 0x6A4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B49CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0013B4A8U - 0x6A4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B4A0U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0013B4ACU + 0x248U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B4A4U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0013B4ACU, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B4BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B4BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B4BC;
    }
block_0013B4BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B4BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B4BCU);
        }
        {
            const uint32_t address = r7 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0013B4BCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B4C0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000021U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000035U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000006CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000044U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013B588; }
        goto block_0013B4D8;
    }
block_0013B4D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B4D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B4D8U);
        }
        {
            r7 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0013B4E4U + 532U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B4DCU, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            const uint32_t address = 0x0013B4E8U + 532U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B4E0U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            r11 = 0x00000032U;
        }
        goto block_0013B4E8;
    }
block_0013B4E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B4E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B4E8U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B4F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B4F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B4F0;
    }
block_0013B4F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B4F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B4F0U);
        }
        {
            const uint32_t address = r13 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B4F0U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[25];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B4FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B4FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B4FC;
    }
block_0013B4FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B4FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B4FCU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B4FCU, 0xEE300A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r13 + 52U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B500U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B50CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_CenteredFloat_003738A8(frame, context, state, 0x003738A8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B50CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B50C;
    }
block_0013B50C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B50CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B50CU);
        }
        {
            const uint32_t address = r13 + 56U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B50CU, address);
            }
        }
        {
            const uint32_t address = r13 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0013B510U, address);
            }
        }
        {
            const uint32_t address = r13 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x0013B514U, address);
            }
        }
        {
            const uint32_t address = r13 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0013B518U, address);
            }
        }
        {
            const uint32_t address = r4 + 180U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B51CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B520U, address);
            }
        }
        {
            const uint32_t address = r4 + 184U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B524U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B528U, address);
            }
        }
        {
            const uint32_t address = r4 + 188U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B52CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r13 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B530U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B53CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Rand_ZeroFloat_00371E50(frame, context, state, 0x00371E50U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B53CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B53C;
    }
block_0013B53C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B53CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B53CU);
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B53CU, 0xEEBD0AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32ToSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            r3 = 0x00000011U;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            value += r11;
            r0 = value;
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0013B55CU + 0x1A4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B554U, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0013B558U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0013B558U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0013B558U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0013B558U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000030U;
            r2 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000004U;
            r3 = r0 - operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0013B564U, address);
            }
        }
        {
            const uint32_t operand = 0x00000024U;
            r3 = r13 + operand;
        }
        {
            const uint32_t operand = 0x00000018U;
            r1 = r13 + operand;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B578U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_EffectSsDust_SpawnUpdateRateScaled_00365D20(frame, context, state, 0x00365D20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B578U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B578;
    }
block_0013B578:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B578U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B578U);
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r7 + operand;
        }
        {
            r7 = r0 & 0x000000FFU;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r7, 0x00000046U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_0013B4E8; }
        goto block_0013B588;
    }
block_0013B588:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B588U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B588U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B588U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000033U;
            r1 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000009U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (flags.C()) { goto block_0013B5C8; }
        goto block_0013B598;
    }
block_0013B598:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B598U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B598U);
        }
        {
            const uint32_t address = 0x0013B5A0U + 356U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B598U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B59CU, address);
            }
        }
        {
            const uint32_t address = 0x0013B5A8U + 352U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B5A0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B5A4U, address);
            }
        }
        {
            const uint32_t address = 0x0013B5B0U + 348U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B5A8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B5ACU, address);
            }
        }
        {
            const uint32_t address = 0x0013B5B8U + 344U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B5B0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B5B4U, address);
            }
        }
        {
            const uint32_t address = 0x0013B5C0U + 340U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B5B8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B5BCU, address);
            }
        }
        {
            const uint32_t address = 0x0013B5C8U + 336U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B5C0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_0013B674;
    }
block_0013B5C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B5C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B5C8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) {
            r0 = 0x00000000U;
        }
        if (!(flags.C())) { goto block_0013B5F4; }
        goto block_0013B5D4;
    }
block_0013B5D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B5D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B5D4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000041U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) {
            r0 = 0x00000001U;
        }
        if (!(flags.C())) { goto block_0013B5F4; }
        goto block_0013B5E0;
    }
block_0013B5E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B5E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B5E0U);
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t address = 0x0013B5ECU + 304U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B5E4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 704U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B5E8U, address);
            }
        }
        {
            const uint32_t address = r6 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0013B5ECU, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[25])) {
                return Oot3dAotMemoryFault(context, 0x0013B5F0U, address);
            }
        }
        goto block_0013B5F4;
    }
block_0013B5F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B5F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B5F4U);
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B5F4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = Oot3dAotLsl(r0, 1U);
            r1 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0013B604U + 0x11CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B5FCU, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B600U, 0xEE300A49U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r0 = r0 + operand;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B608U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B60CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B610U, address);
            }
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B614U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B618U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B61CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B620U, 0xEE300A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B624U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B628U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B62CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x0013B638U + 0xECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B630U, address);
            }
            r0 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B634U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = Oot3dAotLsl(r1, 2U);
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B63CU, 0xEE300A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B640U, address);
            }
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B644U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 0U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B648U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B64CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B650U, address);
            }
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B654U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B658U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B65CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B660U, 0xEE300A0BU};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[22], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B664U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B668U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B66CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B670U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        goto block_0013B674;
    }
block_0013B674:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B674U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B674U);
        }
        {
            const uint32_t address = r4 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B674U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B678U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000078U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0013BA70; }
        goto block_0013B684;
    }
block_0013B684:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B684U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B684U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            r0 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B690U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_SetBGM_003655D0(frame, context, state, 0x003655D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B690U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B690;
    }
block_0013B690:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B690U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B690U);
        }
        {
            r0 = 0x0000004BU;
        }
        {
            const uint32_t address = 0x0013B69CU + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B694U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r8 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013B698U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0013B69CU, address);
            }
        }
        {
            const uint32_t address = r4 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B6A0U, address);
            }
        }
        {
            const uint32_t address = 0x0013B6ACU + 128U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B6A4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B6A8U, address);
            }
        }
        {
            const uint32_t address = 0x0013B6B4U + 124U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B6ACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B6B0U, address);
            }
        }
        {
            const uint32_t address = 0x0013B6BCU + 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B6B4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B6B8U, address);
            }
        }
        {
            const uint32_t address = 0x0013B6C4U + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B6BCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B6C0U, address);
            }
        }
        {
            const uint32_t address = 0x0013B6CCU + 112U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B6C4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B6C8U, address);
            }
        }
        {
            const uint32_t address = r6 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[21])) {
                return Oot3dAotMemoryFault(context, 0x0013B6CCU, address);
            }
        }
        {
            const uint32_t address = r4 + 704U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0013B6D0U, address);
            }
        }
        goto block_0013BA70;
    }
block_0013B740:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B740U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B740U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B740U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000600U;
            r1 = r0 - operand;
        }
        {
            const uint32_t operand = 0x00000002U;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r1 = r1 - operand;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x0013B754U + 0x38CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B74CU, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            r0 = r5;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B758U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B758U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B758;
    }
block_0013B758:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B758U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B758U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x0013B764U + 896U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B75CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B768U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B768U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B768;
    }
block_0013B768:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B768U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B768U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0013B794; }
        goto block_0013B774;
    }
block_0013B774:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B774U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B774U);
        }
        {
            const uint32_t updatedAddress = 0x0013B77CU - 0x97CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B774U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0013B780U - 0x97CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B778U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0013B784U + 0x364U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B77CU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0013B784U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B794U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B794U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B794;
    }
block_0013B794:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B794U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B794U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B794U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r0 - operand;
        }
        {
            const uint32_t operand = 0x000001DCU;
            r0 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000003CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.C()) { goto block_0013B7C0; }
        goto block_0013B7A8;
    }
block_0013B7A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B7A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B7A8U);
        }
        {
            r0 = 0x00000017U;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r5 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013B7B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B7B4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0013B7C0U - 216U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B7B8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B7C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B7C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B7C0;
    }
block_0013B7C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B7C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B7C0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B7C0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000400U;
            r1 = r0 - operand;
        }
        {
            const uint32_t operand = 0x00000218U;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r1 = r1 - operand;
        }
        if (!(flags.Z())) { goto block_0013B7F0; }
        goto block_0013B7D0;
    }
block_0013B7D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B7D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B7D0U);
        }
        {
            const uint32_t updatedAddress = 0x0013B7D8U + 0x314U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B7D0U, address);
            }
            r1 = value;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B7DCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B7DCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B7DC;
    }
block_0013B7DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B7DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B7DCU);
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r5 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0013B7E0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA32U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013B7E4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0013B7E8U, address);
            }
        }
        {
            const uint32_t address = r7 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0013B7ECU, address);
            }
        }
        goto block_0013B7F0;
    }
block_0013B7F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B7F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B7F0U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r4 + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B7F4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B800U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B800U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B800;
    }
block_0013B800:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B800U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B800U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0013B828; }
        goto block_0013B80C;
    }
block_0013B80C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B80CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B80CU);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r1 = 0x00000018U;
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B81CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B81CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B81C;
    }
block_0013B81C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B81CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B81CU);
        }
        {
            const uint32_t address = 0x0013B824U + 716U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B81CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 140U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B820U, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0013B824U, address);
            }
        }
        goto block_0013B828;
    }
block_0013B828:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B828U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B828U);
        }
        {
            const uint32_t address = r4 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[20])) {
                return Oot3dAotMemoryFault(context, 0x0013B828U, address);
            }
        }
        {
            const uint32_t address = r4 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0013B82CU, address);
            }
        }
        {
            const uint32_t address = r4 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0013B830U, address);
            }
        }
        {
            const uint32_t address = r4 + 180U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B834U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0013B840U - 0xA4CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B838U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r4 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B83CU, address);
            }
        }
        {
            const uint32_t address = r4 + 184U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B840U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B844U, address);
            }
        }
        {
            const uint32_t address = r4 + 188U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B848U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0013B84CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B850U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0x3U));
        }
        if (flags.C()) { goto block_0013B86C; }
        goto block_0013B85C;
    }
block_0013B85C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B85CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B85CU);
        }
        {
            const uint32_t value = r0 & 0x00000017U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x0013B868U + 0x28CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B860U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            r0 = r5;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B86CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B86CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B86C;
    }
block_0013B86C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B86CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B86CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B86CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000003CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013BA70; }
        goto block_0013B878;
    }
block_0013B878:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B878U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B878U);
        }
        {
            r0 = 0x00000009U;
        }
        {
            const uint32_t updatedAddress = r8 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013B87CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0013B880U, address);
            }
        }
        {
            const uint32_t updatedAddress = r11 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B884U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x0000000BU;
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013B894U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0013B8A0U + 0x258U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B898U, address);
            }
            r1 = value;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B8A4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B8A4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B8A4;
    }
block_0013B8A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B8A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B8A4U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA32U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0013B8A4U, address);
            }
        }
        {
            const uint32_t address = r7 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0013B8A8U, address);
            }
        }
        goto block_0013BA70;
    }
block_0013B8B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B8B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B8B0U);
        }
        {
            const uint32_t address = 0x0013B8B8U + 580U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B8B0U, address);
            }
            frame.Guest.vfp[20] = value;
        }
        {
            r0 = 0x00000018U;
        }
        {
            const uint32_t updatedAddress = r5 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013B8B8U, address);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            const uint32_t address = r4 + 780U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B8C0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0013B8CCU + 564U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B8C4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000AA0U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B8D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B8D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B8D0;
    }
block_0013B8D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B8D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B8D0U);
        }
        {
            const uint32_t address = r4 + 780U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B8D0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0013B8DCU + 552U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B8D4U, address);
            }
            frame.Guest.vfp[19] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r5 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B8E0U, 0xEE201A29U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0013B8ECU + 540U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B8E4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000002A4U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B8F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B8F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B8F0;
    }
block_0013B8F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B8F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B8F0U);
        }
        {
            const uint32_t address = r4 + 780U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B8F0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0013B8FCU + 528U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B8F4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000002A8U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B900U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            const uint32_t address = 0x0013B910U + 512U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B908U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B910U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B910U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B910;
    }
block_0013B910:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B910U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B910U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B910U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x0000003CU;
            r0 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000069U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.C()) && !(flags.Z())) { goto block_0013B978; }
        goto block_0013B920;
    }
block_0013B920:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B920U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B920U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[18];
        }
        {
            r2 = 0x0000000AU;
        }
        {
            const uint32_t address = 0x0013B930U + 484U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B928U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r9;
        }
        {
            r0 = r5;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B938U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B938U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B938;
    }
block_0013B938:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B938U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B938U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r13 + 0x44U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B93CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0013B948U + 464U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B940U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B94CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B94CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B94C;
    }
block_0013B94C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B94CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B94CU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[26];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[25];
        }
        {
            const uint32_t address = 0x0013B95CU - 628U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B954U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000A80U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B960U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B960U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B960;
    }
block_0013B960:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B960U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B960U);
        }
        {
            const uint32_t updatedAddress = 0x0013B968U + 0x1B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B960U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r11 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B964U, address);
            }
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B96CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B96CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B96C;
    }
block_0013B96C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B96CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B96CU);
        }
        {
        }
        {
        }
        goto block_0013B988;
    }
block_0013B978:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B978U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B978U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x0013B984U - 668U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B97CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000A80U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B988U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B988U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B988;
    }
block_0013B988:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B988U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B988U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B988U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000C3U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            const uint32_t updatedAddress = r11 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B990U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B994U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B998U, 0xEE300A09U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0013B9C4; }
        goto block_0013B9A0;
    }
block_0013B9A0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B9A0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B9A0U);
        }
        {
            const uint32_t address = r4 + 780U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B9A0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0013B9ACU + 372U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B9A4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000AB0U;
            r0 = r5 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B9ACU, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[26];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B9B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B9B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B9B8;
    }
block_0013B9B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B9B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B9B8U);
        }
        {
        }
        {
        }
        goto block_0013B9D8;
    }
block_0013B9C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B9C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B9C4U);
        }
        {
            const uint32_t address = r4 + 780U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B9C4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000AB0U;
            r0 = r5 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0013B9CCU, 0xEE201AA9U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[19], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[20];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B9D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B9D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B9D8;
    }
block_0013B9D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B9D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B9D8U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r5 + operand;
        }
        {
            const uint32_t address = 0x0013B9E8U + 316U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B9E0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x0000030CU;
            r0 = r0 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013B9F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013B9F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013B9F0;
    }
block_0013B9F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B9F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B9F0U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B9F0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0013BA0C; }
        goto block_0013B9FC;
    }
block_0013B9FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013B9FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013B9FCU);
        }
        {
            const uint32_t updatedAddress = r11 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013B9FCU, address);
            }
            r1 = value;
        }
        {
            r0 = 0x0000000CU;
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013BA08U, address);
            }
        }
        goto block_0013BA0C;
    }
block_0013BA0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BA0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BA0CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BA0CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000A5U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0013BA28; }
        goto block_0013BA18;
    }
block_0013BA18:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BA18U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BA18U);
        }
        {
            const uint32_t updatedAddress = r11 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BA18U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x0000000DU;
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013BA24U, address);
            }
        }
        goto block_0013BA28;
    }
block_0013BA28:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BA28U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BA28U);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BA28U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000D2U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x0013BA38U + 0xF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BA30U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r11 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BA34U, address);
            }
            r0 = value;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BA3CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BA3CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BA3C;
    }
block_0013BA3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BA3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BA3CU);
        }
        {
            const uint32_t updatedAddress = r5 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BA3CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000F0U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_0013BA70; }
        goto block_0013BA48;
    }
block_0013BA48:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BA48U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BA48U);
        }
        {
            r3 = 0x00000003U;
        }
        {
            r2 = 0x00000014U;
        }
        {
            r1 = 0x0000006BU;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BA5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_QueueTextRequest_003716F0(frame, context, state, 0x003716F0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BA5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BA5C;
    }
block_0013BA5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BA5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BA5CU);
        }
        {
            const uint32_t updatedAddress = 0x0013BA64U + 0xC8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BA5CU, address);
            }
            r1 = value;
        }
        {
            r0 = ~(0x0000000DU);
        }
        {
            const uint32_t updatedAddress = r1 + 0xA0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013BA64U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BA68U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xC00U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0013BA6CU, address);
            }
        }
        goto block_0013BA70;
    }
block_0013BA70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BA70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BA70U);
        }
        {
            const uint32_t updatedAddress = r8 + 0x9AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BA70U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0013BA98; }
        goto block_0013BA7C;
    }
block_0013BA7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BA7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BA7CU);
        }
        {
            const uint32_t operand = 0x00000800U;
            r3 = r5 + operand;
        }
        {
            const uint32_t operand = 0x000002B8U;
            r3 = r3 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0013BA84U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x40U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BA88U, address);
            }
            r2 = value;
        }
        {
            const uint32_t operand = 0x00000AA0U;
            r3 = r5 + operand;
        }
        {
            r0 = r9;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BA98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b1cc_0035B1CC(frame, context, state, 0x0035B1CCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BA98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BA98;
    }
block_0013BA98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BA98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BA98U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA4U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BA98U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_0013BB34; }
        goto block_0013BAA4;
    }
block_0013BAA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BAA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BAA4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000001U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0013BB68; }
        goto block_0013BAAC;
    }
block_0013BAAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BAACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BAACU);
        }
        {
            const uint32_t updatedAddress = r8 + 0x98U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BAACU, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000007U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_0013BB68; }
        goto block_0013BAB8;
    }
block_0013BAB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BAB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BAB8U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x3CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BAB8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xBF4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BABCU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x0000001FU;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0013BB68; }
        goto block_0013BAC8;
    }
block_0013BAC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BAC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BAC8U);
        }
        {
            const uint32_t operand = 0x0000004CU;
            r13 = r13 + operand;
        }
        {
            r0 = r5;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0013BAD0U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0013BAD0U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0013BAD0U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0013BAD0U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0013BAD0U,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0013BAD0U,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0013BAD0U,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0013BAD0U,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0013BAD0U,
                                           firstAddress + 32U);
            }
            frame.Guest.vfp[24] = value8;
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0013BAD0U,
                                           firstAddress + 36U);
            }
            frame.Guest.vfp[25] = value9;
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 40U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0013BAD0U,
                                           firstAddress + 40U);
            }
            frame.Guest.vfp[26] = value10;
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 44U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0013BAD0U,
                                           firstAddress + 44U);
            }
            frame.Guest.vfp[27] = value11;
            r13 += 48U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0013BAD4U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0013BAD4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0013BAD4U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0013BAD4U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0013BAD4U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0013BAD4U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0013BAD4U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0013BAD4U,
                                           firstAddress + 28U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x0013BAD4U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r14 = value14;
            r13 = r13 + 36U;
        }
        {
            const uint32_t updatedAddress = 0x0013BAE0U + 0x50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BAD8U, address);
            }
            r1 = value;
        }
        return Oot3dAotBranch(0x00375BCCU);
    }
block_0013BB34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BB34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BB34U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = r4 + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0013BB38U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BB44U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BB44U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BB44;
    }
block_0013BB44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BB44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BB44U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0013BB68; }
        goto block_0013BB50;
    }
block_0013BB50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BB50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BB50U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r1 = 0x00000013U;
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r5 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0013BB60U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToLoop_00370350(frame, context, state, 0x00370350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0013BB60U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0013BB60;
    }
block_0013BB60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BB60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BB60U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0013BB64U, address);
            }
        }
        goto block_0013BB68;
    }
block_0013BB68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0013BB68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0013BB68U);
        }
        {
            const uint32_t operand = 0x0000004CU;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0013BB6CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0013BB6CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0013BB6CU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0013BB6CU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0013BB6CU,
                                           firstAddress + 16U);
            }
            frame.Guest.vfp[20] = value4;
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0013BB6CU,
                                           firstAddress + 20U);
            }
            frame.Guest.vfp[21] = value5;
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0013BB6CU,
                                           firstAddress + 24U);
            }
            frame.Guest.vfp[22] = value6;
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0013BB6CU,
                                           firstAddress + 28U);
            }
            frame.Guest.vfp[23] = value7;
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0013BB6CU,
                                           firstAddress + 32U);
            }
            frame.Guest.vfp[24] = value8;
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 36U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0013BB6CU,
                                           firstAddress + 36U);
            }
            frame.Guest.vfp[25] = value9;
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 40U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0013BB6CU,
                                           firstAddress + 40U);
            }
            frame.Guest.vfp[26] = value10;
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 44U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0013BB6CU,
                                           firstAddress + 44U);
            }
            frame.Guest.vfp[27] = value11;
            r13 += 48U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0013BB70U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0013BB70U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0013BB70U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0013BB70U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0013BB70U,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0013BB70U,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0013BB70U,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0013BB70U,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0013BB70U,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_0017dd68_0017DD68(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0017DD68U:
        goto block_0017DD68;
    case 0x0017DDB0U:
        goto block_0017DDB0;
    case 0x0017DE2CU:
        goto block_0017DE2C;
    case 0x0017DE44U:
        goto block_0017DE44;
    case 0x0017DE50U:
        goto block_0017DE50;
    case 0x0017DE5CU:
        goto block_0017DE5C;
    case 0x0017DE68U:
        goto block_0017DE68;
    case 0x0017DE78U:
        goto block_0017DE78;
    case 0x0017DE88U:
        goto block_0017DE88;
    case 0x0017DE94U:
        goto block_0017DE94;
    case 0x0017DEA8U:
        goto block_0017DEA8;
    case 0x0017DEB8U:
        goto block_0017DEB8;
    case 0x0017DF00U:
        goto block_0017DF00;
    case 0x0017DF80U:
        goto block_0017DF80;
    case 0x0017DF88U:
        goto block_0017DF88;
    case 0x0017DFC0U:
        goto block_0017DFC0;
    case 0x0017DFE0U:
        goto block_0017DFE0;
    case 0x0017DFFCU:
        goto block_0017DFFC;
    case 0x0017E01CU:
        goto block_0017E01C;
    case 0x0017E02CU:
        goto block_0017E02C;
    case 0x0017E038U:
        goto block_0017E038;
    case 0x0017E044U:
        goto block_0017E044;
    case 0x0017E050U:
        goto block_0017E050;
    case 0x0017E070U:
        goto block_0017E070;
    case 0x0017E088U:
        goto block_0017E088;
    case 0x0017E0DCU:
        goto block_0017E0DC;
    case 0x0017E0ECU:
        goto block_0017E0EC;
    case 0x0017E0F8U:
        goto block_0017E0F8;
    case 0x0017E118U:
        goto block_0017E118;
    case 0x0017E124U:
        goto block_0017E124;
    case 0x0017E144U:
        goto block_0017E144;
    case 0x0017E198U:
        goto block_0017E198;
    case 0x0017E1BCU:
        goto block_0017E1BC;
    case 0x0017E1D4U:
        goto block_0017E1D4;
    case 0x0017E26CU:
        goto block_0017E26C;
    case 0x0017E278U:
        goto block_0017E278;
    case 0x0017E284U:
        goto block_0017E284;
    case 0x0017E290U:
        goto block_0017E290;
    case 0x0017E2ACU:
        goto block_0017E2AC;
    case 0x0017E2B8U:
        goto block_0017E2B8;
    case 0x0017E2D0U:
        goto block_0017E2D0;
    case 0x0017E2ECU:
        goto block_0017E2EC;
    case 0x0017E300U:
        goto block_0017E300;
    case 0x0017E320U:
        goto block_0017E320;
    case 0x0017E32CU:
        goto block_0017E32C;
    case 0x0017E338U:
        goto block_0017E338;
    case 0x0017E35CU:
        goto block_0017E35C;
    case 0x0017E368U:
        goto block_0017E368;
    case 0x0017E39CU:
        goto block_0017E39C;
    case 0x0017E3A8U:
        goto block_0017E3A8;
    case 0x0017E3D0U:
        goto block_0017E3D0;
    case 0x0017E3F0U:
        goto block_0017E3F0;
    case 0x0017E408U:
        goto block_0017E408;
    case 0x0017E414U:
        goto block_0017E414;
    case 0x0017E420U:
        goto block_0017E420;
    case 0x0017E460U:
        goto block_0017E460;
    case 0x0017E478U:
        goto block_0017E478;
    case 0x0017E488U:
        goto block_0017E488;
    case 0x0017E4ACU:
        goto block_0017E4AC;
    case 0x0017E4B8U:
        goto block_0017E4B8;
    case 0x0017E4C4U:
        goto block_0017E4C4;
    case 0x0017E4E0U:
        goto block_0017E4E0;
    case 0x0017E4E8U:
        goto block_0017E4E8;
    case 0x0017E508U:
        goto block_0017E508;
    case 0x0017E514U:
        goto block_0017E514;
    case 0x0017E528U:
        goto block_0017E528;
    case 0x0017E538U:
        goto block_0017E538;
    case 0x0017E550U:
        goto block_0017E550;
    case 0x0017E5F0U:
        goto block_0017E5F0;
    case 0x0017E610U:
        goto block_0017E610;
    case 0x0017E624U:
        goto block_0017E624;
    case 0x0017E638U:
        goto block_0017E638;
    case 0x0017E648U:
        goto block_0017E648;
    case 0x0017E654U:
        goto block_0017E654;
    case 0x0017E6BCU:
        goto block_0017E6BC;
    case 0x0017E6D8U:
        goto block_0017E6D8;
    case 0x0017E6E4U:
        goto block_0017E6E4;
    case 0x0017E6F8U:
        goto block_0017E6F8;
    case 0x0017E714U:
        goto block_0017E714;
    case 0x0017E73CU:
        goto block_0017E73C;
    case 0x0017E7E0U:
        goto block_0017E7E0;
    case 0x0017E800U:
        goto block_0017E800;
    case 0x0017E80CU:
        goto block_0017E80C;
    case 0x0017E82CU:
        goto block_0017E82C;
    case 0x0017E838U:
        goto block_0017E838;
    case 0x0017E848U:
        goto block_0017E848;
    case 0x0017E854U:
        goto block_0017E854;
    case 0x0017E878U:
        goto block_0017E878;
    case 0x0017E884U:
        goto block_0017E884;
    case 0x0017E8F8U:
        goto block_0017E8F8;
    case 0x0017E910U:
        goto block_0017E910;
    case 0x0017E91CU:
        goto block_0017E91C;
    case 0x0017E928U:
        goto block_0017E928;
    case 0x0017E958U:
        goto block_0017E958;
    case 0x0017E964U:
        goto block_0017E964;
    case 0x0017E978U:
        goto block_0017E978;
    case 0x0017E988U:
        goto block_0017E988;
    case 0x0017E998U:
        goto block_0017E998;
    case 0x0017E9A4U:
        goto block_0017E9A4;
    case 0x0017E9B4U:
        goto block_0017E9B4;
    case 0x0017E9F0U:
        goto block_0017E9F0;
    case 0x0017E9FCU:
        goto block_0017E9FC;
    case 0x0017EA14U:
        goto block_0017EA14;
    case 0x0017EA20U:
        goto block_0017EA20;
    case 0x0017EA38U:
        goto block_0017EA38;
    case 0x0017EA44U:
        goto block_0017EA44;
    case 0x0017EA5CU:
        goto block_0017EA5C;
    case 0x0017EB54U:
        goto block_0017EB54;
    case 0x0017EB74U:
        goto block_0017EB74;
    case 0x0017EB84U:
        goto block_0017EB84;
    case 0x0017EB90U:
        goto block_0017EB90;
    case 0x0017EC14U:
        goto block_0017EC14;
    case 0x0017EC2CU:
        goto block_0017EC2C;
    case 0x0017EC38U:
        goto block_0017EC38;
    case 0x0017EC50U:
        goto block_0017EC50;
    case 0x0017EC60U:
        goto block_0017EC60;
    case 0x0017EC74U:
        goto block_0017EC74;
    case 0x0017EC7CU:
        goto block_0017EC7C;
    case 0x0017EC98U:
        goto block_0017EC98;
    case 0x0017ECA4U:
        goto block_0017ECA4;
    case 0x0017ECACU:
        goto block_0017ECAC;
    case 0x0017ECBCU:
        goto block_0017ECBC;
    case 0x0017ECC8U:
        goto block_0017ECC8;
    case 0x0017ECDCU:
        goto block_0017ECDC;
    case 0x0017ECF0U:
        goto block_0017ECF0;
    case 0x0017ECFCU:
        goto block_0017ECFC;
    case 0x0017ED0CU:
        goto block_0017ED0C;
    case 0x0017ED14U:
        goto block_0017ED14;
    case 0x0017ED20U:
        goto block_0017ED20;
    case 0x0017ED38U:
        goto block_0017ED38;
    case 0x0017ED44U:
        goto block_0017ED44;
    case 0x0017ED64U:
        goto block_0017ED64;
    case 0x0017ED70U:
        goto block_0017ED70;
    case 0x0017ED9CU:
        goto block_0017ED9C;
    case 0x0017EDC0U:
        goto block_0017EDC0;
    case 0x0017EDD4U:
        goto block_0017EDD4;
    case 0x0017EDF0U:
        goto block_0017EDF0;
    case 0x0017EE08U:
        goto block_0017EE08;
    case 0x0017EE14U:
        goto block_0017EE14;
    case 0x0017EE2CU:
        goto block_0017EE2C;
    case 0x0017EE44U:
        goto block_0017EE44;
    case 0x0017EE54U:
        goto block_0017EE54;
    case 0x0017EE60U:
        goto block_0017EE60;
    case 0x0017EE70U:
        goto block_0017EE70;
    case 0x0017EE78U:
        goto block_0017EE78;
    case 0x0017EE98U:
        goto block_0017EE98;
    case 0x0017EEC4U:
        goto block_0017EEC4;
    case 0x0017EEE0U:
        goto block_0017EEE0;
    case 0x0017EEECU:
        goto block_0017EEEC;
    case 0x0017EEF8U:
        goto block_0017EEF8;
    case 0x0017EF04U:
        goto block_0017EF04;
    case 0x0017EF78U:
        goto block_0017EF78;
    case 0x0017EF88U:
        goto block_0017EF88;
    case 0x0017EF90U:
        goto block_0017EF90;
    case 0x0017EF9CU:
        goto block_0017EF9C;
    case 0x0017EFF8U:
        goto block_0017EFF8;
    case 0x0017F02CU:
        goto block_0017F02C;
    case 0x0017F050U:
        goto block_0017F050;
    case 0x0017F060U:
        goto block_0017F060;
    case 0x0017F06CU:
        goto block_0017F06C;
    case 0x0017F084U:
        goto block_0017F084;
    case 0x0017F090U:
        goto block_0017F090;
    case 0x0017F0B0U:
        goto block_0017F0B0;
    case 0x0017F0C0U:
        goto block_0017F0C0;
    case 0x0017F120U:
        goto block_0017F120;
    case 0x0017F144U:
        goto block_0017F144;
    case 0x0017F194U:
        goto block_0017F194;
    case 0x0017F1ACU:
        goto block_0017F1AC;
    case 0x0017F1C0U:
        goto block_0017F1C0;
    case 0x0017F1D0U:
        goto block_0017F1D0;
    case 0x0017F1F0U:
        goto block_0017F1F0;
    case 0x0017F214U:
        goto block_0017F214;
    case 0x0017F22CU:
        goto block_0017F22C;
    case 0x0017F244U:
        goto block_0017F244;
    case 0x0017F250U:
        goto block_0017F250;
    case 0x0017F264U:
        goto block_0017F264;
    case 0x0017F27CU:
        goto block_0017F27C;
    case 0x0017F2BCU:
        goto block_0017F2BC;
    case 0x0017F2FCU:
        goto block_0017F2FC;
    case 0x0017F30CU:
        goto block_0017F30C;
    case 0x0017F31CU:
        goto block_0017F31C;
    case 0x0017F3D4U:
        goto block_0017F3D4;
    case 0x0017F404U:
        goto block_0017F404;
    case 0x0017F43CU:
        goto block_0017F43C;
    case 0x0017F4A8U:
        goto block_0017F4A8;
    case 0x0017F4C8U:
        goto block_0017F4C8;
    case 0x0017F4D4U:
        goto block_0017F4D4;
    case 0x0017F4E8U:
        goto block_0017F4E8;
    case 0x0017F4F4U:
        goto block_0017F4F4;
    case 0x0017F50CU:
        goto block_0017F50C;
    case 0x0017F51CU:
        goto block_0017F51C;
    case 0x0017F530U:
        goto block_0017F530;
    case 0x0017F550U:
        goto block_0017F550;
    case 0x0017F55CU:
        goto block_0017F55C;
    case 0x0017F56CU:
        goto block_0017F56C;
    case 0x0017F584U:
        goto block_0017F584;
    case 0x0017F5ACU:
        goto block_0017F5AC;
    case 0x0017F5C4U:
        goto block_0017F5C4;
    case 0x0017F5D0U:
        goto block_0017F5D0;
    case 0x0017F5E4U:
        goto block_0017F5E4;
    case 0x0017F5F8U:
        goto block_0017F5F8;
    case 0x0017F600U:
        goto block_0017F600;
    case 0x0017F62CU:
        goto block_0017F62C;
    case 0x0017F6F0U:
        goto block_0017F6F0;
    case 0x0017F710U:
        goto block_0017F710;
    case 0x0017F730U:
        goto block_0017F730;
    case 0x0017F740U:
        goto block_0017F740;
    case 0x0017F75CU:
        goto block_0017F75C;
    case 0x0017F768U:
        goto block_0017F768;
    case 0x0017F780U:
        goto block_0017F780;
    case 0x0017F78CU:
        goto block_0017F78C;
    case 0x0017F7B0U:
        goto block_0017F7B0;
    case 0x0017F7D0U:
        goto block_0017F7D0;
    case 0x0017F7F0U:
        goto block_0017F7F0;
    case 0x0017F868U:
        goto block_0017F868;
    case 0x0017F888U:
        goto block_0017F888;
    case 0x0017F898U:
        goto block_0017F898;
    case 0x0017F8ECU:
        goto block_0017F8EC;
    case 0x0017F8F8U:
        goto block_0017F8F8;
    case 0x0017F92CU:
        goto block_0017F92C;
    case 0x0017F94CU:
        goto block_0017F94C;
    case 0x0017F9C0U:
        goto block_0017F9C0;
    case 0x0017F9D8U:
        goto block_0017F9D8;
    case 0x0017F9E4U:
        goto block_0017F9E4;
    case 0x0017FA38U:
        goto block_0017FA38;
    case 0x0017FA58U:
        goto block_0017FA58;
    case 0x0017FA64U:
        goto block_0017FA64;
    case 0x0017FA74U:
        goto block_0017FA74;
    case 0x0017FA88U:
        goto block_0017FA88;
    case 0x0017FAA4U:
        goto block_0017FAA4;
    case 0x0017FAB0U:
        goto block_0017FAB0;
    case 0x0017FB34U:
        goto block_0017FB34;
    case 0x0017FB9CU:
        goto block_0017FB9C;
    case 0x0017FBB4U:
        goto block_0017FBB4;
    case 0x0017FC3CU:
        goto block_0017FC3C;
    case 0x0017FCA4U:
        goto block_0017FCA4;
    case 0x0017FCBCU:
        goto block_0017FCBC;
    case 0x0017FCD0U:
        goto block_0017FCD0;
    case 0x0017FCE0U:
        goto block_0017FCE0;
    case 0x0017FD30U:
        goto block_0017FD30;
    case 0x0017FD44U:
        goto block_0017FD44;
    case 0x0017FD50U:
        goto block_0017FD50;
    case 0x0017FD8CU:
        goto block_0017FD8C;
    case 0x0017FD9CU:
        goto block_0017FD9C;
    case 0x0017FDB0U:
        goto block_0017FDB0;
    case 0x0017FDC8U:
        goto block_0017FDC8;
    case 0x0017FDD4U:
        goto block_0017FDD4;
    case 0x0017FDE4U:
        goto block_0017FDE4;
    case 0x0017FDF4U:
        goto block_0017FDF4;
    case 0x0017FE34U:
        goto block_0017FE34;
    case 0x0017FE4CU:
        goto block_0017FE4C;
    case 0x0017FE68U:
        goto block_0017FE68;
    case 0x0017FE74U:
        goto block_0017FE74;
    case 0x0017FE80U:
        goto block_0017FE80;
    case 0x0017FE8CU:
        goto block_0017FE8C;
    case 0x0017FEB0U:
        goto block_0017FEB0;
    case 0x0017FEBCU:
        goto block_0017FEBC;
    case 0x0017FEF0U:
        goto block_0017FEF0;
    case 0x0017FF10U:
        goto block_0017FF10;
    case 0x0017FF1CU:
        goto block_0017FF1C;
    case 0x0017FFA4U:
        goto block_0017FFA4;
    case 0x0017FFB4U:
        goto block_0017FFB4;
    case 0x0017FFC0U:
        goto block_0017FFC0;
    case 0x0017FFD8U:
        goto block_0017FFD8;
    case 0x0017FFE4U:
        goto block_0017FFE4;
    case 0x00180024U:
        goto block_00180024;
    case 0x0018003CU:
        goto block_0018003C;
    case 0x0018004CU:
        goto block_0018004C;
    case 0x00180064U:
        goto block_00180064;
    case 0x001800A4U:
        goto block_001800A4;
    case 0x001800C4U:
        goto block_001800C4;
    case 0x001800D8U:
        goto block_001800D8;
    case 0x001800E8U:
        goto block_001800E8;
    case 0x001800F4U:
        goto block_001800F4;
    case 0x00180124U:
        goto block_00180124;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0017DD68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DD68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DD68U);
        }
        {
            const uint32_t firstAddress = r13 - 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0017DD68U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0017DD68U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0017DD68U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0017DD68U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0017DD68U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r9)) {
                return Oot3dAotMemoryFault(context, 0x0017DD68U,
                                           firstAddress + 20U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 24U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0017DD68U,
                                           firstAddress + 24U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 28U, r11)) {
                return Oot3dAotMemoryFault(context, 0x0017DD68U,
                                           firstAddress + 28U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 32U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0017DD68U,
                                           firstAddress + 32U);
            }
            r13 = r13 - 36U;
        }
        {
            r4 = r0;
        }
        {
            const uint32_t operand = 0x00000A00U;
            r7 = r4 + operand;
        }
        {
            const uint32_t operand = 0x00002000U;
            r10 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00003800U;
            r11 = r1 + operand;
        }
        {
            r8 = r1;
        }
        {
            r13 -= 16U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017DD80U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0017DD80U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0017DD80U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0017DD80U,
                                           firstAddress + 12U);
            }
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 - operand;
        }
        {
            r9 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DD8CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r10 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DD90U, address);
            }
            r6 = value;
        }
        {
            const uint32_t operand = 0x00000258U;
            r11 = r11 + operand;
        }
        {
            const uint32_t operand = 0x00000001U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017DD9CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DDA0U, address);
            }
            r0 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            const uint32_t operand = 0x00000800U;
            r5 = r4 + operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x0017DDB4U + Oot3dAotLsl(r0, 2U);
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DDACU, address);
            }
            switch (value) {
            case 0x0017DD68U:
                goto block_0017DD68;
            case 0x0017DDB0U:
                goto block_0017DDB0;
            case 0x0017DE2CU:
                goto block_0017DE2C;
            case 0x0017DE44U:
                goto block_0017DE44;
            case 0x0017DE50U:
                goto block_0017DE50;
            case 0x0017DE5CU:
                goto block_0017DE5C;
            case 0x0017DE68U:
                goto block_0017DE68;
            case 0x0017DE78U:
                goto block_0017DE78;
            case 0x0017DE88U:
                goto block_0017DE88;
            case 0x0017DE94U:
                goto block_0017DE94;
            case 0x0017DEA8U:
                goto block_0017DEA8;
            case 0x0017DEB8U:
                goto block_0017DEB8;
            case 0x0017DF00U:
                goto block_0017DF00;
            case 0x0017DF80U:
                goto block_0017DF80;
            case 0x0017DF88U:
                goto block_0017DF88;
            case 0x0017DFC0U:
                goto block_0017DFC0;
            case 0x0017DFE0U:
                goto block_0017DFE0;
            case 0x0017DFFCU:
                goto block_0017DFFC;
            case 0x0017E01CU:
                goto block_0017E01C;
            case 0x0017E02CU:
                goto block_0017E02C;
            case 0x0017E038U:
                goto block_0017E038;
            case 0x0017E044U:
                goto block_0017E044;
            case 0x0017E050U:
                goto block_0017E050;
            case 0x0017E070U:
                goto block_0017E070;
            case 0x0017E088U:
                goto block_0017E088;
            case 0x0017E0DCU:
                goto block_0017E0DC;
            case 0x0017E0ECU:
                goto block_0017E0EC;
            case 0x0017E0F8U:
                goto block_0017E0F8;
            case 0x0017E118U:
                goto block_0017E118;
            case 0x0017E124U:
                goto block_0017E124;
            case 0x0017E144U:
                goto block_0017E144;
            case 0x0017E198U:
                goto block_0017E198;
            case 0x0017E1BCU:
                goto block_0017E1BC;
            case 0x0017E1D4U:
                goto block_0017E1D4;
            case 0x0017E26CU:
                goto block_0017E26C;
            case 0x0017E278U:
                goto block_0017E278;
            case 0x0017E284U:
                goto block_0017E284;
            case 0x0017E290U:
                goto block_0017E290;
            case 0x0017E2ACU:
                goto block_0017E2AC;
            case 0x0017E2B8U:
                goto block_0017E2B8;
            case 0x0017E2D0U:
                goto block_0017E2D0;
            case 0x0017E2ECU:
                goto block_0017E2EC;
            case 0x0017E300U:
                goto block_0017E300;
            case 0x0017E320U:
                goto block_0017E320;
            case 0x0017E32CU:
                goto block_0017E32C;
            case 0x0017E338U:
                goto block_0017E338;
            case 0x0017E35CU:
                goto block_0017E35C;
            case 0x0017E368U:
                goto block_0017E368;
            case 0x0017E39CU:
                goto block_0017E39C;
            case 0x0017E3A8U:
                goto block_0017E3A8;
            case 0x0017E3D0U:
                goto block_0017E3D0;
            case 0x0017E3F0U:
                goto block_0017E3F0;
            case 0x0017E408U:
                goto block_0017E408;
            case 0x0017E414U:
                goto block_0017E414;
            case 0x0017E420U:
                goto block_0017E420;
            case 0x0017E460U:
                goto block_0017E460;
            case 0x0017E478U:
                goto block_0017E478;
            case 0x0017E488U:
                goto block_0017E488;
            case 0x0017E4ACU:
                goto block_0017E4AC;
            case 0x0017E4B8U:
                goto block_0017E4B8;
            case 0x0017E4C4U:
                goto block_0017E4C4;
            case 0x0017E4E0U:
                goto block_0017E4E0;
            case 0x0017E4E8U:
                goto block_0017E4E8;
            case 0x0017E508U:
                goto block_0017E508;
            case 0x0017E514U:
                goto block_0017E514;
            case 0x0017E528U:
                goto block_0017E528;
            case 0x0017E538U:
                goto block_0017E538;
            case 0x0017E550U:
                goto block_0017E550;
            case 0x0017E5F0U:
                goto block_0017E5F0;
            case 0x0017E610U:
                goto block_0017E610;
            case 0x0017E624U:
                goto block_0017E624;
            case 0x0017E638U:
                goto block_0017E638;
            case 0x0017E648U:
                goto block_0017E648;
            case 0x0017E654U:
                goto block_0017E654;
            case 0x0017E6BCU:
                goto block_0017E6BC;
            case 0x0017E6D8U:
                goto block_0017E6D8;
            case 0x0017E6E4U:
                goto block_0017E6E4;
            case 0x0017E6F8U:
                goto block_0017E6F8;
            case 0x0017E714U:
                goto block_0017E714;
            case 0x0017E73CU:
                goto block_0017E73C;
            case 0x0017E7E0U:
                goto block_0017E7E0;
            case 0x0017E800U:
                goto block_0017E800;
            case 0x0017E80CU:
                goto block_0017E80C;
            case 0x0017E82CU:
                goto block_0017E82C;
            case 0x0017E838U:
                goto block_0017E838;
            case 0x0017E848U:
                goto block_0017E848;
            case 0x0017E854U:
                goto block_0017E854;
            case 0x0017E878U:
                goto block_0017E878;
            case 0x0017E884U:
                goto block_0017E884;
            case 0x0017E8F8U:
                goto block_0017E8F8;
            case 0x0017E910U:
                goto block_0017E910;
            case 0x0017E91CU:
                goto block_0017E91C;
            case 0x0017E928U:
                goto block_0017E928;
            case 0x0017E958U:
                goto block_0017E958;
            case 0x0017E964U:
                goto block_0017E964;
            case 0x0017E978U:
                goto block_0017E978;
            case 0x0017E988U:
                goto block_0017E988;
            case 0x0017E998U:
                goto block_0017E998;
            case 0x0017E9A4U:
                goto block_0017E9A4;
            case 0x0017E9B4U:
                goto block_0017E9B4;
            case 0x0017E9F0U:
                goto block_0017E9F0;
            case 0x0017E9FCU:
                goto block_0017E9FC;
            case 0x0017EA14U:
                goto block_0017EA14;
            case 0x0017EA20U:
                goto block_0017EA20;
            case 0x0017EA38U:
                goto block_0017EA38;
            case 0x0017EA44U:
                goto block_0017EA44;
            case 0x0017EA5CU:
                goto block_0017EA5C;
            case 0x0017EB54U:
                goto block_0017EB54;
            case 0x0017EB74U:
                goto block_0017EB74;
            case 0x0017EB84U:
                goto block_0017EB84;
            case 0x0017EB90U:
                goto block_0017EB90;
            case 0x0017EC14U:
                goto block_0017EC14;
            case 0x0017EC2CU:
                goto block_0017EC2C;
            case 0x0017EC38U:
                goto block_0017EC38;
            case 0x0017EC50U:
                goto block_0017EC50;
            case 0x0017EC60U:
                goto block_0017EC60;
            case 0x0017EC74U:
                goto block_0017EC74;
            case 0x0017EC7CU:
                goto block_0017EC7C;
            case 0x0017EC98U:
                goto block_0017EC98;
            case 0x0017ECA4U:
                goto block_0017ECA4;
            case 0x0017ECACU:
                goto block_0017ECAC;
            case 0x0017ECBCU:
                goto block_0017ECBC;
            case 0x0017ECC8U:
                goto block_0017ECC8;
            case 0x0017ECDCU:
                goto block_0017ECDC;
            case 0x0017ECF0U:
                goto block_0017ECF0;
            case 0x0017ECFCU:
                goto block_0017ECFC;
            case 0x0017ED0CU:
                goto block_0017ED0C;
            case 0x0017ED14U:
                goto block_0017ED14;
            case 0x0017ED20U:
                goto block_0017ED20;
            case 0x0017ED38U:
                goto block_0017ED38;
            case 0x0017ED44U:
                goto block_0017ED44;
            case 0x0017ED64U:
                goto block_0017ED64;
            case 0x0017ED70U:
                goto block_0017ED70;
            case 0x0017ED9CU:
                goto block_0017ED9C;
            case 0x0017EDC0U:
                goto block_0017EDC0;
            case 0x0017EDD4U:
                goto block_0017EDD4;
            case 0x0017EDF0U:
                goto block_0017EDF0;
            case 0x0017EE08U:
                goto block_0017EE08;
            case 0x0017EE14U:
                goto block_0017EE14;
            case 0x0017EE2CU:
                goto block_0017EE2C;
            case 0x0017EE44U:
                goto block_0017EE44;
            case 0x0017EE54U:
                goto block_0017EE54;
            case 0x0017EE60U:
                goto block_0017EE60;
            case 0x0017EE70U:
                goto block_0017EE70;
            case 0x0017EE78U:
                goto block_0017EE78;
            case 0x0017EE98U:
                goto block_0017EE98;
            case 0x0017EEC4U:
                goto block_0017EEC4;
            case 0x0017EEE0U:
                goto block_0017EEE0;
            case 0x0017EEECU:
                goto block_0017EEEC;
            case 0x0017EEF8U:
                goto block_0017EEF8;
            case 0x0017EF04U:
                goto block_0017EF04;
            case 0x0017EF78U:
                goto block_0017EF78;
            case 0x0017EF88U:
                goto block_0017EF88;
            case 0x0017EF90U:
                goto block_0017EF90;
            case 0x0017EF9CU:
                goto block_0017EF9C;
            case 0x0017EFF8U:
                goto block_0017EFF8;
            case 0x0017F02CU:
                goto block_0017F02C;
            case 0x0017F050U:
                goto block_0017F050;
            case 0x0017F060U:
                goto block_0017F060;
            case 0x0017F06CU:
                goto block_0017F06C;
            case 0x0017F084U:
                goto block_0017F084;
            case 0x0017F090U:
                goto block_0017F090;
            case 0x0017F0B0U:
                goto block_0017F0B0;
            case 0x0017F0C0U:
                goto block_0017F0C0;
            case 0x0017F120U:
                goto block_0017F120;
            case 0x0017F144U:
                goto block_0017F144;
            case 0x0017F194U:
                goto block_0017F194;
            case 0x0017F1ACU:
                goto block_0017F1AC;
            case 0x0017F1C0U:
                goto block_0017F1C0;
            case 0x0017F1D0U:
                goto block_0017F1D0;
            case 0x0017F1F0U:
                goto block_0017F1F0;
            case 0x0017F214U:
                goto block_0017F214;
            case 0x0017F22CU:
                goto block_0017F22C;
            case 0x0017F244U:
                goto block_0017F244;
            case 0x0017F250U:
                goto block_0017F250;
            case 0x0017F264U:
                goto block_0017F264;
            case 0x0017F27CU:
                goto block_0017F27C;
            case 0x0017F2BCU:
                goto block_0017F2BC;
            case 0x0017F2FCU:
                goto block_0017F2FC;
            case 0x0017F30CU:
                goto block_0017F30C;
            case 0x0017F31CU:
                goto block_0017F31C;
            case 0x0017F3D4U:
                goto block_0017F3D4;
            case 0x0017F404U:
                goto block_0017F404;
            case 0x0017F43CU:
                goto block_0017F43C;
            case 0x0017F4A8U:
                goto block_0017F4A8;
            case 0x0017F4C8U:
                goto block_0017F4C8;
            case 0x0017F4D4U:
                goto block_0017F4D4;
            case 0x0017F4E8U:
                goto block_0017F4E8;
            case 0x0017F4F4U:
                goto block_0017F4F4;
            case 0x0017F50CU:
                goto block_0017F50C;
            case 0x0017F51CU:
                goto block_0017F51C;
            case 0x0017F530U:
                goto block_0017F530;
            case 0x0017F550U:
                goto block_0017F550;
            case 0x0017F55CU:
                goto block_0017F55C;
            case 0x0017F56CU:
                goto block_0017F56C;
            case 0x0017F584U:
                goto block_0017F584;
            case 0x0017F5ACU:
                goto block_0017F5AC;
            case 0x0017F5C4U:
                goto block_0017F5C4;
            case 0x0017F5D0U:
                goto block_0017F5D0;
            case 0x0017F5E4U:
                goto block_0017F5E4;
            case 0x0017F5F8U:
                goto block_0017F5F8;
            case 0x0017F600U:
                goto block_0017F600;
            case 0x0017F62CU:
                goto block_0017F62C;
            case 0x0017F6F0U:
                goto block_0017F6F0;
            case 0x0017F710U:
                goto block_0017F710;
            case 0x0017F730U:
                goto block_0017F730;
            case 0x0017F740U:
                goto block_0017F740;
            case 0x0017F75CU:
                goto block_0017F75C;
            case 0x0017F768U:
                goto block_0017F768;
            case 0x0017F780U:
                goto block_0017F780;
            case 0x0017F78CU:
                goto block_0017F78C;
            case 0x0017F7B0U:
                goto block_0017F7B0;
            case 0x0017F7D0U:
                goto block_0017F7D0;
            case 0x0017F7F0U:
                goto block_0017F7F0;
            case 0x0017F868U:
                goto block_0017F868;
            case 0x0017F888U:
                goto block_0017F888;
            case 0x0017F898U:
                goto block_0017F898;
            case 0x0017F8ECU:
                goto block_0017F8EC;
            case 0x0017F8F8U:
                goto block_0017F8F8;
            case 0x0017F92CU:
                goto block_0017F92C;
            case 0x0017F94CU:
                goto block_0017F94C;
            case 0x0017F9C0U:
                goto block_0017F9C0;
            case 0x0017F9D8U:
                goto block_0017F9D8;
            case 0x0017F9E4U:
                goto block_0017F9E4;
            case 0x0017FA38U:
                goto block_0017FA38;
            case 0x0017FA58U:
                goto block_0017FA58;
            case 0x0017FA64U:
                goto block_0017FA64;
            case 0x0017FA74U:
                goto block_0017FA74;
            case 0x0017FA88U:
                goto block_0017FA88;
            case 0x0017FAA4U:
                goto block_0017FAA4;
            case 0x0017FAB0U:
                goto block_0017FAB0;
            case 0x0017FB34U:
                goto block_0017FB34;
            case 0x0017FB9CU:
                goto block_0017FB9C;
            case 0x0017FBB4U:
                goto block_0017FBB4;
            case 0x0017FC3CU:
                goto block_0017FC3C;
            case 0x0017FCA4U:
                goto block_0017FCA4;
            case 0x0017FCBCU:
                goto block_0017FCBC;
            case 0x0017FCD0U:
                goto block_0017FCD0;
            case 0x0017FCE0U:
                goto block_0017FCE0;
            case 0x0017FD30U:
                goto block_0017FD30;
            case 0x0017FD44U:
                goto block_0017FD44;
            case 0x0017FD50U:
                goto block_0017FD50;
            case 0x0017FD8CU:
                goto block_0017FD8C;
            case 0x0017FD9CU:
                goto block_0017FD9C;
            case 0x0017FDB0U:
                goto block_0017FDB0;
            case 0x0017FDC8U:
                goto block_0017FDC8;
            case 0x0017FDD4U:
                goto block_0017FDD4;
            case 0x0017FDE4U:
                goto block_0017FDE4;
            case 0x0017FDF4U:
                goto block_0017FDF4;
            case 0x0017FE34U:
                goto block_0017FE34;
            case 0x0017FE4CU:
                goto block_0017FE4C;
            case 0x0017FE68U:
                goto block_0017FE68;
            case 0x0017FE74U:
                goto block_0017FE74;
            case 0x0017FE80U:
                goto block_0017FE80;
            case 0x0017FE8CU:
                goto block_0017FE8C;
            case 0x0017FEB0U:
                goto block_0017FEB0;
            case 0x0017FEBCU:
                goto block_0017FEBC;
            case 0x0017FEF0U:
                goto block_0017FEF0;
            case 0x0017FF10U:
                goto block_0017FF10;
            case 0x0017FF1CU:
                goto block_0017FF1C;
            case 0x0017FFA4U:
                goto block_0017FFA4;
            case 0x0017FFB4U:
                goto block_0017FFB4;
            case 0x0017FFC0U:
                goto block_0017FFC0;
            case 0x0017FFD8U:
                goto block_0017FFD8;
            case 0x0017FFE4U:
                goto block_0017FFE4;
            case 0x00180024U:
                goto block_00180024;
            case 0x0018003CU:
                goto block_0018003C;
            case 0x0018004CU:
                goto block_0018004C;
            case 0x00180064U:
                goto block_00180064;
            case 0x001800A4U:
                goto block_001800A4;
            case 0x001800C4U:
                goto block_001800C4;
            case 0x001800D8U:
                goto block_001800D8;
            case 0x001800E8U:
                goto block_001800E8;
            case 0x001800F4U:
                goto block_001800F4;
            case 0x00180124U:
                goto block_00180124;
            default:
                return Oot3dAotBranch(value);
            }
        }
        goto block_0017DDB0;
    }
block_0017DDB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DDB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DDB0U);
        }
        goto block_001800C4;
    }
block_0017DE2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DE2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DE2CU);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017DE38U + 932U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DE30U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017DE3CU + 932U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DE34U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DE44U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DE44U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DE44;
    }
block_0017DE44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DE44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DE44U);
        }
        {
            const uint32_t updatedAddress = 0x0017DE4CU + 0x398U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DE44U, address);
            }
            r1 = value;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DE50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Object_GetIndex_00363C10(frame, context, state, 0x00363C10U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DE50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DE50;
    }
block_0017DE50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DE50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DE50U);
        }
        {
            r1 = r0;
        }
        {
            r0 = r11;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DE5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_field_80x4_positive_00373074(frame, context, state, 0x00373074U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DE5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DE5C;
    }
block_0017DE5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DE5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DE5CU);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_001800C4; }
        goto block_0017DE68;
    }
block_0017DE68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DE68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DE68U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r8 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DE78U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartSkippable_00367494(frame, context, state, 0x00367494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DE78U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DE78;
    }
block_0017DE78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DE78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DE78U);
        }
        {
            r2 = 0x00000008U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DE88U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DE88U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DE88;
    }
block_0017DE88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DE88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DE88U);
        }
        {
            r0 = r8;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DE94U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CreateSubCamera_00367D74(frame, context, state, 0x00367D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DE94U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DE94;
    }
block_0017DE94:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DE94U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DE94U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x9AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017DE94U, address);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DEA8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DEA8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DEA8;
    }
block_0017DEA8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DEA8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DEA8U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x9AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DEA8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x00000007U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DEB8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DEB8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DEB8;
    }
block_0017DEB8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DEB8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DEB8U);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017DEBCU, address);
            }
        }
        {
            const uint32_t address = 0x0017DEC8U + 804U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DEC0U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x0017DECCU + 804U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DEC4U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00000178U;
            r3 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017DED8U, address);
            }
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r8 + operand;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0017DEE0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0017DEE4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0017DEE8U, address);
            }
        }
        {
            const uint32_t address = 0x0017DEF4U + 756U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DEECU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            r1 = r4;
        }
        {
            r2 = r8;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DF00U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SpawnAsChild_0036AA20(frame, context, state, 0x0036AA20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DF00U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DF00;
    }
block_0017DF00:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DF00U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DF00U);
        }
        {
            const uint32_t updatedAddress = 0x0017DF08U + 0x2ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DF00U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017DF0CU + 0x2ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DF04U, address);
            }
            r2 = value;
        }
        {
            const uint32_t address = 0x0017DF10U + 748U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DF08U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017DF14U + 748U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DF0CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x30U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017DF10U, address);
            }
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r2 + r0;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0017DF18U, address);
            }
        }
        {
            const uint32_t address = r0 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0017DF1CU, address);
            }
        }
        {
            const uint32_t address = r0 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0017DF20U, address);
            }
        }
        {
            const uint32_t address = r0 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017DF24U, address);
            }
        }
        {
            r2 = 0x00009000U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0017DF2CU, address);
            }
        }
        {
            const uint32_t address = 0x0017DF38U + 716U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DF30U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0017DF34U, address);
            }
        }
        {
            const uint32_t address = r5 + 696U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017DF38U, address);
            }
        }
        {
            const uint32_t address = r5 + 700U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017DF3CU, address);
            }
        }
        {
            const uint32_t address = r5 + 704U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017DF40U, address);
            }
        }
        {
            const uint32_t address = 0x0017DF4CU + 700U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DF44U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017DF48U, address);
            }
        }
        {
            const uint32_t address = r5 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017DF4CU, address);
            }
        }
        {
            const uint32_t address = 0x0017DF58U + 692U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DF50U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = 0x0000B000U;
        }
        {
            const uint32_t address = r5 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017DF58U, address);
            }
        }
        {
            const uint32_t address = r6 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0017DF5CU, address);
            }
        }
        {
            const uint32_t address = 0x0017DF68U + 680U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DF60U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0017DF64U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017DF68U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r6 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017DF70U, address);
            }
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DF80U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToLoop_00370350(frame, context, state, 0x00370350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DF80U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DF80;
    }
block_0017DF80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DF80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DF80U);
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r8 + operand;
        }
        {
            const uint32_t address = r0 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017DF84U, address);
            }
        }
        goto block_0017DF88;
    }
block_0017DF88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DF88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DF88U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DF88U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0017DF94U + 644U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DF8CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000069U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t address = 0x0017DF9CU + 612U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DF94U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        if (!(flags.C())) {
            const uint32_t operand = 0x00003000U;
            r0 = r8 + operand;
        }
        if (!(flags.C())) {
            const uint32_t address = r0 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017DF9CU, address);
            }
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017DFA4U, address);
            }
        }
        {
            const uint32_t address = r5 + 780U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DFA8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017DFB4U + 608U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DFACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000AA0U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DFB4U, 0xEE201A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DFC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DFC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DFC0;
    }
block_0017DFC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DFC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DFC0U);
        }
        {
            const uint32_t address = r5 + 780U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DFC0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017DFCCU + 592U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DFC4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000002A8U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017DFD0U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x0017DFE0U + 576U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DFD8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DFE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DFE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DFE0;
    }
block_0017DFE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DFE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DFE0U);
        }
        {
            const uint32_t address = 0x0017DFE8U + 540U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DFE0U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017DFF0U + 564U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DFE8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x0017DFF8U + 560U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DFF0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000030CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017DFFCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017DFFCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017DFFC;
    }
block_0017DFFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017DFFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017DFFCU);
        }
        {
            const uint32_t address = 0x0017E004U + 484U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017DFFCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017E008U + 484U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E000U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E004U, address);
            }
        }
        {
            const uint32_t address = r5 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017E008U, address);
            }
        }
        {
            const uint32_t address = r5 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E00CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E010U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000E1U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017E02C; }
        goto block_0017E01C;
    }
block_0017E01C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E01CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E01CU);
        }
        {
            const uint32_t updatedAddress = 0x0017E024U + 0x208U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E01CU, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E02CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E02CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E02C;
    }
block_0017E02C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E02CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E02CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E02CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000178U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_001800C4; }
        goto block_0017E038;
    }
block_0017E038:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E038U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E038U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r8 + operand;
        }
        {
            const uint32_t operand = 0x000008A0U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E044U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_GetState_003769D8(frame, context, state, 0x003769D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E044U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E044;
    }
block_0017E044:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E044U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E044U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_001800C4; }
        goto block_0017E050;
    }
block_0017E050:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E050U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E050U);
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E054U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017E064U + 412U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E05CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E060U, address);
            }
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r8 + operand;
        }
        {
            const uint32_t address = r5 + 780U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E068U, address);
            }
        }
        {
            const uint32_t address = r0 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017E06CU, address);
            }
        }
        goto block_0017E070;
    }
block_0017E070:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E070U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E070U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017E07CU + 436U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E074U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017E080U + 436U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E078U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E088U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E088U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E088;
    }
block_0017E088:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E088U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E088U);
        }
        {
            r0 = 0x00000004U;
        }
        {
            const uint32_t address = 0x0017E094U + 348U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E08CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E090U, address);
            }
        }
        {
            const uint32_t address = r6 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E094U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0017E0A0U + 0x154U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E098U, address);
            }
            r10 = value;
        }
        {
            const uint32_t address = 0x0017E0A4U + 328U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E09CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017E0A8U + 400U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E0A0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r6 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E0A4U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017E0A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E0ACU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0017E0B8U + 388U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E0B0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x0017E0BCU + 0x184U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E0B4U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r0 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017E0B8U, address);
            }
        }
        {
            const uint32_t address = r0 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E0BCU, address);
            }
        }
        {
            const uint32_t address = 0x0017E0C8U + 328U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E0C0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E0C4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0017E0C8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0017E0CCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E0D0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000005AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017E0EC; }
        goto block_0017E0DC;
    }
block_0017E0DC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E0DCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E0DCU);
        }
        {
            const uint32_t updatedAddress = 0x0017E0E4U + 0x160U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E0DCU, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E0ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E0ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E0EC;
    }
block_0017E0EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E0ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E0ECU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E0ECU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000003CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017E118; }
        goto block_0017E0F8;
    }
block_0017E0F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E0F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E0F8U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E0F8U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000001U;
        }
        {
            r2 = 0x0000004EU;
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E108U, address);
            }
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E118U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E118U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E118;
    }
block_0017E118:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E118U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E118U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E118U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000080U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017E144; }
        goto block_0017E124;
    }
block_0017E124:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E124U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E124U);
        }
        {
            const uint32_t updatedAddress = r10 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E124U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000002U;
        }
        {
            r2 = 0x0000004FU;
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E134U, address);
            }
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E144U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E144U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E144;
    }
block_0017E144:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E144U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E144U);
        }
        {
            const uint32_t address = 0x0017E14CU + 252U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E144U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017E150U + 264U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E148U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E14CU, address);
            }
        }
        {
            const uint32_t address = 0x0017E158U + 244U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E150U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E154U, address);
            }
        }
        {
            const uint32_t address = 0x0017E160U + 240U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E158U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E15CU, address);
            }
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E160U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017E16CU + 232U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E164U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0017E168U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E16CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017E170U, 0xEE310A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017E174U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E178U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E17CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E180U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000009EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t address = 0x0017E190U + 204U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E188U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        if (!(flags.C())) {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017E18CU, 0x3E300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        if (!(flags.C())) {
            const uint32_t address = r5 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E190U, address);
            }
        }
        if (!(flags.C())) { goto block_0017E1D4; }
        goto block_0017E198;
    }
block_0017E198:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E198U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E198U);
        }
        {
            const uint32_t address = r5 + 780U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E198U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017E1A4U + 188U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E19CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017E1A8U + 112U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E1A0U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t operand = 0x00000AB0U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017E1A8U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017E1B4U + 176U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E1ACU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017E1B0U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E1BCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E1BCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E1BC;
    }
block_0017E1BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E1BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E1BCU);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017E1CCU + 56U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E1C4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017E1D0U + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E1C8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000030CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E1D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E1D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E1D4;
    }
block_0017E1D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E1D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E1D4U);
        }
        {
        }
        goto block_0017E26C;
    }
block_0017E26C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E26CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E26CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E26CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000FFU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_001800C4; }
        goto block_0017E278;
    }
block_0017E278:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E278U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E278U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r8 + operand;
        }
        {
            const uint32_t operand = 0x000008A0U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E284U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_GetState_003769D8(frame, context, state, 0x003769D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E284U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E284;
    }
block_0017E284:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E284U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E284U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
        }
        if (!(flags.Z())) { goto block_001800C4; }
        goto block_0017E290;
    }
block_0017E290:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E290U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E290U);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E294U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017E2A4U - 164U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E29CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E2A0U, address);
            }
        }
        {
            const uint32_t address = r5 + 780U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E2A4U, address);
            }
        }
        goto block_001800C4;
    }
block_0017E2AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E2ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E2ACU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E2ACU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0017E2D0; }
        goto block_0017E2B8;
    }
block_0017E2B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E2B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E2B8U);
        }
        {
            r2 = 0x00000005U;
        }
        {
            const uint32_t address = 0x0017E2C4U - 148U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E2BCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017E2C8U + 916U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E2C0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E2D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E2D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E2D0;
    }
block_0017E2D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E2D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E2D0U);
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E2D0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017E2DCU - 128U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E2D4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017E2E0U - 120U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E2D8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000AB0U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017E2E0U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017E2ECU - 212U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E2E4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E2ECU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E2ECU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E2EC;
    }
block_0017E2EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E2ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E2ECU);
        }
        {
            r6 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0017E2F0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E2F4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017E32C; }
        goto block_0017E300;
    }
block_0017E300:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E300U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E300U);
        }
        {
            const uint32_t updatedAddress = 0x0017E308U + 0x358U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E300U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017E30CU + 0x358U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E304U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017E310U + 0x358U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E308U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017E314U + 0x358U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E30CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0017E310U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E320U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E320U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E320;
    }
block_0017E320:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E320U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E320U);
        }
        {
            r0 = 0x00000000U;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E32CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0034bdb8_0034BDB8(frame, context, state, 0x0034BDB8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E32CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E32C;
    }
block_0017E32C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E32CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E32CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E32CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017E35C; }
        goto block_0017E338;
    }
block_0017E338:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E338U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E338U);
        }
        {
            const uint32_t updatedAddress = 0x0017E340U - 0x14CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E338U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000003U;
        }
        {
            r2 = 0x00000050U;
        }
        {
            const uint32_t updatedAddress = r1 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E344U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E34CU, address);
            }
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E35CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E35CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E35C;
    }
block_0017E35C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E35CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E35CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E35CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000053U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001800C4; }
        goto block_0017E368;
    }
block_0017E368:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E368U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E368U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0017E36CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E370U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0017E37CU - 0x188U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E374U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0017E380U - 384U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E378U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = 0x00000050U;
        }
        {
            const uint32_t address = r5 + 780U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E380U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E384U, address);
            }
            r0 = value;
        }
        {
            r1 = r4;
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0017E390U, address);
            }
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E39CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E39CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E39C;
    }
block_0017E39C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E39CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E39CU);
        }
        {
        }
        {
        }
        goto block_001800C4;
    }
block_0017E3A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E3A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E3A8U);
        }
        {
            r0 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E3ACU, address);
            }
        }
        {
            const uint32_t address = r5 + 780U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E3B0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017E3BCU + 692U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E3B4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017E3C0U - 424U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E3B8U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t operand = 0x00000AA0U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017E3C0U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x0017E3D0U + 676U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E3C8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E3D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E3D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E3D0;
    }
block_0017E3D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E3D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E3D0U);
        }
        {
            const uint32_t address = r5 + 780U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E3D0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017E3DCU + 668U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E3D4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000002A8U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017E3E0U, 0xEE201A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x0017E3F0U + 652U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E3E8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E3F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E3F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E3F0;
    }
block_0017E3F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E3F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E3F0U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017E3FCU + 644U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E3F4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017E400U - 508U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E3F8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017E404U + 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E3FCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x0000030CU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E408U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E408U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E408;
    }
block_0017E408:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E408U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E408U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E408U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000096U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001800C4; }
        goto block_0017E414;
    }
block_0017E414:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E414U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E414U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E420U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E420U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E420;
    }
block_0017E420:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E420U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E420U);
        }
        {
            const uint32_t operand = 0x00000AA0U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r6 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0017E428U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0017E428U,
                                           firstAddress + 4U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0017E428U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r11 = value11;
        }
        {
            const uint32_t firstAddress = r6;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0017E42CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0017E42CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r11)) {
                return Oot3dAotMemoryFault(context, 0x0017E42CU,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x000000A4U;
            r6 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0017E434U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0017E434U,
                                           firstAddress + 4U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0017E434U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r11 = value11;
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000002ACU;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000080U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r6;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0017E444U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0017E444U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r11)) {
                return Oot3dAotMemoryFault(context, 0x0017E444U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0017E448U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0017E448U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0017E448U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r6 = value6;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0017E44CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0017E44CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0017E44CU,
                                           firstAddress + 8U);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x9AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E454U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E460U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ClearCameraAndRestoreMain_0036E9B8(frame, context, state, 0x0036E9B8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E460U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E460;
    }
block_0017E460:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E460U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E460U);
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r8 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            r0 = r8;
        }
        {
            const uint32_t updatedAddress = r7 + 0x9AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0017E470U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E478U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartUnskippable_00367374(frame, context, state, 0x00367374U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E478U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E478;
    }
block_0017E478:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E478U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E478U);
        }
        {
            r2 = 0x00000007U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E488U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E488U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E488;
    }
block_0017E488:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E488U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E488U);
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E48CU, address);
            }
        }
        {
            r2 = ~(0x00000000U);
        }
        {
            const uint32_t address = 0x0017E49CU - 620U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E494U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017E4A0U + 444U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E498U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x0017E4A4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E4ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E4ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E4AC;
    }
block_0017E4AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E4ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E4ACU);
        }
        {
            const uint32_t updatedAddress = r10 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E4ACU, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000001U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E4B8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetRuntimeFlag200_0035AF04(frame, context, state, 0x0035AF04U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E4B8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E4B8;
    }
block_0017E4B8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E4B8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E4B8U);
        }
        {
        }
        {
        }
        goto block_001800C4;
    }
block_0017E4C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E4C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E4C4U);
        }
        {
            r0 = 0x00000004U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E4C8U, address);
            }
        }
        {
            const uint32_t address = r4 + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E4CCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0017E4D8U + 0x1B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E4D0U, address);
            }
            r0 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.N()) == (flags.V())) { goto block_001800C4; }
        goto block_0017E4E0;
    }
block_0017E4E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E4E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E4E0U);
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E4E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_MessageContext_ResetDisplay_003725E0(frame, context, state, 0x003725E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E4E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E4E8;
    }
block_0017E4E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E4E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E4E8U);
        }
        {
            r0 = 0x0000000AU;
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E4ECU, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r8 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E4F8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E508U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartSkippable_00367494(frame, context, state, 0x00367494U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E508U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E508;
    }
block_0017E508:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E508U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E508U);
        }
        {
            r0 = r8;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E514U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_CreateSubCamera_00367D74(frame, context, state, 0x00367D74U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E514U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E514;
    }
block_0017E514:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E514U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E514U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x9AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E514U, address);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E528U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E528U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E528;
    }
block_0017E528:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E528U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E528U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x9AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E528U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r2 = 0x00000007U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E538U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ChangeCameraStatus_00320D7C(frame, context, state, 0x00320D7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E538U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E538;
    }
block_0017E538:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E538U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E538U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017E544U - 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E53CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017E548U + 324U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E540U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E550U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E550U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E550;
    }
block_0017E550:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E550U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E550U);
        }
        {
            const uint32_t address = 0x0017E558U + 312U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E550U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0017E55CU - 0x368U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E554U, address);
            }
            r10 = value;
        }
        {
            const uint32_t address = r6 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E558U, address);
            }
        }
        {
            const uint32_t address = 0x0017E564U - 888U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E55CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017E568U - 816U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E560U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r6 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E564U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017E568U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E56CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0017E578U + 284U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E570U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r1 = 0x0000C000U;
        }
        {
            const uint32_t address = 0x0017E580U + 220U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E578U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = r0 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017E57CU, address);
            }
        }
        {
            const uint32_t address = r0 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E580U, address);
            }
        }
        {
            const uint32_t address = 0x0017E58CU - 892U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E584U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017E590U + 276U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E588U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E58CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0017E590U, address);
            }
        }
        {
            r1 = 0x0000B000U;
        }
        {
            const uint32_t address = 0x0017E5A0U + 248U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E598U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0017E59CU, address);
            }
        }
        {
            const uint32_t address = r5 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E5A0U, address);
            }
        }
        {
            const uint32_t address = 0x0017E5ACU + 240U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E5A4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E5A8U, address);
            }
        }
        {
            const uint32_t address = 0x0017E5B4U + 236U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E5ACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E5B0U, address);
            }
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E5B4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017E5B8U, 0xEE300A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E5BCU, address);
            }
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E5C0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017E5C4U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017E5D0U + 216U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E5C8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017E5CCU, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E5D0U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E5D4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E5D8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E5DCU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            r0 = 0x00000004U;
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = r4 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E5E8U, address);
            }
        }
        if (!(flags.C())) { goto block_0017E648; }
        goto block_0017E5F0;
    }
block_0017E5F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E5F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E5F0U);
        }
        {
            const uint32_t updatedAddress = 0x0017E5F8U + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E5F0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017E5FCU + 0x68U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E5F4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017E600U + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E5F8U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0017E600U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E610U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E610U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E610;
    }
block_0017E610:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E610U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E610U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[16];
        }
        {
            const uint32_t address = 0x0017E61CU + 148U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E614U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017E620U + 148U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E618U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000A20U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E624U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E624U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E624;
    }
block_0017E624:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E624U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E624U);
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E628U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E62CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0017E648; }
        goto block_0017E638;
    }
block_0017E638:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E638U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E638U);
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r8 + operand;
        }
        {
            const uint32_t address = 0x0017E644U + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E63CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 568U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E640U, address);
            }
        }
        {
            const uint32_t address = r0 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E644U, address);
            }
        }
        goto block_0017E648;
    }
block_0017E648:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E648U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E648U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E648U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017E6D8; }
        goto block_0017E654;
    }
block_0017E654:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E654U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E654U);
        }
        {
            r0 = 0x00000005U;
        }
        goto block_0017E6BC;
    }
block_0017E6BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E6BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E6BCU);
        }
        {
            const uint32_t updatedAddress = r10 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E6BCU, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000051U;
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E6C8U, address);
            }
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E6D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E6D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E6D8;
    }
block_0017E6D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E6D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E6D8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E6D8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001800C4; }
        goto block_0017E6E4;
    }
block_0017E6E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E6E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E6E4U);
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E6E8U, address);
            }
        }
        {
            r0 = 0x0000000BU;
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E6F0U, address);
            }
        }
        goto block_001800C4;
    }
block_0017E6F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E6F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E6F8U);
        }
        {
            const uint32_t address = 0x0017E700U + 988U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E6F8U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017E708U + 976U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E700U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E714U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E714U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E714;
    }
block_0017E714:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E714U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E714U);
        }
        {
            const uint32_t updatedAddress = 0x0017E71CU - 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E714U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017E720U - 0xBCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E718U, address);
            }
            r2 = value;
        }
        {
            r0 = 0x00000005U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E720U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0017E724U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0017E734U - 0x88U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E72CU, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E73CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E73CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E73C;
    }
block_0017E73C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E73CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E73CU);
        }
        {
            const uint32_t address = 0x0017E744U - 180U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E73CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0017E748U - 0x554U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E740U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r6 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E744U, address);
            }
        }
        {
            const uint32_t address = 0x0017E750U + 912U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E748U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017E754U + 912U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E74CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r6 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E750U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017E754U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E758U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0017E764U - 208U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E75CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r1 = 0x0000C000U;
        }
        {
            const uint32_t address = 0x0017E76CU - 200U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E764U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r0 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017E768U, address);
            }
        }
        {
            const uint32_t address = r0 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E76CU, address);
            }
        }
        {
            const uint32_t address = 0x0017E778U + 880U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E770U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E774U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0017E778U, address);
            }
        }
        {
            r1 = 0x0000B000U;
        }
        {
            const uint32_t address = 0x0017E788U + 868U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E780U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0017E784U, address);
            }
        }
        {
            const uint32_t address = r5 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E788U, address);
            }
        }
        {
            const uint32_t address = 0x0017E794U + 860U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E78CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E790U, address);
            }
        }
        {
            const uint32_t address = 0x0017E79CU + 856U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E794U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E798U, address);
            }
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E79CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017E7A0U, 0xEE700A48U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017E7ACU + 844U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E7A4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017E7A8U, 0xEE700A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017E7ACU, address);
            }
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E7B0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017E7B4U, 0xEE700A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017E7C0U + 828U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E7B8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017E7BCU, 0xEE700AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017E7C0U, 0xEE700AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017E7C4U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E7C8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017E7CCU, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E7D0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E7D4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017E800; }
        goto block_0017E7E0;
    }
block_0017E7E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E7E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E7E0U);
        }
        {
            const uint32_t updatedAddress = 0x0017E7E8U - 0x188U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E7E0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017E7ECU - 0x188U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E7E4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017E7F0U - 0x188U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E7E8U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017E7F4U - 0x188U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E7ECU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0017E7F0U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E800U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E800U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E800;
    }
block_0017E800:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E800U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E800U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E800U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017E82C; }
        goto block_0017E80C;
    }
block_0017E80C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E80CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E80CU);
        }
        {
            const uint32_t updatedAddress = 0x0017E814U - 0x1B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E80CU, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017E818U - 0x1B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E810U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017E81CU - 0x1B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E814U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0017E81CU, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E82CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E82CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E82C;
    }
block_0017E82C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E82CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E82CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E82CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017E848; }
        goto block_0017E838;
    }
block_0017E838:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E838U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E838U);
        }
        {
            r2 = 0x00000052U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E848U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E848U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E848;
    }
block_0017E848:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E848U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E848U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E848U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001800C4; }
        goto block_0017E854;
    }
block_0017E854:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E854U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E854U);
        }
        {
            r10 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017E860U - 424U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E858U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r0 = 0x0000000CU;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0017E860U, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E868U, address);
            }
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E878U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E878U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E878;
    }
block_0017E878:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E878U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E878U);
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E884U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E884U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E884;
    }
block_0017E884:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E884U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E884U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            const uint32_t address = 0x0017E890U + 624U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E888U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017E894U + 628U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E88CU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            r0 = 0x00005000U;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[2];
        }
        {
            r1 = 0x0000000DU;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017E89CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 140U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E8A0U, address);
            }
        }
        {
            const uint32_t address = 0x0017E8ACU + 600U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E8A4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017E8A8U, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E8ACU, address);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[2];
        }
        {
            const uint32_t address = r4 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E8B4U, address);
            }
        }
        {
            const uint32_t address = r4 + 196U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0017E8B8U, address);
            }
        }
        {
            const uint32_t address = 0x0017E8C4U + 584U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E8BCU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E8C0U, address);
            }
        }
        {
            const uint32_t address = r5 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0017E8C4U, address);
            }
        }
        {
            const uint32_t address = 0x0017E8D0U + 576U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E8C8U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r8 + operand;
        }
        {
            const uint32_t address = r5 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0017E8D0U, address);
            }
        }
        {
            const uint32_t address = r5 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0017E8D4U, address);
            }
        }
        {
            const uint32_t address = r5 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017E8D8U, address);
            }
        }
        {
            const uint32_t address = 0x0017E8E4U + 560U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E8DCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017E8E0U, address);
            }
        }
        {
            const uint32_t address = r5 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E8E4U, address);
            }
        }
        {
            const uint32_t address = r0 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017E8E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0017E8ECU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x235U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0017E8F0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0017E8F4U, address);
            }
        }
        goto block_0017E8F8;
    }
block_0017E8F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E8F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E8F8U);
        }
        {
            r2 = 0x00000002U;
        }
        {
            const uint32_t address = 0x0017E904U + 532U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E8FCU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017E908U + 532U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E900U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E910U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E910U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E910;
    }
block_0017E910:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E910U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E910U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E91CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E91CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E91C;
    }
block_0017E91C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E91CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E91CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E91CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017E958; }
        goto block_0017E928;
    }
block_0017E928:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E928U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E928U);
        }
        {
            const uint32_t updatedAddress = 0x0017E930U - 0x73CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E928U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = 0x0017E938U - 0x2D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E930U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017E93CU - 0x2D8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E934U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E938U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E93CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0017E940U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            const uint32_t updatedAddress = 0x0017E950U + 0x1D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E948U, address);
            }
            r0 = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            r1 = 0x00000000U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E958U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E958U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E958;
    }
block_0017E958:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E958U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E958U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E958U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_0017E988; }
        goto block_0017E964;
    }
block_0017E964:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E964U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E964U);
        }
        {
            const uint32_t operand = 0x0000002CU;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017E970U - 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E968U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017E974U + 432U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E96CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017E978U + 432U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E970U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E978U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E978U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E978;
    }
block_0017E978:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E978U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E978U);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E978U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017E984U - 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E97CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017E980U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E984U, address);
            }
        }
        goto block_0017E988;
    }
block_0017E988:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E988U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E988U);
        }
        {
            const uint32_t address = r5 + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E988U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017E994U - 740U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E98CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E998U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E998U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E998;
    }
block_0017E998:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E998U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E998U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_001800C4; }
        goto block_0017E9A4;
    }
block_0017E9A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E9A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E9A4U);
        }
        {
            r1 = 0x00000003U;
        }
        {
            const uint32_t address = 0x0017E9B0U - 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E9A8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E9B4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToLoop_00370350(frame, context, state, 0x00370350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E9B4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E9B4;
    }
block_0017E9B4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E9B4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E9B4U);
        }
        {
            r0 = 0x0000000EU;
        }
        {
            r10 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017E9BCU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0017E9C0U, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E9C4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017E9D0U + 348U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E9C8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x0017E9D4U + 0x15CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E9CCU, address);
            }
            r1 = value;
        }
        {
            r2 = r10;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017E9D4U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = r10;
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E9DCU, address);
            }
        }
        {
            const uint32_t address = 0x0017E9E8U + 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E9E0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E9E4U, address);
            }
        }
        {
            const uint32_t address = r4 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017E9E8U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017E9F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_QueueSeqCmd_0036EC40(frame, context, state, 0x0036EC40U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017E9F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017E9F0;
    }
block_0017E9F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E9F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E9F0U);
        }
        {
            const uint32_t updatedAddress = 0x0017E9F8U + 0x13CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E9F0U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000064U;
        }
        {
            const uint32_t updatedAddress = r0 + r8;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E9F8U, address);
            }
            r0 = value;
        }
        goto block_0017E9FC;
    }
block_0017E9FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017E9FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017E9FCU);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint8_t value = 0;
            if (!context.Memory.ReadFast<uint8_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017E9FCU, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000002U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r10))) {
                return Oot3dAotMemoryFault(context, 0x0017EA04U, address);
            }
        }
        {
            const uint32_t operand = 0x00000001U;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r1 = r1 - operand;
        }
        {
            const uint32_t operand = 0x00000044U;
            r0 = r0 + operand;
        }
        if (!(flags.Z())) { goto block_0017E9FC; }
        goto block_0017EA14;
    }
block_0017EA14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EA14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EA14U);
        }
        {
            const uint32_t updatedAddress = 0x0017EA1CU + 0x11CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EA14U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r1 + r8;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017EA1CU, address);
            }
        }
        goto block_0017EA20;
    }
block_0017EA20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EA20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EA20U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017EA2CU + 236U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EA24U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017EA30U + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EA28U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017EA38U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017EA38U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017EA38;
    }
block_0017EA38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EA38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EA38U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017EA44U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017EA44U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017EA44;
    }
block_0017EA44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EA44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EA44U);
        }
        {
            const uint32_t address = 0x0017EA4CU - 924U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EA44U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = 0x0017EA50U + 240U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EA48U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017EA54U + 212U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EA4CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x0000002CU;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017EA5CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017EA5CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017EA5C;
    }
block_0017EA5C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EA5CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EA5CU);
        }
        {
            const uint32_t address = 0x0017EA64U + 224U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EA5CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017EA68U + 224U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EA60U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r6 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017EA64U, address);
            }
        }
        {
            const uint32_t address = 0x0017EA70U + 112U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EA68U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = 0x0000C000U;
        }
        {
            const uint32_t address = r6 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017EA70U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017EA74U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017EA78U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0017EA84U - 0x890U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EA7CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0017EA88U - 1012U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EA80U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EA84U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017EA88U, address);
            }
        }
        {
            const uint32_t address = r0 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017EA8CU, address);
            }
        }
        {
            const uint32_t address = 0x0017EA98U + 80U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EA90U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017EA9CU + 176U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EA94U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r0 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017EA98U, address);
            }
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EA9CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017EAA0U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017EAACU + 164U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EAA4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017EAA8U, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EAACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017EAB0U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017EABCU + 28U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EAB4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017EAB8U, address);
            }
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EABCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017EAC0U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017EAC4U, address);
            }
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EAC8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017EACCU, address);
            }
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EAD0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_0017EB54;
    }
block_0017EB54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EB54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EB54U);
        }
        {
            const uint32_t address = r5 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017EB54U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EB58U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017EB64U + 936U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EB5CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017EB60U, 0xEE300A48U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017EB64U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EB68U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000001EU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017EB84; }
        goto block_0017EB74;
    }
block_0017EB74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EB74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EB74U);
        }
        {
            r2 = 0x0000001EU;
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017EB84U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017EB84U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017EB84;
    }
block_0017EB84:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EB84U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EB84U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EB84U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000005AU, static_cast<Oot3dAotFlagMask>(0x7U));
        }
        if (!(flags.Z())) { goto block_0017EC14; }
        goto block_0017EB90;
    }
block_0017EB90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EB90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EB90U);
        }
        {
            r0 = 0x0000000FU;
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017EB94U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017EB9CU, address);
            }
        }
        {
            const uint32_t address = r8 + 412U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0017EBA0U, address);
            }
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EBA4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017EBB0U + 864U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EBA8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017EBB4U + 864U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EBACU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017EBB0U, 0xEE701A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017EBBCU + 868U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EBB4U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            r0 = 0x00000002U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017EBBCU, 0xEE710AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[3], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017EBC8U + 848U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EBC0U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017EBC4U, 0xEE700AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017EBC8U, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EBCCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017EBD8U + 836U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EBD0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017EBD4U, 0xEE711A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017EBD8U, 0xEE710AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[3], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017EBE4U - 236U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EBDCU, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = r5 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017EBE0U, address);
            }
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EBE4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017EBE8U, 0xEE302AC2U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017EBECU, 0xEE721A61U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[4], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0017EBF0U, address);
            }
        }
        {
            const uint32_t address = r5 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017EBF4U, address);
            }
        }
        {
            const uint32_t address = 0x0017EC00U + 804U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EBF8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017EBFCU, 0xEE310A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017EC00U, address);
            }
        }
        {
            const uint32_t address = 0x0017EC0CU + 796U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EC04U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017EC08U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017EC0CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017EC10U, address);
            }
        }
        goto block_0017EC14;
    }
block_0017EC14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EC14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EC14U);
        }
        {
            const uint32_t updatedAddress = 0x0017EC1CU + 0x310U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EC14U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r8;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EC18U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x0000001FU;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x0017EC28U + 0x308U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EC20U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            r0 = r4;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x0017EC2CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017EC2CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017EC2C;
    }
block_0017EC2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EC2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EC2CU);
        }
        {
        }
        {
        }
        goto block_001800C4;
    }
block_0017EC38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EC38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EC38U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017EC44U - 300U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EC3CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017EC48U - 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EC40U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017EC50U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017EC50U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017EC50;
    }
block_0017EC50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EC50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EC50U);
        }
        {
            const uint32_t updatedAddress = 0x0017EC58U + 0x2D4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EC50U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r8;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EC54U, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x0000001FU;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0017EC74; }
        goto block_0017EC60;
    }
block_0017EC60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EC60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EC60U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EC60U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000096U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = 0x0017EC70U + 0x2C0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EC68U, address);
            }
            r1 = value;
        }
        if (!(flags.C())) {
            r0 = r4;
        }
        if (!(flags.C())) {
            ++context.Stats.DirectCalls;
            r14 = 0x0017EC74U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017EC74U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017EC74;
    }
block_0017EC74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EC74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EC74U);
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017EC7CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017EC7CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017EC7C;
    }
block_0017EC7C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EC7CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EC7CU);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EC7CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017EC88U + 684U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EC80U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017EC8CU + 668U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EC84U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000AB0U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017EC8CU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017EC98U - 344U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EC90U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017EC98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017EC98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017EC98;
    }
block_0017EC98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EC98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EC98U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EC98U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_0017ED38; }
        goto block_0017ECA4;
    }
block_0017ECA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017ECA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017ECA4U);
        }
        {
        }
        if (!(flags.Z())) { goto block_0017ECDC; }
        goto block_0017ECAC;
    }
block_0017ECAC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017ECACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017ECACU);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017ECB8U + 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017ECB0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017ECBCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017ECBCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017ECBC;
    }
block_0017ECBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017ECBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017ECBCU);
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017ECC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017ECC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017ECC8;
    }
block_0017ECC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017ECC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017ECC8U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r0 = 0x00000003U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017ECD0U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 140U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017ECD4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017ECD8U, address);
            }
        }
        goto block_0017ECDC;
    }
block_0017ECDC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017ECDCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017ECDCU);
        }
        {
            const uint32_t address = 0x0017ECE4U + 600U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017ECDCU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = r5 + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017ECE0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017ECF0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017ECF0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017ECF0;
    }
block_0017ECF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017ECF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017ECF0U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0017ED14; }
        goto block_0017ECFC;
    }
block_0017ECFC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017ECFCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017ECFCU);
        }
        {
            r1 = 0x00000006U;
        }
        {
            const uint32_t address = 0x0017ED08U + 560U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017ED00U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017ED0CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToLoop_00370350(frame, context, state, 0x00370350U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017ED0CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017ED0C;
    }
block_0017ED0C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017ED0CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017ED0CU);
        }
        {
            const uint32_t address = 0x0017ED14U + 556U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017ED0CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 140U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017ED10U, address);
            }
        }
        goto block_0017ED14;
    }
block_0017ED14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017ED14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017ED14U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017ED14U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000069U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0017ED38; }
        goto block_0017ED20;
    }
block_0017ED20:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017ED20U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017ED20U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017ED30U + 532U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017ED28U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017ED34U + 532U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017ED2CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000000ACU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017ED38U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017ED38U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017ED38;
    }
block_0017ED38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017ED38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017ED38U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017ED38U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000D2U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001800C4; }
        goto block_0017ED44;
    }
block_0017ED44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017ED44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017ED44U);
        }
        {
            r0 = 0x00000010U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017ED48U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017ED50U, address);
            }
        }
        {
            const uint32_t address = 0x0017ED5CU + 476U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017ED54U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = 0x00000004U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017ED64U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017ED64U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017ED64;
    }
block_0017ED64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017ED64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017ED64U);
        }
        {
            r1 = 0x00000004U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017ED70U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017ED70U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017ED70;
    }
block_0017ED70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017ED70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017ED70U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r0 = 0x00000037U;
        }
        {
            const uint32_t updatedAddress = 0x0017ED80U + 0x1CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017ED78U, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017ED7CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 140U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017ED80U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017ED84U, address);
            }
        }
        {
            const uint32_t address = 0x0017ED90U + 428U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017ED88U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00003000U;
            r0 = r8 + operand;
        }
        {
            const uint32_t address = r0 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017ED90U, address);
            }
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017ED9CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017ED9CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017ED9C;
    }
block_0017ED9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017ED9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017ED9CU);
        }
        {
            const uint32_t address = 0x0017EDA4U + 432U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017ED9CU, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t address = 0x0017EDA8U + 424U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EDA0U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r2 = 0x00000002U;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t address = r8 + 412U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017EDACU, address);
            }
        }
        {
            const uint32_t address = 0x0017EDB8U - 672U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EDB0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017EDC0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017EDC0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017EDC0;
    }
block_0017EDC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EDC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EDC0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EDC0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000026U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            r0 = 0x00000037U;
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = r4 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017EDCCU, address);
            }
        }
        if (!(flags.C())) { goto block_0017EE2C; }
        goto block_0017EDD4;
    }
block_0017EDD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EDD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EDD4U);
        }
        {
            r0 = 0x00000006U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017EDD8U, address);
            }
        }
        {
            const uint32_t address = r5 + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EDDCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x0017EDE8U + 0x170U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EDE0U, address);
            }
            r0 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_0017EE14; }
        goto block_0017EDF0;
    }
block_0017EDF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EDF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EDF0U);
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017EDFCU - 772U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EDF4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017EE00U + 316U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EDF8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017EE04U + 284U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EDFCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000208U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017EE08U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017EE08U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017EE08;
    }
block_0017EE08:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EE08U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EE08U);
        }
        {
        }
        {
        }
        goto block_0017EE2C;
    }
block_0017EE14:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EE14U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EE14U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017EE24U + 312U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EE1CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017EE28U + 276U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EE20U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000208U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017EE2CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017EE2CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017EE2C;
    }
block_0017EE2C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EE2CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EE2CU);
        }
        {
            const uint32_t address = 0x0017EE34U + 260U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EE2CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x0017EE38U - 788U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EE30U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = r5 + 172U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017EE34U, address);
            }
        }
        {
            const uint32_t address = r5 + 176U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0017EE38U, address);
            }
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017EE44U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017EE44U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017EE44;
    }
block_0017EE44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EE44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EE44U);
        }
        {
            const uint32_t address = r5 + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EE44U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017EE50U + 236U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EE48U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017EE54U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017EE54U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017EE54;
    }
block_0017EE54:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EE54U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EE54U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_0017EE78; }
        goto block_0017EE60;
    }
block_0017EE60:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EE60U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EE60U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r1 = 0x00000002U;
        }
        {
            const uint32_t operand = 0x000001A4U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017EE70U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017EE70U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017EE70;
    }
block_0017EE70:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EE70U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EE70U);
        }
        {
            const uint32_t address = 0x0017EE78U + 200U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EE70U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 140U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017EE74U, address);
            }
        }
        goto block_0017EE78;
    }
block_0017EE78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EE78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EE78U);
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EE78U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017EE84U + 136U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EE7CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017EE88U + 216U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EE80U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000AA0U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017EE88U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017EE90U, 0xEE300A49U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[18], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017EE98U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017EE98U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017EE98;
    }
block_0017EE98:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EE98U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EE98U);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EE98U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017EEA4U + 116U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EE9CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017EEACU - 880U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EEA4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017EEA8U, 0xEE700A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x000002A4U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017EEB0U, 0xEE300AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017EEBCU + 168U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EEB4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017EEB8U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017EEC4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017EEC4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017EEC4;
    }
block_0017EEC4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EEC4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EEC4U);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EEC4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017EED0U + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EEC8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017EED4U + 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EECCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000AB0U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017EED4U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017EEE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017EEE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017EEE0;
    }
block_0017EEE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EEE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EEE0U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EEE0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000030U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017EF04; }
        goto block_0017EEEC;
    }
block_0017EEEC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EEECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EEECU);
        }
        {
            const uint32_t updatedAddress = 0x0017EEF4U + 0x7CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EEECU, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017EEF8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017EEF8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017EEF8;
    }
block_0017EEF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EEF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EEF8U);
        }
        {
            const uint32_t updatedAddress = 0x0017EF00U + 0x74U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EEF8U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017EF04U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017EF04U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017EF04;
    }
block_0017EF04:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EF04U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EF04U);
        }
        {
        }
        goto block_0017EF78;
    }
block_0017EF78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EF78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EF78U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EF78U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0x6U));
        }
        if (!(flags.C()) || (flags.Z())) {
            r9 = 0x00000001U;
        }
        if (!(flags.C()) || (flags.Z())) { goto block_001800C4; }
        goto block_0017EF88;
    }
block_0017EF88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EF88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EF88U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000005AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) { goto block_001800C4; }
        goto block_0017EF90;
    }
block_0017EF90:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EF90U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EF90U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017EF9CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017EF9CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017EF9C;
    }
block_0017EF9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EF9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EF9CU);
        }
        {
            const uint32_t operand = 0x00000AA0U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r6 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0017EFA4U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0017EFA4U,
                                           firstAddress + 4U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0017EFA4U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r10 = value10;
        }
        {
            const uint32_t firstAddress = r6;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0017EFA8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0017EFA8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0017EFA8U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x000000A4U;
            r6 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0017EFB0U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0017EFB0U,
                                           firstAddress + 4U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0017EFB0U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r10 = value10;
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000002ACU;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000080U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r6;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0017EFC0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0017EFC0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0017EFC0U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0017EFC4U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0017EFC4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0017EFC4U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r6 = value6;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0017EFCCU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0017EFCCU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0017EFCCU,
                                           firstAddress + 8U);
            }
        }
        {
            r0 = 0x00000011U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017EFD4U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017EFDCU, address);
            }
        }
        {
            r0 = 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA33U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017EFE4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x2B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EFE8U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000228U;
            r6 = r4 + operand;
        }
        {
            r10 = r0;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017EFF8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_ZAR_GetCMBByIndex_00358EF8(frame, context, state, 0x00358EF8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017EFF8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017EFF8;
    }
block_0017EFF8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017EFF8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017EFF8U);
        }
        {
            r12 = r0;
        }
        {
            const uint32_t updatedAddress = r4 + 0x178U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017EFFCU, address);
            }
            r11 = value;
        }
        {
            r3 = 0x00000000U;
        }
        {
            r0 = ~(0x00000000U);
        }
        {
            const uint32_t firstAddress = r13 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r0)) {
                return Oot3dAotMemoryFault(context, 0x0017F008U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0017F008U,
                                           firstAddress + 4U);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0xCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0017F00CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0017F010U, address);
            }
        }
        {
            r3 = r12;
        }
        {
            r2 = r6;
        }
        {
            r1 = r8;
        }
        {
            r0 = r10;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0017F024U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F02CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_InitActorAlt_00353E78(frame, context, state, 0x00353E78U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F02CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F02C;
    }
block_0017F02C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F02CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F02CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0x250U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F02CU, address);
            }
            r1 = value;
        }
        {
            r3 = ~(0x00000000U);
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0017F034U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x0017F038U, address);
            }
        }
        {
            const uint32_t operand = 0x00000400U;
            r0 = r4 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x2B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F040U, address);
            }
            r2 = value;
        }
        {
            r3 = 0x00000003U;
        }
        {
            const uint32_t operand = 0x00000124U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F050U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FaceAnimationSet_InitFromModel_0034E994(frame, context, state, 0x0034E994U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F050U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F050;
    }
block_0017F050:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F050U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F050U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            r1 = 0x00000019U;
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F060U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F060U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F060;
    }
block_0017F060:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F060U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F060U);
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r4 + operand;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F06CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F06CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F06C;
    }
block_0017F06C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F06CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F06CU);
        }
        {
            const uint32_t address = 0x0017F074U - 280U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F06CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r2 = 0x00000054U;
        }
        {
            const uint32_t address = r5 + 176U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F074U, address);
            }
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F084U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F084U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F084;
    }
block_0017F084:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F084U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F084U);
        }
        {
            r0 = 0x00000003U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA10U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F088U, address);
            }
        }
        goto block_001800C4;
    }
block_0017F090:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F090U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F090U);
        }
        {
            const uint32_t address = 0x0017F098U + 952U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F090U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x0017F09CU + 952U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F094U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F0B0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F0B0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F0B0;
    }
block_0017F0B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F0B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F0B0U);
        }
        {
            r0 = 0x00000006U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F0B4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F0C0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F0C0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F0C0;
    }
block_0017F0C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F0C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F0C0U);
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F0C0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017F0CCU - 356U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F0C4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F0C8U, 0xEE700AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017F0CCU, address);
            }
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F0D0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F0D4U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017F0E0U - 380U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F0D8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F0DCU, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F0E0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F0E4U, 0xEE300A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017F0F0U - 472U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F0E8U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t address = r5 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F0ECU, address);
            }
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F0F0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F0F4U, address);
            }
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F0F8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F0FCU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017F108U + 848U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F100U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F104U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F108U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F10CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F110U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F114U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000026U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001800C4; }
        goto block_0017F120;
    }
block_0017F120:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F120U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F120U);
        }
        {
            r0 = 0x00000012U;
        }
        {
            const uint32_t address = 0x0017F12CU - 500U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F124U, address);
            }
            frame.Guest.vfp[18] = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F128U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F134U, address);
            }
        }
        {
            r1 = 0x00000019U;
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F144U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F144U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F144;
    }
block_0017F144:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F144U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F144U);
        }
        {
            const uint32_t address = r4 + 616U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0017F144U, address);
            }
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F148U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017F154U + 776U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F14CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017F158U + 776U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F150U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            r0 = 0x00004000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F158U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F15CU, 0xEE700A88U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F160U, 0xEE300A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F164U, 0xEE300A48U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F168U, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F16CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0017F170U, address);
            }
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F174U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F178U, address);
            }
        }
        {
            const uint32_t address = r5 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017F17CU, address);
            }
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F180U, 0xEE710A28U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[17], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017F184U, address);
            }
        }
        {
            const uint32_t address = r5 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F188U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0x36U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F18CU, address);
            }
        }
        goto block_001800C4;
    }
block_0017F194:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F194U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F194U);
        }
        {
            r2 = 0x00000003U;
        }
        {
            const uint32_t address = 0x0017F1A0U + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F198U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017F1A4U - 572U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F19CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F1ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F1ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F1AC;
    }
block_0017F1AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F1ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F1ACU);
        }
        {
            r0 = 0x00000006U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F1B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F1B4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017F1D0; }
        goto block_0017F1C0;
    }
block_0017F1C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F1C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F1C0U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = 0x0017F1CCU + 0x298U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F1C4U, address);
            }
            r1 = value;
        }
        {
            r0 = r2;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F1D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_QueueSeqCmd_0036EC40(frame, context, state, 0x0036EC40U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F1D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F1D0;
    }
block_0017F1D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F1D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F1D0U);
        }
        {
            const uint32_t address = 0x0017F1D8U + 656U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F1D0U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x0017F1DCU - 672U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F1D4U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = 0x0017F1ECU - 668U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F1E4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000208U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F1F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F1F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F1F0;
    }
block_0017F1F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F1F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F1F0U);
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F1F0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017F1FCU + 608U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F1F4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000AA0U;
            r0 = r4 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F200U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017F20CU + 596U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F204U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F208U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F214U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F214U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F214;
    }
block_0017F214:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F214U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F214U);
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F220U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x000002ACU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F22CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F22CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F22C;
    }
block_0017F22C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F22CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F22CU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017F240U + 556U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F238U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000124U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F244U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F244U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F244;
    }
block_0017F244:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F244U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F244U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F244U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000062U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001800C4; }
        goto block_0017F250;
    }
block_0017F250:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F250U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F250U);
        }
        {
            r0 = 0x00000013U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F254U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F25CU, address);
            }
        }
        goto block_001800C4;
    }
block_0017F264:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F264U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F264U);
        }
        {
            r2 = 0x00000003U;
        }
        {
            const uint32_t address = 0x0017F270U + 480U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F268U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017F274U - 780U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F26CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F27CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F27CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F27C;
    }
block_0017F27C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F27CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F27CU);
        }
        {
            r0 = 0x00000006U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F280U, address);
            }
        }
        {
            const uint32_t address = r5 + 656U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F284U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017F290U + 480U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F288U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017F294U - 856U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F28CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F290U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 656U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F294U, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F298U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 100U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F29CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F2A0U, 0xEE700A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F2A4U, 0xEE300A48U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017F2A8U, address);
            }
        }
        {
            const uint32_t address = r4 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F2ACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F2B0U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001800C4; }
        goto block_0017F2BC;
    }
block_0017F2BC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F2BCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F2BCU);
        }
        {
            r0 = 0x00000014U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F2C0U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F2C8U, address);
            }
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F2CCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017F2D8U + 412U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F2D0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r2 = 0x00000053U;
        }
        {
            r1 = r4;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F2DCU, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = r8;
        }
        {
            const uint32_t address = r4 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F2E4U, address);
            }
        }
        {
            const uint32_t address = 0x0017F2F0U + 392U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F2E8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F2ECU, address);
            }
        }
        {
            const uint32_t address = 0x0017F2F8U - 960U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F2F0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 656U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F2F4U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F2FCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F2FCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F2FC;
    }
block_0017F2FC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F2FCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F2FCU);
        }
        {
            const uint32_t address = 0x0017F304U - 988U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F2FCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 520U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F300U, address);
            }
        }
        {
            const uint32_t address = r5 + 292U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017F304U, address);
            }
        }
        goto block_001800C4;
    }
block_0017F30C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F30CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F30CU);
        }
        {
            r0 = 0x00000006U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F310U, address);
            }
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F31CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F31CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F31C;
    }
block_0017F31C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F31CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F31CU);
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F31CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r4 + 100U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F320U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F324U, 0xEE700A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017F328U, address);
            }
        }
        {
            const uint32_t address = 0x0017F334U - 1016U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F32CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            r0 = 0x0000C000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F334U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r4 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F338U, address);
            }
        }
        {
            const uint32_t address = 0x0017F344U + 304U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F33CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F340U, address);
            }
        }
        {
            const uint32_t address = 0x0017F34CU + 304U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F344U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F348U, address);
            }
        }
        {
            const uint32_t address = 0x0017F354U + 300U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F34CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F350U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F354U, address);
            }
        }
        {
            const uint32_t address = 0x0017F360U - 1016U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F358U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017F364U + 288U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F35CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017F368U + 288U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F360U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            const uint32_t address = r5 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017F364U, address);
            }
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F368U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t updatedAddress = 0x0017F374U + 0x120U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F36CU, address);
            }
            r1 = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F370U, 0xEE311A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017F37CU + 220U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F374U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F378U, 0xEE311A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0017F37CU, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F380U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = 0x0017F38CU + 200U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F384U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F388U, 0xEE711AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F38CU, 0xEE711A82U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[3], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017F398U + 244U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F390U, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            const uint32_t address = r5 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0017F394U, address);
            }
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F398U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = r5 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0017F39CU, address);
            }
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F3A0U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F3A4U, 0xEE711A82U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[3], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F3A8U, 0xEE311AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[3], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F3ACU, 0xEE310A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F3B0U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F3B4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F3B8U, address);
            }
        }
        {
            const uint32_t address = 0x0017F3C4U + 204U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F3BCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 696U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F3C0U, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F3C4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, r1, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z()) && ((flags.N()) == (flags.V()))) { goto block_001800C4; }
        goto block_0017F3D4;
    }
block_0017F3D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F3D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F3D4U);
        }
        {
            r0 = 0x00000015U;
        }
        {
            const uint32_t address = 0x0017F3E0U + 184U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F3D8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = 0x00000019U;
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F3E0U, address);
            }
        }
        {
            const uint32_t address = 0x0017F3ECU + 176U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F3E4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 100U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F3E8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F3ECU, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F3F4U, address);
            }
        }
        {
            const uint32_t address = r5 + 796U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017F3F8U, address);
            }
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F404U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F404U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F404;
    }
block_0017F404:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F404U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F404U);
        }
        {
            r3 = 0x00000001U;
        }
        {
            r2 = 0x0000000AU;
        }
        {
            r1 = 0x000001F4U;
        }
        {
            const uint32_t address = 0x0017F418U + 136U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F410U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x0017F41CU + 136U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F414U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0017F418U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0017F418U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0017F418U,
                                           firstAddress + 8U);
            }
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000800U;
            r2 = r4 + operand;
        }
        {
            r3 = 0x00000003U;
        }
        {
            const uint32_t operand = 0x000000CCU;
            r2 = r2 + operand;
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F43CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SpawnFloorDustRing_0036F00C(frame, context, state, 0x0036F00CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F43CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F43C;
    }
block_0017F43C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F43CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F43CU);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r3 = 0x00000001U;
        }
        {
            r2 = 0x0000000AU;
        }
        {
            r1 = 0x000001F4U;
        }
        goto block_0017F4A8;
    }
block_0017F4A8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F4A8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F4A8U);
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0017F4A8U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0017F4A8U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0017F4A8U,
                                           firstAddress + 8U);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000800U;
            r2 = r4 + operand;
        }
        {
            r3 = 0x00000003U;
        }
        {
            const uint32_t operand = 0x000000D8U;
            r2 = r2 + operand;
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F4C8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Actor_SpawnFloorDustRing_0036F00C(frame, context, state, 0x0036F00CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F4C8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F4C8;
    }
block_0017F4C8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F4C8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F4C8U);
        }
        {
            const uint32_t updatedAddress = 0x0017F4D0U + 0x3D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F4C8U, address);
            }
            r1 = value;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F4D4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F4D4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F4D4;
    }
block_0017F4D4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F4D4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F4D4U);
        }
        {
            r3 = 0x0000000AU;
        }
        {
            r2 = 0x00000002U;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F4E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CameraQuake_Request_0036FCA8(frame, context, state, 0x0036FCA8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F4E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F4E8;
    }
block_0017F4E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F4E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F4E8U);
        }
        {
        }
        {
        }
        goto block_001800C4;
    }
block_0017F4F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F4F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F4F4U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017F500U - 176U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F4F8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017F504U + 928U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F4FCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F50CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F50CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F50C;
    }
block_0017F50C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F50CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F50CU);
        }
        {
            r0 = 0x00000006U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F510U, address);
            }
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F51CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F51CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F51C;
    }
block_0017F51C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F51CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F51CU);
        }
        {
            const uint32_t updatedAddress = 0x0017F524U - 0x5F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F51CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + r8;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F520U, address);
            }
            r0 = value;
        }
        {
            r0 = Oot3dAotLsl(r0, 15U);
        }
        {
            const uint32_t source = Oot3dAotRor(r0, 0U);
            uint32_t value = static_cast<uint32_t>(static_cast<int16_t>(source));
            r0 = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F530U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_cos_idx8_00338F60(frame, context, state, 0x00338F60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F530U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F530;
    }
block_0017F530:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F530U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F530U);
        }
        {
            const uint32_t address = r5 + 796U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F530U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000031CU;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F53CU, 0xEE200A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Multiply(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017F548U + 864U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F540U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 792U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F544U, address);
            }
        }
        {
            const uint32_t address = 0x0017F550U + 860U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F548U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F550U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F550U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F550;
    }
block_0017F550:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F550U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F550U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F550U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000002DU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001800C4; }
        goto block_0017F55C;
    }
block_0017F55C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F55CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F55CU);
        }
        {
            r0 = 0x00000016U;
        }
        {
            const uint32_t address = 0x0017F568U - 228U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F560U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F564U, address);
            }
        }
        {
            const uint32_t address = r5 + 520U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F568U, address);
            }
        }
        goto block_0017F56C;
    }
block_0017F56C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F56CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F56CU);
        }
        {
            r2 = 0x00000002U;
        }
        {
            const uint32_t address = 0x0017F578U + 824U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F570U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017F57CU - 240U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F574U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F584U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F584U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F584;
    }
block_0017F584:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F584U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F584U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F584U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0017F590U - 244U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F588U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x0017F594U - 252U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F58CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000005AU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C())) {
            r0 = 0x00000007U;
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = r4 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F598U, address);
            }
        }
        {
            const uint32_t address = r5 + 696U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017F59CU, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F5A0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F5ACU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F5ACU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F5AC;
    }
block_0017F5AC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F5ACU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F5ACU);
        }
        {
            const uint32_t address = 0x0017F5B4U + 760U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F5ACU, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t address = 0x0017F5BCU - 340U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F5B4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00000208U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F5C4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachZeroF_0036FC20(frame, context, state, 0x0036FC20U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F5C4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F5C4;
    }
block_0017F5C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F5C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F5C4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F5C4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_0017F5F8; }
        goto block_0017F5D0;
    }
block_0017F5D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F5D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F5D0U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = 0x0017F5DCU + 728U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F5D4U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000920U;
            r0 = r4 + operand;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[0];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F5E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F5E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F5E4;
    }
block_0017F5E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F5E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F5E4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F5E4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000005AU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            r0 = 0x00000002U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r4 + 0xA32U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F5F0U, address);
            }
        }
        if (flags.Z()) { goto block_0017F62C; }
        goto block_0017F5F8;
    }
block_0017F5F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F5F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F5F8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000078U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017F62C; }
        goto block_0017F600;
    }
block_0017F600:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F600U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F600U);
        }
        {
            r3 = 0x00000040U;
        }
        {
            r2 = 0x00000100U;
        }
        {
            r1 = 0x000000B4U;
        }
        {
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r1)) {
                return Oot3dAotMemoryFault(context, 0x0017F60CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0017F60CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0017F60CU,
                                           firstAddress + 8U);
            }
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r8 + operand;
        }
        {
            const uint32_t updatedAddress = r4 + 0x884U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F618U, address);
            }
            r2 = value;
        }
        {
            r3 = 0x000000C8U;
        }
        {
            const uint32_t operand = 0x0000024CU;
            r1 = r1 + operand;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F62CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_TitleCard_InitBossName_00354248(frame, context, state, 0x00354248U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F62CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F62C;
    }
block_0017F62C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F62CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F62CU);
        }
        {
            const uint32_t updatedAddress = 0x0017F634U + 0x284U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F62CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0017F638U - 476U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F630U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = 0x0017F63CU - 476U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F634U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017F640U - 440U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F638U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x3D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F63CU, address);
            }
            r1 = value;
        }
        {
            r1 = r1 | 0x00000002U;
        }
        {
            const uint32_t updatedAddress = r0 + 0x3D0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0017F644U, address);
            }
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F648U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F64CU, 0xEE701A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F650U, 0xEE710AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[3], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017F65CU + 612U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F654U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F658U, 0xEE700A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017F664U + 600U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F65CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017F660U, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F664U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017F668U, address);
            }
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F66CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017F670U, address);
            }
        }
        {
            const uint32_t address = r5 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F674U, address);
            }
        }
        {
            const uint32_t address = r5 + 184U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F678U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F67CU, 0xEE300A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F680U, 0xEE300A61U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F684U, address);
            }
        }
        {
            const uint32_t address = r5 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017F688U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F68CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x000000F3U;
            r1 = r0 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000012U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) {
            r1 = 0x00000002U;
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = r4 + 0xA0EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0017F69CU, address);
            }
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r0 - operand;
        }
        {
            const uint32_t operand = 0x00000016U;
            r1 = r1 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000011U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) {
            r1 = 0x00000001U;
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = r4 + 0xA0EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0017F6B0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r0 - operand;
        }
        {
            const uint32_t operand = 0x0000002DU;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0x4U));
            r1 = r1 - operand;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x0017F6C4U + 0x200U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F6BCU, address);
            }
            r2 = value;
        }
        if (flags.Z()) {
            r1 = 0x00000000U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r2 + 0x3U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0017F6C4U, address);
            }
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r0 - operand;
        }
        {
            const uint32_t operand = 0x0000002DU;
            r1 = r1 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000016U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) {
            r1 = 0x00000002U;
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = r4 + 0xA0EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0017F6D8U, address);
            }
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x000000F9U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x00000100U;
            r1 = r0 - operand;
        }
        if (!(flags.Z())) {
            const uint32_t operand = 0x0000001FU;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r1 = r1 - operand;
        }
        if (!(flags.Z())) {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000140U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017F730; }
        goto block_0017F6F0;
    }
block_0017F6F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F6F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F6F0U);
        }
        {
            const uint32_t updatedAddress = 0x0017F6F8U + 0x1D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F6F0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017F6FCU + 0x1D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F6F4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017F700U + 0x1D0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F6F8U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0017F700U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F710U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F710U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F710;
    }
block_0017F710:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F710U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F710U);
        }
        {
            const uint32_t updatedAddress = 0x0017F718U + 0x1B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F710U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017F71CU + 0x1B0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F714U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017F720U + 0x1B4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F718U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0017F720U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F730U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F730U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F730;
    }
block_0017F730:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F730U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F730U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F730U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r0 - operand;
        }
        {
            const uint32_t operand = 0x00000043U;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r1 = r1 - operand;
        }
        if (!(flags.Z())) { goto block_001800C4; }
        goto block_0017F740;
    }
block_0017F740:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F740U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F740U);
        }
        {
            const uint32_t address = r5 + 288U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017F740U, address);
            }
        }
        {
            r0 = 0x00000017U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F748U, address);
            }
        }
        {
            r2 = 0x00000055U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F75CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F75CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F75C;
    }
block_0017F75C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F75CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F75CU);
        }
        {
        }
        {
        }
        goto block_001800C4;
    }
block_0017F768:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F768U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F768U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017F774U - 804U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F76CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017F778U + 352U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F770U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F780U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F780U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F780;
    }
block_0017F780:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F780U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F780U);
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r4 + operand;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F78CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F78CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F78C;
    }
block_0017F78C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F78CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F78CU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F78CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r0 - operand;
        }
        {
            const uint32_t operand = 0x0000004EU;
            r1 = r1 - operand;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x0000000EU, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) {
            r1 = 0x00000002U;
        }
        if (!(flags.C())) {
            const uint32_t updatedAddress = r4 + 0xA0EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0017F7A0U, address);
            }
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r0 - operand;
        }
        {
            const uint32_t operand = 0x0000004DU;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r1 = r1 - operand;
        }
        if (!(flags.Z())) { goto block_0017F7F0; }
        goto block_0017F7B0;
    }
block_0017F7B0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F7B0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F7B0U);
        }
        {
            const uint32_t updatedAddress = 0x0017F7B8U + 0x110U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F7B0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017F7BCU + 0x110U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F7B4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017F7C0U + 0x110U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F7B8U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0017F7C0U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F7D0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F7D0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F7D0;
    }
block_0017F7D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F7D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F7D0U);
        }
        {
            const uint32_t updatedAddress = 0x0017F7D8U + 0xF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F7D0U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017F7DCU + 0xF0U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F7D4U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017F7E0U + 0xF4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F7D8U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0017F7E0U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F7F0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F7F0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F7F0;
    }
block_0017F7F0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F7F0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F7F0U);
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F7F0U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017F7FCU + 196U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F7F4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017F800U + 220U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F7F8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F7FCU, 0xEE311A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F800U, 0xEE710A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017F804U, address);
            }
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F808U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F80CU, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017F818U + 200U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F810U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F814U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F818U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017F824U - 976U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F81CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F820U, 0xEE311A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[2], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F824U, 0xEE710A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[2], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017F828U, address);
            }
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F82CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017F838U - 940U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F830U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[2])) {
                return Oot3dAotMemoryFault(context, 0x0017F834U, address);
            }
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F838U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = 0x0017F844U + 160U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F83CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F840U, 0xEE710AA0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[3], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F844U, 0xEE300AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F848U, 0xEE300A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F84CU, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F850U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F854U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F858U, address);
            }
            r1 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r0 = r1 - operand;
        }
        {
            const uint32_t operand = 0x00000056U;
            Oot3dAotSetSubtractFlags(flags, r0, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r0 = r0 - operand;
        }
        if (!(flags.Z())) { goto block_0017F898; }
        goto block_0017F868;
    }
block_0017F868:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F868U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F868U);
        }
        {
            const uint32_t updatedAddress = 0x0017F870U + 0x58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F868U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017F874U + 0x58U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F86CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017F878U + 0x70U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F870U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0017F878U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F888U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F888U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F888;
    }
block_0017F888:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F888U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F888U);
        }
        {
            r2 = 0x00000056U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F898U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F898U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F898;
    }
block_0017F898:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F898U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F898U);
        }
        {
        }
        goto block_0017F8EC;
    }
block_0017F8EC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F8ECU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F8ECU);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F8ECU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000158U, static_cast<Oot3dAotFlagMask>(0x2U));
        }
        if (!(flags.C())) { goto block_001800C4; }
        goto block_0017F8F8;
    }
block_0017F8F8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F8F8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F8F8U);
        }
        {
            const uint32_t operand = 0x00003000U;
            r10 = r8 + operand;
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r10 + 0x261U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F900U, address);
            }
        }
        {
            r0 = 0x000000FFU;
        }
        {
            const uint32_t updatedAddress = r10 + 0x264U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F908U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x263U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F90CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x262U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F910U, address);
            }
        }
        {
            r0 = 0x00000064U;
        }
        {
            const uint32_t updatedAddress = r10 + 0x265U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F918U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F91CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000100U;
            r1 = r0 - operand;
        }
        {
            const uint32_t operand = 0x0000005FU;
            Oot3dAotSetSubtractFlags(flags, r1, operand, static_cast<Oot3dAotFlagMask>(0xFU));
            r1 = r1 - operand;
        }
        if (!(flags.Z())) { goto block_001800C4; }
        goto block_0017F92C;
    }
block_0017F92C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F92CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F92CU);
        }
        {
            r11 = 0x00000000U;
        }
        {
            r0 = 0x00000018U;
        }
        {
            const uint32_t updatedAddress = r10 + 0x261U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0017F934U, address);
            }
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017F938U, address);
            }
        }
        {
            r1 = 0x00000010U;
        }
        {
            r0 = r6;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0017F944U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F94CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0036f57c_0036F57C(frame, context, state, 0x0036F57CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F94CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F94C;
    }
block_0017F94C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F94CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F94CU);
        }
        {
            const uint32_t firstAddress = r0;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0017F94CU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0017F94CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0017F94CU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r6 = value6;
        }
        {
            const uint32_t operand = 0x00000008U;
            r1 = r13 + operand;
        }
        {
            const uint32_t address = 0x0017F95CU + 756U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F954U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t updatedAddress = 0x0017F960U - 0xE2CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F958U, address);
            }
            r0 = value;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0017F95CU,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0017F95CU,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0017F95CU,
                                           firstAddress + 8U);
            }
        }
        {
            r2 = 0x00000001U;
        }
        {
            const uint32_t address = r13 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F964U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017F968U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017F974U + 748U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F96CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r13 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F970U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + r8;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F974U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0017F980U + 724U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F978U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000004U;
            r6 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0017F980U, address);
            }
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0017F984U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0017F984U,
                                           firstAddress + 4U);
            }
            uint32_t value12 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value12)) {
                return Oot3dAotMemoryFault(context, 0x0017F984U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r12 = value12;
        }
        {
            const uint32_t firstAddress = r6;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0017F988U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0017F988U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r12)) {
                return Oot3dAotMemoryFault(context, 0x0017F988U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t address = r0 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F98CU, address);
            }
        }
        {
            const uint32_t address = 0x0017F998U + 704U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F990U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F994U, address);
            }
        }
        {
            const uint32_t address = 0x0017F9A0U + 700U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F998U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F99CU, address);
            }
        }
        {
            const uint32_t address = r0 + 28U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F9A0U, address);
            }
        }
        {
            const uint32_t address = r0 + 32U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017F9A4U, address);
            }
        }
        {
            const uint32_t address = r0 + 36U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F9A8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x2EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0017F9ACU, address);
            }
        }
        {
            const uint32_t updatedAddress = r0 + 0x1U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0017F9B0U, address);
            }
        }
        {
            const uint32_t address = r10 + 600U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017F9B4U, address);
            }
        }
        {
            const uint32_t updatedAddress = r10 + 0x236U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0017F9B8U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA35U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r11))) {
                return Oot3dAotMemoryFault(context, 0x0017F9BCU, address);
            }
        }
        goto block_0017F9C0;
    }
block_0017F9C0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F9C0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F9C0U);
        }
        {
            r2 = 0x00000004U;
        }
        {
            const uint32_t address = 0x0017F9CCU + 664U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F9C4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017F9D0U + 664U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F9C8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F9D8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F9D8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F9D8;
    }
block_0017F9D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F9D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F9D8U);
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r4 + operand;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017F9E4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017F9E4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017F9E4;
    }
block_0017F9E4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017F9E4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017F9E4U);
        }
        {
            const uint32_t updatedAddress = 0x0017F9ECU - 0xEB8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F9E4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000002ACU;
            r1 = r1 + operand;
        }
        {
            const uint32_t address = 0x0017F9F8U + 628U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F9F0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r0 + r8;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F9F4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0017FA00U + 624U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017F9F8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t operand = 0x00000004U;
            r2 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0017FA00U,
                                           firstAddress + 0U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0017FA00U,
                                           firstAddress + 4U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0017FA00U,
                                           firstAddress + 8U);
            }
            r3 = value3;
            r6 = value6;
            r10 = value10;
        }
        {
            const uint32_t firstAddress = r1;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0017FA04U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0017FA04U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0017FA04U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t address = r0 + 4U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FA08U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FA0CU, 0xEE700A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017FA10U, address);
            }
        }
        {
            const uint32_t address = r0 + 8U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FA14U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FA18U, 0xEE700AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017FA1CU, address);
            }
        }
        {
            const uint32_t address = r0 + 12U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FA20U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FA24U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FA28U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FA2CU, address);
            }
            r0 = value;
        }
        {
            const uint32_t value = r0 & 0x00000005U;
            Oot3dAotSetLogicalFlags(flags, value, flags.C(), static_cast<Oot3dAotFlagMask>(0xEU));
        }
        if (!(flags.Z())) { goto block_0017FA58; }
        goto block_0017FA38;
    }
block_0017FA38:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FA38U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FA38U);
        }
        {
            const uint32_t updatedAddress = 0x0017FA40U - 0x178U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FA38U, address);
            }
            r3 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017FA44U - 0x178U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FA3CU, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = 0x0017FA48U + 0x22CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FA40U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            const uint64_t value = static_cast<uint64_t>(r3) << 32U |
                                   r2;
            uint32_t faultAddress = address;
            if (!context.Memory.WriteFast<uint64_t>(
                    address, value, &faultAddress)) {
                return Oot3dAotMemoryFault(context, 0x0017FA48U, faultAddress);
            }
        }
        {
            const uint32_t operand = 0x00000000U;
            r3 = r2 + operand;
        }
        {
            r2 = 0x00000004U;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017FA58U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlaySoundGeneral_0037547C(frame, context, state, 0x0037547CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017FA58U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017FA58;
    }
block_0017FA58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FA58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FA58U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FA58U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000026U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001800C4; }
        goto block_0017FA64;
    }
block_0017FA64:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FA64U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FA64U);
        }
        {
            r2 = 0x00000057U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017FA74U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017FA74U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017FA74;
    }
block_0017FA74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FA74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FA74U);
        }
        {
            r0 = 0x00000019U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017FA78U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017FA80U, address);
            }
        }
        goto block_001800C4;
    }
block_0017FA88:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FA88U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FA88U);
        }
        {
            const uint32_t address = 0x0017FA90U + 468U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FA88U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017FA98U + 480U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FA90U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017FAA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017FAA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017FAA4;
    }
block_0017FAA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FAA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FAA4U);
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r4 + operand;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017FAB0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017FAB0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017FAB0;
    }
block_0017FAB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FAB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FAB0U);
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FAB0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017FABCU - 508U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FAB4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017FAC0U + 444U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FAB8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017FAC4U + 428U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FABCU, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FAC0U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017FACCU + 416U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FAC4U, address);
            }
            frame.Guest.vfp[5] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FAC8U, 0xEE300A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017FAD4U + 428U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FACCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FAD0U, address);
            }
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FAD4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FAD8U, 0xEE300A08U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[16], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FADCU, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FAE0U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            const uint32_t address = 0x0017FAECU + 408U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FAE4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FAE8U, 0xEE711A82U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[3], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0017FAECU, address);
            }
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FAF0U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FAF4U, 0xEE711AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[3], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0017FAF8U, address);
            }
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FAFCU, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            const uint32_t address = 0x0017FB08U - 588U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FB00U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FB04U, 0xEE322A22U};
            Oot3dAotCommitVfp(frame.Guest.vfp[4], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[4], frame.Guest.vfp[5], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FB08U, 0xEE320A40U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[4], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017FB14U + 316U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FB0CU, address);
            }
            frame.Guest.vfp[4] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FB10U, 0xEE300A42U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[4], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FB14U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FB18U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FB1CU, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FB20U, 0xEE300A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FB24U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FB28U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000000FU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_001800C4; }
        goto block_0017FB34;
    }
block_0017FB34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FB34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FB34U);
        }
        {
            const uint32_t updatedAddress = 0x0017FB3CU + 0x14CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FB34U, address);
            }
            r0 = value;
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t address = 0x0017FB44U + 328U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FB3CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017FB48U + 268U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FB40U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t updatedAddress = r0 + r8;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FB44U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x2EU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0017FB48U, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0017FB54U - 0x290U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FB4CU, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r1 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FB50U, address);
            }
            r1 = value;
        }
        {
            const uint32_t address = r1 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FB54U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FB58U, 0xEE300A21U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 4U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FB5CU, address);
            }
        }
        {
            const uint32_t address = r1 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FB60U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FB64U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 8U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FB68U, address);
            }
        }
        {
            const uint32_t address = r1 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FB6CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017FB78U + 228U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FB70U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FB74U, 0xEE700AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r0 + 12U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017FB78U, address);
            }
        }
        {
            const uint32_t address = r0 + 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FB7CU, address);
            }
        }
        {
            const uint32_t address = r0 + 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FB80U, address);
            }
        }
        {
            const uint32_t address = 0x0017FB8CU + 260U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FB84U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r0 + 20U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FB88U, address);
            }
        }
        {
            r0 = 0x0000001AU;
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017FB90U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017FB98U, address);
            }
        }
        goto block_0017FB9C;
    }
block_0017FB9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FB9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FB9CU);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017FBA8U + 236U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FBA0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017FBACU - 748U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FBA4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017FBB4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017FBB4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017FBB4;
    }
block_0017FBB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FBB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FBB4U);
        }
        {
            const uint32_t updatedAddress = 0x0017FBBCU - 0x2F8U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FBB4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = 0x0017FBC0U + 216U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FBB8U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017FBC4U + 172U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FBBCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r0 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FBC0U, address);
            }
            r0 = value;
        }
        {
            const uint32_t address = r0 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FBC4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FBC8U, 0xEE700A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017FBD4U + 172U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FBCCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017FBD0U, address);
            }
        }
        {
            const uint32_t address = r0 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FBD4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FBD8U, 0xEE700A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017FBE4U + 184U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FBDCU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = r5 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017FBE0U, address);
            }
        }
        {
            const uint32_t address = r0 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FBE4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FBE8U, 0xEE700A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017FBECU, address);
            }
        }
        {
            const uint32_t address = r0 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FBF0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017FBF4U, address);
            }
        }
        {
            const uint32_t address = r0 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FBF8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FBFCU, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017FC08U + 124U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FC00U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FC04U, address);
            }
        }
        {
            const uint32_t address = r0 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FC08U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FC0CU, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FC10U, address);
            }
        }
        {
            const uint32_t address = 0x0017FC1CU + 132U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FC14U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 704U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FC18U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FC1CU, address);
            }
            r1 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000014U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (flags.Z()) {
            const uint32_t operand = 0x00001000U;
            r0 = r0 + operand;
        }
        if (flags.Z()) {
            r1 = 0x00000006U;
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = r0 + 0xE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0017FC2CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FC30U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001800C4; }
        goto block_0017FC3C;
    }
block_0017FC3C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FC3CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FC3CU);
        }
        {
            r0 = 0x0000001BU;
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017FC40U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017FC48U, address);
            }
        }
        goto block_001800C4;
    }
block_0017FCA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FCA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FCA4U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017FCB0U + 960U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FCA8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017FCB4U - 96U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FCACU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017FCBCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017FCBCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017FCBC;
    }
block_0017FCBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FCBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FCBCU);
        }
        {
            const uint32_t address = 0x0017FCC4U - 104U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FCBCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 704U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FCC0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FCC4U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000006U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017FCE0; }
        goto block_0017FCD0;
    }
block_0017FCD0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FCD0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FCD0U);
        }
        {
            r2 = 0x00000058U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017FCE0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017FCE0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017FCE0;
    }
block_0017FCE0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FCE0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FCE0U);
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FCE0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017FCECU - 104U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FCE4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FCE8U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FCECU, address);
            }
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FCF0U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017FCFCU - 152U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FCF4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FCF8U, 0xEE700A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017FCFCU, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FD00U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017FD04U, address);
            }
        }
        {
            const uint32_t address = r6 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FD08U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017FD0CU, address);
            }
        }
        {
            const uint32_t address = r6 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FD10U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FD14U, 0xEE300A80U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FD18U, address);
            }
        }
        {
            const uint32_t address = r6 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FD1CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FD20U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FD24U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000027U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_001800C4; }
        goto block_0017FD30;
    }
block_0017FD30:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FD30U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FD30U);
        }
        {
            const uint32_t updatedAddress = 0x0017FD38U - 0x474U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FD30U, address);
            }
            r1 = value;
        }
        {
            const uint32_t updatedAddress = r10 + 0xD4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FD34U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r1 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017FD3CU, address);
            }
        }
        if (flags.Z()) { goto block_0017FD9C; }
        goto block_0017FD44;
    }
block_0017FD44:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FD44U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FD44U);
        }
        {
            const uint32_t updatedAddress = r0 + 0x0U;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FD44U, address);
            }
            r2 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r2, 0x00000018U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        if (!(flags.Z())) { goto block_0017FD8C; }
        goto block_0017FD50;
    }
block_0017FD50:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FD50U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FD50U);
        }
        {
            const uint32_t address = r0 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FD50U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017FD5CU - 236U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FD54U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FD58U, 0xEE300AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FD5CU, address);
            }
        }
        {
            const uint32_t address = r0 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FD60U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FD64U, address);
            }
        }
        {
            const uint32_t address = r0 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FD68U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FD6CU, address);
            }
        }
        {
            const uint32_t address = r0 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FD70U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FD74U, address);
            }
        }
        {
            const uint32_t address = r0 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FD78U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FD7CU, address);
            }
        }
        {
            const uint32_t address = r0 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FD80U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FD84U, address);
            }
        }
        goto block_0017FD9C;
    }
block_0017FD8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FD8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FD8CU);
        }
        {
            const uint32_t updatedAddress = r0 + 0x130U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FD8CU, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0x4U));
        }
        {
            const uint32_t updatedAddress = r1 + 0x34U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017FD94U, address);
            }
        }
        if (!(flags.Z())) { goto block_0017FD44; }
        goto block_0017FD9C;
    }
block_0017FD9C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FD9CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FD9CU);
        }
        {
            r0 = 0x0000001CU;
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017FDA0U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017FDA8U, address);
            }
        }
        goto block_001800C4;
    }
block_0017FDB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FDB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FDB0U);
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t address = 0x0017FDBCU + 696U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FDB4U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017FDC0U - 320U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FDB8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017FDC8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017FDC8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017FDC8;
    }
block_0017FDC8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FDC8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FDC8U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FDC8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000008U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.Z())) { goto block_0017FDE4; }
        goto block_0017FDD4;
    }
block_0017FDD4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FDD4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FDD4U);
        }
        {
            const uint32_t updatedAddress = 0x0017FDDCU + 0x29CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FDD4U, address);
            }
            r1 = value;
        }
        {
            r2 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017FDE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_StartTextbox_00367C7C(frame, context, state, 0x00367C7CU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017FDE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017FDE4;
    }
block_0017FDE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FDE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FDE4U);
        }
        {
            const uint32_t updatedAddress = 0x0017FDECU - 0x528U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FDE4U, address);
            }
            r6 = value;
        }
        {
            const uint32_t updatedAddress = r6 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FDE8U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_001800C4; }
        goto block_0017FDF4;
    }
block_0017FDF4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FDF4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FDF4U);
        }
        {
            const uint32_t address = r0 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FDF4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017FE00U - 380U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FDF8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017FE04U - 416U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FDFCU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x0017FE08U + 628U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FE00U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FE04U, 0xEE300A60U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = r5 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FE10U, address);
            }
        }
        {
            const uint32_t address = r0 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FE14U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FE18U, address);
            }
        }
        {
            const uint32_t address = r0 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FE1CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FE20U, address);
            }
        }
        {
            const uint32_t address = r0 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FE24U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000002ACU;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017FE34U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017FE34U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017FE34;
    }
block_0017FE34:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FE34U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FE34U);
        }
        {
            const uint32_t updatedAddress = r6 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FE34U, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = r0 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FE40U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000AB0U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017FE4CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017FE4CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017FE4C;
    }
block_0017FE4C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FE4CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FE4CU);
        }
        {
            const uint32_t updatedAddress = r6 + 0x34U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FE4CU, address);
            }
            r0 = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            const uint32_t address = r0 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FE58U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r0 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000002B4U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017FE68U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017FE68U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017FE68;
    }
block_0017FE68:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FE68U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FE68U);
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FE68U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000003CU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (!(flags.C()) || (flags.Z())) { goto block_001800C4; }
        goto block_0017FE74;
    }
block_0017FE74:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FE74U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FE74U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r8 + operand;
        }
        {
            const uint32_t operand = 0x000008A0U;
            r0 = r0 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017FE80U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Message_GetState_003769D8(frame, context, state, 0x003769D8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017FE80U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017FE80;
    }
block_0017FE80:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FE80U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FE80U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (!(flags.Z())) { goto block_001800C4; }
        goto block_0017FE8C;
    }
block_0017FE8C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FE8CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FE8CU);
        }
        {
            r0 = 0x0000001DU;
        }
        {
            const uint32_t address = 0x0017FE98U - 572U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FE90U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017FE94U, address);
            }
        }
        {
            r0 = 0x00000000U;
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017FEA0U, address);
            }
        }
        {
            r1 = 0x0000001AU;
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017FEB0U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_MorphToPlayOnce_00374A58(frame, context, state, 0x00374A58U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017FEB0U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017FEB0;
    }
block_0017FEB0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FEB0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FEB0U);
        }
        {
            r1 = 0x0000001AU;
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017FEBCU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_GetLastFrame_0036AE14(frame, context, state, 0x0036AE14U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017FEBCU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017FEBC;
    }
block_0017FEBC:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FEBCU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FEBCU);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            r0 = 0x00000001U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FEC4U, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 140U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FEC8U, address);
            }
        }
        {
            const uint32_t address = 0x0017FED4U + 428U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FECCU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 196U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0017FED0U, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FED4U, address);
            }
        }
        {
            const uint32_t address = 0x0017FEE0U - 640U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FED8U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r4 + 112U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FEDCU, address);
            }
        }
        {
            const uint32_t address = 0x0017FEE8U + 412U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FEE0U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = r4 + 0xA31U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017FEE4U, address);
            }
        }
        {
            const uint32_t address = r5 + 288U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FEE8U, address);
            }
        }
        goto block_001800C4;
    }
block_0017FEF0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FEF0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FEF0U);
        }
        {
            const uint32_t address = 0x0017FEF8U - 660U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FEF0U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x0017FEFCU + 396U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FEF4U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            r2 = 0x00000004U;
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017FF10U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017FF10U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017FF10;
    }
block_0017FF10:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FF10U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FF10U);
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r4 + operand;
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017FF1CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(frame, context, state, 0x003731E0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017FF1CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017FF1C;
    }
block_0017FF1C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FF1CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FF1CU);
        }
        {
            const uint32_t address = r4 + 40U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FF1CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017FF28U + 356U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FF20U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = 0x0017FF2CU - 672U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FF24U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            const uint32_t address = 0x0017FF30U - 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FF28U, address);
            }
            frame.Guest.vfp[3] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FF2CU, 0xEE700A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            r0 = 0x0000C000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FF34U, 0xEE700AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017FF40U + 336U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FF38U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FF3CU, 0xEE700A81U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017FF48U + 332U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FF40U, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FF44U, 0xEE700AC1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[1], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 672U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017FF48U, address);
            }
        }
        {
            const uint32_t address = r4 + 44U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FF4CU, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t address = r5 + 676U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017FF50U, address);
            }
        }
        {
            const uint32_t address = r4 + 48U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FF54U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FF58U, 0xEE701AA1U};
            Oot3dAotCommitVfp(frame.Guest.vfp[3], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[1], frame.Guest.vfp[3], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 680U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[3])) {
                return Oot3dAotMemoryFault(context, 0x0017FF5CU, address);
            }
        }
        {
            const uint32_t address = r5 + 684U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FF60U, address);
            }
        }
        {
            const uint32_t address = r5 + 184U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FF64U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FF68U, 0xEE300A01U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = 0x0017FF74U + 292U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FF6CU, address);
            }
            frame.Guest.vfp[2] = value;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0017FF70U, 0xEE300A41U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Subtract(frame.Guest.vfp[0], frame.Guest.vfp[2], frame.Guest.fpscr));
        }
        {
            const uint32_t address = r5 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FF74U, address);
            }
        }
        {
            const uint32_t address = 0x0017FF80U + 284U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FF78U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 692U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[1])) {
                return Oot3dAotMemoryFault(context, 0x0017FF7CU, address);
            }
        }
        {
            const uint32_t address = r6 + 40U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FF80U, address);
            }
        }
        {
            const uint32_t address = 0x0017FF8CU + 276U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FF84U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r6 + 48U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0017FF88U, address);
            }
        }
        {
            const uint32_t updatedAddress = r6 + 0xBEU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x0017FF8CU, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA94U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FF90U, address);
            }
            r0 = value;
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x0000004BU, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x0017FFA0U - 0x6CCU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FF98U, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            r0 = r4;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x0017FFA4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017FFA4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017FFA4;
    }
block_0017FFA4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FFA4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FFA4U);
        }
        {
            const uint32_t address = r5 + 140U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FFA4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = 0x0017FFB0U + 212U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0017FFA8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000228U;
            r0 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017FFB4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Animation_OnFrameImpl_003736FC(frame, context, state, 0x003736FCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017FFB4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017FFB4;
    }
block_0017FFB4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FFB4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FFB4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r0, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
        }
        if (flags.Z()) { goto block_001800C4; }
        goto block_0017FFC0;
    }
block_0017FFC0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FFC0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FFC0U);
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[16];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            r2 = ~(0x00000000U);
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017FFD8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b2d0_0035B2D0(frame, context, state, 0x0035B2D0U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017FFD8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017FFD8;
    }
block_0017FFD8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FFD8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FFD8U);
        }
        {
            r1 = 0x00000000U;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0017FFE4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0017FFE4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0017FFE4;
    }
block_0017FFE4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0017FFE4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0017FFE4U);
        }
        {
            const uint32_t operand = 0x00000AA0U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x0000008CU;
            r6 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0017FFECU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0017FFECU,
                                           firstAddress + 4U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0017FFECU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r10 = value10;
        }
        {
            const uint32_t firstAddress = r6;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x0017FFF0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x0017FFF0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r10)) {
                return Oot3dAotMemoryFault(context, 0x0017FFF0U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t operand = 0x000000A4U;
            r6 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0017FFF8U,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0017FFF8U,
                                           firstAddress + 4U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0017FFF8U,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r10 = value10;
        }
        {
            const uint32_t operand = 0x00000800U;
            r1 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000002ACU;
            r1 = r1 + operand;
        }
        {
            const uint32_t operand = 0x00000080U;
            r0 = r0 + operand;
        }
        {
            const uint32_t firstAddress = r6;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00180008U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00180008U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r10)) {
                return Oot3dAotMemoryFault(context, 0x00180008U,
                                           firstAddress + 8U);
            }
        }
        {
            const uint32_t firstAddress = r1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0018000CU,
                                           firstAddress + 0U);
            }
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0018000CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0018000CU,
                                           firstAddress + 8U);
            }
            r2 = value2;
            r3 = value3;
            r6 = value6;
        }
        {
            const uint32_t firstAddress = r0;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r2)) {
                return Oot3dAotMemoryFault(context, 0x00180010U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r3)) {
                return Oot3dAotMemoryFault(context, 0x00180010U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00180010U,
                                           firstAddress + 8U);
            }
        }
        {
            r2 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x9AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00180018U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00180024U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_ClearCameraAndRestoreMain_0036E9B8(frame, context, state, 0x0036E9B8U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00180024U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00180024;
    }
block_00180024:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00180024U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00180024U);
        }
        {
            r6 = 0x00000000U;
        }
        {
            const uint32_t operand = 0x00002000U;
            r1 = r8 + operand;
        }
        {
            const uint32_t operand = 0x00000298U;
            r1 = r1 + operand;
        }
        {
            r0 = r8;
        }
        {
            const uint32_t updatedAddress = r7 + 0x9AU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00180034U, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0018003CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_CutsceneContext_StartUnskippable_00367374(frame, context, state, 0x00367374U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0018003CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0018003C;
    }
block_0018003C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0018003CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0018003CU);
        }
        {
            r2 = 0x00000007U;
        }
        {
            r1 = r4;
        }
        {
            r0 = r8;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0018004CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Player_SetCsActionWithHaltedActors_0036E980(frame, context, state, 0x0036E980U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0018004CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0018004C;
    }
block_0018004C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0018004CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0018004CU);
        }
        {
            r0 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r7 + 0x98U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r6))) {
                return Oot3dAotMemoryFault(context, 0x00180050U, address);
            }
        }
        {
            const uint32_t updatedAddress = r4 + 0xA33U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00180054U, address);
            }
        }
        {
            r1 = r8;
        }
        {
            r0 = r4;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00180064U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0036fadc_0036FADC(frame, context, state, 0x0036FADCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00180064U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00180064;
    }
block_00180064:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00180064U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00180064U);
        }
        {
            r0 = 0x0000004BU;
        }
        {
            const uint32_t updatedAddress = r5 + 0x9CU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x00180068U, address);
            }
        }
        goto block_001800A4;
    }
block_001800A4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001800A4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001800A4U);
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001800A4U, address);
            }
            r0 = value;
        }
        {
            const uint32_t updatedAddress = 0x001800B0U - 0x7ECU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001800A8U, address);
            }
            r1 = value;
        }
        {
            r0 = r0 | 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r4 + 0x4U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001800B0U, address);
            }
        }
        {
            const uint32_t updatedAddress = r1 + 0x30U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001800B4U, address);
            }
            r1 = value;
        }
        {
            r0 = 0x00000007U;
        }
        {
            const uint32_t operand = 0x00001000U;
            r1 = r1 + operand;
        }
        {
            const uint32_t updatedAddress = r1 + 0xE8U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r0))) {
                return Oot3dAotMemoryFault(context, 0x001800C0U, address);
            }
        }
        goto block_001800C4;
    }
block_001800C4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001800C4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001800C4U);
        }
        {
            const uint32_t address = r5 + 520U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001800C4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t updatedAddress = 0x001800D0U + 0x60U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001800C8U, address);
            }
            r0 = value;
        }
        {
            r1 = frame.Guest.vfp[0];
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, r0, static_cast<Oot3dAotFlagMask>(0xDU));
        }
        if ((flags.Z()) || ((flags.N()) != (flags.V()))) { goto block_001800E8; }
        goto block_001800D8;
    }
block_001800D8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001800D8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001800D8U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r9, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) {
            const uint32_t updatedAddress = 0x001800E4U + 0x50U;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001800DCU, address);
            }
            r1 = value;
        }
        if (flags.Z()) {
            r0 = r4;
        }
        if (flags.Z()) {
            ++context.Stats.DirectCalls;
            r14 = 0x001800E8U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Audio_PlayActorSound2_00375BCC(frame, context, state, 0x00375BCCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x001800E8U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_001800E8;
    }
block_001800E8:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001800E8U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001800E8U);
        }
        {
            const uint32_t updatedAddress = r7 + 0x9AU;
            const uint32_t address = updatedAddress;
            uint16_t value = 0;
            if (!context.Memory.ReadFast<uint16_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001800E8U, address);
            }
            r1 = static_cast<uint32_t>(static_cast<int32_t>(
                static_cast<int16_t>(value)));
        }
        {
            Oot3dAotSetSubtractFlags(flags, r1, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        if (flags.Z()) { goto block_00180124; }
        goto block_001800F4;
    }
block_001800F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x001800F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x001800F4U);
        }
        {
            const uint32_t address = r5 + 688U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001800F4U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r5 + 792U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x001800F8U, address);
            }
            frame.Guest.vfp[1] = value;
        }
        {
            const uint32_t operand = 0x00000800U;
            r3 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000002B8U;
            r3 = r3 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00180104U, 0xEE300A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32Add(frame.Guest.vfp[0], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            const uint32_t operand = 0x00000800U;
            r2 = r4 + operand;
        }
        {
            const uint32_t operand = 0x000002ACU;
            r2 = r2 + operand;
        }
        {
            r0 = r8;
        }
        {
            const uint32_t address = r5 + 688U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x00180114U, address);
            }
        }
        {
            const uint32_t updatedAddress = r13 + 0x0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r3))) {
                return Oot3dAotMemoryFault(context, 0x00180118U, address);
            }
        }
        {
            const uint32_t operand = 0x00000AA0U;
            r3 = r4 + operand;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00180124U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_0035b1cc_0035B1CC(frame, context, state, 0x0035B1CCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00180124U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00180124;
    }
block_00180124:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00180124U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00180124U);
        }
        {
            const uint32_t operand = 0x00000014U;
            r13 = r13 + operand;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00180128U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00180128U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00180128U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00180128U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0018012CU,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0018012CU,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0018012CU,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0018012CU,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0018012CU,
                                           firstAddress + 16U);
            }
            uint32_t value9 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value9)) {
                return Oot3dAotMemoryFault(context, 0x0018012CU,
                                           firstAddress + 20U);
            }
            uint32_t value10 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 24U, &value10)) {
                return Oot3dAotMemoryFault(context, 0x0018012CU,
                                           firstAddress + 24U);
            }
            uint32_t value11 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 28U, &value11)) {
                return Oot3dAotMemoryFault(context, 0x0018012CU,
                                           firstAddress + 28U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 32U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0018012CU,
                                           firstAddress + 32U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r9 = value9;
            r10 = value10;
            r11 = value11;
            r13 = r13 + 36U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_FUN_0035b2d0_0035B2D0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    Oot3dAotLazyFlags& flags = state.Flags;
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0035B2D0U:
        goto block_0035B2D0;
    case 0x0035B2F4U:
        goto block_0035B2F4;
    case 0x0035B304U:
        goto block_0035B304;
    case 0x0035B30CU:
        goto block_0035B30C;
    case 0x0035B314U:
        goto block_0035B314;
    case 0x0035B31CU:
        goto block_0035B31C;
    case 0x0035B320U:
        goto block_0035B320;
    case 0x0035B334U:
        goto block_0035B334;
    case 0x0035B344U:
        goto block_0035B344;
    case 0x0035B34CU:
        goto block_0035B34C;
    case 0x0035B36CU:
        goto block_0035B36C;
    case 0x0035B38CU:
        goto block_0035B38C;
    case 0x0035B398U:
        goto block_0035B398;
    case 0x0035B39CU:
        goto block_0035B39C;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0035B2D0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B2D0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B2D0U);
        }
        {
            const uint32_t firstAddress = r13 - 24U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x0035B2D0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x0035B2D0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x0035B2D0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r7)) {
                return Oot3dAotMemoryFault(context, 0x0035B2D0U,
                                           firstAddress + 12U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 16U, r8)) {
                return Oot3dAotMemoryFault(context, 0x0035B2D0U,
                                           firstAddress + 16U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 20U, r14)) {
                return Oot3dAotMemoryFault(context, 0x0035B2D0U,
                                           firstAddress + 20U);
            }
            r13 = r13 - 24U;
        }
        {
            r5 = r0;
        }
        {
            r0 = r1;
        }
        {
            r6 = r2;
        }
        {
            r13 -= 16U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x0035B2E0U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0035B2E0U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x0035B2E0U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x0035B2E0U,
                                           firstAddress + 12U);
            }
        }
        {
            frame.Guest.vfp[18] = frame.Guest.vfp[0];
        }
        {
            frame.Guest.vfp[17] = frame.Guest.vfp[1];
        }
        {
            r1 = ~(0x00000000U);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B2F4U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Gameplay_GetCamera_0036C5BC(frame, context, state, 0x0036C5BCU);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B2F4U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B2F4;
    }
block_0035B2F4:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B2F4U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B2F4U);
        }
        {
            Oot3dAotSetSubtractFlags(flags, r6, 0x00000000U, static_cast<Oot3dAotFlagMask>(0xFU));
        }
        {
            r7 = r0;
        }
        {
            const uint32_t operand = 0x00001000U;
            r4 = r5 + operand;
        }
        if ((flags.N()) == (flags.V())) { goto block_0035B314; }
        goto block_0035B304;
    }
block_0035B304:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B304U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B304U);
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B30CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_set_byte_1b6_00367C48(frame, context, state, 0x00367C48U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B30CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B30C;
    }
block_0035B30C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B30CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B30CU);
        }
        {
            const uint32_t address = 0x0035B314U + 148U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0035B30CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_0035B39C;
    }
block_0035B314:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B314U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B314U);
        }
        {
            r0 = r7;
        }
        if (!(flags.Z())) { goto block_0035B344; }
        goto block_0035B31C;
    }
block_0035B31C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B31CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B31CU);
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B320U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_clear_byte_1b6_00367C54(frame, context, state, 0x00367C54U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B320U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B320;
    }
block_0035B320:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B320U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B320U);
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            r0 = r7;
        }
        {
            const uint32_t address = r4 + 256U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0035B328U, address);
            }
        }
        {
            const uint32_t address = r4 + 260U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x0035B32CU, address);
            }
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B334U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00367c60_00367C60(frame, context, state, 0x00367C60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B334U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B334;
    }
block_0035B334:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B334U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B334U);
        }
        {
            const uint32_t address = r4 + 260U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0035B334U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            const uint32_t address = r7 + 324U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0035B338U, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0035B33CU,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0035B33CU,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0035B33CU,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0035B33CU,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0035B340U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0035B340U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0035B340U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0035B340U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0035B340U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0035B340U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
block_0035B344:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B344U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B344U);
        }
        {
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B34CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_oot3d_clear_byte_1b6_00367C54(frame, context, state, 0x00367C54U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B34CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B34C;
    }
block_0035B34C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B34CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B34CU);
        }
        {
            frame.Guest.vfp[1] = r6;
        }
        {
            const uint32_t address = 0x0035B358U + 84U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0035B350U, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[18];
        }
        {
            const uint32_t operand = 0x00001100U;
            r0 = r5 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0035B360U, 0xEEF80AE0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0035B364U, 0xEEC80A20U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[1], frame.Guest.fpscr));
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B36CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B36CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B36C;
    }
block_0035B36C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B36CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B36CU);
        }
        {
            frame.Guest.vfp[0] = r6;
        }
        {
            frame.Guest.vfp[2] = frame.Guest.vfp[17];
        }
        {
            const uint32_t operand = 0x00001000U;
            r0 = r5 + operand;
        }
        {
            const uint32_t operand = 0x00000104U;
            r0 = r0 + operand;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0035B37CU, 0xEEB80AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[0], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x0035B380U, 0xEEC80A00U};
            Oot3dAotCommitVfp(frame.Guest.vfp[1], frame.Guest.fpscr,
                a32::VfpBinary32Divide(frame.Guest.vfp[16], frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[17];
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B38CU;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_Math_ApproachF_00373500(frame, context, state, 0x00373500U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B38CU) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B38C;
    }
block_0035B38C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B38CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B38CU);
        }
        {
            const uint32_t address = r4 + 256U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0035B38CU, address);
            }
            frame.Guest.vfp[0] = value;
        }
        {
            r0 = r7;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x0035B398U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_FUN_00367c60_00367C60(frame, context, state, 0x00367C60U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x0035B398U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_0035B398;
    }
block_0035B398:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B398U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B398U);
        }
        {
            const uint32_t address = r4 + 260U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0035B398U, address);
            }
            frame.Guest.vfp[0] = value;
        }
        goto block_0035B39C;
    }
block_0035B39C:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0035B39CU, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0035B39CU);
        }
        {
            const uint32_t address = r7 + 324U;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, frame.Guest.vfp[0])) {
                return Oot3dAotMemoryFault(context, 0x0035B39CU, address);
            }
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x0035B3A0U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x0035B3A0U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x0035B3A0U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x0035B3A0U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x0035B3A4U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x0035B3A4U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x0035B3A4U,
                                           firstAddress + 8U);
            }
            uint32_t value7 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value7)) {
                return Oot3dAotMemoryFault(context, 0x0035B3A4U,
                                           firstAddress + 12U);
            }
            uint32_t value8 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 16U, &value8)) {
                return Oot3dAotMemoryFault(context, 0x0035B3A4U,
                                           firstAddress + 16U);
            }
            uint32_t value15 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 20U, &value15)) {
                return Oot3dAotMemoryFault(context, 0x0035B3A4U,
                                           firstAddress + 20U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r7 = value7;
            r8 = value8;
            r13 = r13 + 24U;
            return Oot3dAotReturned(value15);
        }
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Player_SetCsActionWithHaltedActors_0036E980(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r7 = state.R[7];
    uint32_t& r8 = state.R[8];
    uint32_t& r9 = state.R[9];
    uint32_t& r10 = state.R[10];
    uint32_t& r11 = state.R[11];
    uint32_t& r12 = state.R[12];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x0036E980U:
        goto block_0036E980;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_0036E980:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x0036E980U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x0036E980U);
        }
        {
            const uint32_t operand = 0x00002000U;
            r0 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r0 + 0xACU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036E984U, address);
            }
            r0 = value;
        }
        {
            const uint32_t operand = 0x00001000U;
            r3 = r0 + operand;
        }
        {
            const uint32_t updatedAddress = r3 + 0x2BCU;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint8_t>(
                    address, static_cast<uint8_t>(r2))) {
                return Oot3dAotMemoryFault(context, 0x0036E98CU, address);
            }
        }
        {
            const uint32_t updatedAddress = 0x0036E998U + 0x1CU;
            const uint32_t address = updatedAddress;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x0036E990U, address);
            }
            r2 = value;
        }
        {
            const uint32_t updatedAddress = r3 + 0x2C0U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint32_t>(
                    address, static_cast<uint32_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0036E994U, address);
            }
        }
        {
            r1 = 0x00000000U;
        }
        {
            const uint32_t updatedAddress = r2 + r0;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0036E99CU, address);
            }
        }
        {
            const uint32_t operand = 0x00001200U;
            r0 = r0 + operand;
        }
        {
            r1 = 0x00000001U;
        }
        {
            const uint32_t updatedAddress = r0 + 0xE2U;
            const uint32_t address = updatedAddress;
            if (!context.Memory.WriteFast<uint16_t>(
                    address, static_cast<uint16_t>(r1))) {
                return Oot3dAotMemoryFault(context, 0x0036E9A8U, address);
            }
        }
        {
            r0 = r1;
        }
        return Oot3dAotReturned(r14);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_SkelAnime_UpdateNoPlayState_003731E0_003731E0(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r1 = state.R[1];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x003731E0U:
        goto block_003731E0;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_003731E0:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x003731E0U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x003731E0U);
        }
        {
            r1 = 0x00000000U;
        }
        return Oot3dAotBranch(0x0036B4ECU);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

Oot3dWholeAotFlow Execute_Animation_MorphToPlayOnce_00374A58(
    Oot3dWholeAotFrame& frame, Oot3dWholeAotContext& context,
    Oot3dAotArchitecturalState& state,
    uint32_t entryPc) {
    uint32_t& r0 = state.R[0];
    uint32_t& r1 = state.R[1];
    uint32_t& r2 = state.R[2];
    uint32_t& r3 = state.R[3];
    uint32_t& r4 = state.R[4];
    uint32_t& r5 = state.R[5];
    uint32_t& r6 = state.R[6];
    uint32_t& r13 = state.R[13];
    uint32_t& r14 = state.R[14];
    const auto commitState = []() noexcept {
    };
    const auto reloadState = []() noexcept {
    };
    Oot3dAotScopeExit stateCommit(commitState);
    switch (entryPc) {
    case 0x00374A58U:
        goto block_00374A58;
    case 0x00374A78U:
        goto block_00374A78;
    default:
        return {Oot3dWholeAotFlowKind::Unsupported, entryPc, 0U};
    }
block_00374A58:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374A58U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374A58U);
        }
        {
            const uint32_t firstAddress = r13 - 16U;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, r4)) {
                return Oot3dAotMemoryFault(context, 0x00374A58U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, r5)) {
                return Oot3dAotMemoryFault(context, 0x00374A58U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, r6)) {
                return Oot3dAotMemoryFault(context, 0x00374A58U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, r14)) {
                return Oot3dAotMemoryFault(context, 0x00374A58U,
                                           firstAddress + 12U);
            }
            r13 = r13 - 16U;
        }
        {
            r4 = r0;
        }
        {
            r5 = r1;
        }
        {
            r13 -= 16U;
            const uint32_t firstAddress = r13;
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 0U, frame.Guest.vfp[16])) {
                return Oot3dAotMemoryFault(context, 0x00374A64U,
                                           firstAddress + 0U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 4U, frame.Guest.vfp[17])) {
                return Oot3dAotMemoryFault(context, 0x00374A64U,
                                           firstAddress + 4U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 8U, frame.Guest.vfp[18])) {
                return Oot3dAotMemoryFault(context, 0x00374A64U,
                                           firstAddress + 8U);
            }
            if (!context.Memory.WriteFast<uint32_t>(
                    firstAddress + 12U, frame.Guest.vfp[19])) {
                return Oot3dAotMemoryFault(context, 0x00374A64U,
                                           firstAddress + 12U);
            }
        }
        {
            frame.Guest.vfp[18] = frame.Guest.vfp[0];
        }
        {
            const uint32_t address = 0x00374A74U + 52U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374A6CU, address);
            }
            frame.Guest.vfp[16] = value;
        }
        {
            const uint32_t address = 0x00374A78U + 52U;
            uint32_t value = 0;
            if (!context.Memory.ReadFast<uint32_t>(address, &value)) {
                return Oot3dAotMemoryFault(context, 0x00374A70U, address);
            }
            frame.Guest.vfp[17] = value;
        }
        {
            ++context.Stats.DirectCalls;
            r14 = 0x00374A78U;
            commitState();
            const Oot3dWholeAotFlow callFlow = Execute_AnimationResource_GetLastFrameByIndex_0036AE18(frame, context, state, 0x0036AE18U);
            reloadState();
            if (callFlow.Kind != Oot3dWholeAotFlowKind::Returned ||
                callFlow.Pc != 0x00374A78U) {
                stateCommit.Dismiss();
                return callFlow;
            }
        }
        goto block_00374A78;
    }
block_00374A78:
    {
        if (!Oot3dAotEnterBlock(context, frame, state, 0x00374A78U, commitState, reloadState)) {
            return Oot3dAotBlockLimit(context, 0x00374A78U);
        }
        {
            frame.Guest.vfp[0] = r0;
        }
        {
            frame.Guest.vfp[3] = frame.Guest.vfp[18];
        }
        {
            frame.Guest.vfp[1] = frame.Guest.vfp[17];
        }
        {
            r1 = r5;
        }
        {
            r0 = r4;
        }
        {
            r3 = 0x00000000U;
        }
        {
            if ((frame.Guest.fpscr & 0x00379F00U) != 0U) return {Oot3dWholeAotFlowKind::Unsupported, 0x00374A90U, 0xEEB81AC0U};
            Oot3dAotCommitVfp(frame.Guest.vfp[2], frame.Guest.fpscr,
                a32::VfpBinary32FromSigned(frame.Guest.vfp[0], frame.Guest.fpscr));
        }
        {
            frame.Guest.vfp[0] = frame.Guest.vfp[16];
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value0 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value0)) {
                return Oot3dAotMemoryFault(context, 0x00374A98U,
                                           firstAddress + 0U);
            }
            frame.Guest.vfp[16] = value0;
            uint32_t value1 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value1)) {
                return Oot3dAotMemoryFault(context, 0x00374A98U,
                                           firstAddress + 4U);
            }
            frame.Guest.vfp[17] = value1;
            uint32_t value2 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value2)) {
                return Oot3dAotMemoryFault(context, 0x00374A98U,
                                           firstAddress + 8U);
            }
            frame.Guest.vfp[18] = value2;
            uint32_t value3 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value3)) {
                return Oot3dAotMemoryFault(context, 0x00374A98U,
                                           firstAddress + 12U);
            }
            frame.Guest.vfp[19] = value3;
            r13 += 16U;
        }
        {
            r2 = 0x00000002U;
        }
        {
            const uint32_t firstAddress = r13;
            uint32_t value4 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 0U, &value4)) {
                return Oot3dAotMemoryFault(context, 0x00374AA0U,
                                           firstAddress + 0U);
            }
            uint32_t value5 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 4U, &value5)) {
                return Oot3dAotMemoryFault(context, 0x00374AA0U,
                                           firstAddress + 4U);
            }
            uint32_t value6 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 8U, &value6)) {
                return Oot3dAotMemoryFault(context, 0x00374AA0U,
                                           firstAddress + 8U);
            }
            uint32_t value14 = 0;
            if (!context.Memory.ReadFast<uint32_t>(
                    firstAddress + 12U, &value14)) {
                return Oot3dAotMemoryFault(context, 0x00374AA0U,
                                           firstAddress + 12U);
            }
            r4 = value4;
            r5 = value5;
            r6 = value6;
            r14 = value14;
            r13 = r13 + 16U;
        }
        return Oot3dAotBranch(0x0035302CU);
    }
    return {Oot3dWholeAotFlowKind::Unsupported, 0U, 0U};
}

} // namespace Oot3dNativeGame::GeneratedWholeAot
